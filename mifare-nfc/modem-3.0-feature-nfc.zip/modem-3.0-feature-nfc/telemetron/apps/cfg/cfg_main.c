/// \file
/// \brief  КраткоеОписание
/// \author DL <dmitriy@linikov.ru>
///
/// ПодробноеОписание

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <nuttx/config.h>

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <ccan/array_size/array_size.h>
#include <settings/settings.h>
#include <utils/string_utils.h>

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора

#define BASE      ((settings_t*)0)
#define ADDR(a)   ((uint16_t)(uintptr_t)&(a))

////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных

typedef enum type_category_e {
  CATEGORY_PLAIN = 0,
  CATEGORY_ARRAY,
  CATEGORY_STRUCT
} type_category_t;

typedef struct type_info_s type_info_t;
struct type_info_s {
  const char*         name;
  const char*         desc;

  /// \return Количество выведенных символов
  int                 (*print)(const void* value, size_t value_size);

  /// \return Количество обработанных символов строки str
  int                 (*parse)(void* dst, size_t value_size, const char* str);
};

typedef struct param_info_s {
  const char*         name;   ///< Название параметра
  const char*         type;   ///< Тип параметра
  uint16_t            addr;   ///< Смещение параметра относительно начала settings_t
  uint16_t            size;   ///< размер данных в байтах
  const char*         desc;   ///< Описание параметра
  bool                root;   ///< Признак, что это корневой параметр (для команды show)
} param_info_t;

typedef struct command_info_s {
  const char*         name;
  const char*         desc;
  int                 (*exec)(settings_t* settings);
} command_info_t;


static int print_int_value(const void* value, size_t value_size);
static int parse_int_value(void* value, size_t value_size, const char* str);
static int print_uint16_t_value(const void* value, size_t value_size);
static int parse_uint16_t_value(void* value, size_t value_size, const char* str);
static int print_uint16_t_value(const void* value, size_t value_size);
static int parse_uint16_t_value(void* value, size_t value_size, const char* str);
static int print_uint32_t_value(const void* value, size_t value_size);
static int parse_uint32_t_value(void* value, size_t value_size, const char* str);
static int print_string_value(const void* value, size_t value_size);
static int parse_string_value(void* value, size_t value_size, const char* str);
static int print_aux_interface_t_value(const void* value, size_t value_size);
static int parse_aux_interface_t_value(void* value, size_t value_size, const char* str);
static int print_aux_params_t_value(const void* value, size_t value_size);
// static int parse_aux_params_t_value(void* value, size_t value_size, const char* str);
static int print_aux_type_t_value(const void* value, size_t value_size);
static int parse_aux_type_t_value(void* value, size_t value_size, const char* str);
static int print_ddcmp_params_t_value(const void* value, size_t value_size);
static int parse_ddcmp_params_t_value(void* value, size_t value_size, const char* str);
static int print_mdbexe_bus_t_value(const void* value, size_t value_size);
static int parse_mdbexe_bus_t_value(void* value, size_t value_size, const char* str);
static int print_mdbexe_params_t_value(const void* value, size_t value_size);
// static int parse_mdbexe_params_t_value(void* value, size_t value_size, const char* str);
static int print_onoff_t_value(const void* value, size_t value_size);
static int parse_onoff_t_value(void* value, size_t value_size, const char* str);
static int print_printer_params_t_value(const void* value, size_t value_size);
static int parse_printer_params_t_value(void* value, size_t value_size, const char* str);
static int print_server_params_t_value(const void* value, size_t value_size);
// static int parse_server_params_t_value(void* value, size_t value_size, const char* str);
static int print_url_t_value(const void* value, size_t value_size);
static int parse_url_t_value(void* value, size_t value_size, const char* str);


static int cmd_show(settings_t* settings);
static int cmd_defset(settings_t* settings);
static int cmd_defset_fw(settings_t* settings);
static int cmd_defset_apn(settings_t* settings);

static const type_info_t* find_type(const char* name);
static const param_info_t* find_param(const char* name);
static const command_info_t* find_command(const char* name);
////////////////////////////////////////////////////////////////////////////
//  Константы



static const type_info_t   TYPES[] = {
  {
    .name = "",
    .desc = "",
    .print = NULL,
    .parse = NULL,
  },

  {
    .name = "int",
    .desc = "Any integer",
    .print = print_int_value,
    .parse = parse_int_value,
  },

  {
    .name = "uint16_t",
    .desc = "Any unsigned 16-bit integer",
    .print = print_uint16_t_value,
    .parse = parse_uint16_t_value,
  },

  {
    .name = "uint32_t",
    .desc = "Any unsigned 32-bit integer",
    .print = print_uint32_t_value,
    .parse = parse_uint32_t_value,
  },

  {
    .name = "string",
    .desc = "Text string",
    .print = print_string_value,
    .parse = parse_string_value,
  },

  {
    .name = "aux_interface_t",
    .desc = "One of: off, ttl, com, rs485, auto",
    .print = print_aux_interface_t_value,
    .parse = parse_aux_interface_t_value,
  },

  {
    .name = "aux_params_t",
    .desc = "Readonly",
    .print = print_aux_params_t_value,
    .parse = NULL, //parse_aux_params_t_value,
  },

  {
    .name = "aux_type_t",
    .desc = "One of: off, auto, dex, ddcmp, gerhardt, kkm, console",
    .print = print_aux_type_t_value,
    .parse = parse_aux_type_t_value,
  },

  {
    .name = "ddcmp_params_t",
    .desc = "comma-separated: mode(0-2),extended(0-1),auditmode(0-2),fixbaud(0-5),saecofix(0-4)",
    .print = print_ddcmp_params_t_value,
    .parse = parse_ddcmp_params_t_value,
  },

  {
    .name = "mdbexe_bus_t",
    .desc = "One of: mdb, exe",
    .print = print_mdbexe_bus_t_value,
    .parse = parse_mdbexe_bus_t_value,
  },

  {
    .name = "mdbexe_params_t",
    .desc = "Readonly",
    .print = print_mdbexe_params_t_value,
    .parse = NULL, //parse_mdbexe_params_t_value,
  },

  {
    .name = "onoff_t",
    .desc = "One of: on, off",
    .print = print_onoff_t_value,
    .parse = parse_onoff_t_value,
  },

  {
    .name = "printer_params_t",
    .desc = "comma-separated: tcp_port(0-65535),psw(any number)",
    .print = print_printer_params_t_value,
    .parse = parse_printer_params_t_value,
  },

  {
    .name = "server_params_t",
    .desc = "Readonly",
    .print = print_server_params_t_value,
    .parse = NULL, //parse_server_params_t_value,
  },

  {
    .name = "url_t",
    .desc = "Web url in following format: [http://]address.com:80/resource/path",
    .print = print_url_t_value,
    .parse = parse_url_t_value,
  },

};

static const param_info_t   PARAMETERS[] = {
  {
    .name = "server",
    .type = "server_params_t",
    .addr = ADDR(BASE->fw_params.server),
    .size = sizeof(BASE->fw_params.server),
    .desc = "Server settings",
    .root = true,
  },

  {
    .name = "server.ping_interval",
    .type = "uint16_t",
    .addr = ADDR(BASE->fw_params.server),
    .size = sizeof(BASE->fw_params.server),
    .desc = "Time between keep-alive packets to server",
  },

  {
    .name = "server.url",
    .type = "url_t",
    .addr = ADDR(BASE->fw_params.server.url),
    .size = sizeof(BASE->fw_params.server.url),
    .desc = "LK Server endpoint",
  },

  {
    .name = "mdbexe",
    .type = "mdbexe_params_t",
    .addr = ADDR(BASE->fw_params.mdbexe),
    .size = sizeof(BASE->fw_params.mdbexe),
    .desc = "All MDB/EXE bus settings",
    .root = true,
  },

  {
    .name = "mdbexe.bus",
    .type = "mdbexe_bus_t",
    .addr = ADDR(BASE->fw_params.mdbexe.bus),
    .size = sizeof(BASE->fw_params.mdbexe.bus),
    .desc = "MDB/EXE bus type",
  },

  {
    .name = "mdbexe.MDB_EXE_log",
    .type = "onoff_t",
    .addr = ADDR(BASE->fw_params.mdbexe.MDB_EXE_log),
    .size = sizeof(BASE->fw_params.mdbexe.MDB_EXE_log),
    .desc = "Enable MDB/EXE bus logs",
  },

  {
    .name = "mdbexe.bus_autodetect",
    .type = "onoff_t",
    .addr = ADDR(BASE->fw_params.mdbexe.bus_autodetect),
    .size = sizeof(BASE->fw_params.mdbexe.bus_autodetect),
    .desc = "Enable MDB/EXE bus autodetect",
  },

  {
    .name = "mdbexe.error_timeout_ms",
    .type = "uint32_t",
    .addr = ADDR(BASE->fw_params.mdbexe.error_timeout_ms),
    .size = sizeof(BASE->fw_params.mdbexe.error_timeout_ms),
    .desc = "Delay of error condition in ms",
  },

  {
    .name = "aux1",
    .type = "aux_params_t",
    .addr = ADDR(BASE->fw_params.aux[0]),
    .size = sizeof(BASE->fw_params.aux[0]),
    .desc = "All settings of AUX1 port",
    .root = true,
  },

  {
    .name = "aux2",
    .type = "aux_params_t",
    .addr = ADDR(BASE->fw_params.aux[1]),
    .size = sizeof(BASE->fw_params.aux[1]),
    .desc = "All settings of AUX2 port",
    .root = true,
  },

  {
    .name = "aux3",
    .type = "aux_params_t",
    .addr = ADDR(BASE->fw_params.aux[2]),
    .size = sizeof(BASE->fw_params.aux[2]),
    .desc = "All settings of AUX3 port",
    .root = true,
  },

  {
    .name = "aux1.type",
    .type = "aux_type_t",
    .addr = ADDR(BASE->fw_params.aux[0].type),
    .size = sizeof(BASE->fw_params.aux[0].type),
    .desc = "Type of peripheral connected to AUX1 port",
  },

  {
    .name = "aux2.type",
    .type = "aux_type_t",
    .addr = ADDR(BASE->fw_params.aux[1].type),
    .size = sizeof(BASE->fw_params.aux[1].type),
    .desc = "Type of peripheral connected to AUX2 port",
  },

  {
    .name = "aux3.type",
    .type = "aux_type_t",
    .addr = ADDR(BASE->fw_params.aux[2].type),
    .size = sizeof(BASE->fw_params.aux[2].type),
    .desc = "Type of peripheral connected to AUX3 port",
  },

  {
    .name = "aux1.interface",
    .type = "aux_interface_t",
    .addr = ADDR(BASE->fw_params.aux[0].interface),
    .size = sizeof(BASE->fw_params.aux[0].interface),
    .desc = "Physical layer type of AUX1 port",
  },

  {
    .name = "aux2.interface",
    .type = "aux_interface_t",
    .addr = ADDR(BASE->fw_params.aux[1].interface),
    .size = sizeof(BASE->fw_params.aux[1].interface),
    .desc = "Physical layer type of AUX2 port",
  },

  {
    .name = "aux3.interface",
    .type = "aux_interface_t",
    .addr = ADDR(BASE->fw_params.aux[2].interface),
    .size = sizeof(BASE->fw_params.aux[2].interface),
    .desc = "Physical layer type of AUX3 port",
  },

  {
    .name = "aux1.ddcmp_params",
    .type = "ddcmp_params_t",
    .addr = ADDR(BASE->fw_params.aux[0].ddcmp_params),
    .size = sizeof(BASE->fw_params.aux[0].ddcmp_params),
    .desc = "Audit driver extra settings of AUX1 port",
  },

  {
    .name = "aux2.ddcmp_params",
    .type = "ddcmp_params_t",
    .addr = ADDR(BASE->fw_params.aux[1].ddcmp_params),
    .size = sizeof(BASE->fw_params.aux[1].ddcmp_params),
    .desc = "Audit driver extra settings of AUX2 port",
  },

  {
    .name = "aux3.ddcmp_params",
    .type = "ddcmp_params_t",
    .addr = ADDR(BASE->fw_params.aux[2].ddcmp_params),
    .size = sizeof(BASE->fw_params.aux[2].ddcmp_params),
    .desc = "Audit driver extra settings of AUX3 port",
  },

  {
    .name = "evadts_search",
    .type = "onoff_t",
    .addr = ADDR(BASE->fw_params.evadts_search),
    .size = sizeof(BASE->fw_params.evadts_search),
    .desc = "Allow autodetect of audit driver",
    .root = true,
  },

  {
    .name = "request_evadts_after_mdb_change",
    .type = "onoff_t",
    .addr = ADDR(BASE->fw_params.request_evadts_after_mdb_change),
    .size = sizeof(BASE->fw_params.request_evadts_after_mdb_change),
    .desc = "Automatically request audit whenever MDB/EXE bus changes",
    .root = true,
  },

  {
    .name = "printer",
    .type = "printer_params_t",
    .addr = ADDR(BASE->fw_params.printer),
    .size = sizeof(BASE->fw_params.printer),
    .desc = "All extra printer params (which are not in aux params)",
    .root = true,
  },

  {
    .name = "printer.printer_tcp_port",
    .type = "uint16_t",
    .addr = ADDR(BASE->fw_params.printer.printer_tcp_port),
    .size = sizeof(BASE->fw_params.printer.printer_tcp_port),
    .desc = "TCP port for printers, working over IP connection",
  },

  {
    .name = "printer.printer_psw",
    .type = "int",
    .addr = ADDR(BASE->fw_params.printer.printer_psw),
    .size = sizeof(BASE->fw_params.printer.printer_psw),
    .desc = "Password for accessing printer",
  },

  {
    .name = "beep",
    .type = "onoff_t",
    .addr = ADDR(BASE->fw_params.beep),
    .size = sizeof(BASE->fw_params.beep),
    .desc = "Enable sound",
    .root = true,
  },

  {
    .name = "sms",
    .type = "onoff_t",
    .addr = ADDR(BASE->fw_params.sms),
    .size = sizeof(BASE->fw_params.sms),
    .desc = "Enable SMS messaging",
    .root = true,
  },

  {
    .name = "door_time_s",
    .type = "uint16_t",
    .addr = ADDR(BASE->fw_params.door_time_s),
    .size = sizeof(BASE->fw_params.door_time_s),
    .desc = "Powerup checks delay in seconds",
    .root = true,
  },

  {
    .name = "APN",
    .type = "string",
    .addr = ADDR(BASE->apn_params.APN),
    .size = sizeof(BASE->apn_params.APN),
    .desc = "Internet access point name",
    .root = true,
  },

  {
    .name = "user_apn",
    .type = "string",
    .addr = ADDR(BASE->apn_params.user_apn),
    .size = sizeof(BASE->apn_params.user_apn),
    .desc = "Internet access point user name",
    .root = true,
  },

  {
    .name = "psw_apn",
    .type = "string",
    .addr = ADDR(BASE->apn_params.psw_apn),
    .size = sizeof(BASE->apn_params.psw_apn),
    .desc = "Internet access point password",
    .root = true,
  },
};

static const command_info_t COMMANDS[] = {
  {
    .name = "show",
    .desc = "Prints entire config to console",
    .exec = cmd_show,
  },

  {
    .name = "defset",
    .desc = "Clears fw and apn settings to default values",
    .exec = cmd_defset,
  },

  {
    .name = "defset-fw",
    .desc = "Clears fw settings to default values",
    .exec = cmd_defset_fw,
  },

  {
    .name = "defset-apn",
    .desc = "Clears apn settings to default values",
    .exec = cmd_defset_apn,
  },

};

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Приватные функции

static int print_int_value(const void* value, size_t value_size)
{
  const int* v = (const int*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));

  return printf("%d", *v);
}

static int parse_int_value(void* value, size_t value_size, const char* str)
{
  int* v = (int*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));
  char* end;
  long data = strtol(str, &end, 0);
  if (end == str) {
    return -EINVAL;
  }
  *v = (int)data;
  return end-str;
}

static int print_uint16_t_value(const void* value, size_t value_size)
{
  const uint16_t* v = (const uint16_t*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));
  return printf("%u", (unsigned)*v);
}

static int parse_uint16_t_value(void* value, size_t value_size, const char* str)
{
  uint16_t* v = (uint16_t*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));
  char* end;
  unsigned long data = strtoul(str, &end, 0);
  if (end == str) {
    return -EINVAL;
  }
  if (data > 0xFFFF) {
    return -ERANGE;
  }
  *v = (uint16_t)data;

  return end-str;
}

static int print_uint32_t_value(const void* value, size_t value_size)
{
  const uint32_t* v = (const uint32_t*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));

  return printf("%" PRIu32, *v);
}

static int parse_uint32_t_value(void* value, size_t value_size, const char* str)
{
  uint32_t* v = (uint32_t*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));

  char* end;
  unsigned long data = strtoul(str, &end, 0);
  if (end == str) {
    return -EINVAL;
  }
  *v = (uint32_t)data;

  return end-str;
}

static int print_string_value(const void* value, size_t value_size)
{
  const char* v = (const char*)value;
  DEBUGASSERT(v);

  return printf("\"%s\"", v);
}

static int parse_string_value(void* value, size_t value_size, const char* str)
{
  char* v = (char*)value;
  DEBUGASSERT(v && str);
  return snprintf(v, value_size, "%s", str);
}

static int print_ddcmp_params_t_value(const void* value, size_t value_size)
{
  const ddcmp_params_t* v = (const ddcmp_params_t*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));

  return printf(
    "{ ddcmp_mode:%s, ddcmp_extended:%s, ddcmp_auditmode:%s, "
    "ddcmp_fix_baud:%s, ddcmp_saeco_fix:%s }",
    ddcmp_mode_to_string(v->ddcmp_mode),
    ddcmp_extspeed_to_string(v->ddcmp_extended),
    ddcmp_auditmode_to_string(v->ddcmp_auditmode),
    ddcmp_fix_baud_to_string(v->ddcmp_fix_baud),
    ddcmp_saeco_fix_to_string(v->ddcmp_saeco_fix)
  );
}

static const char* extract_next_param(char* buffer, size_t bufsize, const char** str)
{
  DEBUGASSERT(buffer && bufsize && str && *str);
  *buffer = '\0';

  const char* wordstart = *str;
  const char* wordend   = strchr(wordstart, ',');
  if (!wordend) {
    wordend = wordstart + strlen(wordstart);
  }

  // в исходной строке пропускаем разделитель (если wordend - не конец строки)
  *str = *wordend ? wordend+1 : wordend;

  // копируем извлечённый параметр
  size_t length = wordend - wordstart;
  if (length >= bufsize) {
    // При любых ошибках возвращаем пустую строку
    return buffer;
  }
  memcpy(buffer, wordstart, length);
  buffer[length] = '\0';
  return buffer;
}

static int parse_ddcmp_params_t_value(void* value, size_t value_size, const char* str)
{
  // Для параметров ddcmp самый длинный = "off-nak-timeout" = 16 символов
  // параметры должны быть указаны через запятую, т.е. всего 4 запятых
  DEBUGASSERT(value);
  ddcmp_params_t* v = (ddcmp_params_t*)value;

  char buffer[16];
  const char* ptr = str;

  // параметр 1 - ddcmp_mode
  extract_next_param(buffer, sizeof(buffer), &ptr);
  if (ddcmp_mode_parse(buffer, &v->ddcmp_mode) < 0) {
    v->ddcmp_mode = EVADTS_DDCMP_AUTO;
  }

  // параметр 2 - ddcmp_extended
  extract_next_param(buffer, sizeof(buffer), &ptr);
  if (ddcmp_extspeed_parse(buffer, &v->ddcmp_extended) < 0) {
    v->ddcmp_extended = EVADTS_DDCMP_SPEED_UP_OFF;
  }

  // параметр 3 - ddcmp_auditmode
  extract_next_param(buffer, sizeof(buffer), &ptr);
  if (ddcmp_auditmode_parse(buffer, &v->ddcmp_auditmode) < 0) {
    v->ddcmp_auditmode = EVADTS_DDCMP_AUDIT;
  }

  // параметр 4 - ddcmp_fix_baud
  extract_next_param(buffer, sizeof(buffer), &ptr);
  if (ddcmp_fix_baud_parse(buffer, &v->ddcmp_fix_baud) < 0) {
    v->ddcmp_fix_baud = EVADTS_DDCMP_FIX_9600;
  }

  // параметр 5 - ddcmp_saeco_fix
  extract_next_param(buffer, sizeof(buffer), &ptr);
  if (ddcmp_saeco_fix_parse(buffer, &v->ddcmp_saeco_fix) < 0) {
    v->ddcmp_saeco_fix = EVADTS_DDCMP_FIX_SAECO_OFF;
  }

  return ptr - str;
}


static int print_aux_params_t_value(const void* value, size_t value_size)
{
  const aux_params_t* v = (const aux_params_t*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));

  int ret;
  int length = 0;

  ret = printf(
    "{ type:%s, interface:%s, idlestate:%s, ddcmp_params:",
    aux_type_to_string(v->type),
    aux_interface_to_string(v->interface),
    aux_idlestate_to_string(v->idlestate)
  );
  if (ret < 0) {
    return ret;
  }
  length += ret;

  ret = print_ddcmp_params_t_value(&v->ddcmp_params, sizeof(v->ddcmp_params));
  if (ret < 0) {
    return ret;
  }
  length += ret;

  ret = printf(" }");
  if (ret < 0) {
    return ret;
  }
  length += ret;
  return length;
}

// static int parse_aux_params_t_value(void* value, size_t value_size, const char* str)
// {
//   DEBUGASSERT(value);
//   aux_params_t* v = (aux_params_t*)value;

//   return 0;
// }

static int print_aux_interface_t_value(const void* value, size_t value_size)
{
  const aux_interface_t* v = (const aux_interface_t*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));

  return printf("%s", aux_interface_to_string(*v));
}

static int parse_aux_interface_t_value(void* value, size_t value_size, const char* str)
{
  aux_interface_t* v = (aux_interface_t*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));

  return aux_interface_parse(str, v);
}

static int print_aux_type_t_value(const void* value, size_t value_size)
{
  const aux_type_t* v = (const aux_type_t*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));

  return printf("%s", aux_type_to_string(*v));
}

static int parse_aux_type_t_value(void* value, size_t value_size, const char* str)
{
  aux_type_t* v = (aux_type_t*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));

  return aux_type_parse(str, v);
}

static int print_mdbexe_bus_t_value(const void* value, size_t value_size)
{
  const mdbexe_bus_t* v = (const mdbexe_bus_t*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));

  return printf("%s", mdbexe_bus_to_string(*v));
}

static int parse_mdbexe_bus_t_value(void* value, size_t value_size, const char* str)
{
  mdbexe_bus_t* v = (mdbexe_bus_t*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));

  return mdbexe_bus_parse(str, v);
}

static int print_mdbexe_params_t_value(const void* value, size_t value_size)
{
  const mdbexe_params_t* v = (const mdbexe_params_t*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));

  return printf(
    "{ bus:%s, MDB_EXE_log:%s, bus_autodetect:%s, error_timeout_ms:%" PRIu32 " }",
    mdbexe_bus_to_string(v->bus),
    onoff_to_string(v->MDB_EXE_log),
    onoff_to_string(v->bus_autodetect),
    v->error_timeout_ms
  );
}

// static int parse_mdbexe_params_t_value(void* value, size_t value_size, const char* str)
// {
//   mdbexe_params_t* v = (mdbexe_params_t*)value;
//   DEBUGASSERT(v && value_size == sizeof(*v));

//   return 0;
// }

static int print_onoff_t_value(const void* value, size_t value_size)
{
  const onoff_t* v = (const onoff_t*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));

  return printf("%s", onoff_to_string(*v));
}

static int parse_onoff_t_value(void* value, size_t value_size, const char* str)
{
  onoff_t* v = (onoff_t*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));

  return onoff_parse(str, v);
}

static int print_printer_params_t_value(const void* value, size_t value_size)
{
  const printer_params_t* v = (const printer_params_t*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));

  return printf(
    "{ printer_tcp_port:%u, printer_psw:%d }",
    v->printer_tcp_port,
    v->printer_psw
  );
}

static int parse_printer_params_t_value(void* value, size_t value_size, const char* str)
{
  char              buffer[20];
  const char*       ptr = str;
  printer_params_t* v = (printer_params_t*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));

  // параметр1 - printer_tcp_port
  extract_next_param(buffer, sizeof(buffer), &ptr);
  if (parse_uint16_t_value(&v->printer_tcp_port, sizeof(v->printer_tcp_port), buffer) < 0) {
    v->printer_tcp_port = 0;
  }

  // параметр2 - printer_psw
  extract_next_param(buffer, sizeof(buffer), &ptr);
  if (parse_int_value(&v->printer_psw, sizeof(v->printer_psw), buffer) < 0) {
    v->printer_psw = 0;
  }

  return ptr - str;
}

static int print_server_params_t_value(const void* value, size_t value_size)
{
  const server_params_t* v = (const server_params_t*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));
  int length = 0;
  int ret;

  ret = printf("{ ping_interval_s:%u, url:", v->ping_interval_s);
  if (ret < 0) {
    return ret;
  }
  length += ret;

  ret = print_url_t_value(&v->url, sizeof(v->url));
  if (ret < 0) {
    return ret;
  }
  length += ret;

  ret = printf(" }");
  if (ret < 0) {
    return ret;
  }
  length += ret;
  return length;
}

// static int parse_server_params_t_value(void* value, size_t value_size, const char* str)
// {
//   server_params_t* v = (server_params_t*)value;
//   DEBUGASSERT(v && value_size == sizeof(*v));

//   return 0;
// }

static int print_url_t_value(const void* value, size_t value_size)
{
  const url_t* v = (const url_t*)value;
  DEBUGASSERT(v && value_size == sizeof(*v));

  return printf("%s:%u%s", v->address, v->port, v->directory);
}

static int parse_url_t_value(void* value, size_t value_size, const char* str)
{
  url_t*      v = (url_t*)value;
  const char* addr_start = str;
  DEBUGASSERT(v && value_size == sizeof(*v));
  if (StartsWith(addr_start, "http://")) {
    addr_start += strlen("http://");
  } else if (StartsWith(addr_start, "https://")) {
    addr_start += strlen("https://");
  }

  unsigned long   port_n      = 0;
  const char*     port_start  = strchr(addr_start, ':');
  const char*     path_start  = strchr(addr_start, '/');

  if (!path_start) {
    // если путь не задан, то указываем на '\0' в конце строки
    // для удобства дальнейшей обработки
    path_start = addr_start + strlen(addr_start);
  }

  if (path_start && port_start && path_start < port_start) {
    // порт указывается до первого символа пути ресурса.
    // Если нашли двоеточие после слеша, то это не порт, а что-то другое.
    port_start = NULL;
  }

  if (port_start) {
    char* port_end;
    port_n = strtoul(port_start, &port_end, 0);
    if (port_end == port_start || port_n > 0xFFFF) {
      return -EINVAL;
    }
    if (*port_end != '\0' && *port_end != '/') {
      // после номера порта должен начинаться путь ресурса
      return -EINVAL;
    }
  } else {
    // Порт не задан, стандартный порт = 80
    port_n = 80;
  }

  // сохраняем значения в результирующую переменную.
  const char* addr_end = port_start ? port_start : path_start;
  if (addr_end - addr_start >= sizeof(v->address)) {
    return -ENOBUFS;
  }
  memcpy(v->address, addr_start, addr_end - addr_start);
  v->address[addr_end - addr_start] = '\0';

  const char* path_end = path_start + strlen(path_start);
  if (path_end - path_start >= sizeof(v->directory)) {
    return -ENOBUFS;
  }
  memcpy(v->directory, path_start, path_end - path_start);
  v->directory[path_end - path_start] = '\0';

  v->port = (uint16_t)port_n;
  v->unused = 0;

  return path_end - str;
}

static int cmd_show(settings_t* settings)
{
  int ret;
  int length = 0;
  ret = printf("config: {\n");
  if (ret < 0) {
    return -errno;
  }
  length += ret;

  for (size_t i=0; i < ARRAY_SIZE(PARAMETERS); ++i) {
    const param_info_t* param = &PARAMETERS[i];
    const type_info_t*  type  = find_type(param->type);
    const void*         data  = (const void*)((uintptr_t)settings + param->addr);

    if (!param->root) {
      continue;
    }

    ret = printf("  %s: ", param->name);
    if (ret < 0) {
      return -errno;
    }
    length += ret;

    if (!type || !type->print) {
      ret = printf("\"printer not impletented\"\n");
      if (ret < 0) {
        return -errno;
      }
      length += ret;
      continue;
    }


    ret = type->print(data, param->size);
    if (ret < 0) {
      ret = printf("\"print fail with err=%d (%s)\"\n", ret, strerror(-ret));
      if (ret < 0) {
        return -errno;
      }
      length += ret;
      continue;
    }

    length += ret;

    ret = printf("\n");
    if (ret < 0) {
      return -errno;
    }
    length += ret;
  } // for

  ret = printf("}\n");
  if (ret < 0) {
    return -errno;
  }
  length += ret;
  return length;
}

static int cmd_defset(settings_t* settings)
{
  return settings_default_all(settings);
}

static int cmd_defset_fw(settings_t* settings)
{
  return settings_default_fw_params(settings);
}

static int cmd_defset_apn(settings_t* settings)
{
  return settings_default_apn_params(settings);
}



static const type_info_t* find_type(const char* name)
{
  for (size_t i=0; i < ARRAY_SIZE(TYPES); ++i) {
    if (strcmp(TYPES[i].name, name) == 0) {
      return &TYPES[i];
    }
  }
  return NULL;
}

static const param_info_t* find_param(const char* name)
{
  for (size_t i=0; i < ARRAY_SIZE(PARAMETERS); ++i) {
    if (strcmp(PARAMETERS[i].name, name) == 0) {
      return &PARAMETERS[i];
    }
  }
  return NULL;
}

static const command_info_t* find_command(const char* name)
{
  for (size_t i=0; i < ARRAY_SIZE(COMMANDS); ++i) {
    if (strcmp(COMMANDS[i].name, name) == 0) {
      return &COMMANDS[i];
    }
  }
  return NULL;
}


static void print_command_names(void)
{
  printf("Supported commands:\n");

  for (size_t i=0; i < ARRAY_SIZE(COMMANDS); ++i) {
    const command_info_t* command = &COMMANDS[i];
    printf("  %-32s - %s\n", command->name, command->desc);
  }
}

static void print_param_names(void)
{
  printf("List of supported param_names:\n");
  for (size_t i=0; i < ARRAY_SIZE(PARAMETERS); ++i) {
    const param_info_t* param = &PARAMETERS[i];
    const type_info_t*  type  = find_type(param->type);

    printf(
      "  %-32s - %s, param_value: %s\n",
      param->name,
      param->desc,
      type ? type->desc : "Unknown"
    );
  }
}

static int print_usage(int ret)
{
  printf(
    "Telemetron config utility.\n"
    "Usage:\n"
    "  cfg [list of commands, set-requests and get-requests]\n"
    "\n"
  );
  print_command_names();
  printf(
    "\n"
    "Set requests are strings like this: `param_name=param_value`\n"
    "Get requests are just `param_name`\n"
    "\n"
  );

  print_param_names();

  printf(
    "\n"
    "Examples:\n"
    "  cfg show                         - prints whole config\n"
    "  cfg beep                         - prints current sound settings\n"
    "  cfg aux1.interface=rs485         - sets AUX1 interface to RS485\n"
    "  cfg beep=on show                 - Enables sound and prints settings afterwards\n"
    "\n"
  );

  return ret;
}

static int perr(const char* what, int ret)
{
  fprintf(stderr, "%s error: %d (%s)\n", what, ret, strerror(-ret));
  return ret;
}

static int process_get(settings_t* settings, const param_info_t* param)
{
  const type_info_t* type = find_type(param->type);
  if (!type || !type->print) {
    return -EINVAL;
  }

  const void* data = (const void*)((uintptr_t)settings + param->addr);

  int ret;
  int length = 0;

  ret = printf("%s:", param->name);
  if (ret < 0) {
    return -errno;
  }
  length += ret;

  ret = type->print(data, param->size);
  if (ret < 0) {
    return ret;
  }
  length += ret;

  ret = printf("\n");
  if (ret < 0) {
    return -errno;
  }
  length += ret;
  return length;
}

static int process_set(settings_t* settings, const param_info_t* param, const char* value)
{
  const type_info_t* type = find_type(param->type);
  if (!type || !type->parse) {
    return -EINVAL;
  }

  void* data  = (void*)((uintptr_t)settings + param->addr);
  int   ret   = type->parse(data, param->size, value);
  if (ret < 0) {
    return ret;
  }

  settings->fw_params_version++;
  settings->apn_params_version++;
  return 0;
}

static int process_cmd(settings_t* settings, const char* cmd)
{
  const command_info_t* command = find_command(cmd);
  if (!command || !command->exec) {
    return -EINVAL;
  }
  return command->exec(settings);
}

static int process_arg(settings_t* settings, char* arg)
{
  const param_info_t* param;
  char*               param_value_start = strchr(arg, '=');

  // Обработка записи параметра
  if (param_value_start) {
    *param_value_start++ = '\0';
    param = find_param(arg);
    if (!param) {
      return -ENOENT;
    }
    return process_set(settings, param, param_value_start);
  }


  // Обработка чтения параметра
  param = find_param(arg);
  if (param) {
    return process_get(settings, param);
  }

  // Последний вариант - простая команда.
  return process_cmd(settings, arg);
}

////////////////////////////////////////////////////////////////////////////
//  cfg_main

#ifdef CONFIG_BUILD_KERNEL
int main(int argc, FAR char *argv[])
#else
int cfg_main(int argc, char *argv[])
#endif
{
  if (argc == 1) {
    return print_usage(0);
  }

  int         ret;
  settings_t  settings;

  ret = settings_create(&settings);
  if (ret < 0) {
    return perr("settings_create", ret);
  }

  ret = settings_load_all(&settings);
  if (ret < 0) {
    return perr("settings_load_all", ret);
  }


  for (int i=1; i < argc; ++i) {
    // Последовательная обработка всех переданных параметров
    ret = process_arg(&settings, argv[i]);
    if (ret < 0) {
      perr(argv[i], ret);
    }
  }

  if (settings.fw_params_version != settings.fw_params_vers_on_disk
  ||  settings.apn_params_version != settings.apn_params_vers_on_disk
  ) {
    ret = settings_save_all(&settings);
    if (ret < 0) {
      return perr("settings_save", ret);
    }
  }

  return 0;
}
