/// \file
/// \brief  Визуализация нажатия кнопок для тестирования платы.
/// \author DL <dmitriy@linikov.rsu>

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <nuttx/config.h>

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <poll.h>
#include <nuttx/input/buttons.h>

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Приватные функции


////////////////////////////////////////////////////////////////////////////
//  btn_main

#ifdef CONFIG_BUILD_KERNEL
int main(int argc, FAR char *argv[])
#else
int btn_main(int argc, char *argv[])
#endif
{
  int               fd;
  ssize_t           ret;
  const char*       dev;
  btn_buttonset_t   supported;
  btn_buttonset_t   buttons;
  int               nbuttons;

  if (argc != 2) {
    fprintf(stderr, "ERROR: No device specified.\n");
    return -EINVAL;
  }

  dev = argv[1];

  fd = open(dev, O_RDONLY | O_BINARY);
  if (fd < 0) {
    fprintf(stderr, "ERROR: Can't open '%s', err=%d (%s)\n", fd, strerror(-fd));
    return fd;
  }

  ret = ioctl(fd, BTNIOC_SUPPORTED, (unsigned long)&supported);
  if (ret < 0) {
    fprintf(stderr, "ERROR: Can't read supported buttons, err=%d (%s)\n", ret, strerror(-ret));
    goto cleanup;
  }

  printf("%s: supported buttons:", dev);
  for (int i=0; i < sizeof(supported)*8; ++i) {
    if (((supported >> i) & 1) != 0) {
      printf(" B%02d", i);
      nbuttons = i+1;
    }
  }

  if (nbuttons < 0) {
    printf(" NONE\n");
  } else {
    printf("\n");
  }


  do {
    ret = read(fd, &buttons, sizeof(buttons));
    if (ret < 0) {
      fprintf(stderr, "ERROR: Can't read '%s', err=%d (%s)\n", ret, strerror(-ret));
      break;
    }

    printf("%s:", dev);
    for (size_t i = 0; i < nbuttons; ++i) {
      if (((buttons >> i) & 1) != 0) {
        printf(" B%02d", i);
      } else {
        printf("    ");
      }
    }
    printf("\n");

    // Ожидание событий
    struct pollfd   pfd = {
      .fd       = fd,
      .events   = POLLIN,
      .revents  = 0,
    };

    ret = poll(&pfd, 1, -1);
    if (ret < 0) {
      ret = -errno;
      if (ret == -EINTR) {
        fprintf(stderr, "\n'btn %s' got signal. Terminating.\n", dev);
      } else {
        fprintf(stderr, "\nERROR: can't poll, err=%d (%s)\n", ret, strerror(-ret));
      }
      break;
    }
    if (ret != 1 || !(pfd.revents & POLLIN)) {
      continue;
    }
  } while (ret >= 0);

  printf("\n'btn %s' completed\n", dev);

cleanup:
  close(fd);
  return ret;
}
