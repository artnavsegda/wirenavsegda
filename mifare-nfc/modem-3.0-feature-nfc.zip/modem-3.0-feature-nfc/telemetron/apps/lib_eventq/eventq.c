/// \file
/// \brief  Очередь сообщений для проекта Modem-3.0
/// \author DL <dmitriy@linikov.ru>

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <eventq/eventq.h>

#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>

#include <utils/dbg.h>
#include <utils/posix_iohelper.h>

/// \todo NONPOSIX: Для mkfifo2 необходимо подключить nuttx/drivers/drivers.h
#include <nuttx/drivers/drivers.h>


////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Приватные функции

/// \brief Открывает существующий файл.
static int eventq_open_existing(eventq_t* q, int flags)
{
  int ret;
  q->fd = -1;

  ret = open(q->path.value, flags);
  if (ret < 0) {
    return -errno;
  }
  q->fd = ret;

  ret = TtySetNonblock(q->fd);
  if (ret < 0) {
    log_debug("EQ: Can't make '%s' nonblock, err=%d (%s)",
      q->path.value, -ret, strerror(-ret)
    );
    close(q->fd);
    q->fd = -1;
    return ret;
  }
  log_trace("EQ: Opened FIFO '%s' as fd=%d.", q->path.value, q->fd);
  return OK;
}

/// \brief Создаёт очередь событий
static int eventq_create(eventq_t* q, int flags)
{
  int ret;

  /// \todo NONPOSIX: eventq_create использует mkfifo2 вместо mkfifo

  // почему-то для mkfifo2 нужен лишний байт,
  // иначе последняя запись записывается не полностью.
  size_t qsize = CONFIG_LIB_EVENTQ_EVENTS_COUNT * sizeof(eventq_event_t) + 1;

  // mkfifo2 - это исключительно NuttX интерфейс, в linux такого нет
  // однако при использовании на микроконтроллере это позволяет
  // задать точный размер fifo. При портировании нужно доделать.
  ret = mkfifo2(q->path.value, DEFFILEMODE, qsize);

  if (ret != OK) {
    //ret = -errno; // mkfifo2 и так возвращает код ошибки
    log_debug("VMCDQ: Can't create '%s', err=%d (%s)",
      q->path.value, errno, strerror(errno)
    );
    return ret;
  }

  log_trace("EQ: Created FIFO '%s'", q->path.value);

  // Очередь создана, теперь можно открыть созданный файл
  ret = eventq_open_existing(q, flags);
  if (ret < 0) {
    return ret;
  }

  // Последний шаг - установка настроек очереди, что бы данные не удалялись,
  // даже если на очередь нет ни одной ссылки.
  ioctl(q->fd, PIPEIOC_POLICY, 1);
  return ret;
}


/// \brief  Дожидается возникновения одного из событий \p events_mask.
/// \param  q           Указатель на буффер, хранящий состояние очереди
/// \param  timeout_ms  Максимальное время ожидания в мс.
///                     Если 0, то функция завершится без ожидания.
///                     Если -1, то функция будет ждать бесконечно.
/// \param  events_mask Маска событий, которые следует ожидать.
/// \return Неотрицательную маску полученных событий (pfd.revents),
///         или отрицательный код ошибки:
/// \retval -ETIMEDOUT  Ожидание завершилось по таймауту, событий не было.
/// \retval -EINTR      Получено внешнее прерывание
/// \retval ...         Другие возможные системные ошибки
static int eventq_waitevent(eventq_t* q, int timeout_ms, short events_mask)
{
  struct pollfd   pfd;

  dbg_assert(q, "eq-opn#1");

  pfd.fd = q->fd;
  pfd.events = events_mask;
  pfd.revents = 0;

  int ret;

  ret = poll(&pfd, 1, timeout_ms);
  if (ret < 0) {
    ret = -errno;
    if (errno == EAGAIN) {
      ret = -ETIMEDOUT;
    }
    log_debug("EQ: Poll '%s' failed, err=%d (%s)",
      q->path.value, errno, strerror(errno)
    );
    return ret;
  }

  if (ret == 0) {
    return -ETIMEDOUT;
  }

  if (!(pfd.revents & events_mask)) {
    // poll вернул, что есть данные, а в pfd не указал их.
    // Это странно. Возможно, проблема с заданием маски событий.
    log_debug("EQ: Poll '%s' returned no events", q->path.value);
    return -ETIMEDOUT;
  }
  return pfd.revents;
}

/// \brief  Отправляет событие типа \p event с \p size байт данных \p data.
/// \param  q     Указатель на буффер, хранящий состояние очереди
/// \param  event Указатель на буффер, хранящий событие
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
/// \retval -EAGAIN Нет места в очереди.
/// \retval -EBADE  Читающая сторона прочитала меньше, чем размер события
///                 Для восстановления желательно пересоздать очередь.
/// \note   Данная функция не блокируется, если нет места в очереди, то
///         данная функция вернёт -EAGAIN. Что бы дождаться места в очереди
///         необходимо выполнить `eventq_pollwr` или соответствующий `poll`
static int eventq_write_raw(eventq_t* q, const eventq_event_t* event)
{
  int ret;
  dbg_assert(q, "eq-wrr#1");
  dbg_assert(event->size <= CONFIG_LIB_EVENTQ_PAYLOAD_SIZE, "eq-wr#2");

  ret = write(q->fd, event, sizeof(*event));
  if (ret < 0) {
    ret = -errno;
    if (errno == EAGAIN) {
      // FIFO заполнена.
      log_debug("EQ: FIFO '%s' full", q->path.value);
    } else {
      // Остальные ошибки
      log_warn("EQ: Can't write to '%s', err=%d (%s)",
        q->path.value, errno, strerror(errno)
      );
    }
    return ret;
  }

  if (ret != sizeof(*event)) {
    log_warn("EQ: FIFO '%s' sync lost! size=%d, ret=%d",
      q->path.value, sizeof(*event), ret
    );
    return -EBADE;
  }

# if (USED_LOG_LEVEL >= LOG_LEVEL_TRACE) && defined(CFG_USE_LOG)
    // Если для текущего файла разрешён вывод trace сообщений в лог,
    // то помимо сообщения о типе события выводим информацию
    // о занятом и свободном месте в очереди.
    int nbytes = 0;
    ioctl(q->fd, FIONREAD, (uintptr_t)&nbytes);

    int n_events = nbytes / sizeof(eventq_event_t);
    int n_free = CONFIG_LIB_EVENTQ_EVENTS_COUNT - n_events;
    log_trace("EQ: Wr ev=%d sz=%u. n_ev/n_free: %d/%d",
      event->id, event->size, n_events, n_free
    );
# endif

  return OK;
}



/// \brief  Читает из очереди одно сообщение
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
/// \retval -EINVAL Попытка прочесть неоткрытую очередь.
/// \retval -EAGAIN В очереди нет сообщений.
/// \retval -EBADE  Читающая сторона записала меньше, чем размер одного сообщения.
///                 Для восстановления желательно пересоздать очередь.
static int eventq_read_raw(eventq_t* q, eventq_event_t* event)
{
  dbg_assert(q,     "eq-rd#1");
  dbg_assert(event, "eq-rd#2");

  if (q->fd < 0) {
    return -EINVAL;
  }

  ssize_t ret = read(q->fd, event, sizeof(*event));
  if (ret < 0) {
    ret = -errno;
    if (errno != EAGAIN) {
      // Ошибки, кроме отсутствия данных в очереди
      log_warn("EQ: Can't read '%s', err=%d (%s)",
        q->path.value, errno, strerror(errno)
      );
    }
    return ret;
  }

  if (ret != sizeof(*event)) {
    log_warn("EQ: FIFO '%s' sync lost! size=%d, ret=%d",
      q->path.value, sizeof(*event), ret
    );
    return -EBADE;
  }

# if (USED_LOG_LEVEL >= LOG_LEVEL_TRACE) && defined(CFG_USE_LOG)
    // Если для текущего файла разрешён вывод trace сообщений в лог,
    // то помимо сообщения о типе события выводим информацию
    // о занятом и свободном месте в очереди.
    int nbytes = 0;
    ioctl(q->fd, FIONREAD, (uintptr_t)&nbytes);

    int n_events = nbytes / sizeof(*event);
    int n_free = CONFIG_LIB_EVENTQ_EVENTS_COUNT - n_events;
    log_trace("EQ: Rd ev=%d sz=%u. n_ev/n_free: %d/%d",
      event->id, event->size, n_events, n_free
    );
# endif

  return OK;
}



////////////////////////////////////////////////////////////////////////////
//  Публичные функции


/// \brief  Очищает буффер под очередь сообщения и переводит его в известное состояние.
/// \param  q     Указатель на буффер, хранящий состояние очереди
int eventq_init(eventq_t* q)
{
  dbg_assert(q,       "eq-ini");

  memset(q, 0, sizeof(*q));
  q->fd = -1;

  return OK;
}

/// \brief  Открывает очередь сообщений.
/// \param  q     Указатель на буффер, хранящий состояние очереди
/// \param  name  Имя очереди сообщений в формате `/some-name`
/// \param  flags Битмаска с настройками открытия. Возможные флаги:
///   * O_RDONLY    - Открытие очереди для чтения.
///   * O_WRONLY    - Открытие очереди для записи.
///   * O_CREAT     - Создать, если не существует.
///   **Внимание: очередь может быть открыта либо для чтения, либо для записи**
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int eventq_open(eventq_t* q, const char* name, int flags)
{
  int ret;
  bool can_create = flags & O_CREAT;

  dbg_assert(q,       "eq-opn#1");
  dbg_assert(name,    "eq-opn#2");

  // Обнуление структуры
  eventq_init(q);

  // Выделение поддерживаемых флагов и их проверка
  flags &= O_RDWR;
  if (flags == O_RDONLY) {
    // Если очередь открывается только для чтения, то используем режим
    // O_RDWR, что бы вызов eventq_open не блокировался до тех пор,
    // пока появится хоть один записывающий в эту очередь поток.
    flags = O_RDWR;
  }

  if (*name == '/') {
    ++name;
  }


  // Форматируем имя файла очереди
  // можно через strlen/memcpy, но так - компактнее и безопасно
  ret = snprintf(q->path.value, sizeof(q->path.value), "/var/eq/%s", name);
  dbg_assert(ret < sizeof(q->path.value), "vmq-crt#5");
  (void)ret; // Подавление предупреждений, если dbg_assert отключен


  // Попытка открыть существующий файл очереди
  ret = eventq_open_existing(q, flags);
  if (ret == -ENOENT && can_create) {
    // Если нет такого файла и разрешено создание, то создаём
    ret = eventq_create(q, flags);
  }

  return ret;
}



/// \brief  Закрывает очередь сообщений.
/// \param  q     Указатель на буффер, хранящий состояние очереди
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int eventq_close(eventq_t* q)
{
  dbg_assert(q, "eq-cls#1");
  if (q->fd < 0) {
    return OK;
  }

  int ret = close(q->fd);
  if (ret < 0) {
    ret = -errno;
    log_debug("EQ: Can't close queue '%s', err=%d (%s)",
      q->path.value, errno, strerror(errno)
    );
    return ret;
  }
  q->fd = -1;
  return OK;
}



/// \brief  Инициализирует структуру события
/// \param  dst   Указатель, в котором следует создать событие
/// \param  id    Тип события
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno)
int eventq_init_event(eventq_event_t* dst, int id)
{
  dst->id = id;
  dst->size = 0;
  clock_gettime(CLOCK_REALTIME, &dst->time);

  return OK;
}


/// \brief  Отправляет событие типа \p event с \p size байт данных \p data.
/// \param  q     Указатель на буффер, хранящий состояние очереди
/// \param  event Тип события. Сама очередь никак этот тип не обрабатывает.
/// \param  data  Указатель на буффер с данными. Если NULL, то событие без данных
/// \param  size  Размер данных. Если 0, то событие без данных.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
/// \retval -EAGAIN Нет места в очереди.
/// \retval -EBADE  Читающая сторона прочитала меньше, чем размер события
///                 Для восстановления желательно пересоздать очередь.
/// \note   Данная функция не блокируется, если нет места в очереди, то
///         данная функция вернёт -EAGAIN. Что бы дождаться места в очереди
///         необходимо выполнить `eventq_pollwr` или соответствующий `poll`
int eventq_write(eventq_t* q, int event, const void* data, size_t size)
{
  dbg_assert(q, "eq-wr#1");
  dbg_assert(size <= CONFIG_LIB_EVENTQ_PAYLOAD_SIZE, "eq-wr#2");

  eventq_event_t e;
  eventq_init_event(&e, event);

  if (data && size) {
    memcpy(e.data, data, size);
    e.size = size;
  } else {
    e.size = 0;
  }

  return eventq_write_raw(q, &e);
}



/// \brief  Отправляет в очередь событие \p event.
/// \param  q     Указатель на буффер, хранящий состояние очереди
/// \param  event Указатель на событие, которое необходимо отправить.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
/// \retval -EAGAIN Нет места в очереди.
/// \retval -EBADE  Читающая сторона прочитала меньше, чем размер события
///                 Для восстановления желательно пересоздать очередь.
/// \note   Данная функция не блокируется, если нет места в очереди, то
///         данная функция вернёт -EAGAIN. Что бы дождаться места в очереди
///         необходимо выполнить `eventq_pollwr` или соответствующий `poll`
int eventq_write_ex(eventq_t* q, const eventq_event_t* event)
{
  return eventq_write_raw(q, event);
}



/// \brief  Без блокирования читает из очереди одно сообщение
/// \param  q       Указатель на буффер, хранящий состояние очереди
/// \param  event   Указатель на буффер, в который сохранить прочитанное сообщение
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
/// \retval -EINVAL Попытка прочесть неоткрытую очередь.
/// \retval -EAGAIN В очереди нет сообщений.
/// \retval -EBADE  Читающая сторона записала меньше, чем размер одного сообщения.
///                 Для восстановления желательно пересоздать очередь.
int eventq_read(eventq_t* q, eventq_event_t* event)
{
  return eventq_read_raw(q, event);
}


/// \brief  Ожидает наличия и читает из очереди одно сообщение
/// \param  q           Указатель на буффер, хранящий состояние очереди
/// \param  event       Указатель на буффер, в который сохранить прочитанное сообщение
/// \param  timeout_ms  Время ожидания в ms:
///           * Если > 0,   то это время ожидания прихода сообщения
///           * Если == 0,  то данная функция эквивалентна `eventq_read`
///           * Если == -1, то данная функция ожидает события (или ошибки) бесконечно.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
/// \retval -EINVAL Попытка прочесть неоткрытую очередь.
/// \retval -EAGAIN В очереди нет сообщений.
/// \retval -EBADE  Читающая сторона записала меньше, чем размер одного сообщения.
///                 Для восстановления желательно пересоздать очередь.
int eventq_read_timeout(eventq_t* q, eventq_event_t* event, int timeout_ms)
{
  if (timeout_ms) {
    int ret = eventq_waitrx(q, timeout_ms);
    if (ret != OK) {
      return ret;
    }
  }
  return eventq_read(q, event);
}

/// \brief  Возвращает номер файла, который можно передать в функцию poll
/// \return Неотрицательный номер файла, или отрицательный код ошибки (-errno)
int eventq_pollfd(eventq_t* q)
{
  dbg_assert(q, "eq-pfd#1");
  return q->fd;
}



/// \brief  Дожидается наличия в очереди места под новое сообщение
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
/// \retval -ETIMEDOUT    Истекло время ожидания
int eventq_waittx(eventq_t* q, int timeout_ms)
{
  int ret = eventq_waitevent(q, timeout_ms, POLLOUT);
  if (ret < 0) {
    return ret;
  }
  return OK;
}

/// \brief  Дожидается наличия в очереди входящих сообщений
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
/// \retval -ETIMEDOUT    Истекло время ожидания
int eventq_waitrx(eventq_t* q, int timeout_ms)
{
  int ret = eventq_waitevent(q, timeout_ms, POLLIN);
  if (ret < 0) {
    return ret;
  }
  return OK;
}


/// \brief Возвращает количество сообщений, под которые выделено место в очереди
/// \return `>=0` количество сообщений, `< 0` код ошибки
int eventq_get_capacity(eventq_t* q)
{
  if (!q) {
    return -EINVAL;
  }
  if (q->fd < 0) {
    return -EBADF;
  }

  return CONFIG_LIB_EVENTQ_EVENTS_COUNT;
}

/// \brief Возвращает количество сообщений в очереди.
/// \return `>=0` количество сообщений, `< 0` код ошибки
int eventq_get_unread_count(eventq_t* q)
{
  if (!q) {
    return -EINVAL;
  }
  if (q->fd < 0) {
    return -EBADF;
  }

  int nbytes  = 0;
  int ret     = ioctl(q->fd, FIONREAD, (uintptr_t)&nbytes);
  if (ret < 0) {
    ret = -errno;
    return ret;
  }

  nbytes = nbytes/sizeof(eventq_event_t);
  return nbytes;
}

/// \brief Возвращает количество сообщений в очереди.
/// \return `>=0` количество сообщений, `< 0` код ошибки
int eventq_get_free_count(eventq_t* q)
{
  if (!q) {
    return -EINVAL;
  }
  if (q->fd < 0) {
    return -EBADF;
  }

  int nbytes  = 0;
  int ret     = ioctl(q->fd, FIONSPACE, (uintptr_t)&nbytes);
  if (ret < 0) {
    ret = -errno;
    return ret;
  }

  nbytes = nbytes/sizeof(eventq_event_t);
  return nbytes;
}


/// \brief проверяет, что очередь \p q можно использовать.
bool eventq_is_opened(eventq_t* q)
{
  return q && q->fd >= 0;
}
