# lib_eventq, Очередь сообщений для использования в Telemetron Modem 3.0

Данная библиотека определяет тип системного сообщения `eventq_event_t`
и предоставляет функции для создания, чтения, записи и ожидания событий.

## Features

## Example

### Пример программы, которая читает очередь:
```c
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <eventq/eventq.h>

#define MSGID_HELLO     1

void main(...)
{
  eventq_t    q;
  // Считаем, что данная программа вызывается первой,
  // поэтому разрешаем чтение и создание
  int result = eventq_open(&q, "/sysq", O_RDONLY | O_CREAT);
  if (result != OK) {
    printf("Can't open queue.\n")
    return result;
  }

  eventq_event_t  event;

  // Бесконечно ожидаем сообщение
  result = eventq_read_timeout(&q, &event, -1);
  if (result == OK) {
    printf("Can't read queue. error=%d\n", result);
  } else if (event.id == MSGID_HELLO) {
    printf("Read event MSGID_HELLO: data=\"%s\"\n", event.data);
  } else {
    printf("Read unknown event: id=%d, size=%u\n", event.id, event.size);
  }

  eventq_close(&q);
  return result;
}
```

### Пример программы, которая записывает в очередь:
```c
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <eventq/eventq.h>

#define MSGID_HELLO     1

void main(...)
{
  eventq_t    q;
  // Считаем, что данная программа вызывается второй,
  // поэтому её даём право только на запись
  int result = eventq_open(&q, "/sysq", O_WRONLY);
  if (result != OK) {
    printf("Can't open queue.\n")
    return result;
  }
  const char* message = "Hello Queue!";
  result = eventq_write(&q, MSGID_HELLO, message, strlen(message)+1);
  if (result == -EAGAIN) {
    printf("Can't write, queue is full\n");
  } else if (result < 0) {
    printf("Write error=%d\n", result);
  } else {
    printf("Write completed.\n);
  }

  eventq_close(&q);
  return result;
}
```

## Limitations

Список известных ограничений.

## Bugs

Багов нет, есть незадокументированные фичи.

## Licensing

## Author
DL <dmitriy@linikov.ru>

