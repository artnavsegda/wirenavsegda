/// \file
/// \brief  Реализация протокола DDCMP
/// \author DL <dmitriy@linikov.ru>
/// \author AS <a.syrenkov@telemetron.net>
/// \note Данный файл основан на коде из проекта modem-2.7, автор AS

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "bus_ddcmp.h"
#include "ddcmp_baud.h"

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <utils/math_utils.h>
#include <utils/string_utils.h>
#include <utils/smartio.h>
#include <settings/settings.h>

#include <sysutils/crc.h>

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора

#ifdef CONFIG_AUDITD_BUS_DDCMP_LOG_TXRX
#define log_tx(value)   auditd_trace("DdcmpTx:%02X\n", (value))
#define log_rx(value)   auditd_trace("DdcmpRx:%02X\n", (value))
#else
#define log_tx(value)   ((void)value)
#define log_rx(value)   ((void)value)
#endif

#ifdef CONFIG_AUDITD_BUS_DDCMP_LOG_FUNC
#define log_func()      auditd_trace("%s\n", __FUNCTION__)
#else
#define log_func()      ((void)0)
#endif

#define CFG_DDCMP_TIMERA_TIMEOUT_MS               3000
/// \brief Максимальное время запроса. Считаем исходя из того,
/// скорость 2400 бит в секунду, размер 16536 байт + запас
#define CFG_DDCMP_TIMERD_TIMEOUT_MS               150000

// Временные интервалы
// Ошибки реализации в NECTA.
#define DDCMP_TIMEOUT_ACK                         (1170+83)       // 170 mS по документации + макисмальное время приема пакета на скорости 1200
#define DDCMP_TIMEOUT_ACK_byte                    (40)
#define DDCMP_TIMEOUT_TURN_AROUND                 (4)             // 4 мСек задержка для аппаратов, которые не переключаются быстро с передачи на прием (видио сделано у них не на прерываниях)
#define DDCMP_TIMEOUT_STACK                       (500)//(250+83)      // 250 mS по документации + макисмальное время приема пакета на скорости 1200
#define DDCMP_TIMEOUT_LINK_H                      12000
#define DDCMP_TIMEOUT_LINK                        5000

#define DDCMP_CTLMSG_SIZE                         6
#define DDCMP_CRC_SIZE                            2
#define DDCMP_CTLMSG_SIZE_WITH_CRC                (DDCMP_CTLMSG_SIZE + DDCMP_CRC_SIZE)
// Размер заголовка ответа Data Message
#define DDCMP_SIZEOF_HEADER                       3

// Количество реповторов на передачу данных
#define DDCMP_MAX_DATA_ATTEMPTS                   5
/// Врменно!! Это Saeco тупит
#define DDCMP_MAX_DATA_ATTEMPTS_SAECO             (DDCMP_MAX_DATA_ATTEMPTS-2)

// Максимальная скорость в расширенном режиме, которую мы хотим запросить. С этой скокростью можно поиграться
#define DDCMP_MAX_BAUD_EXTENDED_MODE              DDCMP_BAUD_9600
// Скорость в расширенном режиме. Менять НЕЛЬЗЯ!
#define DDCMP_BAUD_EXTENDED_MODE                  DDCMP_BAUD_2400
// Скорость в фикисрованном режиме. Менять НЕЛЬЗЯ!
#define DDCMP_BAUD_FIXED_MODE                     DDCMP_BAUD_9600
// адрес слейва 0x01 широковещательный запрос для точка-точка
// 0x10 индивидуальный адрес VMC
#define DDCMP_SLAVE_ADDR                          0x01
#define DDCMP_SLAVE_VMC                           0x10

// Сообщения
// Управляющее
#define DDCMP_CONTROL_MESSAGE                     0x05
// Данные
#define DDCMP_DATA_MESSAGE                        0x81

// Команды запросы
#define DDCMP_COMMAND_MESSAGE               0x77

// Команды запроса
#define DDCMP_CMD_WAY                       0xE0

#define DDCMP_CMD_RD                        0xE2

#define DDCMP_CMD_PRGM                      0xE5

#define DDCMP_CMD_FIN                       0xFF

// Команды ответа
#define DDCMP_COMMAND_RESPONSE              0x88

#define DDCMP_APPLICATION_DATA_MESSAGE      0x99


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


/// \brief Один символ данных, передаваемых по шине dex, либо код ошибки.
/// Если значение находится от 0 до 255, то это одиночный символ,
/// Если значение находится от 256 до 65535, то это двухбайтный символ.
/// Если значение меньше нуля, то это код ошибки
/// Если значение больше 65535 - это недопустимый символ.
typedef int32_t   ddcmpchar_t;

/// \brief перечисление всех "специальных" значений, которые может принимать
/// переменная типа dexchar_t.
typedef enum ddcmp_result_e {
  DDCMP_OK = 0,
  // ==================== Ошибки =====================
  DDCMP_TIMEOUT = -ETIMEDOUT,
  DDCMP_BAD_CRC = -EILSEQ,

  DDCMP_ERROR_RESPONSE = (-__ELASTERROR-1),
  DDCMP_ERROR_STACK = (DDCMP_ERROR_RESPONSE-1),
  DDCMP_ERROR_ZERO_Q = (DDCMP_ERROR_STACK-1),
  DDCMP_ERROR_NACK = (DDCMP_ERROR_ZERO_Q-1),
  DDCMP_ERROR_UNKNOW_ACK = (DDCMP_ERROR_NACK-1),
  DDCMP_ERROR_NOSLAVES = (DDCMP_ERROR_UNKNOW_ACK-1),
  DDCMP_ERROR_UNKNOW_BAUDRATE = (DDCMP_ERROR_NOSLAVES-1),
  DDCMP_RXN_NOT_TXN = (DDCMP_ERROR_UNKNOW_BAUDRATE-1),
  DDCMP_ERROR_RESPONSE_ENVELOPE = (DDCMP_RXN_NOT_TXN-1),
  DDCMP_TXN_NOT_RXN = (DDCMP_ERROR_RESPONSE_ENVELOPE-1),
  DDCMP_ERROR_RECEIVE_DATA_OUT_OF_MEMMORY = (DDCMP_TXN_NOT_RXN-1),
  DDCMP_ERROR_RECEIVE_DATA_MSG_PTR = (DDCMP_ERROR_RECEIVE_DATA_OUT_OF_MEMMORY-1),
  DDCMP_ERROR_BLOCK_OR_APLMSG = (DDCMP_ERROR_RECEIVE_DATA_MSG_PTR-1),

  // опкоды смещения дял определния номера процедуры, вызвавшей ошибку
  // DDCMP_FUNC_ERROR = -256,
  // DDCMP_FUNC_DdcmpInitializeChannel = DDCMP_FUNC_ERROR-1,
  // DDCMP_FUNC_DdcmpInitializeChannel_ret = DDCMP_FUNC_ERROR+DDCMP_FUNC_DdcmpInitializeChannel,
  // DDCMP_FUNC_DdcmpCheckWAY_DdcmpTransmitMessage = DDCMP_FUNC_ERROR+DDCMP_FUNC_DdcmpInitializeChannel_ret,
  // DDCMP_FUNC_DdcmpCheckWAY_DdcmpReceiveData = DDCMP_FUNC_ERROR+DDCMP_FUNC_DdcmpCheckWAY_DdcmpTransmitMessage,
  // DDCMP_FUNC_DdcmpEnableReadData_DdcmpTransmitMessage = DDCMP_FUNC_ERROR+DDCMP_FUNC_DdcmpCheckWAY_DdcmpReceiveData,
  // DDCMP_FUNC_DdcmpEnableReadData_DdcmpReceiveData = DDCMP_FUNC_ERROR+DDCMP_FUNC_DdcmpEnableReadData_DdcmpTransmitMessage,
  // DDCMP_FUNC_ReadingData = DDCMP_FUNC_ERROR+DDCMP_FUNC_DdcmpEnableReadData_DdcmpReceiveData,
  // DDCMP_FUNC_ddcmp_get_evadts = DDCMP_FUNC_ERROR+DDCMP_FUNC_ReadingData,
  // DDCMP_FUNC_n = DDCMP_FUNC_ERROR+DDCMP_FUNC_ddcmp_get_evadts,

  DDCMP_FUNC_DdcmpInitializeChannel = 0,
  DDCMP_FUNC_DdcmpInitializeChannel_ret = 0,
  DDCMP_FUNC_DdcmpCheckWAY_DdcmpTransmitMessage = 0,
  DDCMP_FUNC_DdcmpCheckWAY_DdcmpReceiveData = 0,
  DDCMP_FUNC_DdcmpEnableReadData_DdcmpTransmitMessage = 0,
  DDCMP_FUNC_DdcmpEnableReadData_DdcmpReceiveData = 0,
  DDCMP_FUNC_ReadingData = 0,
  DDCMP_FUNC_ddcmp_get_evadts = 0,
  DDCMP_FUNC_n = 0,

  // смещение кода ошибки при неподтверждении дата сообщений
  /// \todo Переделать такую индикацию на что-то более адекватное
  DDCMP_EERORCODE = -800000,
} ddcmp_result_t;

/// \brief Типы управляющих сообщений
enum DdcmpTypeOfCtrl{
    DDCMP_CTRL_START        = 0x06,         ///< START
    DDCMP_CTRL_STACK        = 0x07,         ///< Подтверждение START
    DDCMP_CTRL_ACK          = 0x01,         ///< Подтверждение Data Message
    DDCMP_CTRL_NACK         = 0x02          ///< Неподтверждение Data Message
};

/// \brief Типы запросов данных для команды E2
enum DdcmpTypeOfLists{
    DDCMP_E2_AUDIT          = 1,            ///< Стандартный запрос EVA-DTS (похоже со сбросом счетчиков)
    DDCMP_E2_AUDIT_WOR      = 2,            ///< Стандартный запрос EVA-DTS без сброса счетчиков
    DDCMP_E2_ALL_DATA       = 50,           ///< Запрос конфигурации и EVA-DTS
    DDCMP_E2_CTRL_BOARD     = 64            ///< Запрос конфигурации, хранящейся в Control Board
};

/// \brief Коды ошибок (NAK)
enum DdcmpNakErrors{
    DDCMP_NAK_HEADER_CRC    = 1,            ///< Ошибка заголовка CRC
    DDCMP_NAK_DATA_CRC      = 2,            ///< Ошибка блока данных CRC
    DDCMP_NAK_REP           = 3,            ///< Не используется в расширенном DDCMP
    DDCMP_NAK_BUF_UNAV      = 8,            ///< Ошибка буфер недоступен
    DDCMP_NAK_REC_OVER      = 9,            ///< Ошибка приемник переполнен
    DDCMP_NAK_MSG_LONG      = 16,           ///< Ошибка сообщение слишком большое для нас
    DDCMP_NAK_MSG_FORMAT    = 17,           ///< Ошибка формата сообщения
};


/// \brief Стурктуры DDCMP сообщений
typedef union {
  /// \brief Control Message
  struct {
    uint8_t cmd;      ///< Тип сообщения (Control Message или Data Message)
    uint8_t cmd_type; ///< Номер управляющего сообщения
    struct {
      uint8_t errcode : 0x06; ///< код ошибки
      uint8_t q       : 0x01; ///< всегда 1
      uint8_t f_end   : 0x01; ///< Флаг завершения передачи данных
    } status;
    uint8_t sbd_rr;   ///< Для STACK - это скорость слейва, для ACK/NACK это номер RX сообщения Data Message
    uint8_t mbd;      ///< скорость мастера. Для ACK/NACK всегда 0
    uint8_t sadd;     ///< Адрес слейва
  } ctrl_msg;

  /// \brief Data Message
  struct {
    uint8_t cmd;      ///< Тип сообщения (Control Message или Data Message)
    uint8_t ls_len;   ///< младшая часть длины сообщения
    struct {
      uint8_t ms_len  : 0x06; ///< старшая часть длины сообщения
      uint8_t q       : 0x01; ///< всегда 1
      uint8_t f_end   : 0x01; ///< Флаг завершения передачи данных
    } status;
    uint8_t Rx_n;     ///< Номер
    uint8_t Tx_n;     ///< скорость мастера. Для ACK/NACK всегда 0
    uint8_t sadd;     ///< Адрес слейва
  } data_msg;
} ddcmp_msg_t;

/// \brief Запросы
typedef struct {
  uint8_t cmd_msg;    ///< Всегда DDCMP_COMMAND_MESSAGE
  uint8_t cmd;        ///< команды вида 0xE0 - 0xE6, 0xFF
  uint8_t ack;        ///< в запросе всегда 0x00
  union {
    //---------------------------
    /// \brief Структура запроса - сообщение типа WhoAreYou
    struct {
      uint8_t secure[2];    ///< Security Code
      uint8_t password[2];  ///< Password Code
      uint8_t day;          ///< День
      uint8_t month;        ///< Месяц
      uint8_t year;         ///< Год
      uint8_t hours;        ///< Часы
      uint8_t minutes;      ///< Минуты
      uint8_t seconds;      ///< Секунды
      uint8_t userid[2];    ///< ?? в сканере было 0x57 0x04
      uint8_t maintenance;  ///< для технического обслуживания всегда 0x0B
    } E0;
    //---------------------------
    /// \brief Структура запроса - Read Data
    struct {
      uint8_t list_n;         ///< List Number (1, 2, 50, 64) 2 - запрос EVA-DTS без сброса счетчиков
      uint8_t record_n;       ///< Record Number всегда 0x01
      uint8_t offset[2];      ///< смещение в байтах.
      uint8_t segment_len[2]; ///< длина запрашиваемых данных.
    } E2;
  } bodys;
} ddcmp_req_t;

/// \brief Ответы
typedef struct {
  uint8_t cmd_resp;   ///< Всегда DDCMP_COMMAND_RESPONSE
  uint8_t cmd;        ///< команда вида 0xE0 - 0xE6, 0xFF
  uint8_t ack;        ///< код подтвержедния (01 - ACK, 00 - NACK)
  union {
    //---------------------------

    /// \brief структура ответа типа WAY
    struct {
      union {
        uint8_t DC;           ///< Если ack= 0x00, то в DC код заперта (01 - пароль или  secure code неверный)
        uint8_t secure[2];    ///< Security Code
      } s_dc;
      uint8_t password[2];    ///< Password Code
      uint8_t VMC_serial[8];  ///< Серийный номер машины
      uint8_t SW_ver;         ///< версия ПО
      uint8_t Man_code;       ///< игнорим
      uint8_t Extra_RD;       ///< количество вычиток, которое необходимо сделать, что бы вычитать весь
                              /// буфер? Возможно необходимо при получении блока данных

      uint8_t zero;           ///< Значение всегда равно 0

      uint8_t buf_size[2];    ///< размер приемного (но видимо и передаваемого буфера). Если тут 0
                              /// значит буфер равен 256 байт
    } E0;
    //---------------------------

    /// \brief Структура ответа Programm Slave
    struct {
      uint8_t secure[2];      ///< Security Code
      uint8_t password[2];    ///< Password Code
      uint8_t VMC_serial[8];  ///< Серийный номер машины
    } E1;
    //---------------------------

    /// \brief Структура ответа Read Data
    struct {
      uint8_t list_n;         ///< List Number (1, 2, 50, 64) 2 - запрос EVA-DTS без сброса счетчиков
      uint8_t record_n;       ///< Record Number всегда 0x01
      uint8_t offset[2];      ///< смещение в байтах.
      uint8_t segment_len[2]; ///< длина запрашиваемых данных.
    } E2;
    //---------------------------

    // Write Data
    // в ответе нет других полей
    // E3;
    //---------------------------

    // Delete Data
    // в ответе нет других полей
    // E4;
    //---------------------------
    /// \brief Programm Module
    struct {
      union {
        uint8_t error;  ///< код ошибки. Если ack = 0x00
        uint8_t RS[2];  ///<
      } s_dc;
    } E5;
    //---------------------------

    /// \brief Read Memmory
    struct {
      uint8_t start_adr[2];    ///< Start Address
      uint8_t segment_len[2];  ///< Segment Length
    } E6;
  } bodys;
} ddcmp_rsp_t;


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Приватные функции


static inline uint32_t SetErrorResult(uint32_t result,uint32_t error)
{
  return error;
//  return ((result&DDCMP_ERROR_FUNC_MASK)|(error&~DDCMP_ERROR_FUNC_MASK));
}


/// \brief Читает из шины \p bus один байт данных, при не обходимости
/// подсчитывая контрольную сумму.
static int ddcmp_read_raw(auditbus_ddcmp_t* bus)
{
  if (timeout_is_elapsed(&bus->timer_a) || timeout_is_elapsed(&bus->timer_d)) {
    bus->transaction_active = false;
    return -ETIMEDOUT;
  }

  systime_t   ms_to_wait = min_u32(timeout_ticks_left(&bus->timer_a),
                                   timeout_ticks_left(&bus->timer_d));
  int result = smartio_nbgetc(auditbus_port(bus), ms_to_wait);
  log_rx(result);

  return result;
}

/// \brief Читает из шины \p bus в буффер \p data размером \p size.
static int ddcmp_read_raw_bytes(auditbus_ddcmp_t* bus, void* data, size_t size)
{
  uint8_t* value = (uint8_t*)data;
  int      result;
  log_func();

  while (size) {
    // читаем байт
    result = ddcmp_read_raw(bus);
    // проверка результата
    if (result < 0) {
      auditd_debug("read_raw bytes >> %d\n", size);
      return (result);
    }
    // сохраняем результат
    *value = (uint8_t)result;
    value++;
    size--;
  }
  return (size);
}

// DL: Данная функция - какой-то хак функции ddcmp_read_raw_bytes, сделанный для
// поддержки работы автомата saeco.
// Используется исключительно из одного места.
static int ddcmp_read_raw_bytes_fix_saeco_on_timeout(
  auditbus_ddcmp_t* bus, void* data, size_t size, size_t* ret_size
)
{
  uint8_t*    value = (uint8_t*)data;
  ddcmpchar_t result;

  log_func();
  DEBUGASSERT(ret_size);  // Для данного варианта функции обязательно должен быть.

  *ret_size = size;

  while (size) {
    timeout_start(&bus->timer_a, DDCMP_TIMEOUT_ACK_byte);

    // читаем байт
    result = ddcmp_read_raw(bus);

    // проверка результата
    if (result < 0) {
      *ret_size -= size;
      auditd_debug("read_raw bytes >> %d\n", size);
      return (result);
    }
    // сохраняем результат
    *value = (uint8_t)result;
    value++;
    size--;
  }
  return (size);
}

/// \brief Записывает в шину \p bus один байт данных, при необходимости
/// обновляя контрольную сумму.
static int ddcmp_write_raw(auditbus_ddcmp_t* bus, uint8_t value)
{
  int ret = smartio_nbputc(auditbus_port(bus), value, -1);
  log_tx(value);
  return ret;
}

/// \brief Записывает в шину \p bus буффер \p data размером \p size.
static ssize_t ddcmp_write_raw_bytes(auditbus_ddcmp_t* bus, const void* data, size_t size)
{
  int             ret;
  ssize_t         result  = size;
  const uint8_t*  value   = (const uint8_t*)data;

  while(size--) {
    ret = ddcmp_write_raw(bus, *value++);
    if (ret < 0) {
      return ret;
    }
  }
  return result;
}

/// \brief Сбрасывает нумерацию ожидаемых от VMD команд ACK к начальному ACK0.
static inline void ddcmp_restart_rx_ack_sequence(auditbus_ddcmp_t* bus)
{
  bus->rx_ack_number = 0;
}

/// \brief Сбрасывает нумерацию передаваемых ACK команд к начальному ACK0.
static inline void ddcmp_restart_tx_ack_sequence(auditbus_ddcmp_t* bus)
{
  bus->tx_ack_number = 0;
}

/// \brief Сбрасывает модуль вычисления контрольной суммы передаваемых данных
/// к начальному значению.
static inline void ddcmp_reset_tx_crc(auditbus_ddcmp_t* bus)
{
  log_func();
  smartio_clear_crc_tx(auditbus_port(bus));
}

/// \brief Сбрасывает модуль вычисления контрольной суммы принимаемых данных
/// к начальному значению.
static inline void ddcmp_reset_rx_crc(auditbus_ddcmp_t* bus)
{
  log_func();
  smartio_clear_crc_rx(auditbus_port(bus));
}

/// \brief Сбрасывает таймер обратного отсчета TimerA (максимальная
/// продолжительность одной транзакции) к начальному значению.
static inline void ddcmp_reset_timer_a(auditbus_ddcmp_t* bus, uint32_t timeout)
{
  log_func();
  timeout_start(&bus->timer_a, timeout);
}

/// \brief Сбрасывает таймер обратного отсчёта TimerD (максимальное время между
/// транзакциями одной сессии) к начальному значению.
static inline void ddcmp_reset_timer_d(auditbus_ddcmp_t* bus)
{
  log_func();
  timeout_start(&bus->timer_d, CFG_DDCMP_TIMERD_TIMEOUT_MS);
}

/// \brief читает из шины 2 символа контрольной суммы.
/// \return Если прочитано успешно и CRC совпало с bus->rx_crc, то возвращает 0
/// Иначе вернет код ошибки
static int ddcmp_read_crc(auditbus_ddcmp_t* bus)
{
  uint16_t  crc;
  uint16_t  calc_crc  = bus->rx_crc.value;
  ssize_t   ret       = ddcmp_read_raw_bytes(bus,&crc,sizeof(crc));
  if (ret < 0) {
    // Ошибка чтения
    return ret;
  }

  if (crc != calc_crc) {
    // Ошибка CRC
    return -EILSEQ;
  }

  return DDCMP_OK;
}

/// \brief Записывает в шину \p bus 2 символа контрольной суммы, которые
/// к моменту вызова были накоплены в модуле подсчёта контрольной суммы
/// передаваемых данных (\see `bus->tx_crc`).
static int ddcmp_write_crc(auditbus_ddcmp_t* bus)
{
  uint16_t  crc = bus->tx_crc.value;
  return ddcmp_write_raw_bytes(bus,&crc,sizeof(crc));
}

/// \return Инициализация буфера USRT, таймера A
static int ddcmp_master_start_transfer(auditbus_ddcmp_t* bus)
{
  int ret;
  ret = smartio_discard_rx(auditbus_port(bus), 0);
  if (ret < 0) {
    return ret;
  }
  // Сброс таймаута приёма и нумерации подтверждений
  ddcmp_reset_timer_a(bus,CFG_DDCMP_TIMERA_TIMEOUT_MS);
  ddcmp_reset_rx_crc(bus);
  ddcmp_restart_rx_ack_sequence(bus);
  ddcmp_reset_tx_crc(bus);
  ddcmp_restart_tx_ack_sequence(bus);
  return DDCMP_OK;
}


/// Процедура получения и проверки подтверждения
/// Возвращает код ошибки. 0 Все Ок
static ddcmpchar_t ddcmp_check_ack(
    auditbus_ddcmp_t* bus, enum DdcmpTypeOfCtrl ack_type, uint8_t* sbd_rr,
    volatile ddcmp_msg_t** ret_msg_envelope)
{
  log_func();
  ddcmp_msg_t msg_stack;
  ddcmpchar_t result;

  smartio_logger_printf(auditbus_port(bus), "\r\nACK ");

  // Сброс CRC приема
  ddcmp_reset_rx_crc(bus);
  // Выставляем таймер на ожидание подтверждения
  if (ack_type == DDCMP_CTRL_STACK)
    ddcmp_reset_timer_a(bus, DDCMP_TIMEOUT_STACK);
  else
    ddcmp_reset_timer_a(bus, DDCMP_TIMEOUT_ACK);
  // чиатем данные
  result = ddcmp_read_raw_bytes(bus, &msg_stack, sizeof(msg_stack.ctrl_msg));
  if (result < 0) {
    return (result);
  }

  // чиатем CRC
  result = ddcmp_read_crc(bus);

  // Ошибка CRC
  if (result < 0) {
    return (result);
  }

  // Проверяем тип подтверждения
  if (ret_msg_envelope != NULL) {
    if ((msg_stack.ctrl_msg.cmd != DDCMP_CONTROL_MESSAGE)
        && (msg_stack.ctrl_msg.cmd != DDCMP_DATA_MESSAGE)) {
      // Ошибка ответа
      return (DDCMP_ERROR_RESPONSE);
    }
  }

  if (msg_stack.ctrl_msg.cmd != DDCMP_CONTROL_MESSAGE) {
    // Ошибка ответа
    return (DDCMP_ERROR_RESPONSE);
  }

  // Проверям константу
  if (msg_stack.ctrl_msg.status.q != 1) {
    // Ошибка формата
    return (DDCMP_ERROR_ZERO_Q);
  }

  // Тип подтверждения STACK
  if (ack_type == DDCMP_CTRL_STACK) {
    // отклик STACK
    if ((msg_stack.ctrl_msg.cmd == DDCMP_DATA_MESSAGE)
        || (msg_stack.ctrl_msg.cmd_type != DDCMP_CTRL_STACK)) {
      // Ошибка подтверждения
      return (DDCMP_ERROR_STACK);
    }

    if (sbd_rr) {
      *sbd_rr = msg_stack.ctrl_msg.sbd_rr;
    }
    result = DDCMP_OK;

  } else {
    // Отклик ACK
    if (ack_type == DDCMP_CTRL_ACK) {
      uint8_t cmd_type;
      if ((ret_msg_envelope != NULL) && (msg_stack.ctrl_msg.cmd == DDCMP_DATA_MESSAGE)) {
        // Копируем ответ
        cmd_type = sizeof(**ret_msg_envelope);
        uint8_t *ptr_dst, *ptr_src;
        ptr_dst = (uint8_t*)(*ret_msg_envelope);
        ptr_src = (uint8_t*)&msg_stack;
        while (cmd_type) {
          *ptr_dst++ = *ptr_src++;
          cmd_type--;
        }
        cmd_type = DDCMP_CTRL_ACK;
      } else {
        if (ret_msg_envelope != NULL) {
          *ret_msg_envelope = NULL;
        }
        cmd_type = msg_stack.ctrl_msg.cmd_type;
      }

      // Проверям тип подтверждения
      switch (cmd_type) {
      // Получили подтверждение
      case DDCMP_CTRL_ACK:
        if (sbd_rr) {
          *sbd_rr = msg_stack.ctrl_msg.sbd_rr;
        }

        result = DDCMP_OK;
        if (bus->tx_ack_number != msg_stack.ctrl_msg.sbd_rr) {
          if (sbd_rr) {
            *sbd_rr = 0;
          }
          result = DDCMP_ERROR_NACK;
        }
        break;

      // Получили неподтверждение
      case DDCMP_CTRL_NACK:
        if (sbd_rr) {
          *sbd_rr = msg_stack.ctrl_msg.status.errcode;
        }
        result = DDCMP_ERROR_NACK;
        break;

      // Все остальное
      default:
        result = DDCMP_ERROR_UNKNOW_ACK;
        break;
      }
    }
  }
  return (result);
}

/// Отправка данных
static int DdcmpTransmitData(auditbus_ddcmp_t* bus, const void* msg, size_t size)
{
  int ret;
  ddcmp_reset_tx_crc(bus);
  ret = ddcmp_write_raw_bytes(bus, msg, size);
  if (ret < 0) {
    return ret;
  }

  ret = ddcmp_write_crc(bus);
  if (ret < 0) {
    return ret;
  }
  return 0; /// \todo Возможно, стоит заменить на size
}

/// Отправка конверта
static int DdcmpSendEnvelopeMsg(auditbus_ddcmp_t* bus, const ddcmp_msg_t* msg)
{
  smartio_logger_printf(auditbus_port(bus), "\r\n>Menv ");
  return DdcmpTransmitData(bus, msg, sizeof(ddcmp_msg_t));
}

/// Получение данных
static ddcmpchar_t DdcmpReceiveData(
    auditbus_ddcmp_t* bus,
    const void*       msg,
    size_t            size,
    size_t*           rec_size,
    volatile ddcmp_msg_t* msg_envelope_ack
)
{
  log_func();
  ddcmpchar_t  result, r2;
  char*        tmp_ptr;
  char         number[20];
  bool         err   = false;
  uint8_t      count = DDCMP_MAX_DATA_ATTEMPTS;
  bool         skip = false;
  ddcmp_msg_t  msg_envelope_new;
  ddcmp_msg_t* msg_envelope;
  size_t       msg_size, save_msg_size;
  ddcmp_rsp_t* msg_response = (ddcmp_rsp_t*)msg;


  if (!msg_response) {
    return -EINVAL;
  }

  // Готовим отклик
  ddcmp_msg_t msg_ack = {.ctrl_msg.cmd            = DDCMP_CONTROL_MESSAGE,
                         .ctrl_msg.cmd_type       = DDCMP_CTRL_NACK,
                         .ctrl_msg.status.errcode = 0,
                         .ctrl_msg.status.q       = 1,
                         .ctrl_msg.status.f_end   = 0,
                         .ctrl_msg.sbd_rr         = bus->rx_ack_number,
                         .ctrl_msg.mbd            = 0,
                         .ctrl_msg.sadd           = bus->ddcmp_slave_adr};
  /// Временно!! Это Saeco Cristallo 600 тупит
  do {
    if (msg_envelope_ack != NULL) {
      msg_envelope = (ddcmp_msg_t*)msg_envelope_ack;
    } else {
      msg_envelope = &msg_envelope_new;
    }
    skip = false;
    err   = false;
    /*----------------------------*/
    /* Получаем конверт сообщения */
    /*----------------------------*/
    auditd_debug(" DdcmpReceiveData       attempt -> %d\n", (5 - count) + 1);
    // Сброс CRC приема
    ddcmp_reset_rx_crc(bus);
    // Выставляем таймер на ожидание подтверждения
    ddcmp_reset_timer_a(bus, DDCMP_TIMEOUT_LINK);
    ddcmp_reset_timer_d(bus);

    if (auditbus_should_stop((auditbus_t*)bus)) {
      auditd_debug("  DdcmpReceiveData aborted by signal\n")
      result = -EINTR;
      break;
    }

    if (msg_envelope_ack == NULL) {
      // Нет подтверждения пакета типом Data Message
      // чиатем данные
      smartio_logger_printf(auditbus_port(bus), "\r\n<Menv ");

      result = ddcmp_read_raw_bytes(bus, msg_envelope, sizeof(*msg_envelope));
      auditd_debug(" DDCMP [DdcmpReceiveData]        0x%x\n", result);
      if (result < 0) {
        return (result);
      }

      // чиатем CRC
      result = ddcmp_read_crc(bus);
      // Ошибка CRC
      if (result < 0) {
        msg_ack.ctrl_msg.status.errcode = DDCMP_NAK_HEADER_CRC;
        DdcmpSendEnvelopeMsg(bus, &msg_ack);
        return (result);
      }
    } else {
      // При следующем цикле исключаем использование предыдущего подтверждения
      msg_envelope_ack = NULL;
    }

    // Проверяем тип подтверждения
    if (msg_envelope->data_msg.cmd != DDCMP_DATA_MESSAGE) {
      msg_ack.ctrl_msg.status.errcode = DDCMP_NAK_MSG_FORMAT;
      DdcmpSendEnvelopeMsg(bus, &msg_ack);
      // Ошибка ответа
      return (DDCMP_ERROR_RESPONSE_ENVELOPE);
    }

    // Проверяем константу
    if (msg_envelope->data_msg.status.q != 1) {
      msg_ack.ctrl_msg.status.errcode = DDCMP_NAK_MSG_FORMAT;
      DdcmpSendEnvelopeMsg(bus, &msg_ack);
      // Ошибка формата
      return (DDCMP_ERROR_ZERO_Q);
    }

    // Выставлен режим приема окончаняи по приходу флага окончания
    if (bus->data_end_flg) {
      bus->rec_flag_end = msg_envelope->data_msg.status.f_end;
    }

    // Проверям что подтверждают нашу отправку
    if (msg_envelope->data_msg.Rx_n != bus->tx_ack_number) {
      msg_ack.ctrl_msg.status.errcode = DDCMP_NAK_MSG_FORMAT;
      DdcmpSendEnvelopeMsg(bus, &msg_ack);
      return (DDCMP_RXN_NOT_TXN);
    }

    // Проверяем непрерыввность поступающей информации
    if (((bus->rx_ack_number) != msg_envelope->data_msg.Tx_n) || (!bus->rx_ack_number_is_set)) {
      if (((uint8_t)(bus->rx_ack_number + 1) != msg_envelope->data_msg.Tx_n)
          && (bus->rx_ack_number_is_set)
      ) {
        msg_ack.ctrl_msg.status.errcode = DDCMP_NAK_MSG_FORMAT;
        DdcmpSendEnvelopeMsg(bus, &msg_ack);
        return (DDCMP_TXN_NOT_RXN);
      }

      // Если установки номера первого переданного пакета небыло, то необходимо его проставить
      if (!bus->rx_ack_number_is_set) {
        bus->rx_ack_number_is_set = true;
        bus->rx_ack_number        = msg_envelope->data_msg.Tx_n;
      } else {
        // Переводим счетчик принимаемых пакетов на следующий
        bus->rx_ack_number++;
      }

      msg_ack.ctrl_msg.sbd_rr = bus->rx_ack_number;
    } else {
      skip = true;
    }

    // Считываем длину сообщения
    msg_size = msg_envelope->data_msg.status.ms_len << 8;
    msg_size |= msg_envelope->data_msg.ls_len;
    save_msg_size = msg_size;

    /*-------------------------*/
    /* Получаем само сообщение */
    /*-------------------------*/
    // Проверяем доступность места под данные
    auditd_debug(" DDCMP [msg_size]        %d\n", msg_size);
    auditd_debug(" DDCMP [size]            %d\n", size);
    if (size < msg_size) {
      msg_ack.ctrl_msg.status.errcode = DDCMP_NAK_MSG_LONG;
      DdcmpSendEnvelopeMsg(bus, &msg_ack);
      return (DDCMP_ERROR_RECEIVE_DATA_OUT_OF_MEMMORY);
    }

    // Сообщаем о количестве получаемых данных
    if (rec_size) {
      if (skip) {
        *rec_size = 0;
      } else {
        *rec_size = msg_size;
      }
    }

    // Сброс CRC приема
    ddcmp_reset_rx_crc(bus);

    // Выставляем таймер на ожидание
    ddcmp_reset_timer_a(bus, DDCMP_TIMEOUT_ACK);
    smartio_logger_printf(auditbus_port(bus), "\r\n<Mdata ");

    // чиатем данные только первые DDCMP_SIZEOF_HEADER байт
    // В NECTA реализация DDCMP кривая.
    // размер msg_size в некте всегда равен 21. По этому ориентироваться можно толкьо частичной
    // вычиткой
    result = ddcmp_read_raw_bytes(bus, msg_response, DDCMP_SIZEOF_HEADER);
    auditd_debug(" DDCMP [read DDCMP_SIZEOF_HEADER]        0x%x\n", result);
    if (result < 0) {
      return (result);
    }

    // Проверяем, что идет то что нужно!
    if (msg_response->cmd_resp == DDCMP_COMMAND_RESPONSE) {
      // Проверяем на обшибку ответа
      if (!msg_response->ack) {
        r2 = 0;
        // У следующих ответов есть еще один значащий байт с кодом ошибки
        if ((msg_response->cmd == DDCMP_CMD_WAY)
            || (msg_response->cmd == DDCMP_CMD_PRGM)
        ) {
          // Вычитываем еще один байт данных
          result = ddcmp_read_raw(bus);
          // ошибка чтения байта
          if (result < 0) {
            return (result);
          }

          r2 = result;
        }

        // читаем CRC
        result = ddcmp_read_crc(bus);
        if (result >= 0) {
          // Передаем код ишибки. Почему нас отлупили
          result = DDCMP_EERORCODE - r2;
        }

        msg_ack.ctrl_msg.cmd_type = DDCMP_CTRL_ACK;
        DdcmpSendEnvelopeMsg(bus, &msg_ack);
        return (result);
      }

    } else if (msg_response->cmd_resp != DDCMP_APPLICATION_DATA_MESSAGE) {
      // Проверим на поступление блока данных
      // Неизвестный тип данных
      msg_ack.ctrl_msg.status.errcode = DDCMP_NAK_MSG_FORMAT;
      DdcmpSendEnvelopeMsg(bus, &msg_ack);
      return (DDCMP_ERROR_RESPONSE);
    }

    // Уменьшаем длину ожидаемых данных на величину уже прочитанных
    msg_size -= DDCMP_SIZEOF_HEADER;
    // Выставляем таймер на ожидание
    // ddcmp_reset_timer_a(bus,DDCMP_TIMEOUT_ACK,true);
    // Дочитываем остаток ответа
    /// Временно!! Это Saeco тупит
    if (auditbus_get_saeco_fix(bus) == EVADTS_DDCMP_FIX_SAECO_ON_TIMEOUT) {
      result = ddcmp_read_raw_bytes_fix_saeco_on_timeout(
        bus, (((uint8_t*)msg_response) + DDCMP_SIZEOF_HEADER), msg_size, &msg_size
      );

    } else {
      result = ddcmp_read_raw_bytes(
        bus, (((uint8_t*)msg_response) + DDCMP_SIZEOF_HEADER), msg_size
      );
    }

    auditd_debug(" DDCMP [read ALL_BODY]        0x%x\n", result);
    if (result < 0) {
      if (!count--) {
        return (result);
      }

      err = true;
    }

    if (!err) {
      // читаем CRC
      result = ddcmp_read_crc(bus);
      auditd_debug(" DDCMP [read BODY CRC]        0x%x\n", result);
      if (result < 0) {
        if (!count--) {
          msg_ack.ctrl_msg.status.errcode = DDCMP_NAK_DATA_CRC;
          DdcmpSendEnvelopeMsg(bus, &msg_ack);
          return (result);
        }

        err = true;
      }


      /*--------------------------*/
      /* Отправляем подтверждение */
      /*--------------------------*/
      // Отправка ACK
      if (!err) {
        msg_ack.ctrl_msg.cmd_type = DDCMP_CTRL_ACK;
      }

      /*/// Временно!! Это Saeco тупит. Теперь постоянно! Актуально для Saeco Cristallo, Atlante,
      Diamante else if (((len_err) && (g_settings.ddcmp_saeco_fix==EVADTS_DDCMP_FIX_SAECO_ON)))
          {
              result=0;
              err=false;
              tmp_ptr=(((char *)msg_response)+DDCMP_SIZEOF_HEADER+msg_size);
              tmp_ptr=strcpy_ex(tmp_ptr,"@@@");
              snprintf(number, sizeof(number), "%d", msg_size+1);
              tmp_ptr=strcpy_ex(tmp_ptr,number);
              tmp_ptr=strcpy_ex(tmp_ptr,",");
              snprintf(number, sizeof(number), "%d", save_msg_size-2); // сообщаем о длине данных,
      которую передал нам аппарат tmp_ptr=strcpy_ex(tmp_ptr,number);
              tmp_ptr=strcpy_ex(tmp_ptr,"@@@");
              save_msg_size=((uint8_t *)tmp_ptr-(((uint8_t
      *)msg_response)+DDCMP_SIZEOF_HEADER+msg_size)); if (rec_size) *rec_size+=save_msg_size;
              auditd_debug("++++++ EVADTS_DDCMP_FIX_SAECO_ON +++++  @@@%d@@@ \n",msg_size+1);
          }*/
    }

    /// Временно!! Это Saeco тупит
    if ( ((auditbus_get_saeco_fix(bus) == EVADTS_DDCMP_FIX_SAECO_ON_TIMEOUT) && (!err))
      || ( auditbus_get_saeco_fix(bus) != EVADTS_DDCMP_FIX_SAECO_ON_TIMEOUT)
      || ((auditbus_get_saeco_fix(bus) == EVADTS_DDCMP_FIX_SAECO_ON_TIMEOUT) && (count <= DDCMP_MAX_DATA_ATTEMPTS_SAECO) )
    ) {
      if ((auditbus_get_saeco_fix(bus) == EVADTS_DDCMP_FIX_SAECO_ON_TIMEOUT) && (err)) {
        result = 0;
        err    = false;
        msg_size -= 2;  // убирем из буфера CRC, которое там должно быть
        tmp_ptr = (((char*)msg_response) + DDCMP_SIZEOF_HEADER + msg_size);
        // tmp_ptr=AppendIntValue(tmp_ptr, "@@@", msg_size+1, INT_VALUE);
        tmp_ptr = strcpy_ex(tmp_ptr, "@@@");
        snprintf(number, sizeof(number), "%d", msg_size + 1);
        tmp_ptr = strcpy_ex(tmp_ptr, number);
        // tmp_ptr=AppendIntValue(tmp_ptr, ",", save_msg_size-2, INT_VALUE);
        tmp_ptr = strcpy_ex(tmp_ptr, ",");
        // сообщаем о длине данных, которую передал нам аппарат
        snprintf(number, sizeof(number), "%d", save_msg_size - 2);
        tmp_ptr       = strcpy_ex(tmp_ptr, number);
        tmp_ptr       = strcpy_ex(tmp_ptr, "@@@");
        save_msg_size = ((uint8_t*)tmp_ptr - ((uint8_t*)msg_response));
        if (rec_size) {
          *rec_size = save_msg_size;
        }
        auditd_debug("+ EVADTS_DDCMP_FIX_SAECO_ON_TIMEOUT ++  @@@%d@@@\n", msg_size + 1);
      }

      // Rhevendors CINO не успевает перейти в режим приема подтверждения. Добавил задержку.
      usleep(DDCMP_TIMEOUT_TURN_AROUND*1000);
      if ( (msg_ack.ctrl_msg.cmd_type != DDCMP_CTRL_NACK)
         || ((auditbus_get_saeco_fix(bus) != EVADTS_DDCMP_FIX_JEDY_115200)
            && (auditbus_get_saeco_fix(bus) != EVADTS_DDCMP_FIX_SAECO_OFF_NAK_TIMEOUT))
      ) {
        DdcmpSendEnvelopeMsg(bus, &msg_ack);
      }
    }
    /// Временно!! Это Saeco тупит
  } while ((count) && (err == true));
  return (result);
}


/// Пробует открыть соединение по двум режимам DDCMP
/// 1. По стандартным правилам (EXTENDED - режим DDCMP)
/// 2. По нестандартным правилам (FIXED - режим DDCMP)
static ddcmpchar_t DdcmpInitializeChannel(auditbus_ddcmp_t* bus)
{
  log_func();
  const ddcmp_params_t* params    = auditbus_get_params(bus);
  bool                  extended  = true;
  ddcmpchar_t           result    = DDCMP_OK;
  uint8_t               sbd_rr;
  uint8_t               conn_type = DDCMP_WS_NOT_SET;
  uint8_t               ddcmp_baud_fixed_mode;

  smartio_logger_printf(auditbus_port(bus), "INIT\r\n");

  // Определяем скорость для fixed режима работы
  ddcmp_baud_fixed_mode = ddcmp_fix_baud_t_to_ddcmp_baud_e(params->ddcmp_fix_baud);
  bus->ddcmp_slave_adr  = DDCMP_SLAVE_ADDR;

  /// соединяется на 2400, спрашивает максимальную скорость
  // 1. Выставляем базовую скорость EXTENDED режим
  bus->mbd=DDCMP_BAUD_EXTENDED_MODE;
  ddcmp_msg_t msg_start={
    .ctrl_msg.cmd=DDCMP_CONTROL_MESSAGE,
    .ctrl_msg.cmd_type=DDCMP_CTRL_START,
    .ctrl_msg.status.q=1,
    .ctrl_msg.status.errcode=0,
    .ctrl_msg.status.f_end=0,
    .ctrl_msg.sbd_rr=0,
    .ctrl_msg.mbd=DDCMP_MAX_BAUD_EXTENDED_MODE,
  };

  // Включена максимальная скорость
  if ((params->ddcmp_saeco_fix==EVADTS_DDCMP_FIX_SAECO_115200) ||
      (params->ddcmp_saeco_fix==EVADTS_DDCMP_FIX_JEDY_115200)
  ) {
    msg_start.ctrl_msg.mbd=DDCMP_BAUD_115200;
  }
  sbd_rr=msg_start.ctrl_msg.sbd_rr;
  // Выбираем тип соединения
  if ((bus->conn_type != DDCMP_WS_NOT_SET) && (params->ddcmp_mode==EVADTS_DDCMP_AUTO)) {
    conn_type=bus->conn_type;
    switch (conn_type)
    {
    // Тип соединения EXTENDED адрес слейва 0x01
    case DDCMP_WS_EXT_ADR01 :
      extended=true;
      bus->ddcmp_slave_adr=DDCMP_SLAVE_ADDR;
      bus->mbd=DDCMP_BAUD_EXTENDED_MODE;
      break;
    // Тип соединения EXTENDED адрес слейва 0x10
    case DDCMP_WS_EXT_ADR10 :
      extended=true;
      bus->ddcmp_slave_adr=DDCMP_SLAVE_VMC;
      bus->mbd=DDCMP_BAUD_EXTENDED_MODE;
      break;
    // Тип соединения FIXED адрес слейва 0x01
    case DDCMP_WS_FIX_ADR01 :
      extended=false;
      bus->ddcmp_slave_adr=DDCMP_SLAVE_ADDR;
      msg_start.ctrl_msg.mbd=DDCMP_BAUD_UNCHANGED;
      bus->mbd=ddcmp_baud_fixed_mode;
      break;
    // Тип соединения FIXED адрес слейва 0x10
    case DDCMP_WS_FIX_ADR10 :
      extended=false;
      bus->ddcmp_slave_adr=DDCMP_SLAVE_VMC;
      msg_start.ctrl_msg.mbd=DDCMP_BAUD_UNCHANGED;
      bus->mbd=ddcmp_baud_fixed_mode;
      break;
    default :
      conn_type=DDCMP_WS_NOT_SET;
      extended=true;
      bus->ddcmp_slave_adr=DDCMP_SLAVE_ADDR;
      bus->mbd=DDCMP_BAUD_EXTENDED_MODE;
      break;
    }

  } else if (params->ddcmp_mode==EVADTS_DDCMP_EXT) {
    extended=true;
    bus->ddcmp_slave_adr=DDCMP_SLAVE_ADDR;
    bus->mbd=DDCMP_BAUD_EXTENDED_MODE;

  } else if (params->ddcmp_mode==EVADTS_DDCMP_FIX) {
    extended=false;
    bus->ddcmp_slave_adr=DDCMP_SLAVE_ADDR;
    msg_start.ctrl_msg.mbd=DDCMP_BAUD_UNCHANGED;
    bus->mbd=ddcmp_baud_fixed_mode;
  }

  // Сбрасываем защитный таймер. Все обошлось. Можно продолжать работу
  //Softdog_OnReturnedToMainLoop();
  // Цикл установления соединения START<->STACK
  while (1) {
    if (auditbus_should_stop((auditbus_t*)bus)) {
      result = -EINTR;
      break;
    }
    // Делаем задержку при переключении скорокстей. Для медленных монетников (Например JEDY 5700)
    usleep(DDCMP_TIMEOUT_TURN_AROUND * 1000);

    // сброс всего UART
    ddcmp_master_start_transfer(bus);

    // Выставляем адрес
    msg_start.ctrl_msg.sadd = bus->ddcmp_slave_adr;

    smartio_logger_printf(auditbus_port(bus), "BR %d", ddcmp_baud_to_speed_t(bus->mbd));

    smartio_set_comm_params(
        auditbus_port(bus), ddcmp_baud_to_speed_t(bus->mbd), SERIAL_WORDLEN_8_BIT,
        SERIAL_PARITY_NONE, SERIAL_FLOWCTL_NONE);

    auditd_debug("DDCMP: BaudRate =%d\n", ddcmp_baud_to_speed_t(bus->mbd));

    // Отправка START
    DdcmpSendEnvelopeMsg(bus, &msg_start);

    // Чтение Подтверждения
    result = ddcmp_check_ack(bus, DDCMP_CTRL_STACK, &sbd_rr, NULL);
    auditd_debug("DDCMP: ddcmp_check_ack [DDCMP_CTRL_STACK] =0x%x\n", result);

    if (result < 0 && result != DDCMP_TIMEOUT) {
      // Произошла неожиданная ошибка. Выходим.
      break;
    }

    if (result == DDCMP_TIMEOUT) {
      // Отклика нет меняем скорость и повторяем попытку
      // Пауза на восстановление возможности соединения
      delay_ms(DDCMP_TIMEOUT_LINK_H);
      if (conn_type != DDCMP_WS_NOT_SET) {
        break;
      }

      // Пауза на восстановление возможности соединения
      if (extended)
      {// В расширенном режиме пытаемся установить соединение
        if (bus->ddcmp_slave_adr!=DDCMP_SLAVE_ADDR)
        {
          bus->ddcmp_slave_adr=DDCMP_SLAVE_ADDR;
          // Фиксируем скорость
          msg_start.ctrl_msg.mbd=DDCMP_BAUD_UNCHANGED;
          bus->mbd=ddcmp_baud_fixed_mode;
          extended=false;
          if (params->ddcmp_mode==EVADTS_DDCMP_EXT)
            break;
          continue;
        }
        // Пробуем опросить по другому адресу
        bus->mbd=DDCMP_BAUD_EXTENDED_MODE;
        bus->ddcmp_slave_adr=DDCMP_SLAVE_VMC;

      } else {
        if (bus->ddcmp_slave_adr!=DDCMP_SLAVE_ADDR) {
          bus->ddcmp_slave_adr=DDCMP_SLAVE_ADDR;
          bus->mbd=DDCMP_MAX_BAUD_EXTENDED_MODE;
          extended=false;
          result=DDCMP_ERROR_NOSLAVES;
          break;
        }

        // Пробуем опросить по другому адресу
        bus->mbd=ddcmp_baud_fixed_mode;
        bus->ddcmp_slave_adr=DDCMP_SLAVE_VMC;
      }
      continue;
    } // if result==DDCMP_TIMEOUT


    // Запоминаем тип успешного соединения
    if (extended)
    {
      bus->conn_type = bus->ddcmp_slave_adr==DDCMP_SLAVE_ADDR
                        ? DDCMP_WS_EXT_ADR01
                        : DDCMP_WS_EXT_ADR10;
    } else {
      bus->conn_type = bus->ddcmp_slave_adr==DDCMP_SLAVE_ADDR
                        ? DDCMP_WS_FIX_ADR01
                        : DDCMP_WS_FIX_ADR10;
    }

    // Есть возможность на повышенную скорость?
    if (!sbd_rr || msg_start.ctrl_msg.mbd == DDCMP_BAUD_UNCHANGED) {
      // Возможности нет, остаемся и выходим
      break;
    }

    if (sbd_rr == bus->mbd) {
      break;
    }

    if (!ddcmp_baud_to_speed_t(sbd_rr)) {
      result = DDCMP_ERROR_UNKNOW_BAUDRATE;
      break;
    }

    // выбираем минимальную скорость, которую можно установить
    bus->mbd = min_u32(sbd_rr, msg_start.ctrl_msg.mbd);
    // Повышение скорости может привести к нестабильности получения данных.
    // Убираем возможность поднятия скорости более чем 9600
    // На Saeco выяснилось, что аппарат выдает поток данных с ошибками на низких скоростях.
    // На скорости 115200 Saeco выдает без ошибок (причем на всех аппаратах Saeco).
    // Повидимому Saeco формирует поток данных очень быстро и не контроллирует успешность
    // отправки байта и таким образом перезаписывает его у себя в исходящем буфере.
    if ((msg_start.ctrl_msg.mbd != sbd_rr) && (bus->need_increase_speed)) {
      msg_start.ctrl_msg.mbd = sbd_rr;
    } else {
      msg_start.ctrl_msg.mbd = DDCMP_BAUD_UNCHANGED;
    }
  } // while(1)

  // Меняем адрес на полученный в отклике от аппарата (некоторые аппараты, при ответе на 0x10,
  // отвечают с адреса 0x01)
  bus->ddcmp_slave_adr = msg_start.ctrl_msg.sadd;
  // Сбрасываем защитный таймер. Все обошлось. Можно продолжать работу
  //Softdog_OnReturnedToMainLoop();
  // watchdog_reset();
  return (result);
}

/// Отправка сообщений
static ddcmpchar_t DdcmpTransmitMessage(auditbus_ddcmp_t* bus, const void* msg, size_t size_msg, volatile ddcmp_msg_t **ret_msg_envelope)
{
    log_func();
    uint8_t Rx_n=0;
    uint8_t count=DDCMP_MAX_DATA_ATTEMPTS;
    ddcmpchar_t    result = DDCMP_OK;
    bus->tx_ack_number++;
    ddcmp_msg_t envelope_msg={
        .data_msg.cmd=DDCMP_DATA_MESSAGE,
        .data_msg.sadd=bus->ddcmp_slave_adr,
        .data_msg.Tx_n=bus->tx_ack_number,
        .data_msg.Rx_n=bus->rx_ack_number,
        .data_msg.status.q=1,
        .data_msg.status.f_end=0
    };
    // Укладываем длину пакета
    envelope_msg.data_msg.ls_len=size_msg&0xFF;
    envelope_msg.data_msg.status.ms_len=size_msg>>8;
    do{
      if (auditbus_should_stop((auditbus_t*)bus)) {
        result = -EINTR;
        break;
      }

      //Отправляем конверт
      DdcmpSendEnvelopeMsg(bus,&envelope_msg);

      // Отправляем тело письма
      smartio_logger_printf(auditbus_port(bus), "\r\n>Mdata ");
      DdcmpTransmitData(bus,msg,size_msg);

      // Ждем подтверждения
      result=ddcmp_check_ack(bus,DDCMP_CTRL_ACK,&Rx_n, ret_msg_envelope);
      auditd_debug("DDCMP: DdcmpTransmitMessage [DDCMP_CTRL_ACK] =0x%x\n",result);
      if (result == DDCMP_TIMEOUT) {
        break;
      }

      if (result < 0) {
        continue;
      }

      if (Rx_n != bus->tx_ack_number)
      {
        result = DDCMP_RXN_NOT_TXN;
        continue;
      }
    } while(result && (count--));

    return(result);
}

/// Проверяем отклик на команду WhoAreYou
/// Без ее запроса данные не получить!
static ddcmpchar_t DdcmpCheckWAY(auditbus_ddcmp_t* bus)
{
    log_func();

    time_t      now = time(NULL);
    struct tm   t;
    localtime_r(&now, &t);

    ddcmp_msg_t volatile return_msg_envelope;
    ddcmp_msg_t volatile *ptr_return_msg_envelope=&return_msg_envelope;
    ddcmp_rsp_t rsp_way;
    ddcmp_req_t way_msg={
        .cmd_msg=DDCMP_COMMAND_MESSAGE,
        .cmd=DDCMP_CMD_WAY,
        .ack=0,
        .bodys.E0.day=BinToBCD(t.tm_mday),
        .bodys.E0.month=BinToBCD(t.tm_mon + 1),
        .bodys.E0.year=BinToBCD(t.tm_year % 100),
        .bodys.E0.hours=BinToBCD(t.tm_hour),
        .bodys.E0.minutes=BinToBCD(t.tm_min),
        .bodys.E0.seconds=BinToBCD(t.tm_sec),
        .bodys.E0.maintenance=0x0B
    };
    *((uint16_t*)&way_msg.bodys.E0.secure)=((bus->ddcmp_secure_code&0xFF)<<8)|((bus->ddcmp_secure_code&0xFF00)>>8);
    *((uint16_t*)&way_msg.bodys.E0.password)=((bus->ddcmp_psw&0xFF)<<8)|((bus->ddcmp_psw&0xFF00)>>8);
    *((uint16_t*)&way_msg.bodys.E0.userid)=0x0457; // в шину должно выйти 0x57 0x04
    // Отправляем запрос
    ddcmpchar_t result = DdcmpTransmitMessage(bus,&way_msg,sizeof(way_msg.bodys.E0)+DDCMP_SIZEOF_HEADER, &ptr_return_msg_envelope);
    auditd_debug("DDCMP: DdcmpCheckWAY - [DdcmpTransmitMessage] =0x%x\n",result);
    if (result==DDCMP_OK)
    {
        // Ждем ответа
        result=DdcmpReceiveData(bus,&rsp_way,sizeof(rsp_way.bodys.E0)+DDCMP_SIZEOF_HEADER, NULL, ptr_return_msg_envelope);
        auditd_debug("DDCMP: DdcmpCheckWAY - [DdcmpReceiveData] =0x%x\n",result);
        if (!result)
        {
            bus->SW_ver=rsp_way.bodys.E0.SW_ver;
        }
        else
            result=SetErrorResult(result, DDCMP_FUNC_DdcmpCheckWAY_DdcmpReceiveData);
        // Разберем ответ если нужно
    }
    else
        result=SetErrorResult(result, DDCMP_FUNC_DdcmpCheckWAY_DdcmpTransmitMessage);
    return(result);
}

/// Запускаем процесс считывания данных
/// Без ее запроса данные не получить!
static ddcmpchar_t DdcmpEnableReadData(auditbus_ddcmp_t* bus, enum DdcmpTypeOfLists type_of_audit)
{
    log_func();
    ddcmp_msg_t volatile return_msg_envelope;
    ddcmp_msg_t volatile *ptr_return_msg_envelope=&return_msg_envelope;
    ddcmp_rsp_t rsp_rd;
    ddcmp_req_t rd_msg={
        .cmd_msg=DDCMP_COMMAND_MESSAGE,
        .cmd=DDCMP_CMD_RD,
        .ack=0,
        .bodys.E2.record_n=0x01,
    };
    *((uint16_t*)&rd_msg.bodys.E2.offset)=0;
    *((uint16_t*)&rd_msg.bodys.E2.segment_len)=0;
    rd_msg.bodys.E2.list_n=type_of_audit;
    // сброс номера ожидаемого блока на ноль
    bus->block_number=0;
    // Отправляем запрос
    ddcmpchar_t result = DdcmpTransmitMessage(bus,&rd_msg,sizeof(rd_msg.bodys.E2)+DDCMP_SIZEOF_HEADER, &ptr_return_msg_envelope);
    auditd_debug("DDCMP: DdcmpEnableReadData - [DdcmpTransmitMessage] =0x%x\n",result);
    if (result==DDCMP_OK)
    {
        // Ждем ответа
        result=DdcmpReceiveData(bus,&rsp_rd,sizeof(rsp_rd.bodys.E2)+DDCMP_SIZEOF_HEADER, NULL, ptr_return_msg_envelope);
        auditd_debug("DDCMP: DdcmpEnableReadData - [DdcmpReceiveData] =0x%x\n",result);
        // Разберем ответ если нужно
        if (!result)
        {
            // Определим признак окончания получения данных
            bus->data_receive_len=(((uint16_t)rsp_rd.bodys.E2.segment_len[1])<<8)|((uint16_t)rsp_rd.bodys.E2.segment_len[0]);
            bus->data_end_flg=0;
            if (bus->data_receive_len==0xFFFF)
                bus->data_end_flg=1;
        }
        else
            result=SetErrorResult(result, DDCMP_FUNC_DdcmpEnableReadData_DdcmpReceiveData);
    }
    else
        result=SetErrorResult(result,DDCMP_FUNC_DdcmpEnableReadData_DdcmpTransmitMessage);
    return(result);
}

/// Прекращаем работу
static ddcmpchar_t DdcmpFinal(auditbus_ddcmp_t* bus)
{
    log_func();
    uint8_t fin_msg[]={
        DDCMP_COMMAND_MESSAGE,
        DDCMP_CMD_FIN
    };
    // Отправляем запрос
    ddcmpchar_t result = DdcmpTransmitMessage(bus,&fin_msg,sizeof(fin_msg), NULL);
    return(result);
}





////////////////////////////////////////////////////////////////////////////
//  Основная функция чтения данных

static int32_t ddcmp_get_audit_data(auditbus_ddcmp_t* bus, bool only_check)
{
  log_func();
  DEBUGASSERT(bus);

  int32_t               result              = 0;
  size_t                rec_size            = 0;
  bool                  block_number_is_set = false;
  const ddcmp_params_t* params              = auditbus_get_params(bus);
  smartio_t*            port                = auditbus_port(bus);
  finfile_t*            dst                 = auditbus_outfile(bus);
  enum DdcmpTypeOfLists type_of_audit;


  if (params->ddcmp_auditmode == EVADTS_DDCMP_AUDIT_CFG) {
    type_of_audit=DDCMP_E2_ALL_DATA;
  } else if (params->ddcmp_auditmode == EVADTS_DDCMP_AUDIT_RST) {
    type_of_audit=DDCMP_E2_AUDIT;
  } else {
    type_of_audit=DDCMP_E2_AUDIT_WOR;
  }

  auditbus_on_state_changed(bus, AUDIT_STATE_DDCMP_CONNECTING);

  ddcmp_reset_timer_d(bus);

  smartio_logger_printf(port, "Raw log.\r\n");
  auditd_trace("ddcmp_get_audit_data(): Sending connect request.\n");

  // Пытаемся уставновить соединение
  result = DdcmpInitializeChannel(bus);
  auditd_trace("ddcmp_get_audit_data(): Sent connect request. result=%d\n", result);

  if (result < 0) {
    result=SetErrorResult(result,DDCMP_FUNC_DdcmpInitializeChannel);
  }

  uint8_t conn_type=bus->conn_type;

  if ((result) && (conn_type!=DDCMP_WS_NOT_SET) && (params->ddcmp_mode==EVADTS_DDCMP_AUTO))
  {// Ошибка
    auditd_debug("DDCMP: DdcmpInitializeChannel =0x%x.\n",result);
    auditd_debug("DDCMP: Type of connection %d is failed.\n",conn_type);

    // Сбрасываем тип установленного соединения
    bus->conn_type = DDCMP_WS_NOT_SET;

    // Повторяем попытку поиска слейва
    auditd_debug("DDCMP: Reset type of connection and try again....\n");
    result = DdcmpInitializeChannel(bus);
    if (result) {
      result=SetErrorResult(result,DDCMP_FUNC_DdcmpInitializeChannel_ret);
    }
  }
  // Возвращаем тип соединения

  // Тут какая-то "криптографическая" дичь
  // if (error)
  // {
  //   if (bus->ptr_type_of_connection)
  //     *error=*bus->ptr_type_of_connection+(ddcmp_baud_to_speed_t(bus->mbd)*1000)+(type_of_audit*10);
  // }

  auditd_debug("DDCMP: DdcmpInitializeChannel =0x%x\n",result);


  if (only_check)
  {
    auditbus_on_state_changed(bus, AUDIT_STATE_IDLE);
    return result;
  }

  if (result < 0) {
    // Ошибка установления соединения DDCMP
    auditd_error("DDCMP connection error. =0x%x\n",result);
    goto cleanup_without_connection;
  }

  // Получение данных

  // Пытаемся послать Who Are You
  auditd_trace("Getting WhoAreYou ...\n");
  smartio_logger_printf(port, "\r\nWAY\r\n");

  result = DdcmpCheckWAY(bus);
  auditd_debug("DDCMP: DdcmpCheckWAY =0x%x\n",result);
  if (result < 0) {
    // Ошибка подключения WAY
    auditd_error("DDCMP error WhoAreYou =0x%x\n",result);
    goto cleanup_with_connection;
  }

  // Теперь пытаемся перевести аппарат в выдачу нам данных
  smartio_logger_printf(port, "\r\nEN RD\r\n");

  result = DdcmpEnableReadData(bus, type_of_audit);
  auditd_debug("DDCMP: DdcmpEnableReadData =0x%x\n",result);
  if (result < 0) {
    // Ошибка включения режима чтения данных
    auditd_error("DDCMP error command Read Data (0xE2) =0x%x\n",result);
    goto cleanup_with_connection;
  }

  // Получение данных
  auditd_trace("Reading data on DDCMP ...\n");
  smartio_logger_printf(port, "\r\nRD\r\n");

  // Пробуем запросить данные
  auditbus_on_state_changed(bus, AUDIT_STATE_DDCMP_DATA_TRANSFER);
  block_number_is_set=false;

  while(1)
  {
      if (auditbus_should_stop((auditbus_t*)bus)) {
        result = -EINTR;
        goto cleanup_with_connection;
      }

      // Ждем ответа
      result=DdcmpReceiveData(bus, bus->rx_buffer, sizeof(bus->rx_buffer), &rec_size, NULL);
      // переопрделеим на всякий случай стартовый номер блока
      if (!block_number_is_set)
      {
        block_number_is_set=true;
        bus->block_number = bus->rx_buffer[1];
      }

      // Вывод информации в логи
      smartio_logger_printf(port, "\r\nDATA BLOCK %d, size %d\r\n", bus->block_number, rec_size);
      auditd_debug("DDCMP: DdcmpReceiveData          =0x%x\n",result);
      auditd_debug("DDCMP: DdcmpReceiveData rec_size =%d\n",rec_size);

      if (result < 0) {
        auditd_error("DDCMP DdcmpReceiveData result   =0x%x\n",result);
        auditd_debug("DDCMP error read EVA-DTS (0x99) =0x%x\n",*dst);
        result=SetErrorResult(result,DDCMP_FUNC_ReadingData);
        // Ошибка получения пакета данных (рассинхронизация)
        goto cleanup_with_connection;
      }

      // Получили данные?
      if ( bus->rx_buffer[0] != DDCMP_APPLICATION_DATA_MESSAGE
        || bus->rx_buffer[1] != bus->block_number
      ) {
        // Ошибка получения пакета данных (рассинхронизация)
        auditd_error("DDCMP       (0x99)              =0x%x\n",*dst);
        auditd_error("DDCMP        block              =0x%x\n",*(dst+1));
        auditd_error("DDCMP        bus->block_number  =0x%x\n",bus->block_number);
        result=DDCMP_FUNC_ReadingData+DDCMP_ERROR_BLOCK_OR_APLMSG;
        goto cleanup_with_connection;
      }

      // Данные получены
      auditd_debug("DDCMP read EVA-DTS block =%d\n",bus->block_number);
      bus->block_number++;

      // Записываем их в выходной файл
      // в полезный объем данных не попадает номер команды 99 и номер блока
      if (rec_size > 2) {
        finfile_write(dst, &bus->rx_buffer[2], rec_size-2);
      }

      if (!bus->data_end_flg)
      {// Ориентируемся по длине
        bus->data_receive_len-=rec_size;
      }
      // Определяем признак окончания
      if (((!bus->data_end_flg) && (bus->data_receive_len<=0))
        ||((bus->data_end_flg) && (bus->rec_flag_end))
      ) {
        // Признак окончания получен. Выходим
        result = finfile_size(dst);
        break;
      }
  } // while(...)

cleanup_with_connection:
  // Отправляем команду FIN
  DdcmpFinal(bus);

cleanup_without_connection:
  // Выходим
  if (result < 0) {
    auditbus_on_state_changed(bus, AUDIT_STATE_ERROR);
    auditd_debug("ddcmp_get_audit_data(): fail with err=%x\n", result);

    if (result == DDCMP_ERROR_RECEIVE_DATA_OUT_OF_MEMMORY) {
      // ошибка - нехватка памяти. Выходим с ошибкой, но при этом позволяем отправить кусок отчета
      auditd_error("ddcmp_get_audit_data(): No buffer space\n");
      result = finfile_size(dst);
    }
    return result;
  }

  auditbus_on_state_changed(bus, AUDIT_STATE_IDLE);
  auditd_debug("ddcmp_get_audit_data(): received %d bytes.\n", received_size);

  if (finfile_isoverflow(dst)) {
    auditd_warn(
      "DDCMP Not enough storage for EVA DTS report. Storage size: %d, Report size: %d.\n",
      finfile_size(dst), finfile_virtual_size(dst)
    );
  }
  return result;
}

////////////////////////////////////////////////////////////////////////////
//  Реализация функций интерфейса `auditbus`

static int ddcmp_probe(auditbus_t* bus)
{
  DEBUGASSERT(bus);
  int32_t result = ddcmp_get_audit_data((auditbus_ddcmp_t*)bus, /* onlycheck = */ true);
  if (result < 0) {
    return -EPROTO;
  }
  return 0;
}


static int32_t ddcmp_get_audit(auditbus_t* bus)
{
  return ddcmp_get_audit_data((auditbus_ddcmp_t*)bus, /* onlycheck = */ false);
}

static int ddcmp_destroy(auditbus_t* bus)
{
  // Здесь нечего делать.
  (void)bus;
  return 0;
}

////////////////////////////////////////////////////////////////////////////
//  Публичные функции

int auditbus_ddcmp_create(
  auditbus_ddcmp_t*     instance,
  auditd_t*             owner,
  int                   instance_id,
  audit_interface_t     interface,
  eventq_t*             eventq,
  const char*           port_path,
  const char*           out_path,
  const ddcmp_params_t* params
)
{
  static const auditbus_vmt_t   AUDITBUS_DDCMP_VMT = {
    .probe      = ddcmp_probe,
    .get_audit  = ddcmp_get_audit,
    .destroy    = ddcmp_destroy
  };

  int ret;


  ret = auditbus_create(
    instance,
    &AUDITBUS_DDCMP_VMT,
    owner,
    instance_id,
    eventq,
    port_path,
    out_path,
    AUX_TYPE_AUDIT_DDCMP,
    interface,
    "ddcmp",
    params
  );

  if (ret < 0) {
    return ret;
  }

  return 0;
}
