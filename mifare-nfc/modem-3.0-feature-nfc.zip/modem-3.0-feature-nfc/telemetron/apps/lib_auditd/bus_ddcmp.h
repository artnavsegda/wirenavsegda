/// \file
/// \brief  Реализация протокола DDCMP
/// \author DL <dmitriy@linikov.ru>
/// \author AS <a.syrenkov@telemetron.net>
/// \note Данный файл основан на коде из проекта modem-2.7, автор AS

#ifndef TELEMETRON_APPS_LIB_AUDITD_BUS_DDCMP_H_INCLUDED
#define TELEMETRON_APPS_LIB_AUDITD_BUS_DDCMP_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <errno.h>
#include <utils/timeout.h>
#include <utils/smartio_crc16.h>
#include <auditd/audit_state.h>
#include "auditbus.h"

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Типы данных

/// \brief Тип режима работы при установлении связи с торговым аппаратом.
typedef enum ddcmp_conntype_e {
    DDCMP_WS_NOT_SET =0,                ///< Тип соединения не установлен
    DDCMP_WS_EXT_ADR01,                 ///< Тип соединения EXTENDED адрес слейва 0x01
    DDCMP_WS_EXT_ADR10,                 ///< Тип соединения EXTENDED адрес слейва 0x10
    DDCMP_WS_FIX_ADR01,                 ///< Тип соединения FIXED адрес слейва 0x01
    DDCMP_WS_FIX_ADR10                  ///< Тип соединения FIXED адрес слейва 0x10
} ddcmp_conntype_t;


typedef struct auditbus_ddcmp_s {
  /// \brief Наследуемся от auditbus_t.
  auditbus_t        base;
  uint8_t           mbd;                  ///< индекс скорости DDCMP UART
  uint8_t           ddcmp_slave_adr;      ///< адрес слейва
  uint16_t          ddcmp_psw;            ///< пароль
  uint16_t          ddcmp_secure_code;    ///< код

  /// \brief Таймер A служит для обнаружения отсутствия ответа после приёма
  /// команды начала передачи (ENQ). Обычно, это 1 секунда.
  timeout_t       timer_a;

  /// \brief Таймер D служит для обнаружения зависания сессии (т.е. максимальное
  /// время бездействия после открытия сессии - максимальное время между блоками
  /// данных). Обычно это TimerA + 2 секунды.
  timeout_t         timer_d;
  bool              rx_ack_number_is_set;
  bool              need_increase_speed;
  uint8_t           rx_ack_number;
  uint8_t           tx_ack_number;
  smartio_crc16_t   rx_crc;
  smartio_crc16_t   tx_crc;

  int32_t           data_receive_len;     ///< количество получаемых данных по команде DDCMP_APPLICATION_DATA_MESSAGE
  uint8_t           data_end_flg;         ///< тип определения окончания блока данных (1 - по флагу, 0 - по data_receive_len)
  uint8_t           rec_flag_end;         ///< Значение полученого флага окончания
  uint8_t           block_number;         ///< Номер ожидаемого блока данных
  uint8_t           SW_ver;               ///< Версия ПО аппарата
  ddcmp_conntype_t  conn_type;            ///< Тип режима работы при установлении связи с торговым аппаратом.

  /// \brief Признак того, что в slave режиме была получена команда начала
  /// передачи данных.
  bool              transaction_active;

  uint8_t           rx_buffer[280];       ///< Буффер для принимаемых данных
} auditbus_ddcmp_t;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int auditbus_ddcmp_create(
  auditbus_ddcmp_t*     instance,
  auditd_t*             owner,
  int                   instance_id,
  audit_interface_t     interface,
  eventq_t*             eventq,
  const char*           port_path,
  const char*           out_path,
  const ddcmp_params_t* params
);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_LIB_AUDITD_BUS_DDCMP_H_INCLUDED
