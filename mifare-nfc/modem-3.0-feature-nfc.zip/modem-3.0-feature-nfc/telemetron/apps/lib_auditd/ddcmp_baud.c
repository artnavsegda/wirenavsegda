/// \file
/// \brief  Функции работы с перечислением ddcmp_baud_e
/// \author DL <dmitriy@linikov.ru>

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "ddcmp_baud.h"

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <settings/settings.h>

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных

// Структура записи соответствия индекса скорости
typedef struct {
  uint8_t index;
  speed_t baudrate;
} ddcmpbauds_t;


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы

static const ddcmpbauds_t DDCMP_BAUDS[]={
  {DDCMP_BAUD_UNCHANGED,  0},
  {DDCMP_BAUD_1200,       B1200},
  {DDCMP_BAUD_2400,       B2400},
  {DDCMP_BAUD_4800,       B4800},
  {DDCMP_BAUD_9600,       B9600},
  {DDCMP_BAUD_19200,      B19200},
  {DDCMP_BAUD_38400,      B38400},
  {DDCMP_BAUD_57600,      B57600},
  {DDCMP_BAUD_115200,     B115200}
};

////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Приватные функции


////////////////////////////////////////////////////////////////////////////
//  Публичные функции


/// Возвращает значение скорости по индексу
/// 0 - скорсть неопределена.
speed_t ddcmp_baud_to_speed_t(enum ddcmp_baud_e baud)
{
  uint32_t count = sizeof(DDCMP_BAUDS) / sizeof(DDCMP_BAUDS[0]);
  while (count--) {
    if (DDCMP_BAUDS[count].index == baud) {
      return (DDCMP_BAUDS[count].baudrate);
    }
  }
  return (0);
}

enum ddcmp_baud_e ddcmp_fix_baud_t_to_ddcmp_baud_e(enum ddcmp_fix_baud_e baud)
{
  enum ddcmp_baud_e   result;
  switch (baud) {
  // Фиксированная скорость 9600 - используется в аппаратах NEcts, когда в настройках сменили
  // протокол аудита с DEX на DDCMP и забыли изменить скорость с 9600 на 2400
  case EVADTS_DDCMP_FIX_9600:     return DDCMP_BAUD_9600;

  // Фиксированная скорость 19200 - используется в аппаратах Шпенглер (Shpengler)
  case EVADTS_DDCMP_FIX_19200:    return DDCMP_BAUD_19200;

  // Фиксированная скорость 38400.
  case EVADTS_DDCMP_FIX_38400:    return DDCMP_BAUD_38400;

  // Фиксированная скорость 57600.
  case EVADTS_DDCMP_FIX_57600:    return DDCMP_BAUD_57600;

  // Фиксированная скорость 115200.
  case EVADTS_DDCMP_FIX_115200:   return DDCMP_BAUD_115200;

  // Фиксированная скорость 2400. Во всех остальных случаях
  default:                        return DDCMP_BAUD_2400;
  }
}
