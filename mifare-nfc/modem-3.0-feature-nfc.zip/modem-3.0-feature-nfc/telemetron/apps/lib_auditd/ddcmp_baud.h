/// \file
/// \brief  Перечисление enum ddcmp_baud_e и функции работы с ним
/// \author DL <dmitriy@linikov.ru>
///
/// Перечисление enum ddcmp_baud_e описывает скорость работы
/// последовательного порта при работе с DDCMP протоколом

#ifndef TELEMETRON_APPS_LIB_AUDITD_DDCMP_BAUD_H_INCLUDED
#define TELEMETRON_APPS_LIB_AUDITD_DDCMP_BAUD_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <stdbool.h>
#include <termios.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Типы данных

// Предварительное объявление для ddcmp_fix_baud_e из settings/settings.h
// - что бы не тянуть дополнительные зависимости в заголовочный файл.
enum ddcmp_fix_baud_e;

enum ddcmp_baud_e {
  DDCMP_BAUD_UNCHANGED  = 0x00,
  DDCMP_BAUD_1200       = 0x01,
  DDCMP_BAUD_2400       = 0x02,
  DDCMP_BAUD_4800       = 0x03,
  DDCMP_BAUD_9600       = 0x04,
  DDCMP_BAUD_19200      = 0x05,
  DDCMP_BAUD_38400      = 0x06,
  DDCMP_BAUD_57600      = 0x07,
  DDCMP_BAUD_115200     = 0x08
};


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

speed_t ddcmp_baud_to_speed_t(enum ddcmp_baud_e value);
enum ddcmp_baud_e ddcmp_fix_baud_t_to_ddcmp_baud_e(enum ddcmp_fix_baud_e baud);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_LIB_AUDITD_DDCMP_BAUD_H_INCLUDED
