/// \file
/// \brief  Реализация протокола Gerhardt для снятия отчетов аудита.
/// \author DL <dmitriy@linikov.ru>


////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "bus_gerhardt.h"

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <sysutils/crc.h>

#include <utils/math_utils.h>
#include <utils/string_utils.h>

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора

#define GERHARDT_BAUDRATE_2400          B2400
#define GERHARDT_BAUDRATE_9600          B9600
// Стандартная скорость для Gerhardt
#define GERHARDT_BAUDRATE_19200         B19200
#define GERHARDT_BAUDRATE_38400         B38400
#define GERHARDT_BAUDRATE_57600         B57600
#define GERHARDT_BAUDRATE_115200        B115200
// Максимальное время чтеняи данных из аппарат Gerhardt на скорости GERHARDT_BAUDRATE
#define MAX_GERHARDT_TIME               60000
#define MAX_GERHARDT_TIME_ONLY_CHECK    20000
// Время получения одного символа
#define GERHARDT_TIME_ONE_CHAR          2000
// Время получения символа во время запуска
#define GERHARDT_TIME_SMALL_CHAR        10
// Время импульса
#define GERHARDT_TIME_TO_START          100
// Время разрешенного повтора запроса
#define GERHARDT_REPEAT_REQ_TIME        15000


#define GERHARDT_CFG_SMALL_CHAR_RANGE         1

#define GERHARDT_START_STRING           "ID1*"
#define GERHARDT_END_STRING             "EVADTS Daten"
#define GERHARDT_START_INCLUDE          "DXS*GERHARDT*VA*V1.0*1**\r\n"
#define GERHARDT_END_INCLUDE            "DXE*1*0\r\n"
#define GERHARDT_RESTART_STRING         "activate printout with"
#define GERHARDT_LRN_STRING             "\r\n\r"

// Максимальное количество символов после символовокончаняи передачи данных
#define GERHARDT_MAX_COUNT_ENDS         3

#define GERHARDT_CTS_ON                 true
#define GERHARDT_CTS_OFF                false


#define log_func()      auditd_trace("%s\n", __FUNCTION__)

#ifdef CONFIG_AUDITD_BUS_GERHARDT_LOG_RX
# define log_rx(value)   auditd_trace("GerRx:%02X\n", (value))
#else
# define log_rx(value)   ((void)value)
#endif



////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных

/// \brief  Вспомогательная структура для поточного детектирования строк
typedef struct {
    char*       ptr;      ///< Указатель на искомую строку
    uint32_t    index;    ///< Индекс в строке текущего проверяемого символа
} search_state_t;


/// \brief  Тип чтения данных Gerhardt
typedef int32_t   gerhardtchar_t;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Приватные функции

/// \brief Читает из шины \p bus один байт данных, при не обходимости
/// подсчитывая контрольную сумму. При таймауте закрывает сессию.
static gerhardtchar_t gerhardt_read_raw(auditbus_gerhardt_t* bus)
{
  if (timeout_is_elapsed(&bus->timer_d)) {
    return IO_ERR_TIMEOUT;
  }

  systime_t   timerd_ticks  = timeout_ticks_left(&bus->timer_d);
  systime_t   ms_to_wait    = min_u32(
    timerd_ticks,
    bus->restart ? GERHARDT_TIME_SMALL_CHAR : GERHARDT_TIME_ONE_CHAR
  );

  int result = smartio_nbgetc(auditbus_port(bus), ms_to_wait);
  log_rx(result);
  return result;
}

/// \brief Сбрасывает таймер обратного отсчёта TimerD (максимальное время между
/// транзакциями одной сессии) к начальному значению.
static inline void gerhardt_reset_timer_d(auditbus_gerhardt_t* bus, bool only_check)
{
  log_func();
  uint32_t max_time=MAX_GERHARDT_TIME;
  if (only_check) max_time=MAX_GERHARDT_TIME_ONLY_CHECK;
  timeout_start(&bus->timer_d, max_time);
}


/// Процедура поиска строки в строке посимвольно.
/// Возвращает true, когда строки совпали
static bool gerhardt_search_char(char c, search_state_t* look_for)
{
  char* str=look_for->ptr;

  if (c != str[look_for->index]) {
    look_for->index = 0;
    return false;
  }

  look_for->index++;
  if (str[look_for->index] != '\0') {
    return false;
  }

  look_for->index = 0;
  return true;
}

/// \brief Читает из шины \p bus данные аудита, сохраняя их в буффер \p dst,
/// размером \p s.
/// \return В случае успеха возвращает указатель на конец записанных в буффер
/// данных (на нуль-символ).
/// Если же запрос завершился ошибкой, то возвращает NULL.
static int32_t gerhardt_get_audit_data(auditbus_gerhardt_t* bus, bool only_check)
{
  // static char* gerhardt_get_audit_data(GerhardtHandle bus, char* dst, size_t s, uint32_t* error, bool only_check)

  log_func();

  DEBUGASSERT(bus);

  int32_t     ret   = 0;
  finfile_t*  dst   = auditbus_outfile(bus);
  smartio_t*  port  = auditbus_port(bus);


  //char*     dst_end = dst + s - 1; // резервируем место для '\0'
  size_t    received_size = 0;
  //char *    dst_report=dst;
  //char *    save_dst=dst;
  //char *    dst_end_report=dst_end;

  auditbus_on_state_changed(bus, AUDIT_STATE_CONNECTING);

  /// \todo Gerhardt - добавить возможность выбирать фиксированную скорость порта
  // Выбираем скорость работы порта
  speed_t baudrate = B19200;
  // if (g_settings.ddcmp_params[n].evadts.ddcmp_mode==EVADTS_DDCMP_FIX)
  // {
  //   // Определяем скорость для fixed режима работы
  //   switch (g_settings.ddcmp_params[n].evadts.ddcmp_fix_baud)
  //   {
  //       // Фиксированная скорость 9600
  //       case EVADTS_DDCMP_FIX_9600 :
  //           baudrate=GERHARDT_BAUDRATE_9600;
  //           break;
  //       // Фиксированная скорость 19200 - используется в аппаратах Шпенглер (Shpengler) Gerhardt
  //       case EVADTS_DDCMP_FIX_19200 :
  //           baudrate=GERHARDT_BAUDRATE_19200;
  //           break;
  //       // Фиксированная скорость 38400.
  //       case EVADTS_DDCMP_FIX_38400 :
  //           baudrate=GERHARDT_BAUDRATE_38400;
  //           break;
  //       // Фиксированная скорость 57600.
  //       case EVADTS_DDCMP_FIX_57600 :
  //           baudrate=GERHARDT_BAUDRATE_57600;
  //           break;
  //       // Фиксированная скорость 115200.
  //       case EVADTS_DDCMP_FIX_115200 :
  //           baudrate=GERHARDT_BAUDRATE_115200;
  //           break;
  //       // Фиксированная скорость 2400. Во всех остальных случаях
  //       default :
  //           baudrate=GERHARDT_BAUDRATE_2400;
  //           break;
  //   }
  // }

  smartio_set_comm_params(port, baudrate, SERIAL_WORDLEN_8_BIT, SERIAL_PARITY_NONE, SERIAL_FLOWCTL_NONE);

  // Читаем в цикле куски данных.
  //smartio_discard_rx(port, 0);
  gerhardt_reset_timer_d(bus, only_check);
  smartio_logger_printf(port,"Raw log.\r\n");



  // Чистим буфер
  smartio_discard_rx(port, 0);
  auditd_info("Gerhardt connect\n");
  // Анализируем куски на предмет наличия в них строки окончания данных \r\nDXE* (DXS* начало транзакции!)
  bool synchro=false;
  bool start=false;
  bool end=false;
  bool restart=false;
  timeout_t restart_period={.start=0,};
  //uint16_t count_end_chars=GERHARDT_MAX_COUNT_ENDS;
  search_state_t gerhardt_start_str={GERHARDT_START_STRING,0};
  search_state_t gerhardt_end_str={GERHARDT_END_STRING,0};
  search_state_t gerhardt_lrn_str={GERHARDT_LRN_STRING,0};

  //static search_state_t gerhardt_restart_str={GERHARDT_RESTART_STRING,0};
  // Сбрасываем защитный таймер. Все обошлось. Можно продолжать работу
  //Softdog_OnReturnedToMainLoop();
  /// Сообщаем машине о желании поучить данные
  smartio_send_brake(port, GERHARDT_CTS_ON);
  while (1)
  {
    gerhardtchar_t response;
    if (auditbus_should_stop((auditbus_t*)bus)) {
      ret = -EINTR;
      break;
    }

    if (timeout_is_elapsed(&bus->timer_d)) {
      // Истекло время ожидания ответа. Завершаем работу.
      ret = -ETIMEDOUT;
      break;
    }

    // Отрабатываем импульс запуска
    if (bus->restart)
    {
      if ((restart_period.start) && (timeout_is_elapsed(&restart_period)))
      {
        if (!restart)
        {
          //Softdog_OnReturnedToMainLoop();
          gerhardt_reset_timer_d(bus, only_check);
          restart=true;
        }
        smartio_logger_printf(port, "\r\nCTS_ON.\r\n");
        smartio_send_brake(port, GERHARDT_CTS_ON);
        bus->restart=false;
        restart_period.start=0;
        // Сброс синхронизации
        start=false;
        gerhardt_start_str.index=0;
        gerhardt_end_str.index=0;

      } else if (!restart_period.start) {
        timeout_start(&restart_period, GERHARDT_TIME_TO_START);
        smartio_send_brake(port, GERHARDT_CTS_OFF);
        smartio_logger_printf(port, "\r\nCTS_OFF.\r\n");
      }
    }

    // Формируем начало
    if ((synchro) && (!start))
    {
      if (only_check) {
        // Функция вызвана в режиме проверки, что автомат работает по протоколу Gerhardt.
        // Обнаружили маркер начала данных - значит проверка успешно завершена.
        ret = 0;
        break;
      }

      start=true;
      auditbus_on_state_changed(bus, AUDIT_STATE_DATA_TRANSFER);
      smartio_logger_printf(port, "Gerhardt start.\r\n");
      finfile_write(dst, GERHARDT_START_INCLUDE, strlen(GERHARDT_START_INCLUDE));
      finfile_write(dst, GERHARDT_START_STRING, strlen(GERHARDT_START_STRING));
    }

    // Читаем байт
    response = ret = gerhardt_read_raw(bus);

    if (ret == -ETIMEDOUT) {
      // Поиск уведомления о необходимости сброса
      if (!bus->restart) {
        bus->restart=true;
      }
      continue;
    }

    if (ret < 0) {
      // При получении других ошибок, кроме таймаута, завершаем работу
      auditd_error("Gerhardt can't read, ret=%d (%s)\n", ret, strerror(-ret));
      break;
    }

    // Поиск начала и конца данных
    if (!start) {
      // Поиск начала данных
      synchro=gerhardt_search_char(response, &gerhardt_start_str);
      // Поиск уведомления о необходимости сброса
      //if (!bus->restart) bus->restart=gerhardt_search_char(response, &gerhardt_restart_str);

    } else {
      // конец
      end=gerhardt_search_char(response, &gerhardt_end_str);
      if (end) {
        smartio_logger_printf(port, "Gerhardt end.\r\n");

      } else {
        // Поиск последовательности 0x0D 0x0A 0x0D и \убираем последний символ 0x0D
        if (gerhardt_search_char(response, &gerhardt_lrn_str)) {
          continue;
        }
      }
    }

    // Запись символа
    received_size++;
#ifdef GERHARDT_CFG_SMALL_CHAR_RANGE
    if (response < 0 || response > 127) {
      auditd_warn(
        "gerhardt_receive(): Rx invalid value [0x%04X] in DATA mode\n",
        response
      );
      finfile_printf(dst, "@@@%02X@@@", response);

    }
    else
#endif // GERHARDT_CFG_SMALL_CHAR_RANGE
    {
      finfile_putc(dst, response);
    }

    if (end)  {
      // Вставляем префикс окончания
      finfile_write(dst, GERHARDT_END_INCLUDE, strlen(GERHARDT_END_INCLUDE));
      ret = finfile_size(dst);
      break;
    }
  } // while ((count_end_chars) && (!timeout_is_elapsed(&bus->timer_d)))
  smartio_send_brake(port, GERHARDT_CTS_OFF);
  timeout_start(&bus->repeat_time, GERHARDT_REPEAT_REQ_TIME);


  /// Продолжить работу отсюда!!!
  if (!only_check) {
    if (!finfile_size(dst)) {
      auditd_warn("No data was received\n");
      ret = -ENODATA;
    }

    if (finfile_isoverflow(dst)) {
      auditd_warn(
        "Not enough storage for EVA DTS report. Storage size: %d, Report size: %d.",
        finfile_size(dst),
        finfile_virtual_size(dst)
      );
      ret = -ENOBUFS;
    }

    auditd_info("Gerhardt received %d bytes.\n", finfile_size(dst));
  }

  if (ret < 0) {
    // Ошибка
    auditbus_on_state_changed(bus, AUDIT_STATE_ERROR);
  } else {
    auditbus_on_state_changed(bus, AUDIT_STATE_IDLE);
  }

  auditd_info("Gerhardt read done, ret=%d\n", ret);
  // Прекращаем работу
  // При получении признака окончание передачи данных, выходим.
  return ret;
}




static int gerhardt_probe(auditbus_t* bus)
{
  DEBUGASSERT(bus);
  int32_t result = gerhardt_get_audit_data((auditbus_gerhardt_t*)bus, /* onlycheck = */ true);
  if (result < 0) {
    return -EPROTO;
  }
  return 0;
}


static int32_t gerhardt_get_audit(auditbus_t* bus)
{
  return gerhardt_get_audit_data((auditbus_gerhardt_t*)bus, /* onlycheck = */ false);
}


static int gerhardt_destroy(auditbus_t* bus)
{
  (void)bus;

  // Возвращаем порт в первозданный вид, даже если работа была завершена в середине
  // чтения данных и gerhardt_get_audit не сделала (что странно) этого самостоятельно
  smartio_send_brake(auditbus_port(bus), GERHARDT_CTS_OFF);
  return 0;
}



////////////////////////////////////////////////////////////////////////////
//  Публичные функции

int auditbus_gerhardt_create(
  auditbus_gerhardt_t*  instance,
  auditd_t*             owner,
  int                   instance_id,
  audit_interface_t     interface,
  eventq_t*             eventq,
  const char*           port_path,
  const char*           out_path
)
{
  static const auditbus_vmt_t   AUDITBUS_GERHARDT_VMT = {
    .probe      = gerhardt_probe,
    .get_audit  = gerhardt_get_audit,
    .destroy    = gerhardt_destroy
  };

  int ret;


  ret = auditbus_create(
    instance,
    &AUDITBUS_GERHARDT_VMT,
    owner,
    instance_id,
    eventq,
    port_path,
    out_path,
    AUX_TYPE_AUDIT_GERHARDT,
    interface,
    "gerhardt",
    NULL
  );

  if (ret < 0) {
    return ret;
  }

  return 0;
}
