/// \file
/// \brief  Базовый объект для всех протоколов аудита.
/// \author DL <dmitriy@linikov.ru>
///
/// Данный объект предоставляет очередь сообщений, учёт имени, идентификатора
/// текущего протокола, а так же доступ к методам конкретного протокола
/// через одни и те же функции.

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "auditbus.h"

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <nuttx/telemetron/aux.h>

#include <utils/string_utils.h>
#include <utils/service.h>

#include <auditd/auditd_config.h>
#include <auditd/audit_events.h>
#include <auditd/audit_protocol.h>

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Приватные функции


////////////////////////////////////////////////////////////////////////////
//  Публичные функции

int auditbus_create(
  void*                 instance,
  const auditbus_vmt_t* vmt,
  auditd_t*             owner,
  int                   instance_id,
  eventq_t*             eventq,
  const char*           tty_path,
  const char*           out_path,
  audit_protocol_t      protocol,
  audit_interface_t     interface,
  const char*           name,
  const ddcmp_params_t* params
)
{
  DEBUGASSERT(instance && vmt);

  int         ret;
  auditbus_t* auditbus = (auditbus_t*)instance;

  auditbus->vmt         = vmt;
  auditbus->owner       = owner;
  auditbus->instance_id = instance_id;
  auditbus->eventq      = eventq;
  auditbus->tty_path    = tty_path;
  auditbus->out_path    = out_path;
  auditbus->protocol    = protocol;
  auditbus->interface   = interface;
  auditbus->name        = name;

  if (params) {
    auditbus->params = *params;
  } else {
    memset(&auditbus->params, 0, sizeof(auditbus->params));
  }

  ret = smartio_create(&auditbus->port);
  if (ret < 0) {
    auditd_perror("Can't create port", -ret);
    return ret;
  }

  ret = finfile_create(
    &auditbus->outfile,
    CONFIG_LIB_AUDITD_MAX_REPORT_SIZE,
    FINFILE_OVERFLOW_IGNORE,
    FINFILE_PARTWRITE_ALLOWED
  );
  if (ret < 0) {
    return ret;
  }

  ret = finfile_create(
    &auditbus->logfile,
    CONFIG_LIB_AUDITD_MAX_REPORT_SIZE,
    FINFILE_OVERFLOW_IGNORE,
    FINFILE_PARTWRITE_ALLOWED
  );

  return 0;
}


int auditbus_destroy(auditbus_t* auditbus)
{
  int ret = 0;
  DEBUGASSERT(auditbus && auditbus->vmt);
  if (auditbus->vmt->destroy) {
    ret = auditbus->vmt->destroy(auditbus);
    if (ret < 0) {
      // Уничтожение наследника не удалось. Оставляем базовый объект
      // в созданном состоянии для возможности повторного уничтожения
      auditd_perror("Can't destroy inherited object", -ret);
      return ret;
    }
  }

  ret = finfile_destroy(&auditbus->logfile);
  if (ret < 0) {
    auditd_perror("Can't destroy logfile", -ret);
  }

  ret = finfile_destroy(&auditbus->outfile);
  if (ret < 0) {
    auditd_perror("Can't destroy outfile", -ret);
  }

  return 0;
}

int auditbus_set_cb(auditbus_t* auditbus, auditbus_state_fxn_t cb_state, void* arg)
{
  DEBUGASSERT(auditbus);
  auditbus->cb_state  = cb_state;
  auditbus->cb_arg    = arg;
  return 0;
}

static aux_protocol_t audit_interface_to_aux_protocol(audit_interface_t value)
{
  switch(value) {
  case AUX_INTERFACE_RS232:   return AUX_PROTOCOL_RS232;
  case AUX_INTERFACE_RS485:   return AUX_PROTOCOL_RS485v1;
  default:                    return AUX_PROTOCOL_TTL;
  }
}

int auditbus_probe(auditbus_t* auditbus)
{
  int ret;
  int probe_ret;
  DEBUGASSERT(auditbus && auditbus->vmt);
  auditd_debug("AUDIT[%s]: Start probe\n", auditbus->name);
  if (!auditbus->vmt->probe) {
    auditd_trace("ERROR: probe not supported\n");
    return -ENOSYS;
  }

  // при попытке определить тип шины оба выходных файла остаются закрытыми,
  // Открывается и закрывается только порт.

  ret = smartio_open_file(&auditbus->port, auditbus->tty_path);
  if (ret < 0) {
    auditd_error("ERROR: Can't open \"%s\", ret=%d (%s)\n", auditbus->tty_path, ret, strerror(-ret));
    return ret;
  }

  ret = ioctl(auditbus->port.fd, AUXIOC_IS_AUX, 0);
  if (ret <= 0) {
    auditd_warn("WARN: %s does not support AUX commands\n", auditbus->tty_path);
  } else {
    aux_settings_t    aux_settings;
    aux_settings.protocol   = audit_interface_to_aux_protocol(auditbus->interface);
    aux_settings.direction  = AUX_DIRECTION_NORMAL;
    aux_settings.extra      = AUX_EXTRA_NONE;
    aux_settings.inverted   = false;
    ret = ioctl(auditbus->port.fd, AUXIOC_CONFIGURE, (unsigned long)&aux_settings);
    if (ret < 0) {
      auditd_error(
        "ERROR: Can't setup AUX port \"%s\", ret=%d (%s)\n",
        auditbus->tty_path, ret, strerror(-ret)
      );
    }
  }

  auditd_trace("AUDIT[%s]: Call vmt->probe\n", auditbus->name);
  probe_ret = auditbus->vmt->probe(auditbus);
  auditd_trace("AUDIT[%s]: vmt->probe returned %d\n", auditbus->name, probe_ret);

  (void)probe_ret; // Оставлена для отладки

  ret = smartio_close(&auditbus->port);
  if (ret < 0) {
    auditd_perror("Can't close port", -ret);
  }

  auditd_trace("AUDIT[%s]: Probe completed\n", auditbus->name);
  return probe_ret;
}

int auditbus_get_audit(auditbus_t* auditbus)
{
  int ret = -ENOSYS;
  int32_t  error_code;
  DEBUGASSERT(auditbus && auditbus->vmt);

  auditd_debug("AUDIT[%s]: Enter get_audit\n", auditbus->name);

  if (!auditbus->vmt->get_audit) {
    auditd_trace("ERROR: get_audit not supported\n");
    return -ENOSYS;
  }

  // Открываем файлы
  auditd_trace("AUDIT[%s]: opening port %s\n", auditbus->name, auditbus->tty_path);
  ret = smartio_open_file(&auditbus->port, auditbus->tty_path);
  if (ret < 0) {
    auditd_error("ERROR: Can't open \"%s\", ret=%d (%s)\n", auditbus->tty_path, ret, strerror(-ret));
    return ret;
  }

  ret = ioctl(auditbus->port.fd, AUXIOC_IS_AUX, 0);
  if (ret <= 0) {
    auditd_warn("WARN: %s does not support AUX commands\n", auditbus->tty_path);
  } else {
    aux_settings_t    aux_settings;
    aux_settings.protocol   = audit_interface_to_aux_protocol(auditbus->interface);
    aux_settings.direction  = AUX_DIRECTION_NORMAL;
    aux_settings.extra      = AUX_EXTRA_NONE;
    aux_settings.inverted   = false;
    ret = ioctl(auditbus->port.fd, AUXIOC_CONFIGURE, (unsigned long)&aux_settings);
    if (ret < 0) {
      auditd_error(
        "ERROR: Can't setup AUX port \"%s\", ret=%d (%s)\n",
        auditbus->tty_path, ret, strerror(-ret)
      );
    }
  }

  if (!IsWhiteOrEmptyString(auditbus->out_path)) {
    auditd_trace("AUDIT[%s]: removing old audit file %s\n", auditbus->name, auditbus->out_path);
    // Удаление файла, что бы на его место создать новый (только если он не в папке /dev)
    // Это нужно из-за того, что не все файлы поддерживают усечение размера
    if (!StartsWith(auditbus->out_path, "/dev/") && !StartsWith(auditbus->out_path, "dev/")) {
      ret = unlink(auditbus->out_path);
      if (ret < 0) {
        auditd_error(
          "WARN: Can't unlink old audit file \"%s\", ret=%d (%s)\n",
          auditbus->out_path, errno, strerror(errno)
        );
      }
    }

    // Открытие файла для сохранения данных
    auditd_trace("AUDIT[%s]: creating new audit file %s\n", auditbus->name, auditbus->out_path);
    ret = finfile_open(&auditbus->outfile, auditbus->out_path, O_WRONLY | O_CREAT);
    if (ret < 0) {
      auditd_error("ERROR: Can't open \"%s\", ret=%d (%s)\n", auditbus->out_path, ret, strerror(-ret));
      goto cleanup;
    }
  }

  // Запрос аудита
  auditd_trace("AUDIT[%s]: Calling vmt->get_audit\n", auditbus->name);
  error_code = auditbus->vmt->get_audit(auditbus);
  auditd_trace("AUDIT[%s]: vmt->get_audit returned %d\n", auditbus->name, error_code);

  if (error_code != 0) {
    auditd_error("Can't get audit data. error=%08X\n", error_code);
    ret = -EPROTO;
  }


  // При любом раскладе отправляем событие в контроллер. Отправлять его на сервер или нет - задача контроллера.
  auditbus->last_error_code   = error_code;
  auditbus->last_report_size  = finfile_size(&auditbus->outfile);

cleanup:
  finfile_close(&auditbus->logfile);
  finfile_close(&auditbus->outfile);
  smartio_close(&auditbus->port);

  auditd_trace("AUDIT[%s]: get_audit completed\n", auditbus->name);
  return ret;
}

bool auditbus_should_stop(auditbus_t* auditbus)
{
  return service_should_stop((service_t*)auditbus->owner);
}
