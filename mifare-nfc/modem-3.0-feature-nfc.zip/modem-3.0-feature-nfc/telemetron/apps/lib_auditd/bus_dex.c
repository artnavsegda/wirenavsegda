/// \file
/// \author DL <dmitriy.linikov@gmail.com>
/// \see bus_dex.h

#ifndef CFG_FILE_LOG_LEVEL
#define CFG_FILE_LOG_LEVEL  LOG_LEVEL_ALL
#endif // CFG_FILE_LOG_LEVEL

#define CFG_DEX_LOG_RXTX    0

#include "bus_dex.h"

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <poll.h>
#include "sysutils/crc.h"

#include "utils/math_utils.h"
#include "utils/string_utils.h"
#include "utils/dbg.h"
#include "utils/timeout.h"
#include "utils/posix_iohelper.h"

#include <auditd/audit_protocol.h>



#if defined(CFG_DEX_LOG_RXTX) && (CFG_DEX_LOG_RXTX == 1)
#define log_tx(value)   auditd_trace("DexTx:%02X\n", (value))
#define log_rx(value)   auditd_trace("DexRx:%02X\n", (value))
#else
#define log_tx(value)   ((void)value)
#define log_rx(value)   ((void)value)
#endif


/// \brief Значение для начальной инициализации auditbus_dex_t*.port
///
/// Если в качестве i/o порта использован POSIX файл, то -1,
/// если указатель на драйвер - то NULL.
#define DEX_INVALID_PORT                        -1

// Изменили время ожидания. Так как это время используется везде.
// В частности при ожидании начала передачи отчета
// (например MEI CF8000 в режиме EXE долго готовит отчет и попросту не успевает ответить за отведенный промежуток времени).
#define CFG_DEX_TIMERA_TIMEOUT_MS               8000//3000
/// \brief Максимальное время запроса. Считаем исходя из того,
/// что передача 5 кБ происходит примерно за 10 секунд.
/// Таким образом, если размер EVADTS отчета 32кБ, то
/// время запроса составит 32/5*10 = 64 секунды.
/// Следует добавить ещё где-то 1/4 времени для подстраховки.
#define CFG_DEX_TIMERD_TIMEOUT_MS               80000

/// \brief Максимальное время ответа на установление связи.
#define CFG_DEX_HANDSHAKE_TIMEOUT_MS            ((CFG_DEX_TIMERA_TIMEOUT_MS+2000)*5)//5000
#define CFG_DEX_MIN_HANDSHAKE_TIMEOUT_MS        ((CFG_DEX_TIMERA_TIMEOUT_MS+2000)*1)//5000

#define CFG_DEX_UART_TURNAROUND_DELAY_MS        15
#define CFG_DEX_SESSION_TURNAROUND_DELAY_MS     110


#define DEX_SLAVE_REQUEST                       "009252131001R01L01"
#define DEX_MASTER_REQUEST                      "9252131001RR01L01"


int32_t dex_errorcode(int32_t func, int32_t basic)
{
  int32_t result;
  bool neg = basic < 0;
  if (neg) {
    basic = -basic;
  }

  result = ((func&0x7F000000)|(basic&0x00FFFFFF));

  if (neg)  {
    result = -result;
  }
  return result;
}


static void dex_on_state_changed(auditbus_dex_t* bus, audit_state_t state);



static int dexport_getc_timeout(auditbus_dex_t* bus, int timeout_ms)
{
  smartio_t* port = auditbus_port(bus);
  int result = smartio_nbgetc(port, timeout_ms);
  if (result == -EINTR) {
    return DEX_INTERRUPTED;
  }
  if (result == -ETIMEDOUT) {
    return DEX_TIMEOUT;
  }
  if (result < 0) {
    return DEX_BAD_INSTANCE;
  }
  return result;
}

// static int dexport_getc_immediately(auditbus_dex_t* bus)
// {
//   return dexport_getc_timeout(bus, 0);
// }

static int dexport_putc_timeout(auditbus_dex_t* bus, int value, int timeout_ms)
{
  smartio_t* port = auditbus_port(bus);
  int result = smartio_nbputc(port, value, timeout_ms);
  if (result == -EINTR) {
    // Если ожидание завершилось по внешнему сигналу, то не считаем это ошибкой
    return DEX_INTERRUPTED;
  }

  if (result == -ETIMEDOUT) {
    // Ожидание завершилось по таймауту
    return DEX_TIMEOUT;
  }

  if (result < 0) {
    return DEX_BAD_INSTANCE;
  }

  return result;
}

static int dexport_putc(auditbus_dex_t* bus, int value)
{
  int ret;
  do {
    // ждём до победного.
    ret = dexport_putc_timeout(bus, value, -1);
    if (ret == -EINTR) {
      return ret;
    }
  } while (ret < 0);

  return OK;
}

// static bool dexport_wait_tx_complete(auditbus_dex_t* bus)
// {
//   if (tcdrain(bus->port) < 0) {
//     auditd_debug("DexPort:tcdrain err=%d\n", errno);
//     return false;
//   }
//   return true;
// }



static uint32_t dex_uart_clear(auditbus_dex_t* bus)
{
  smartio_t* port = auditbus_port(bus);

  smartio_logger_printf(port, "Uclr>");
  ssize_t result = smartio_discard_rx(port, 0);
  smartio_logger_printf(port, "\r\n");

  return result >= 0 ? result : 0;
}

/// \brief Читает из шины \p bus один байт данных, при не обходимости
/// подсчитывая контрольную сумму. При таймауте закрывает сессию.
static dexchar_t dex_read_raw(auditbus_dex_t* bus)
{
  if (timeout_is_elapsed(&bus->timer_a) || timeout_is_elapsed(&bus->timer_d)) {
    bus->transaction_active = false;
    return DEX_TIMEOUT;
  }

  systime_t   ms_to_wait = min_u32(timeout_ticks_left(&bus->timer_a),
                                   timeout_ticks_left(&bus->timer_d));
  int result = dexport_getc_timeout(bus, ms_to_wait);
  if (result == DEX_INTERRUPTED) {
    return result;
  }
  log_rx(result);

  if (result != DEX_TIMEOUT
      && result != DEX_DLE_CHAR
      && result != DEX_SYN_CHAR) {
    // Для всех символов кроме DLE и SYN обновляем CRC
    crc16_calc_byte(&bus->rx_crc, result & 0xFF);
  }
  return result;
}

/// \brief Записывает в шину \p bus один байт данных, при необходимости
/// обновляя контрольную сумму.
static int dex_write_raw(auditbus_dex_t* bus, uint8_t value)
{
  int ret = dexport_putc(bus, value);
  if (ret < 0) {
    return ret;
  }

  log_tx(value);

  if (value != DEX_DLE_CHAR && value != DEX_SYN_CHAR) {
    // Для всех символов кроме DLE и SYN обновляем CRC
    crc16_calc_byte(&bus->tx_crc, value);
  }
  return 0;
}

#if defined(CFG_DEX_USE_PROLOGUE_EPILOGUE) && (CFG_DEX_USE_PROLOGUE_EPILOGUE==1)
/// \brief Записывает в шину \p bus буффер \p data размером \p size.
static int dex_write_raw_bytes(auditbus_dex_t* bus, const void* data, size_t size, char ** dst2, char* dst_end)
{
  const uint8_t* value = (const uint8_t*)data;

  while(size--) {
    int ret = dex_write_raw(bus, *value++, dst2, dst_end);
    if (ret < 0) {
      return ret;
    }
  }
  return 0;
}
#endif // defined(CFG_DEX_USE_PROLOGUE_EPILOGUE) ...

/// \brief Читает из шины \p bus одно-байтовый или двух-байтовый символ.
/// \return Возвращает прочитанный символ, либо DEX_TIMEOUT.
static dexchar_t dex_read(auditbus_dex_t* bus)
{
  dexchar_t c = dex_read_raw(bus);
  if (c == DEX_TIMEOUT || c == DEX_INTERRUPTED) {
    return c;
  }
  if (c != DEX_DLE_CHAR) {
    // получен однобайтный символ.
    return c;
  }

  // получана управляющая команда.
  dexchar_t result = DEX_DLE_CHAR << 8;

  c = dex_read_raw(bus);
  if (c == DEX_TIMEOUT || c == DEX_INTERRUPTED) {
    return c;
  }

  result |= c & 0xFF;
  return result;
}

/// \brief Записывает в шину \p bus одно- или двух-байтовый символ.
static int dex_write(auditbus_dex_t* bus, dexchar_t value)
{
  int ret;
  if ((value & 0xFF00) != 0) {
    ret = dex_write_raw(bus, value >> 8);
    if (ret < 0) {
      return ret;
    }
  }
  ret = dex_write_raw(bus, value & 0xFF);
  if (ret < 0) {
    return ret;
  }
  return 0;
}

/// \brief Сбрасывает нумерацию ожидаемых от VMD команд ACK к начальному ACK0.
static inline void dex_restart_rx_ack_sequence(auditbus_dex_t* bus)
{
  bus->rx_ack_number = 0;
}

/// \brief Сбрасывает нумерацию передаваемых ACK команд к начальному ACK0.
static inline void dex_restart_tx_ack_sequence(auditbus_dex_t* bus)
{
  bus->tx_ack_number = 0;
}

/// \brief Сбрасывает модуль вычисления контрольной суммы передаваемых данных
/// к начальному значению.
static inline void dex_reset_tx_crc(auditbus_dex_t* bus)
{
  auditd_trace("%s\n", __FUNCTION__);
  bus->tx_crc = 0;
}

/// \brief Сбрасывает модуль вычисления контрольной суммы принимаемых данных
/// к начальному значению.
static inline void dex_reset_rx_crc(auditbus_dex_t* bus)
{
  auditd_trace("%s\n", __FUNCTION__);
  bus->rx_crc = 0;
}

/// \brief Сбрасывает таймер обратного отсчета TimerA (максимальная
/// продолжительность одной транзакции) к начальному значению.
static inline void dex_reset_timer_a(auditbus_dex_t* bus, bool shorttime)
{
  auditd_trace("%s\n", __FUNCTION__);
  if (shorttime)
    timeout_start(&bus->timer_a, CFG_DEX_TIMERA_TIMEOUT_MS/3);
  else
    timeout_start(&bus->timer_a, CFG_DEX_TIMERA_TIMEOUT_MS);
}

/// \brief Сбрасывает таймер обратного отсчёта TimerD (максимальное время между
/// транзакциями одной сессии) к начальному значению.
static inline void dex_reset_timer_d(auditbus_dex_t* bus)
{
  auditd_trace("%s\n", __FUNCTION__);
  timeout_start(&bus->timer_d, CFG_DEX_TIMERD_TIMEOUT_MS);
}

/// \brief читает из шины 2 символа контрольной суммы.
/// \return Если прочитано успешно, то возвращает значение прочитанной
/// контрольной суммы, иначе - возращает отрицательный код ошибки.
static dexchar_t dex_read_crc(auditbus_dex_t* bus)
{
  uint16_t  received_crc = 0;

  // сначала младший байт
  dexchar_t c = dex_read_raw(bus);
  if (c == DEX_TIMEOUT || c == DEX_INTERRUPTED) {
    return c;
  }
  received_crc = (c & 0xFF);

  // затем - старший байт
  c = dex_read_raw(bus);
  if (c == DEX_TIMEOUT || c == DEX_INTERRUPTED) {
    return c;
  }
  received_crc |= (c & 0xFF) << 8;

  return received_crc;
}

/// \brief Записывает в шину \p bus 2 символа контрольной суммы, которые
/// к моменту вызова были накоплены в модуле подсчёта контрольной суммы
/// передаваемых данных (\see `bus->tx_crc`).
static int dex_write_crc(auditbus_dex_t* bus)
{
  int       ret;
  uint16_t  calculated_crc = bus->tx_crc;

  // записываем сперва младший байт контрольной суммы, а, затем, старший.
  ret = dex_write_raw(bus, calculated_crc & 0xFF);
  if (ret < 0) {
    return ret;
  }

  ret = dex_write_raw(bus, calculated_crc >> 8);
  if (ret < 0) {
    return ret;
  }
  return 0;
}

/// \brief Читает символ подтверждения и проверяет его
/// (ACK0 и ACK1 коды постоянно чередуются).
/// \return Возвращает код подтверждения, полученный от VMD.
/// \retval DEX_TIMEOUT   VMD не ответила в установленный временнОй интревал
/// \retval DEX_WACK      VMD ещё не готова к приёму
/// \retval DEX_ACK       VMD подтвердила получение
/// \retval DEX_NAK       VMD отказалась принимать данные.
/// \retval DEX_BAD_RSP   Получены некорректные данные.
/// \retval DEX_ENQ       VMD оказалась мастером и первая отправила запрос
///                       передачи данных.
static dexchar_t dex_read_ack(auditbus_dex_t* bus)
{
  smartio_logger_printf(auditbus_port(bus), "\r\nread_ack\r\n");

  dexchar_t result = dex_read(bus);
  dexchar_t expected_ack = DEX_ACK + bus->rx_ack_number;
  if (result == DEX_TIMEOUT) {
    auditd_debug("dex_read_ack(): Response timeout.\n");
    return result;
  }
  if (result == DEX_INTERRUPTED) {
    auditd_debug("dex_read_ack(): Interrupted.\n");
    return result;
  }
  if (result == DEX_WACK) {
    auditd_debug("dex_read_ack(): VMD not ready yet.\n");
    return result;
  }
  if (result == DEX_NAK) {
    auditd_debug("dex_read_ack(): VMD cancelled transfer.\n");
    return result;
  }
  if (result == DEX_ENQ) {
    auditd_debug("dex_read_ack(): got ENQ.\n");
    return result;
  }
  // проверка на предмет начала блока данных
  if (result == DEX_STX) {
    auditd_debug("dex_read_ack(): got STX. Data block! Handshake need skip.\n");
    return result;
  }

  if (result != expected_ack) {
    auditd_debug("dex_read_ack(): Invalid response [0x%04X], expect [0x%04X]\n", result, expected_ack);
    return (((result<<8)&0xFFFFFF00)|(DEX_BAD_RSP&0x000000FF));//(DEX_BAD_RSP&0x000000FF));
  }

  // прочитан корректный ACK код. Выбираем следующий.
  bus->rx_ack_number = 1 - bus->rx_ack_number;
  return DEX_ACK;
}

/// \brief Отправляет ACK команду с нужным номером (ACK0/ACK1).
static int dex_send_ack(auditbus_dex_t* bus)
{
  // Отправка нужного ACK
  dexchar_t   ack_id  = DEX_ACK0 + bus->tx_ack_number;
  int         ret     = dex_write(bus, ack_id);

  // И чередование ACK0/ACK1
  bus->tx_ack_number = 1 - bus->tx_ack_number;
  return ret;
}

/// \brief Отправляет NAK
static int dex_send_nak(auditbus_dex_t* bus)
{
  return dex_write(bus, DEX_NAK);
}

/// \return Возвращает код подтверждения, полученный от VMD.
/// \retval DEX_TIMEOUT   VMD не ответила в установленный временнОй интревал
/// \retval DEX_WACK      VMD ещё не готова к приёму
/// \retval DEX_ACK       VMD подтвердила получение
/// \retval DEX_NAK       VMD отказалась принимать данные.
/// \retval DEX_BAD_RSP   Получены некорректные данные.
/// \retval DEX_ENQ       VMD оказалась мастером и первая отправила запрос
///                       передачи данных.
static dexchar_t dex_master_start_transfer(auditbus_dex_t* bus)
{
  int ret;
  dex_uart_clear(bus);
  // Сброс таймаута приёма и нумерации подтверждений
  // (Все подтверждения постоянно чередуются: ACK0-ACK1-ACK0-ACK1...)

  dex_reset_timer_a(bus, true);
  dex_restart_rx_ack_sequence(bus);

  ret = dex_write(bus, DEX_ENQ);
  if (ret < 0) {
    return (dexchar_t)ret;
  }

  dexchar_t result = dex_read_ack(bus);
  if (result < 0) {
    auditd_debug("dex_master_start_transfer(): Can't read ack, ret=%d\n", result);
    return result;
  }

  if (result == DEX_ENQ) {
    // Аппарат перехватил инициативу
    auditd_debug("dex_master_start_transfer(): VMD sent ENQ first. Back to slave.\n");
    delay_ms(CFG_DEX_UART_TURNAROUND_DELAY_MS);
    return result;
  }

  if (result == DEX_ACK) {
    bus->transaction_active = true;
    delay_ms(CFG_DEX_UART_TURNAROUND_DELAY_MS);
  }

  auditd_trace("dex_master_start_transfer(): ack=[0x%04X]\n", result);

  return result;
}

/// \brief Отправляет команду завершения транзакции (EOT).
static int dex_end_transfer(auditbus_dex_t* bus)
{
  int ret = dex_write(bus, DEX_EOT);
  bus->transaction_active = false;
  return ret;
}


// передача данных handshake начинается с DEX_SOH
// и заканчивается DEX_ETX и контрольной суммой.

// передача данных аудита начинается с DEX_STX
// и заканчивается DEX_ETB (конец блока) или DEX_ETX (конец последнего блока),
// после чего следует контрольная сумма.

/// \brief Отправляет блок данных.
/// \return Возвращает код подтверждения, полученный от VMD.
/// \retval DEX_TIMEOUT   VMD не ответила в установленный временнОй интревал
/// \retval DEX_WACK      VMD ещё не готова к приёму
/// \retval DEX_ACK       VMD подтвердила получение
/// \retval DEX_NAK       VMD отказалась принимать данные.
/// \retval DEX_BAD_RSP   Получены некорректные данные.
static dexchar_t dex_send_block(auditbus_dex_t* bus, const DexBlock* block)
{
  int ret;
  ret = dex_write(bus, block->type);
  if (ret < 0) {
    return (dexchar_t)ret;
  }
  dex_reset_tx_crc(bus);

  char*   data = block->data;
  size_t  size = block->size;
  while(*data && size) {
    ret = dex_write_raw(bus, *data++);
    if (ret < 0) {
      return (dexchar_t)ret;
    }
    --size;
  }

  ret = dex_write(bus, block-> is_last_block ? DEX_ETX : DEX_ETB);
  if (ret < 0) {
    return (dexchar_t)ret;
  }

  ret = dex_write_crc(bus);
  if (ret < 0) {
    return (dexchar_t)ret;
  }

  dexchar_t response = dex_read_ack(bus);
  auditd_trace("dex_send_block(): ack=[0x%04X]\n", response);
  return response;
}

/// \brief Отправляет Handshake1 (или Handshake2) блок с текстом \p header.
/// \return Возвращает код подтверждения, полученный от VMD.
/// \retval DEX_TIMEOUT   VMD не ответила в установленный временнОй интревал
/// \retval DEX_WACK      VMD ещё не готова к приёму
/// \retval DEX_ACK       VMD подтвердила получение
/// \retval DEX_NAK       VMD отказалась принимать данные.
/// \retval DEX_BAD_RSP   Получены некорректные данные.
static dexchar_t dex_send_header(auditbus_dex_t* bus, const char* header)
{
  DexBlock  block = {
    .data = (char*) header,
    .size = strlen(header),
    .type = DEX_BLOCK_HANDSHAKE,
    .is_last_block = true
  };

  dexchar_t result = dex_send_block(bus, &block);
  if (result < 0) {
    return result;
  }

  int ret = dex_end_transfer(bus);
  if (ret < 0) {
    return (dexchar_t)ret;
  }

  return result;
}

#if 0
// Если потребуется отправка данных в VMD, то раскомментировать.

/// \brief Отправляет блок с \p size байтами данных \p data.
/// \return Возвращает код подтверждения, полученный от VMD.
/// \retval DEX_TIMEOUT   VMD не ответила в установленный временнОй интревал
/// \retval DEX_WACK      VMD ещё не готова к приёму
/// \retval DEX_ACK       VMD подтвердила получение
/// \retval DEX_NAK       VMD отказалась принимать данные.
/// \retval DEX_BAD_RSP   Получены некорректные данные.
static dexchar_t dex_send_datablock(auditbus_dex_t* bus, const void* data, size_t size,
                             bool is_last)
{
  const DexBlock  block = {
    .data = (char*) data,
    .size = size,
    .type = DEX_BLOCK_DATA,
    .is_last_block = is_last
  };

  return dex_send_block(bus, &block);
}
#endif // 0

/// \brief Очищает буффер приёма и прописывает его в переменную \p dst.
static void dex_clear_rx_block(auditbus_dex_t* bus, DexBlock* dst)
{
  bus->rx_index = 0;
  bus->rx_buffer[0] = '\0';

  dst->data = bus->rx_buffer;
  dst->size = 0;
  dst->type = DEX_BLOCK_INVALID;
  dst->is_last_block = true;
  dst->is_crc_valid = false;
}

/// \brief Сохраняет очередной символ \p value в буффер приёма блока данных,
/// проверяя валидность этого символа и наличие места в буффере.
bool dex_save_char(DexBlock* dst, dexchar_t value)
{
  // // В состоянии приёма всё остальные служебные символы и символы, значение
  // // которых больше 127 - это ошибка приёма. Игнорируем.
  // if (value < 0 || value > 127) {
  //     auditd_warn("dex_receive(): Received invalid value [0x%04X] in DATA mode\n", value);
  //     finfile_printf(
  //       output,
  //        "@@@%X@@@", value
  //     );
  //   return true;
  // }

  if (dst->size < DEX_BLOCK_MAX_CHARS) {
    ((uint8_t*)dst->data)[dst->size++] = value;
    return true;
  }

  return false; // превышен максимальный размер блока
}

/// \brief Действия, выполняемые в slave-режиме при таймауте приёма
static void dex_slave_on_timeout(auditbus_dex_t* bus)
{
  auditd_debug("dex_receive(): timeout.\n");
}

/// \brief Действия, выполняемые в slave-режиме при получении команды EOT
static void dex_slave_on_end_transaction(auditbus_dex_t* bus)
{
  auditd_trace("dex_receive(): Got EOT.\n");
  bus->transaction_active = false;
}

/// \brief Действия, выполняемые в slave-режиме при получении команды ENQ.
///
/// Данная функция должна отправить в VMD подтверждение приёма.
static int dex_slave_on_start_transaction(auditbus_dex_t* bus, DexBlock* dst)
{
  auditd_trace("dex_receive(): Got ENQ.\n");
  // Вне зависимости от текущего состояния приёма DEX_ENQ - команда начала
  // (или повторного начала) транзакции.
  // Нужно сбросить таймер приёма и удалить данные, которые уже, возможно,
  // были записаны в целевой буффер.
  dex_reset_timer_a(bus, false);
  dex_clear_rx_block(bus, dst);

  // Задержка перед изменением направления передачи
  delay_ms(CFG_DEX_UART_TURNAROUND_DELAY_MS);

  // Сброс нумерации ACK ответов и отправка ACK0
  dex_restart_tx_ack_sequence(bus);
  int ret = dex_send_ack(bus);
  bus->transaction_active = true;
  return ret;
}

/// \brief Действия, выполняемые в slave-режиме при получении начала блока данных.
static void dex_slave_on_start_block(auditbus_dex_t* bus, DexBlock* dst,
                                     dexchar_t type)
{
  auditd_trace("dex_receive(): Got block start, type=[0x%04X].\n", type);
  //if (!bus->transaction_active) {
  //  // Если транзакция ещё не была начата, то это ошибка.
  //  // Попробуем её проигнорировать, создав транзакцию заново и
  //  // сбросив последовательность ACK в исходное состояние.
  //  auditd_warn("dex_receive(): got SOH when no transaction active.\n");
  //  dex_restart_tx_ack_sequence(bus);
  //  bus->transaction_active = true;
  //}

  // Вне зависимости от текущего состояния приёма DEX_SOH и DEX_STB
  // начинают приём блока данных.
  // Необходимо сбросить таймер приёма блока, очистить буффер, начать
  // подсчёт контрольной суммы с начала и ответить ACK0
  dex_reset_timer_a(bus, false);
  dex_clear_rx_block(bus, dst);

  // сброс накопленного CRC к начальному значению.
  dex_reset_rx_crc(bus);

  // сохраняем тип блока
  dst->type = type;
}

/// \brief Действия, выполняемые в slave-режиме при получении команды SYN.
static void dex_slave_on_transfer_pause(auditbus_dex_t* bus)
{
  auditd_trace("dex_receive(): Got SYN.\n");
  // В состоянии приёма, если получен DLE_SYN, это значит, что отправитель
  // ещё не готов предоставить порцию данных. Необходимо сбросить таймер А.
  dex_reset_timer_a(bus, false);
}

/// \brief Действия, выполняемые в slave-режиме при окончании приёма блока данных
/// \returns Возвращает тип полученного блока или DEX_TIMEOUT.
static dexchar_t dex_slave_on_end_block(auditbus_dex_t* bus, DexBlock* dst,
                                        dexchar_t response)
{
  int ret;
  auditd_trace("dex_receive(): Got End-Of-Block, type=[0x%04X].\n", response);
  // получена команда завершения блока. Осталось прочитать и проверить
  // контрольную сумму.
  dst->is_last_block = (response == DEX_ETX);
  dst->calculated_crc = bus->rx_crc;
  //dst->size = bus->rx_index;

  response = dex_read_crc(bus);
  if (response == DEX_TIMEOUT) {
    dex_slave_on_timeout(bus);
    return response;
  }
  if (response == DEX_INTERRUPTED) {
    return response;
  }

  dst->received_crc = response;
  dst->is_crc_valid = dst->calculated_crc == dst->received_crc;

  delay_ms(CFG_DEX_UART_TURNAROUND_DELAY_MS);
  if (dst->is_crc_valid) {
    ret = dex_send_ack(bus);
    if (ret < 0) {
      return (dexchar_t)ret;
    }
    return dst->type;
  }

  ret = dex_send_nak(bus);
  if (ret < 0) {
    return (dexchar_t)ret;
  }
  return DEX_BAD_CRC_PACKET;
}

/// \brief Переходит в slave режим и ожидает принятие блока данных
///
/// Если при передаче не совпадает контрольная сумма, то данная функция
/// отправляет VMD код WACK
///
/// \param force_ack              Если true, до во входной поток "подставляется"
///                               символ DEX_ENQ, перед началом приёма.
/// \return Возвращает тип принятого блока или код ошибки:
/// \retval DEX_BLOCK_TIMEOUT     Превышено время ожидания данных
/// \retval DEX_BLOCK_EOT         Получена команда завершения транзакции,
///                               данные не получены.
/// \retval DEX_BLOCK_HANDSHAKE   (Оно же DEX_SOH) Получен блок handshake данных.
/// \retval DEX_BLOCK_DATA        (Оно же DEX_STB) Получен блок данных.
static dexchar_t dex_slave_receive(auditbus_dex_t* bus, dexchar_t include_data, DexBlock* dst)
{
#define WAITING_START   0
#define READING_DATA    1
#define MAX_REPEAT_DEX_PACKET       5
  smartio_t* port = auditbus_port(bus);
  timeout_start(&bus->timer_a, CFG_DEX_TIMERA_TIMEOUT_MS);
  smartio_logger_printf(port, "\r\ndex_slave_receive\r\n");

  int     ret;
  uint8_t state = WAITING_START;
  uint8_t i     = 0;

  dex_clear_rx_block(bus, dst);
  while(1) {
    dexchar_t response;
    if (auditbus_should_stop((auditbus_t*)bus)) {
      return -EINTR;
    }

    if ((include_data==DEX_STX) || (include_data == DEX_ENQ)) {
      // Если нужно, то первым символом читаем ENQ.
      response = include_data;
      include_data=DEX_ACK;
    } else {
      response = dex_read(bus);
    }

    if (response == DEX_TIMEOUT) {
      dex_slave_on_timeout(bus);
      // <<===== <<===== <<===== <<===== <<===== <<===== <<===== <<===== <<=====
      // Превышено время ожидания одного из таймеров. Выход из данной функции.
      return response;
    }
    if (response == DEX_INTERRUPTED) {
      return response;
    }

    if (response == DEX_EOT) {
      dex_slave_on_end_transaction(bus);
      // <<===== <<===== <<===== <<===== <<===== <<===== <<===== <<===== <<=====
      // Получена остановка передачи. Выход из данной функции.
      return response;
    }

    if (response == DEX_ENQ) {
      // Начата транзакция
      ret = dex_slave_on_start_transaction(bus, dst);
      if (ret < 0) {
        return ret;
      }
      continue;
    }

    if (response == DEX_SOH || response == DEX_STX) {
      // начало блока данных
      dex_slave_on_start_block(bus, dst, response);
      state = READING_DATA;
      continue;
    }

    // Все возможные символы режима WAITING_START обработаны.

    if (state != READING_DATA) {
      // остальные символы в режиме ожидания начала приёма - ошибка.
      // Проигнорируем их с выводом оповещения в журнал.
      ret = dex_send_nak(bus);
      if (ret < 0) {
        return (dexchar_t)ret;
      }
      include_data=DEX_ACK;
      dex_clear_rx_block(bus, dst);
      auditd_debug("dex_receive(): Received invalid value [0x%04X] in WAIT mode\n",
                response);
      continue;
    }

    if (response == DEX_SYN) {
      dex_slave_on_transfer_pause(bus);
      continue;
    }

    dexchar_t result=0;
    if (response == DEX_ETB || response == DEX_ETX) {
      // <<===== <<===== <<===== <<===== <<===== <<===== <<===== <<===== <<=====
      // Блок прочитан. Выход из данной функции.
      result = dex_slave_on_end_block(bus, dst, response);
      if (result != DEX_BAD_CRC_PACKET) {
        if (response == DEX_ETB)
            bus->nblock++;

        ((uint8_t*)dst->data)[dst->size] = '\0';
        return result;
      }
    }

    if ((result == DEX_BAD_CRC_PACKET) || (!dex_save_char(dst, response & 0xFF)))
    {// Ошибка символа. Нарушена синхронизация!
        state = WAITING_START;
        ret = dex_send_nak(bus);
        if (ret < 0) {
          return ret;
        }
        //delay_ms(CFG_DEX_UART_TURNAROUND_DELAY_MS);
        include_data=DEX_ACK;
        dex_clear_rx_block(bus, dst);
        if ((++i)<MAX_REPEAT_DEX_PACKET)
            continue;
        else
            return(((response<<8)&0xFFFFFF00)|(0x000000FF&DEX_ERROR_OUT_OF_ATTEMPTS));
    }
  } // while(1)
} // dex_receive()



//  /// \brief В master-режиме отправляет Handshake1 запрос на получение данных аудита.
//  /// \return Возвращает код подтверждения, полученный от VMD.
//  /// \retval DEX_TIMEOUT   VMD не ответила в установленный временнОй интревал
//  /// \retval DEX_WACK      VMD ещё не готова к приёму
//  /// \retval DEX_ACK       VMD подтвердила получение
//  /// \retval DEX_NAK       VMD отказалась принимать данные.
//  /// \retval DEX_BAD_RSP   Получены некорректные данные.
//  static dexchar_t dex_master_send_audit_request_header(auditbus_dex_t* bus)
//  {
//    const char* request = DEX_MASTER_REQUEST;
//    return dex_send_header(bus, request);
//  }

//  /// \brief В slave-режиме отправляет Handshake2 ответ с запросом на получение
//  /// данных аудита.
//  /// \return Возвращает код подтверждения, полученный от VMD.
//  /// \retval DEX_TIMEOUT   VMD не ответила в установленный временнОй интревал
//  /// \retval DEX_WACK      VMD ещё не готова к приёму
//  /// \retval DEX_ACK       VMD подтвердила получение
//  /// \retval DEX_NAK       VMD отказалась принимать данные.
//  /// \retval DEX_BAD_RSP   Получены некорректные данные.
//  static dexchar_t dex_slave_send_audit_request_header(auditbus_dex_t* bus)
//  {
//    const char* request = DEX_SLAVE_REQUEST;
//    return dex_send_header(bus, request);
//  }


/// \brief Отправляет устройству хендшейк.
/// \param data           Данные, которые следует передать
/// \param retry_enq      следует ли пытаться повторно отправлять ENQ
/// \return Возвращает под подтверждения, полученный от VMD.
/// \retval DEX_ACK       VMD подтвердила получение
/// \retval DEX_TIMEOUT   VMD не ответила в установленный временнОй интревал
/// \retval DEX_WACK      VMD ещё не готова к приёму
/// \retval DEX_NAK       VMD отказалась принимать данные.
/// \retval DEX_BAD_RSP   Получены некорректные данные.
static dexchar_t dex_send_handshake(auditbus_dex_t* bus, const char* data, bool retry_enq, bool only_check)
{
  dexchar_t   result = DEX_WACK;
  timeout_t   handshake_timeout;
  systime_t   timeout=CFG_DEX_HANDSHAKE_TIMEOUT_MS;
  if (only_check) timeout=CFG_DEX_MIN_HANDSHAKE_TIMEOUT_MS;
  timeout_start(&handshake_timeout, timeout);

  auditd_trace("%s\n", __FUNCTION__);
  // Отправка начала хендшейка.
  smartio_t* port = auditbus_port(bus);
  smartio_logger_printf(port, "\r\ndex_send_handshake\r\n");

  do {
    // Сбрасываем защитный таймер. Все обошлось. Можно продолжать работу
    //Softdog_OnReturnedToMainLoop();
    if (auditbus_should_stop((auditbus_t*)bus)) {
      result = -EINTR;
      break;
    }

    delay_ms(100);
    if (auditbus_should_stop((auditbus_t*)bus)) {
      result = -EINTR;
      break;
    }

    result = dex_master_start_transfer(bus);
    // При попытке установить Хендшейк, обнаружили данные
    if (result == DEX_STX) {
      auditd_trace("dex_master_handshake(): !!! Receive STX. HANDSHAKE SKIP!\n");
      break;
    }

    if (result == DEX_INTERRUPTED) {
      auditd_debug("dex_master_handshake(): interrupted.\n");
      break;
    }

    if (result == DEX_TIMEOUT) {
      auditd_debug("dex_master_handshake(): timeout.\n");
      continue;
    }

    if (result == DEX_WACK) {
      auditd_warn("dex_master_handshake(): VMD not yet ready.\n");
      delay_ms(90);
      continue;
    }

    if (result == DEX_ENQ) {
      // Это первая сессия с момента старта. Аппарат взял инициативу.
      auditd_trace("dex_master_handshake(): VMD is master.\n");
      break;
    }

    if (result == DEX_ACK) {
      auditd_trace("dex_master_handshake(): Started handshake.\n");
      break;
    }
  } while(retry_enq && !timeout_is_elapsed(&handshake_timeout)); // что бы не ставить внутри цикла условие.

  if (result != DEX_ACK) {
    return result;
  }

  // Если подтверждено, то отправка остальной части.
  delay_ms(CFG_DEX_UART_TURNAROUND_DELAY_MS);
  result = dex_send_header(bus, data);
  if (result < 0) {
    auditd_debug("get_evadts(): Failed to send Handshake data. Got I/O error %d\n", result);
    return result;
  }

  if (result != DEX_ACK && result != DEX_STX) {
    //
    auditd_debug("get_evadts(): Failed to send Handshake data: [0x%04X]\n", result);
    return (((result<<8)&0xFFFFFF00)|(DEX_BAD_RSP_HANDSHAKE_MASTER_NOT_ACK&0x000000FF));
  }

  if (result == DEX_STX)
  {// Получили начало блока данных. Завершаем процедуру установки соединенения.
    auditd_debug("get_evadts(): Failed to send Handshake data. Got a data block. Handshake skip\n");
  }

  return result;
}

static dexchar_t dex_receive_handshake(auditbus_dex_t* bus, dexchar_t include_data, DexBlock* block, bool only_check)
{
  auditd_trace("%s\n", __FUNCTION__);

  // Получим Handshake
  smartio_t* port = auditbus_port(bus);
  smartio_logger_printf(port, "\r\ndex_receive_handshake\r\n");

  // Запомним начальный указатель на данные
  dexchar_t result = dex_slave_receive(bus, include_data, block);


  if (result != DEX_BLOCK_HANDSHAKE) {
    auditd_warn("dex_receive_handshake(): Got [0x%04X] instead of handshake.\n", result);
    if (!only_check) {
      dex_on_state_changed(bus, AUDIT_STATE_ERROR);
    }
    return (((result<<8)&0xFFFFFF00)|(DEX_BAD_RSP_HANDSHAKE_SLAVE_NOT_SOH&0x000000FF));
  }
  auditd_trace("dex_receive_handshake(): Got handshake1 from VMD: [%s]\n", block->data);

  // Получим EOT.
  result = dex_slave_receive(bus, DEX_ACK, block);

  if (result != DEX_BLOCK_EOT) {
    auditd_warn("dex_receive_handshake(): Got [0x%04X] instead of EOT.\n", result);
    if (!only_check)
      dex_on_state_changed(bus, AUDIT_STATE_ERROR);
    return (((result<<8)&0xFFFFFF00)|(DEX_BAD_RSP_HANDSHAKE_SLAVE_NOT_EOT&0x000000FF));
  }
  auditd_trace("dex_receive_handshake(): Got EOT. Just as expected.\n");
  return DEX_ACK;
}

/// \brief Читает из шины \p bus данные аудита, сохраняя их в буффер \p dst,
/// размером \p s.
/// \return В случае успеха возвращает указатель на конец записанных в буффер
/// данных (на нуль-символ).
/// Если же запрос завершился ошибкой, то возвращает NULL.
int32_t dex_get_audit_data(auditbus_dex_t* bus, bool only_check)
{
  auditd_trace("%s\n", __FUNCTION__);

  if (!bus) {
    auditd_warn("dex_get_audit_data(): No port specified for IO.\n");
    return dex_errorcode(DEX_FUNC_enter_dex_get_audit_data, -EINVAL);
  }

  finfile_t*  dst   = auditbus_outfile(bus);
  smartio_t*  port  = auditbus_port(bus);
  DexBlock    block;
  size_t      received_size = 0;

  // Включена только проверка шины
  //if (!only_check) {
    dex_on_state_changed(bus, AUDIT_STATE_CONNECTING);
  //}

  // Настраиваем порт.
  // Битрейт порта требуется задавать не числом,
  // а одной из констант (B4800, B9600, B19200, ...), определённых в termios.h
  smartio_set_comm_params(port, B9600, SERIAL_WORDLEN_8_BIT, SERIAL_PARITY_NONE, SERIAL_FLOWCTL_NONE);

  dex_reset_timer_d(bus);

  auditd_trace("dex_get_audit_data(): Sending connect request.\n");
//  uint32_t count=
  dex_uart_clear(bus);
#if defined(CFG_DEX_USE_PROLOGUE_EPILOGUE) && (CFG_DEX_USE_PROLOGUE_EPILOGUE==1)
  // Пролог и эпилог, вообще-то стандартом DEX не предусмотрены.
  // Они были обнаружены, когда я (DL) снимал общение между автоматом
  // Crane 167 и специализированным Bluetooth сканером.
  //
  // При этом, в конечном итоге, этот аппарат заработал и без данных
  // строк. Скоее всего, помогло увеличение таймаута чтения
  // (см. набор изменений 9031dc97c1b6 в репозитории).
  static const char   CONNECT_PROLOGUE[]    = "\r\nCONNECT 70F395EB8A48\r\n";
  static const char   DISCONNECT_EPILOGUE[] = "\r\nDISCONNECT\r\n";
  dex_write_raw_bytes(bus, CONNECT_PROLOGUE, strlen(CONNECT_PROLOGUE));

  delay_ms(CFG_DEX_UART_TURNAROUND_DELAY_MS);
#endif // defined(CFG_DEX_USE_PROLOGUE_EPILOGUE) && ...

  smartio_logger_printf(port, "\r\nRaw log.\r\n");


  auditd_trace("Trying to send Handshake 1 to VMD...\n");
  dexchar_t result;

  result = dex_send_handshake(bus, DEX_MASTER_REQUEST, true, only_check);
  if (result != DEX_ENQ && result != DEX_ACK && result != DEX_STX) {
    result=dex_errorcode(DEX_FUNC_dex_send_handshake_1,result);
    goto handle_error;
  }

  if (result == DEX_ENQ) {
      auditd_info("dex_get_audit_data(): Receiving EVA DTS (DEX) in slave mode.\n");
      auditd_trace("Receiving Handshake 1 from VMD...\n");
      // ТА перехватил инициативу.
      result = dex_receive_handshake(bus, DEX_ENQ, &block, only_check);
      if (result != DEX_ACK) {
        result=dex_errorcode(DEX_FUNC_dex_receive_handshake_2,result);
        goto handle_error;
      }

      auditd_trace("Sending Handshake 2 to VMD...\n");
      delay_ms(CFG_DEX_SESSION_TURNAROUND_DELAY_MS);

      result = dex_send_handshake(bus, DEX_SLAVE_REQUEST, false, only_check);
      if (result != DEX_ACK) {
        result=dex_errorcode(DEX_FUNC_dex_send_handshake_2,result);
        goto handle_error;
      }

      smartio_logger_printf(port, "! DEX slave mode !\r\n");

  } else if (result == DEX_ACK)  {

    auditd_info("dex_get_audit_data(): Receiving EVA DTS (DEX) in master mode.\n");
    result = dex_receive_handshake(bus, DEX_ACK, &block, only_check);
    if (result != DEX_ACK && result != DEX_STX)
    {
      result=dex_errorcode(DEX_FUNC_dex_receive_handshake_1,result);
      goto handle_error;
    }

    smartio_logger_printf(port, "! DEX master mode !\r\n");
  }


  if (result==DEX_STX)
  {
    smartio_logger_printf(port, "! Not standard DEX. Handshake skiped. !\r\n");
  }


  // на тестируемом автомате если сразу после проверки шины запустить снятие отчёта
  // то происходила ошибка из-за того, что автомат ещё не вернулся в обычный режим.
  //
  // Поскольку при работе в многозадачной среде время проверки более не является
  // критическим местом, то я (DL) решил вне зависимости от того, проверка это или нет,
  // всегда снимать полный отчёт.
#if 0
  // Включена только проверка шины
  if (only_check)
  {
      dex_on_state_changed(bus, AUDIT_STATE_IDLE);
      return DEX_OK;
  }
#endif


  // Получение данных
  auditd_trace("Reading data...\n");
  dex_on_state_changed(bus, AUDIT_STATE_DATA_TRANSFER);
  // Сбрасываем защитный таймер. Все обошлось. Можно продолжать работу
  //Softdog_OnReturnedToMainLoop();
  while(1) {
    if (auditbus_should_stop((auditbus_t*)bus)) {
      return -EINTR;
    }

    result = dex_slave_receive(bus, result, &block);

    if (result == DEX_EOT) {
      auditd_debug("get_evadts(): transfer completed.\n");
      break;
    }

    if (result == DEX_BLOCK_HANDSHAKE)
    {
      auditd_warn("get_evadts(): invalid state: got handshake instead of data.\n");
      dex_on_state_changed(bus, AUDIT_STATE_ERROR);

      return dex_errorcode(DEX_FUNC_dex_receive_data_BLOCK_HANDSHAKE,result);
    }

    if (result != DEX_BLOCK_DATA) {
      // Проверим включена ли запись логов
      auditd_warn("get_evadts(): failed to receive data block, result=[0x%04X]\n", result);
      dex_on_state_changed(bus, AUDIT_STATE_ERROR);
      return dex_errorcode(DEX_FUNC_dex_receive_data,result);
    }

    auditd_debug("get_evadts(): got data:\n");
    dbg_printhex(block.data, block.size);
    received_size += block.size;

    // Сохранение данных в результирующий файл.
    finfile_write(dst, block.data, block.size);

    smartio_logger_printf(port, "\r\nDATA BLOCK %d\r\n", bus->nblock);

    dex_reset_timer_a(bus, false);
    result=DEX_ACK;
  } // while(1)

  // Сбрасываем защитный таймер. Все обошлось. Можно продолжать работу
  //Softdog_OnReturnedToMainLoop();

  // Передача завершена.
#if defined(CFG_DEX_USE_PROLOGUE_EPILOGUE) && (CFG_DEX_USE_PROLOGUE_EPILOGUE==1)
  dex_write_raw_bytes(bus, DISCONNECT_EPILOGUE, strlen(DISCONNECT_EPILOGUE), &dst, dst_end);
#endif
  dex_on_state_changed(bus, AUDIT_STATE_IDLE);

  auditd_debug("get_evadts(): received %d bytes.\n", received_size);
  if (received_size<10) {
    // Ошибка получения данных
    return dex_errorcode(DEX_FUNC_dex_receive_data_EOT,result);
  }

  bool overflow = finfile_isopen(dst) && finfile_isoverflow(dst);
  if (overflow) {
    auditd_error(
      "Not enough storage for EVA DTS report. Storage size: %d, Report size: %d.",
      finfile_size(dst),
      finfile_virtual_size(dst)
    );
    return dex_errorcode(DEX_FUNC_dex_receive_data,DEX_ERROR_RECEIVE_DATA_OUT_OF_MEMMORY);
  }

  return DEX_OK;




handle_error:
  auditd_info("dex_get_audit_data(): Failed to read EVA DTS. result=[0x%08X]\n", result);
  dex_on_state_changed(bus, /*  only_check ? AUDIT_STATE_IDLE :*/ AUDIT_STATE_ERROR);

  return result;
} // dex_get_audit_data



static void dex_on_state_changed(auditbus_dex_t* bus, audit_state_t state)
{
  auditbus_on_state_changed(bus, state);
}




// void dex_init(auditbus_dex_t* bus, int fd_dex_port)
// {
//   dex_deinit(bus);
//   bus->port = fd_dex_port;
//   // Выключаем режим записи сырых данных
//   bus->raw_log=false;
//   bus->nblock=0;
// }

// int dex_create(auditbus_dex_t* bus, const char* devpath, bool raw_log)
// {
//   DEBUGASSERT(bus && devpath);

//   int ret;
//   int port_fd = open(devpath, O_RDWR | O_BINARY);
//   if (port_fd < 0) {
//     ret = -errno;
//     auditd_error("Dex: can't open '%s'\n", devpath);
//     return ret;
//   }

//   dex_init(bus, port_fd);
//   bus->raw_log=raw_log;
//   return 0;
// }

// void dex_destroy(auditbus_dex_t* bus)
// {
//   /// \todo Решить, нужно ли вообще разделять на отдельные функции,
//   /// или же достаточно просто добавить открытие/закрытие файла внутрь dex_init/dex_deinit.
//   if (!bus) {
//     return;
//   }
//   // сохранение id файла, т.к. dex_deinit очистит поле bus->port.
//   int port_fd = bus->port;
//   dex_deinit(bus);

//   if (port_fd != DEX_INVALID_PORT) {
//     close(port_fd);
//   }
// }


int dex_probe(auditbus_t* bus)
{
  DEBUGASSERT(bus);
  int32_t result = dex_get_audit_data((auditbus_dex_t*)bus, /* onlycheck = */ true);
  if (result != DEX_OK) {
    return -EPROTO;
  }
  return 0;
}


int32_t dex_get_audit(auditbus_t* bus)
{
  return dex_get_audit_data((auditbus_dex_t*)bus, /* onlycheck = */ false);
}

int dex_destroy(auditbus_t* bus)
{
  // Здесь нечего делать.
  (void)bus;
  return 0;
}


int auditbus_dex_create(
  auditbus_dex_t*       instance,
  auditd_t*             owner,
  int                   instance_id,
  audit_interface_t     interface,
  eventq_t*             eventq,
  const char*           port_path,
  const char*           out_path
)
{
  static const auditbus_vmt_t   AUDITBUS_DEX_VMT = {
    .probe      = dex_probe,
    .get_audit  = dex_get_audit,
    .destroy    = dex_destroy
  };

  int ret;


  ret = auditbus_create(
    instance,
    &AUDITBUS_DEX_VMT,
    owner,
    instance_id,
    eventq,
    port_path,
    out_path,
    AUX_TYPE_AUDIT_DEX,
    interface,
    "dex",
    NULL
  );

  if (ret < 0) {
    return ret;
  }

  return 0;
}
