/// \file
/// \brief Получение данных аудита через протокол DEX.
/// \author DL <dmitriy.linikov@gmail.com>

#ifndef BUS_DEX_H_INCLUDED
#define BUS_DEX_H_INCLUDED

#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <errno.h>
#include <utils/timeout.h>
#include <auditd/audit_state.h>
#include "auditbus.h"


#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

/// \brief Определение двухбайтной команды, начинающейся с DLE
#define DEX_CMD(code)   ((DEX_DLE_CHAR << 8) | (code & 0xFF))

/// \brief Максимальный размер блока DEX - 245 байт включая завершающие DLE/ETB.
/// В данной реализации DLE/ETB в буффер блока не попадают. Итого 243 символа.
#define DEX_BLOCK_MAX_CHARS                     243


/// \brief перечисление всех "специальных" значений, которые может принимать
/// переменная типа dexchar_t.
typedef enum DexResultTag {
  DEX_OK = 0,

  // ==================== Ошибки =====================

  DEX_TIMEOUT = (-EAGAIN),
  DEX_INTERRUPTED = (-EINTR),
  DEX_BAD_RSP = (-__ELASTERROR - 1),
  DEX_BAD_INSTANCE = (DEX_BAD_RSP-1),
  DEX_ERROR_RECEIVE_DATA_OUT_OF_MEMMORY = (DEX_BAD_INSTANCE-1),
  DEX_ERROR_OUT_OF_ATTEMPTS = (DEX_ERROR_RECEIVE_DATA_OUT_OF_MEMMORY-1),
  DEX_BAD_CRC_PACKET =(DEX_ERROR_OUT_OF_ATTEMPTS-1),
  DEX_BAD_RSP_HANDSHAKE_SLAVE_NOT_SOH =(DEX_BAD_CRC_PACKET-1),
  DEX_BAD_RSP_HANDSHAKE_SLAVE_NOT_EOT =(DEX_BAD_RSP_HANDSHAKE_SLAVE_NOT_SOH-1),
  DEX_BAD_RSP_HANDSHAKE_MASTER_NOT_ACK =(DEX_BAD_RSP_HANDSHAKE_SLAVE_NOT_EOT-1),

  // Номера базовых процедур DEX

  DEX_FUNC_enter_dex_get_audit_data         = 0x01000000,
  DEX_FUNC_dex_send_handshake_1             = 0x02000000,
  DEX_FUNC_dex_receive_handshake_1          = 0x03000000,
  DEX_FUNC_dex_send_handshake_2             = 0x04000000,
  DEX_FUNC_dex_receive_handshake_2          = 0x05000000,
  DEX_FUNC_dex_receive_data_BLOCK_HANDSHAKE = 0x06000000,
  DEX_FUNC_dex_receive_data                 = 0x07000000,
  DEX_FUNC_dex_receive_data_EOT             = 0x08000000,

  // ======== Определения сырых символов =============

  DEX_SOH_CHAR= 0x0001,
  DEX_STX_CHAR= 0x0002,
  DEX_ETX_CHAR= 0x0003,
  DEX_EOT_CHAR= 0x0004,
  DEX_ENQ_CHAR= 0x0005,
  DEX_DLE_CHAR= 0x0010,
  DEX_NAK_CHAR= 0x0015,
  DEX_SYN_CHAR= 0x0016,
  DEX_ETB_CHAR= 0x0017,

  // ======== Определения двух-байтных команд =====================

  DEX_ACK0    = DEX_CMD(0x30),

  // при успешном приёме ACK всегда возвращается DEX_ACK.
  // остальные ACK-константы нужны для внутреннего использования в
  // функциях dex_read_ack и dex_send_ack
  DEX_ACK     = DEX_ACK0,
  DEX_ACK1    = DEX_CMD(0x31),
  DEX_WACK    = DEX_CMD(0x3B),
  DEX_SOH     = DEX_CMD(DEX_SOH_CHAR),
  DEX_STX     = DEX_CMD(DEX_STX_CHAR),
  DEX_ETB     = DEX_CMD(DEX_ETB_CHAR),
  DEX_ETX     = DEX_CMD(DEX_ETX_CHAR),
  DEX_SYN     = DEX_CMD(DEX_SYN_CHAR),

  // ======== Определение однобайтных команд ======================

  DEX_EOT     = DEX_EOT_CHAR,
  DEX_ENQ     = DEX_ENQ_CHAR,
  DEX_NAK     = DEX_NAK_CHAR,

} DexResult;



/// \brief Один символ данных, передаваемых по шине dex, либо код ошибки.
/// Если значение находится от 0 до 255, то это одиночный символ,
/// Если значение находится от 256 до 65535, то это двухбайтный символ.
/// Если значение меньше нуля, то это код ошибки
/// Если значение больше 65535 - это недопустимый символ.
typedef int32_t   dexchar_t;


/// \brief Тип блока данных и Результат выполнения функции \see dex_receive
typedef enum DexBlockTypeTag {
  DEX_BLOCK_TIMEOUT   = DEX_TIMEOUT,
  DEX_BLOCK_INVALID   = DEX_BAD_RSP,
  DEX_BLOCK_EOT       = DEX_EOT,
  DEX_BLOCK_HANDSHAKE = DEX_SOH,
  DEX_BLOCK_DATA      = DEX_STX
} DexBlockType;


typedef struct DexDataBlockTag {
  /// \brief Строка данных, оканчивающася на '\0'
  void*           data;

  /// \brief Количество символов в строке. При отправке, если в строке
  /// был обнаружен нуль-символ, то отправка завершается, даже если ещё не
  /// было отправлено size байт.
  size_t          size;

  /// \brief Тип блока данных.
  DexBlockType    type;

  /// \brief Контрольная сумма, полученная от VMD.
  uint16_t        received_crc;

  /// \brief Контрольная сумма, вычисленная при приёме данных от VMD.
  uint16_t        calculated_crc;

  /// \brief Является ли данный блок последним в текущей транзакции.
  bool            is_last_block;

  /// \brief Вычисленная контрольная сумма совпадает с отправленной VMD.
  bool            is_crc_valid;


} DexBlock;



typedef struct auditbus_dex_s {
  /// \brief Наследуемся от auditbus_t.
  auditbus_t      base;


  /// \brief Таймер A служит для обнаружения отсутствия ответа после приёма
  /// команды начала передачи (ENQ). Обычно, это 1 секунда.
  timeout_t       timer_a;

  /// \brief Таймер D служит для обнаружения зависания сессии (т.е. максимальное
  /// время бездействия после открытия сессии - максимальное время между блоками
  /// данных). Обычно это TimerA + 2 секунды.
  timeout_t       timer_d;
  uint8_t         rx_ack_number;
  uint8_t         tx_ack_number;
  uint16_t        rx_crc;
  uint16_t        tx_crc;

  dex_state_listener_t    on_state_changed;

  /// \brief Признак того, что в slave режиме была получена команда начала
  /// передачи данных.
  bool            transaction_active;

  char            rx_buffer[DEX_BLOCK_MAX_CHARS + 1];
  size_t          rx_index;
  /// количество полученных блоков
  int16_t         nblock;

} auditbus_dex_t;






int auditbus_dex_create(
  auditbus_dex_t*       instance,
  auditd_t*             owner,
  int                   instance_id,
  audit_interface_t     interface,
  eventq_t*             eventq,
  const char*           port_path,
  const char*           out_path
);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // BUS_DEX_H_INCLUDED
