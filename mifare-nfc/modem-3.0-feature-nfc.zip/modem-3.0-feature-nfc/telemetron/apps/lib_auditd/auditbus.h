/// \file
/// \brief  Публичный интерфейс для абстрактного протокола аудита
/// \author DL <dmitriy@linikov.ru>


#ifndef TELEMETRON_APPS_LIB_AUDITD_PROTOCOL_H_INCLUDED
#define TELEMETRON_APPS_LIB_AUDITD_PROTOCOL_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <assert.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <eventq/eventq.h>
#include <utils/finfile.h>
#include <utils/smartio.h>

#include <auditd/auditd_config.h>
#include <auditd/audit_state.h>
#include <auditd/audit_protocol.h>

#include <settings/settings.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора



////////////////////////////////////////////////////////////////////////////
//  Типы данных
typedef struct auditd_s       auditd_t;
typedef struct auditbus_s     auditbus_t;

typedef void (*auditbus_state_fxn_t)(void* arg, audit_state_t newstate);
typedef void (*auditbus_report_fxn_t)(void* arg, uint32_t error_code, size_t report_size);

/// \brief Таблица методов протокола аудита.
typedef struct auditbus_vmt_s {
  /// \retval 0         Проверка шины прошла успешно.
  /// \retval -EINTR    Получено внешнее прерывание. Нужно завершить работу.
  /// \retval <0        Ошибка
  int (*probe)(auditbus_t* bus);


  /// \retval -EPROTO   Не подходящий протокол.
  /// \retval -ENODATA  На шине долго нет подходящих данных. Сменился тип?
  /// \retval -EINTR    Получено внешнее прерывание. Нужно завершить работу.
  int32_t (*get_audit)(auditbus_t* bus);

  int (*destroy)(auditbus_t* bus);

} auditbus_vmt_t;


/// \brief Базовый объект для всех протоколов аудита
struct auditbus_s {
  const auditbus_vmt_t*   vmt;        ///< Таблица методов.
  auditd_t*               owner;      ///< Владелец/создатель шины.
  int                     instance_id;///< Номер экземпляра сервиса auditd

  void*                   cb_arg;     ///< Параметр, передаваемый в функцию cb_state и cb_report
  auditbus_state_fxn_t    cb_state;   ///< Функция, вызываемая при изменении состояния передачи
  auditbus_report_fxn_t   cb_report;  ///< Функция, вызываемая при завершении снятия отчёта

  eventq_t*               eventq;     ///< Очередь сообщений для отправки событий
  const char*             tty_path;   ///< Путь к драйверу последовательного порта
  const char*             out_path;   ///< Путь к файлу для сохранения результата
  audit_protocol_t        protocol;   ///< Тип шины аудита
  audit_interface_t       interface;  ///< Аппаратный интерфейс подключения
  const char*             name;       ///< Строка с типом шины аудита. (для отладочных сообщений)

  ddcmp_params_t          params;     ///< что-то для ddcmp и автоматы saeco

  smartio_t               port;       ///< Файл порта ввода-вывода.
  finfile_t               outfile;    ///< Файл для вывода данных
  finfile_t               logfile;    ///< Файл для хранения сырого лога

  uint32_t                last_error_code;  ///< код ошибки при последнем снятии отчёта
  uint32_t                last_report_size; ///< Размер файла последнего снятого отчёта
};

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int auditbus_create(
  void*                 instance,
  const auditbus_vmt_t* vmt,
  auditd_t*             owner,
  int                   instance_id,
  eventq_t*             eventq,
  const char*           tty_path,
  const char*           out_path,
  audit_protocol_t      protocol,
  audit_interface_t     interface,
  const char*           name,
  const ddcmp_params_t* params
);

int auditbus_destroy(auditbus_t* auditbus);
int auditbus_set_cb(auditbus_t* auditbus, auditbus_state_fxn_t cb_state, void* arg);
int auditbus_probe(auditbus_t* auditbus);
int auditbus_get_audit(auditbus_t* auditbus);
bool auditbus_should_stop(auditbus_t* auditbus);

#ifdef __cplusplus
} // extern "C"
#endif

// inline функции для использования из наследных объектов

static inline void auditbus_on_state_changed(void* instance, audit_state_t newstate)
{
  auditbus_t* auditbus = (auditbus_t*)instance;

  DEBUGASSERT(auditbus);

  if (auditbus->cb_state) {
    auditbus->cb_state(auditbus->cb_arg, newstate);
  }
}


static inline smartio_t*  auditbus_port(void* instance)
{
  auditbus_t* auditbus = (auditbus_t*)instance;

  DEBUGASSERT(auditbus);
  return &auditbus->port;
}

static inline finfile_t*  auditbus_logfile(void* instance)
{
  auditbus_t* auditbus = (auditbus_t*)instance;

  DEBUGASSERT(auditbus);
  return &auditbus->logfile;
}

static inline finfile_t*  auditbus_outfile(void* instance)
{
  auditbus_t* auditbus = (auditbus_t*)instance;

  DEBUGASSERT(auditbus);
  return &auditbus->outfile;
}

static inline audit_protocol_t auditbus_get_protocol(void* instance)
{
  auditbus_t* auditbus = (auditbus_t*)instance;

  DEBUGASSERT(auditbus);
  return auditbus->protocol;
}

static inline audit_interface_t auditbus_get_interface(void* instance)
{
  auditbus_t* auditbus = (auditbus_t*)instance;

  DEBUGASSERT(auditbus);
  return auditbus->interface;
}

static inline const char* auditbus_get_name(void* instance)
{
  auditbus_t* auditbus = (auditbus_t*)instance;

  DEBUGASSERT(auditbus && auditbus->vmt);
  return auditbus->name;
}

static inline const ddcmp_params_t* auditbus_get_params(void* instance)
{
  auditbus_t* auditbus = (auditbus_t*)instance;

  DEBUGASSERT(auditbus && auditbus->vmt);
  return &auditbus->params;
}


static inline uint8_t auditbus_get_saeco_fix(void* instance)
{
  auditbus_t* auditbus = (auditbus_t*)instance;

  DEBUGASSERT(auditbus && auditbus->vmt);
  return auditbus->params.ddcmp_saeco_fix;
}

#endif // TELEMETRON_APPS_LIB_AUDITD_PROTOCOL_H_INCLUDED
