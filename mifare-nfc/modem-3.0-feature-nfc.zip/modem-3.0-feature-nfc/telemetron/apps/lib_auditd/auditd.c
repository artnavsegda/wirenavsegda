/// \file
/// \brief  Библиотека сервиса чтения отчётов с торговых автоматов
/// \author DL <dmitriy@linikov.ru>

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <auditd/auditd.h>
#include "auditbus.h"

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <ccan/array_size/array_size.h>
#include <utils/service.h>
#include <utils/time_utils.h>
#include <utils/string_utils.h>
#include <utils/posix_iohelper.h>
#include <eventq/eventq.h>

#include <auditd/audit_events.h>
#include <auditd/audit_protocol.h>

#include "bus_dex.h"
#include "bus_ddcmp.h"
#include "bus_gerhardt.h"

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора

////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных

auditbus_t* (*auditbus_create_fxn)(auditd_t* auditd);

typedef union auditbus_storage_s {
  auditbus_dex_t          bus_dex;
  auditbus_ddcmp_t        bus_ddcmp;
  auditbus_gerhardt_t     bus_gerhardt;
} auditbus_storage_t;


struct auditd_s {
  service_t   base;             ///< Наследуемся от service_t
  int         instance_id;      ///< Номер экземпляра
  eventq_t    eventq;           ///< Очередь исходящих сообщений
  sem_t       wake_sem;         ///< Семафор для снятия отчёта

  char        tty_path[AUDITD_TTYPATH_MAX];     ///< Путь к порту
  char        out_path[AUDITD_OUTPATH_MAX];     ///< Путь к отчёту
  char        eventq_name[AUDITD_TTYPATH_MAX];  ///< Имя очереди сообщений

  aux_params_t                settings;     ///< Настройки AUX порта и протоколов
  bool                        autodetect;   ///< Следует ли автоматически проверять тип протокола

  auditbus_t*                 bus;          ///< Текущий протокол
  auditbus_storage_t          bus_storage;  ///< Буффер для хранения любого из протоколов.
};


/// \brief Класс, описывающий фабрику, создающую и удаляющую обработчика шины
typedef struct auditbus_factory_s auditbus_factory_t;

/// \brief Класс, описывающий фабрику, создающую и удаляющую обработчика шины
struct auditbus_factory_s {
  // Идентификатор шины.
  aux_type_t                protocol;

  // Идентификатор физического интерфейса
  aux_interface_t           interface;

  // Вызов конструктора обработчика шины
  auditbus_t*               (*create)(auditd_t* auditd, const auditbus_factory_t* factory);
} ;


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

static auditbus_t* auditd_create_bus_dex(auditd_t* auditd, const auditbus_factory_t* factory);
static auditbus_t* auditd_create_bus_ddcmp(auditd_t* auditd, const auditbus_factory_t* factory);
static auditbus_t* auditd_create_bus_gerhardt(auditd_t* auditd, const auditbus_factory_t* factory);


////////////////////////////////////////////////////////////////////////////
//  Константы

static const auditbus_factory_t    BUS_FACTORIES[] = {
  { .protocol = AUX_TYPE_AUDIT_DEX,       .interface = AUX_INTERFACE_TTL,   .create = auditd_create_bus_dex },
  { .protocol = AUX_TYPE_AUDIT_DDCMP,     .interface = AUX_INTERFACE_TTL,   .create = auditd_create_bus_ddcmp },
  { .protocol = AUX_TYPE_AUDIT_DEX,       .interface = AUX_INTERFACE_RS232, .create = auditd_create_bus_dex },
  { .protocol = AUX_TYPE_AUDIT_DDCMP,     .interface = AUX_INTERFACE_RS232, .create = auditd_create_bus_ddcmp },
  { .protocol = AUX_TYPE_AUDIT_GERHARDT,  .interface = AUX_INTERFACE_TTL,   .create = auditd_create_bus_gerhardt },
  { .protocol = AUX_TYPE_AUDIT_GERHARDT,  .interface = AUX_INTERFACE_RS232, .create = auditd_create_bus_gerhardt },
};

////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные

static auditd_t       g_auditd_instances[CONFIG_LIB_AUDITD_MAX_INSTANCES];
static bool           g_auditd_used[CONFIG_LIB_AUDITD_MAX_INSTANCES];

static volatile bool  g_auditd_inited = false;

////////////////////////////////////////////////////////////////////////////
//  Приватные функции

/// \brief Поиск первой фабрики, удовлетворяющей параметрам.
off_t auditd_find_first_factory_index(
  audit_protocol_t  protocol,
  audit_interface_t interface
)
{
  if (protocol == AUX_TYPE_AUDIT_AUTO && interface == AUX_INTERFACE_AUTO) {
    // При полном авто-определении начинаем поиск с самого первого варианта
    return 0;
  }

  for (size_t i=0; i < ARRAY_SIZE(BUS_FACTORIES); ++i) {
    const auditbus_factory_t* factory = &BUS_FACTORIES[i];
    if (factory->protocol == protocol && factory->interface == interface) {
      // полное совпадение
      return (off_t)i;
    }

    if (interface == AUX_INTERFACE_AUTO && factory->protocol == protocol) {
      // Поиск с фиксированным протоколом, найдена первая подходящая запись
      return (off_t)i;
    }

    if (protocol == AUX_TYPE_AUDIT_AUTO && factory->interface == interface) {
      // Поиск с фиксированным интерфейсом, найдена первая подходящая запись
      return (off_t)i;
    }
  } // for
  return -1;
}

off_t auditd_find_next_factory_index(
  off_t             prev,
  audit_protocol_t  protocol,
  audit_interface_t interface
)
{
  if (prev < 0 || prev >= ARRAY_SIZE(BUS_FACTORIES)) {
    // Если предыдущий индекс оказался вне массива, то нельзя продолжить поиск.
    return -1;
  }

  off_t i = prev + 1;
  while (i < ARRAY_SIZE(BUS_FACTORIES)) {
    const auditbus_factory_t* factory = &BUS_FACTORIES[i];

    if (factory->protocol == protocol && factory->interface == interface) {
      // полное совпадение
      return (off_t)i;
    }

    if (interface == AUX_INTERFACE_AUTO && factory->protocol == protocol) {
      // Поиск с фиксированным протоколом, найдена первая подходящая запись
      return (off_t)i;
    }

    if (protocol == AUX_TYPE_AUDIT_AUTO && factory->interface == interface) {
      // Поиск с фиксированным интерфейсом, найдена первая подходящая запись
      return (off_t)i;
    }
    ++i;
  } // for;

  return -1;
}

const auditbus_factory_t* auditd_find_bus_factory(
  audit_protocol_t  protocol,
  audit_interface_t interface
)
{
  for (size_t i=0; i < ARRAY_SIZE(BUS_FACTORIES); ++i) {
    const auditbus_factory_t* factory = &BUS_FACTORIES[i];
    if (factory->protocol == protocol && factory->interface == interface) {
      return factory;
    }
  }
  return NULL;
}



static bool auditd_supports_type_interface(aux_type_t type, aux_interface_t interface)
{
  if (type == AUX_TYPE_AUDIT_AUTO && interface == AUX_INTERFACE_AUTO) {
    // Если задан автоматический поиск как протокола, так и физического интерфейса,
    // то достаточно, что бы в списке поддерживаемых был хоть один протокол.
    return ARRAY_SIZE(BUS_FACTORIES) > 0;
  }

  for (size_t i=0; i < ARRAY_SIZE(BUS_FACTORIES); ++i) {
    const auditbus_factory_t* factory = &BUS_FACTORIES[i];
    if (type == AUX_TYPE_AUDIT_AUTO && factory->interface == interface) {
      // При автоматическом поиске протокола при известном интерфейсе
      // достаточно, что бы хоть один протокол поддерживал этот
      // физический интерфейс
      return true;
    }

    if (interface == AUX_INTERFACE_AUTO && factory->protocol == type) {
      // При автоматическом поиске физического интерфейса достаточно,
      // что бы хоть один протокол работал через этот интерфейс.
      return true;
    }

    if (factory->protocol == type && factory->interface == interface) {
      // Есть полное соответствие протокола и интерфейса - значит поддерживается.
      return true;
    }
  } // for
  return false;
}

static void auditd_lazyinit(void)
{
  if (g_auditd_inited) {
    return;
  }

  memset(g_auditd_used, 0, sizeof(g_auditd_used));
  g_auditd_inited = true;
}

static auditd_t* auditd_calloc(int instance_id)
{
  auditd_t* auditd = NULL;

  sched_lock();
    auditd_lazyinit();
    if (    instance_id >= 0
         && instance_id < CONFIG_LIB_AUDITD_MAX_INSTANCES
         && !g_auditd_used[instance_id]
    ) {
      auditd = &g_auditd_instances[instance_id];
      g_auditd_used[instance_id] = true;
    }
  sched_unlock();

  if (auditd) {
    auditd_trace("Allocated auditd instance #%d @%p\n", instance_id, auditd);
    memset(auditd, 0, sizeof(*auditd));
  }

  return auditd;
}

static void auditd_free(auditd_t* auditd)
{
  bool found = false;
  sched_lock();
    for (size_t i=0; i < CONFIG_LIB_AUDITD_MAX_INSTANCES; ++i) {
      if (&g_auditd_instances[i] != auditd) {
        continue;
      }

      if (g_auditd_used[i]) {
        found = true;
        g_auditd_used[i] = false;
      }
    }
  sched_unlock();

  if (!found) {
    auditd_error("ERROR: Attempt to free not allocated instance @%p\n", auditd);
  }
}

static auditd_t* auditd_get_instance(int instance_id)
{
  auditd_t* auditd = NULL;

  if (instance_id < 0 || instance_id >= CONFIG_LIB_AUDITD_MAX_INSTANCES) {
    return NULL;
  }

  sched_lock();
    if (g_auditd_used[instance_id]) {
      auditd = &g_auditd_instances[instance_id];
    }
  sched_unlock();

  return auditd;
}


static int         auditd_emit_event(auditd_t* auditd, eventq_event_t* event)
{
  DEBUGASSERT(auditd);
  if (eventq_is_opened(&auditd->eventq)) {
    return eventq_write_ex(&auditd->eventq, event);
  }
  return 0;
}


static int         auditd_emit_ev_state(auditd_t* auditd, audit_state_t state)
{
  DEBUGASSERT(auditd);
  eventq_event_t buffer;
  ev_audit_state_t* ev = EVENTQ_CREATE_EVENT(&buffer, EV_AUDIT_STATE, ev_audit_state_t);

  ev->instance_id = auditd->instance_id;
  ev->protocol    = auditd->settings.type;
  ev->interface   = auditd->settings.interface;
  ev->saeco_fix   = auditd->settings.ddcmp_params.ddcmp_saeco_fix;

  return auditd_emit_event(auditd, &buffer);
}


static int auditd_emit_ev_report(auditd_t* auditd, uint32_t error_code, size_t report_size)
{
  DEBUGASSERT(auditd);

  int ret;
  eventq_event_t buffer;
  ev_audit_report_t* ev = EVENTQ_CREATE_EVENT(&buffer, EV_AUDIT_REPORT, ev_audit_report_t);

  ev->instance_id = auditd->instance_id;
  ev->protocol    = auditd->settings.type;
  ev->interface   = auditd->settings.interface;
  ev->error_code  = error_code;
  ev->report_size = report_size;
  ev->saeco_fix   = auditd->settings.ddcmp_params.ddcmp_saeco_fix;

  ret = snprintf(ev->path, sizeof(ev->path), "%s", auditd->out_path);
  DEBUGASSERT(ret < sizeof(ev->path));

  return auditd_emit_event(auditd, &buffer);
}

static int auditd_emit_ev_report_error(auditd_t* auditd, int error_code)
{
  return auditd_emit_ev_report(auditd, (uint32_t)error_code, 0);
}


static auditbus_t* auditd_create_bus_dex(auditd_t* auditd, const auditbus_factory_t* factory)
{
  int ret = auditbus_dex_create(
    &auditd->bus_storage.bus_dex,
    auditd,
    auditd->instance_id,
    factory->interface,
    &auditd->eventq,
    auditd->tty_path,
    auditd->out_path
  );

  if (ret < 0) {
    auditd_perror("Can't create bus_dex", -ret);
    return NULL;
  }

  return (auditbus_t*)&auditd->bus_storage.bus_dex;
}

static auditbus_t* auditd_create_bus_ddcmp(auditd_t* auditd, const auditbus_factory_t* factory)
{
  int ret = auditbus_ddcmp_create(
    &auditd->bus_storage.bus_ddcmp,
    auditd,
    auditd->instance_id,
    factory->interface,
    &auditd->eventq,
    auditd->tty_path,
    auditd->out_path,
    NULL
  );

  if (ret < 0) {
    auditd_perror("Can't create bus_dex", -ret);
    return NULL;
  }

  return (auditbus_t*)&auditd->bus_storage.bus_ddcmp;
}

static auditbus_t* auditd_create_bus_gerhardt(auditd_t* auditd, const auditbus_factory_t* factory)
{
  int ret = auditbus_gerhardt_create(
    &auditd->bus_storage.bus_gerhardt,
    auditd,
    auditd->instance_id,
    factory->interface,
    &auditd->eventq,
    auditd->tty_path,
    auditd->out_path
  );

  if (ret < 0) {
    auditd_perror("Can't create bus_gerhardt", -ret);
    return NULL;
  }

  return (auditbus_t*)&auditd->bus_storage.bus_gerhardt;
}

static void auditd_on_bus_state(void* arg, audit_state_t newstate)
{
  auditd_emit_ev_state((auditd_t*)arg, newstate);
}

static auditbus_t* auditd_create_bus(auditd_t* auditd, const auditbus_factory_t* factory)
{
  auditbus_t* bus;

  if (!factory || !factory->create) {
    return NULL;
  }
  bus = factory->create(auditd, factory);
  if (!bus) {
    return NULL;
  }
  auditbus_set_cb(bus, auditd_on_bus_state, auditd);

  const char* bus_name = auditbus_get_name(bus);
  if (!bus_name) {
    bus_name = "error";
  }
  auditd_info("AUDIT: Created bus. name='%s'\n", bus_name);

  return bus;
}


static int detect_bus(auditd_t* auditd)
{
  // Если в качестве протокола выбрано автоопределение, то
  // при каждом старте сервиса происходит попытка определить, какой протокол
  // следует использовать.
  // Автоопределение осуществляется опросом каждого из имеющихся
  // протоколов/физических уровней с паузой в 1 минуту между опросами.
  //
  // При этом, что бы не было лишних событий, можно временно отключить
  // callback.
  int               ret;
  bool              need_report = false;
  aux_params_t*     settings    = &auditd->settings;
  auditd->bus = NULL;

  if (!auditd_is_enabled(auditd)) {
    return 0;
  }


  // Проверяем (без блокировки), нужно ли при первой попытке запроса
  // сохранить данные отчёта.
  for (;;) {
    ret = sem_trywait(&auditd->wake_sem);
    if (ret < 0) {
      ret = -errno;
    }

    if (ret == -EINTR) {
      continue;
    }

    need_report = (ret == 0);
    break;
  }


  off_t factory_index = -1;
  for (;;) {
    if (service_should_stop((service_t*)auditd)) {
      return -EINTR;
    }

    // Поиск следующей подходящей конфигурации шины
    if (factory_index < 0) {
      // Рестарт поиска
      factory_index = auditd_find_first_factory_index(settings->type, settings->interface);
      if (factory_index < 0) {
        // невозможно найти шину с заданными параметрами.
        break;
      }

    } else {
      // Продолжение поиска
      factory_index = auditd_find_next_factory_index(factory_index, settings->type, settings->interface);
      if (factory_index < 0) {
        // достигли конца массива. Начнём сначала.
        continue;
      }
    }

    // Создание шины и попытка снять отчёт/проверить шину.
    const auditbus_factory_t* factory = &BUS_FACTORIES[factory_index];
    auditd->bus = auditd_create_bus(auditd, factory);
    if (auditd->bus) {
      ret = need_report ? auditbus_get_audit(auditd->bus) : auditbus_probe(auditd->bus);
      if (ret >= 0) {
        // Успешно прочитан отчёт.
        // Сохраняем обнаруженные параметры в переменную настроек.
        settings->type        = factory->protocol;
        settings->interface   = factory->interface;
        if (need_report) {
          auditd_emit_ev_report(auditd, auditd->bus->last_error_code, auditd->bus->last_report_size);
        }
        auditd_emit_ev_state(auditd, AUDIT_STATE_IDLE);
        break;
      }
    }

    if (settings->type != AUX_TYPE_AUDIT_AUTO && settings->interface != AUX_INTERFACE_AUTO) {
      // Сервис был настроен на фиксированный протокол и физический интерфейс
      // поэтому даже при ошибке создания или снятия отчёта завершаем поиск и возвращаем 0.
      if (auditd->bus && need_report) {
        // попытка снятия отчёта завершилась ошибкой. Нужно уведомить внешний код.
        auditd_emit_ev_report_error(auditd, ret);
      }
      auditd_emit_ev_state(auditd, AUDIT_STATE_ERROR);
      break;
    }

    // Не удалось снять отчёт - текущие параметры не подходят.
    auditd_emit_ev_state(auditd, AUDIT_STATE_UNDEFINED);
    if (auditd->bus) {
      auditbus_destroy(auditd->bus);
      auditd->bus = NULL;
    }

    // Проверка перед паузой, что сервис ещё не остановлен
    if (service_should_stop((service_t*)auditd)) {
      return -EINTR;
    }

    // Пауза перед очередным снятием отчёта, отслеживая при этом команды снятия отчёта
    struct timespec   next_iteration_time = timespec_after_ms(60*1000);
    ret = sem_timedwait(&auditd->wake_sem, &next_iteration_time);
    if (ret < 0) {
      ret = -errno;
    }

    // Если получили сигнал через семафор, то это значит, что внешний код ожидает
    // получения отчёта.
    need_report |= (ret >= 0);
  }
  return 0;
}

static int auditd_thread_main(void* arg)
{
  int             ret;
  auditd_t*       auditd = (auditd_t*)arg;
  DEBUGASSERT(auditd);

  eventq_open(&auditd->eventq, auditd->eventq_name, O_WRONLY);



  auditd_emit_ev_state(auditd, AUDIT_STATE_UNDEFINED);

  // Обнаружить шину
  detect_bus(auditd);

  if (!auditd->bus) {
    auditd_emit_ev_state(auditd, AUDIT_STATE_UNDEFINED);
  }

  while (!service_should_stop((service_t*)auditd)) {
    struct timespec   next_try_time = timespec_after_ms(1000*60*CONFIG_LIB_AUDITD_AUTODETECT_MINUTTES);
    ret = sem_timedwait(&auditd->wake_sem, &next_try_time);
    if (ret < 0) {
      ret = -errno;
    }

    if (ret == -EINTR || ret == -EAGAIN || !auditd->bus) {
      continue;
    }
    if (service_should_stop((service_t*)auditd)) {
      // Если получили запрос остановки сервиса, не обработанный через EINTR
      // то выход из цикла.
      break;
    }

    ret = auditbus_get_audit(auditd->bus);
    if (ret < 0) {
      auditd_emit_ev_report_error(auditd, ret);
      auditd_emit_ev_state(auditd, AUDIT_STATE_ERROR);
    } else {
      auditd_emit_ev_report(auditd, auditd->bus->last_error_code, auditd->bus->last_report_size);
      auditd_emit_ev_state(auditd, AUDIT_STATE_IDLE);
    }

  } // while


  if (auditd->bus) {
    auditbus_destroy(auditd->bus);
    auditd->bus = NULL;
  }

  eventq_close(&auditd->eventq);
  return 0;
}


////////////////////////////////////////////////////////////////////////////
//  Публичные функции

int auditd_create(auditd_t** dst, int id, const char* tty_path, const char* out_path, const char* queue)
{
  int     ret;
  auditd_t* auditd = auditd_calloc(id);

  DEBUGASSERT(dst && tty_path);

  if (!auditd) {
    auditd_error("ERROR: Can't alloc auditd instance #%d\n", id);
    return -ENOMEM;
  }

  ret = service_create(
    (service_t*)auditd,
    "AUDITD",
    CONFIG_LIB_AUDITD_DAEMON_PRIORITY,
    CONFIG_LIB_AUDITD_DAEMON_STACKSIZE,
    auditd_thread_main,
    auditd
  );
  if (ret < 0) {
    auditd_error("ERROR: Can't create auditd service, ret=%d (%s)\n", ret, strerror(-ret));
    goto errcleanup;
  }

  ret = eventq_init(&auditd->eventq);
  if (ret < 0) {
    auditd_error("ERROR: Can't init eventq, ret=%d (%s)\n", ret, strerror(-ret));
    goto errcleanup;
  }

  ret = sem_init(&auditd->wake_sem, 0, 0); // изначально несвободный
  if (ret < 0) {
    ret = -errno;
    auditd_error("ERROR: Can't init sem, ret=%d (%s)\n", ret, strerror(-ret));
    goto errcleanup;
  }

  auditd->instance_id = id;
  auditd->autodetect  = false;

  memset(&auditd->settings, 0, sizeof(auditd->settings));

  ret = snprintf(auditd->tty_path, sizeof(auditd->tty_path), "%s", tty_path);
  DEBUGASSERT(ret < sizeof(auditd->tty_path));

  ret = snprintf(auditd->out_path, sizeof(auditd->out_path), "%s", out_path ? out_path : "");
  DEBUGASSERT(ret < sizeof(auditd->out_path));

  ret = snprintf(auditd->eventq_name, sizeof(auditd->eventq_name), "%s", queue ? queue : "");
  DEBUGASSERT(ret < sizeof(auditd->eventq_name));

  *dst = auditd;
  return 0;

errcleanup:
  auditd_free(auditd);
  return ret;
}

int auditd_destroy(auditd_t* auditd)
{
  DEBUGASSERT(auditd);

  int ret;
  if (auditd_is_started(auditd)) {
    // Сперва остановка сервиса, если он активен.
    ret = auditd_kill_and_wait(auditd, 45000);
    if (ret < 0) {
      auditd_error("ERROR: Can't stop service, ret=%d (%s)\n", ret, strerror(-ret));
      return ret;
    }
  }

  sem_destroy(&auditd->wake_sem);
  eventq_close(&auditd->eventq);
  service_delete((service_t*)auditd);

  auditd_free(auditd);
  return 0;
}

auditd_t* auditd_find_instance(int id)
{
  return auditd_get_instance(id);
}

int auditd_setup(auditd_t* auditd, const aux_params_t* settings, bool use_autodetect)
{
  DEBUGASSERT(auditd);

  if (aux_params_equals(&auditd->settings, settings) && use_autodetect == auditd->autodetect) {
    // Настройки не изменились.
    return 0;
  }

  bool was_started  = false;
  if (auditd_is_started(auditd)) {
    was_started = true;
    auditd_kill_and_wait(auditd, -1);
  }

  auditd->settings    = *settings;
  auditd->autodetect  = use_autodetect;

  if (was_started) {
    auditd_start(auditd);
  }
  return 0;
}

int auditd_wake(auditd_t* auditd)
{
  DEBUGASSERT(auditd);
  if (!auditd_is_started(auditd)) {
    // Нет такого процесса
    auditd_trace("ERROR: Attempt to wake not-started auditd instance\n");
    return -ESRCH;
  }

  return sem_post(&auditd->wake_sem);
}

const aux_params_t* auditd_get_settings(auditd_t* auditd)
{
  DEBUGASSERT(auditd);
  return &auditd->settings;
}

bool              auditd_get_autodetect(auditd_t* auditd)
{
  DEBUGASSERT(auditd);
  return auditd->autodetect;
}

/// \returns true, если настройки позволяют данному экземпляру работать.
bool auditd_is_enabled(auditd_t* auditd)
{
  aux_params_t* settings    = &auditd->settings;
  bool          autodetect  = auditd->autodetect;

  if ( settings->type       == AUX_TYPE_OFF
    || settings->type       == AUX_TYPE_KKM_PRINTER
    || settings->type       == AUX_TYPE_CONSOLE
    || settings->interface  == AUX_INTERFACE_OFF
  ) {
    // Порт отключен
    return false;
  }

  if ((settings->type == AUX_TYPE_AUDIT_AUTO || settings->interface == AUX_INTERFACE_AUTO)
      && !autodetect
  ) {
    // Требуется автоопределение, которое отключено настройками
    return false;
  }

  if (!auditd_supports_type_interface(settings->type, settings->interface)) {
    // Выбранная пара протокол-интерфейс не поддерживается.
    return false;
  }

  return true;
}
