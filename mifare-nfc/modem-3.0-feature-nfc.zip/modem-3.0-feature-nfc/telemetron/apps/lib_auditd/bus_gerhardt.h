/// \file
/// \brief  Реализация протокола Gerhardt для снятия отчетов аудита.
/// \author DL <dmitriy@linikov.ru>


#ifndef TELEMETRON_APPS_LIB_AUDITD_BUS_GERHARDT_H_INCLUDED
#define TELEMETRON_APPS_LIB_AUDITD_BUS_GERHARDT_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов


#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <errno.h>
#include <utils/timeout.h>
#include <auditd/audit_state.h>
#include "auditbus.h"

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Типы данных

typedef struct auditbus_gerhardt_s {
  /// \brief Наследуемся от auditbus_t.
  auditbus_t      base;

  dex_state_listener_t    on_state_changed;

  size_t          rx_index;
  uint16_t        rx_crc;
  timeout_t       timer_d;
  timeout_t       repeat_time;
  bool            restart;


} auditbus_gerhardt_t;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int auditbus_gerhardt_create(
  auditbus_gerhardt_t*  instance,
  auditd_t*             owner,
  int                   instance_id,
  audit_interface_t     interface,
  eventq_t*             eventq,
  const char*           port_path,
  const char*           out_path
);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_LIB_AUDITD_BUS_GERHARDT_H_INCLUDED
