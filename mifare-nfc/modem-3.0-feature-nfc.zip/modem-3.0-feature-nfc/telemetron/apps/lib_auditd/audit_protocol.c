/// \file
/// \brief  Служебные функции для перечислений audit_protocol_t и audit_interface_t.
/// \author DL <dmitriy@linikov.ru>


////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <auditd/audit_protocol.h>


////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Приватные функции


////////////////////////////////////////////////////////////////////////////
//  Публичные функции

const char* audit_protocol_to_string(audit_protocol_t value)
{
  switch(value) {
  case AUX_TYPE_OFF:            return "off";
  case AUX_TYPE_AUDIT_AUTO:     return "auto";
  case AUX_TYPE_AUDIT_DEX:      return "dex";
  case AUX_TYPE_AUDIT_DDCMP:    return "ddcmp";
  case AUX_TYPE_AUDIT_GERHARDT: return "gerhardt";
  default:                      return "UNKNOWN";
  }
}

const char* audit_interface_to_string(audit_interface_t value)
{
  switch(value) {
  case AUX_INTERFACE_OFF:       return "off";
  case AUX_INTERFACE_AUTO:      return "auto";
  case AUX_INTERFACE_TTL:       return "ttl";
  case AUX_INTERFACE_RS232:     return "com";
  case AUX_INTERFACE_RS485:     return "485";
  default:                      return "UNKNOWN";
  }
}
