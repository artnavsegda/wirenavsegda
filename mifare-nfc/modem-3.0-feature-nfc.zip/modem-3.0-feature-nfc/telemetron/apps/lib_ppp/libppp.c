/// \file
/// \brief  Реализация публичного API поверх LwIP-PPP
/// \author DL <dmitriy@linikov.ru>


////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <ppp/libppp.h>

#include <debug.h>
#include <fcntl.h>
#include <poll.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>

#include <arpa/inet.h>
#include <net/if.h>
#include <netinet/in.h>
#include <nuttx/net/dns.h>
#include <nuttx/net/tun.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <netutils/netlib.h>

#include <nuttx/fs/fs.h>
#include <nuttx/gsm/at.h>
#include <nuttx/gsm/atport.h>
#include <nuttx/gsm/stdmodem_commands.h>


#include <utils/posix_iohelper.h>
#include <utils/service.h>
#include <utils/string_utils.h>
#include <utils/system_utils.h>
#include <utils/time_utils.h>
#include <utils/dbg.h>
#include <utils/sq_foreach.h>

#include "lwip/init.h"
#include "lwip/ip4_addr.h"
#include "lwip/udp.h"
#include "lwip/inet_chksum.h"
#include "lwip/prot/tcp.h"
#include "netif/ppp/ppp.h"
#include "netif/ppp/pppos.h"

////////////////////////////////////////////////////////////////////////////
//  Объявление внешних функций

#ifdef CONFIG_LIB_PPP_DEBUG_PRINT_IP_PACKETS
void        libppp_ip4_debug_print(struct pbuf *p, const char* msg, const char* dev);
#else
#define     libppp_ip4_debug_print(p, msg, dev)    ((void)0)
#endif


////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора

// Строка для форматирования переменной типа endpoint_t
#define ENDPOINT_FMT  "%u.%u.%u.%u:%u"

// Добавление параметров для форматирования переменной типа endpoint_t
#define ENDPOINT_ARG(ep_ptr)  ((uint8_t*)&((ep_ptr)->ip))[0],\
                              ((uint8_t*)&((ep_ptr)->ip))[1],\
                              ((uint8_t*)&((ep_ptr)->ip))[2],\
                              ((uint8_t*)&((ep_ptr)->ip))[3],\
                              (ntohs((ep_ptr)->port))



// скопировано из файла nuttx/net/ip.h,
// что бы не включать его, т.к. конфликтует с заголовками lwip
#  define net_ipv4addr_maskcmp(addr1, addr2, mask) \
   (((in_addr_t)(addr1) & (in_addr_t)(mask)) == \
    ((in_addr_t)(addr2) & (in_addr_t)(mask)))


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных

/// \brief Сырой адрес сокета (TCP или UDP)
typedef struct endpoint_s {
  uint16_t        flags;      ///< Не используется
  uint16_t        port;       ///< порт в сетевом порядке байт
  in_addr_t       ip;         ///< ip4 адрес в сетевом порядке байт.
} endpoint_t;


/// \brief Запись о трансляции адреса.
///
/// Данная структура хранит адреса сокетов до трансляции адреса,
/// а так же номер порта после трансляции. ip после трансляции не хранится,
/// т.к. в данной реализации он всегда равен локальному адресу туннеля.
///
/// Пока что поддерживаются только протоколы TCP и UDP.
/// При необходимости сравнительно легко можно добавить поддержку
/// трансляции ICMP Эхо-запросов и ICMP пакетов, содержащих заголовок IP.
typedef struct nat_entry_s {
  struct nat_entry_s* flink;

  uint8_t         proto;        ///< Протокол
  endpoint_t      remote;       ///< Сокет удалённого хоста
  endpoint_t      local;        ///< Локальный сокет до преобразования
  endpoint_t      translated;   ///< Локальный сокет после преобразованияы

  time_t          ttl;          ///< Время (localtime), когда запись будет удалена.
} nat_entry_t;

/// \brief Экземпляр сеанса PPP-связи
struct libppp_s {
  /// \brief Если true, то данный экземпляр уже выделен.
  volatile bool   allocated;

  /// \brief  Аргумент, передаваемый во все callback функции
  void*           cb_arg;

  /// \brief  Список всех callback-обработчиков из внешнего кода.
  const struct libppp_cb_s* cb;

  /// \brief  Сетевой интерфейс lwip для ppp
  struct netif    netif;

  /// \brief  Состояние lwip-ppp сервиса
  ppp_pcb*        ppp;

  /// \brief  Открытый дескриптор tun интерфейса
  struct file*    tun;

  /// \brief Хранилище для дескриптора tun интерфейса
  struct file     tun_instance;

  /// \brief  Имя открытого tun интерфейса
  char            tunname[IF_NAMESIZE];

  /// \brief  Буффер, используемый для получения данных как из последовательного порта,
  ///         так и из сетевого туннеля.
  uint8_t         rxbuf[PPP_MAXMRU];

  /// \brief  Оболочка над буффером, используемая для передачи внутрь lwip-ppp
  ///         ip-пакета, полученного из tcp/ip стека NuttX
  ///
  /// Выделяется однажды при инициализации и не удаляется.
  /// Изменение размера происходит ручным редактированием структуры.
  /// Однако это позволяет не выделять память для каждого пакета.
  struct pbuf*    pbuf;

  /// \brief Задачи поллинга для всех используемых каналов данных.
  struct pollfd   pfd[2];

  /// \brief Набор файловых дескрипторов для всех используемых каналов данных.
  struct file*    pfs[2];

  /// \brief Необходимо использовать трансляцию ip адресов.
  bool            use_nat;

  /// \brief Признак, что уже закрываем соединение
  ///
  /// - `0` = Соединение уже закрыто или ещё не было открыто
  /// - `1` = Не закрываем соединение
  /// - `2` = Закрываем соединение с отправкой уведомления удалённой точке
  /// - `3` = Принудительно закрываем соединение из-за аппаратной проблемы
  uint8_t         session_state;
# define LIBPPP_SESSION_STATE_NOT_ACTIVE    0
# define LIBPPP_SESSION_STATE_ACTIVE        1
# define LIBPPP_SESSION_STATE_CLOSING       2
# define LIBPPP_SESSION_STATE_FORCE_CLOSING 3

  /// \brief Список активных NAT записей этого PPP соединения.
  sq_queue_t      nat_entries;

  /// \brief Локальная копия своего адреса для удобства использования.
  uint32_t        ouraddr;
};


struct ip4_changeset_s {
  uint32_t            srcaddr;
  uint32_t            dstaddr;
  uint16_t            srcport;
  uint16_t            dstport;
  uint8_t             ttl;
};

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные

static volatile bool  g_libppp_inited = false;
static sem_t          g_lwip_sem;
static libppp_t       g_libppp_instances[CONFIG_LIB_PPP_MAX_INSTANCE];
static nat_entry_t    g_nat_entries[CONFIG_LIB_PPP_NAT_ENTRIES];
static sq_queue_t     g_free_nat_entries;

////////////////////////////////////////////////////////////////////////////
//  Приватные функции

static bool endpoint_eq(const endpoint_t* a, const endpoint_t* b)
{
  return a->ip == b->ip && a->port == b->port;
}

static void nat_entry_dump(const char* msg, const nat_entry_t* e)
{
  libppp_trace(
    "%s"
    "proto:%s, "
    "remote:" ENDPOINT_FMT ", "
    "local:" ENDPOINT_FMT ", "
    "translated:" ENDPOINT_FMT ", "
    "ttl:%lu\n",

    msg,
    e->proto == IP_PROTO_TCP ? "TCP" : e->proto == IP_PROTO_UDP ? "UDP" : "???",
    ENDPOINT_ARG(&e->remote),
    ENDPOINT_ARG(&e->local),
    ENDPOINT_ARG(&e->translated),
    (unsigned long)e->ttl
  );
}

/// \brief Начальная инициализация экземпляра libppp. Выполняется однажды.
static void libppp_init_instance(libppp_t* libppp)
{
  memset(libppp, 0, sizeof(*libppp));
  libppp->pbuf = pbuf_alloc_reference(libppp->rxbuf, sizeof(libppp->rxbuf), PBUF_REF);
  if (!libppp->pbuf) {
    libppp_error("Can't alloc pbuf\n");
    PANIC();
  }
  libppp->allocated = false;
}

/// \brief Начальная инициализация пула свободных NAT записей.
static void libppp_nat_init(void)
{
  sq_init(&g_free_nat_entries);

  memset(g_nat_entries, 0, sizeof(g_nat_entries));
  for (size_t i=0; i != CONFIG_LIB_PPP_NAT_ENTRIES; ++i) {
    sq_addfirst((sq_entry_t*)&g_nat_entries[i], &g_free_nat_entries);
  }
}

/// \brief Начальная инициализация библиотеки libppp.
static void libppp_init(void)
{
  sched_lock();
  if (!g_libppp_inited) {
    sem_init(&g_lwip_sem, 0, 1);

    lwip_init();

    for (size_t i=0; i < CONFIG_LIB_PPP_MAX_INSTANCE; ++i) {
      libppp_init_instance(&g_libppp_instances[i]);
    }

    libppp_nat_init();
    g_libppp_inited = true;
  }
  sched_unlock();
}

static void libppp_lock(void)
{
  int ret;
  do {
    ret = sem_wait(&g_lwip_sem);
    if (ret < 0) {
      DEBUGASSERT(errno == EINTR || errno == ECANCELED);
      continue;
    }
  } while (ret < 0);
}

static void libppp_unlock(void)
{
  sem_post(&g_lwip_sem);
}

/// \brief Возвращает незанятый экземпляр libppp или NULL, если не найден.
static libppp_t* libppp_alloc(void)
{
  libppp_t* instance = NULL;
  libppp_lock();
  for (size_t i=0; i < CONFIG_LIB_PPP_MAX_INSTANCE; ++i) {
    if (!g_libppp_instances[i].allocated) {
      g_libppp_instances[i].allocated = true;
      instance = &g_libppp_instances[i];
      break;
    }
  }
  libppp_unlock();

  if (!instance) {
    libppp_error("No more free instances of libppp\n");
  }
  return instance;
}

/// \brief Возвращает экземпляр \p libppp в список доступных для выделения.
static void libppp_free(libppp_t* libppp)
{
  bool found = false;

  if (!libppp->allocated) {
    libppp_warn("Attempt to free not allocated instance %X\n", libppp);
    return;
  }

  libppp_lock();
  for (size_t i=0; i < CONFIG_LIB_PPP_MAX_INSTANCE; ++i) {
    if (libppp == &g_libppp_instances[i]) {
      libppp->allocated = false;
      found = true;
      break;
    }
  }
  libppp_unlock();

  if (!found) {
    libppp_warn("Unknown libppp instance %X\n", libppp);
  }
}

/// \brief Получение NAT записи из пула свободных.
static nat_entry_t* libppp_nat_alloc(void)
{
  nat_entry_t*  entry = NULL;
  libppp_lock();
    entry = (nat_entry_t*)sq_remfirst(&g_free_nat_entries);
  libppp_unlock();
  return entry;
}

/// \brief Возвращение NAT записи в пул свободных.
static void libppp_nat_free(nat_entry_t* entry)
{
  bool          found = false;
  if (!entry) {
    return;
  }
  libppp_lock();

    // Проверка, что не пытаемся повторно освободить ранее
    // освобождённую запись.
    SQ_FOREACH(nat_entry_t, e, &g_free_nat_entries) {
      if (e == entry) {
        found = true;
        break;
      }
    }

    // Завершаем работу, если повторное освобождение и assert-ы включены
    DEBUGASSERT(!found);

    if (!found) {
      // Даже если ассерты выключены, не освобождаем запись,
      // если она уже есть в списке свободных.
      sq_addfirst((sq_entry_t*)entry, &g_free_nat_entries);
    }
  libppp_unlock();
}

/// \brief Создаёт экземпляр туннельного сетевого адаптера.
static int libppp_tun_alloc(char *dev, struct file* result)
{
  struct ifreq ifr;
  int fd;
  int errcode;

  if ((fd = open("/dev/tun", O_RDWR)) < 0)
    {
      return fd;
    }

  libppp_info("tun fd:%i\n", fd);

  if ((errcode = TtySetNonblock(fd)) < 0)
    {
      close(fd);
      return errcode;
    }

  memset(&ifr, 0, sizeof(ifr));
  ifr.ifr_flags = IFF_TUN;
  if (*dev)
    {
      strncpy(ifr.ifr_name, dev, IFNAMSIZ);
    }

  if ((errcode = ioctl(fd, TUNSETIFF, (unsigned long)&ifr)) < 0)
    {
      errcode = -errno;
      close(fd);
      return errcode;
    }

  strcpy(dev, ifr.ifr_name);

  errcode = file_detach(fd, result);
  if (errcode < 0) {
    close(fd);
  }
  return errcode;
}


/// \brief Установка адреса роутера на конкретном соединении без замены стандартного маршрута.
static int libppp_set_remotev4addr(FAR const char *ifname, FAR const struct in_addr *addr)
{
  int ret = ERROR;

  if (ifname && addr)
    {
      int sockfd = socket(PF_INET, NETLIB_SOCK_TYPE, 0);
      if (sockfd >= 0)
        {
          FAR struct sockaddr_in *inaddr;
          struct ifreq req;

          /* Add the device name to the request */

          strncpy(req.ifr_name, ifname, IFNAMSIZ);

          /* Add the INET address to the request */

          inaddr             = (FAR struct sockaddr_in *)&req.ifr_addr;
          inaddr->sin_family = AF_INET;
          inaddr->sin_port   = 0;
          memcpy(&inaddr->sin_addr, addr, sizeof(struct in_addr));

          ret = ioctl(sockfd, SIOCSIFDSTADDR, (unsigned long)&req);

          close(sockfd);
        }
    }

  return ret;
}


/// \brief Устанавливает ip адрес / gate / netmask и переводит туннель в активное состояние.
static void libppp_ifup(libppp_t* libppp)
{
  int               ret;
  struct in_addr    ouraddr;
  struct in_addr    gateway;
  struct in_addr    mask;

  ouraddr.s_addr  = libppp->netif.ip_addr.addr;
  gateway.s_addr  = libppp->netif.gw.addr;

  // Вычисление маски на основе ouraddr и gateway
  for (mask.s_addr = 0xFFFFFFFF; mask.s_addr != 0; mask.s_addr <<= 1) {
    if (net_ipv4addr_maskcmp(ouraddr.s_addr, gateway.s_addr, htonl(mask.s_addr))) {
      // Вычислили подходящую маску подсети.
      break;
    }
  }
  mask.s_addr = htonl(mask.s_addr);

  libppp->ouraddr = ouraddr.s_addr;
  if ((ret = netlib_set_ipv4addr(libppp->tunname, &ouraddr)) < 0) {
    libppp_warn(
      "Can't set \"%s\" ip, ret=%d (%s)\n",
      libppp->tunname,
      ret,
      strerror(-ret)
    );
  }

  if ((ret = netlib_set_ipv4netmask(libppp->tunname, &mask)) < 0) {
    libppp_warn(
      "Can't set \"%s\" netmask, ret=%d (%s)\n",
      libppp->tunname,
      ret,
      strerror(-ret)
    );
  }

  if ((ret = libppp_set_remotev4addr(libppp->tunname, &gateway)) < 0) {
    libppp_warn(
      "Can't set \"%s\" gateway, ret=%d (%s)\n",
      libppp->tunname,
      ret,
      strerror(-ret)
    );
  }

  if ((ret = netlib_ifup(libppp->tunname)) < 0) {
    libppp_error(
      "ERROR: Can't bring \"%s\" up, ret=%d (%s)\n",
      libppp->tunname,
      ret,
      strerror(-ret)
    );
  }

  if (libppp->cb->on_ifup) {
    libppp->cb->on_ifup(libppp->cb_arg, &ouraddr, &gateway, &mask);
  }
}

/// \brief Переводит туннель в неактивное состояние.
static void libppp_ifdown(libppp_t* libppp)
{
  int ret;

  // Перевод туннеля в неактивное состояние
  if ((ret = netlib_ifdown(libppp->tunname)) < 0) {
    libppp_warn(
      "ERROR: Can't bring \"%s\" down, ret=%d (%s)\n",
      libppp->tunname,
      ret,
      strerror(-ret)
    );
  }

  // Очистка таблицы NAT
  if (libppp->use_nat) {
    for (nat_entry_t* entry=(nat_entry_t*)sq_remfirst(&libppp->nat_entries);
        entry;
        entry = (nat_entry_t*)sq_remfirst(&libppp->nat_entries)
    ) {
      libppp_nat_free(entry);
    }
  }

  libppp->ouraddr = htonl(IPADDR_ANY);

  // Вызов внешнего обработчика события ifdown
  if (libppp->cb->on_ifdown) {
    libppp->cb->on_ifdown(libppp->cb_arg);
  }
}

/// \brief Преобразует значение типа libppp_err_t в строку
const char* libppp_err_to_string(libppp_err_t value)
{
  switch (value) {
  case LIBPPP_ERR_NONE:         return "ERR_NONE";
  case LIBPPP_ERR_PARAM:        return "ERR_PARAM";
  case LIBPPP_ERR_OPEN:         return "ERR_OPEN";
  case LIBPPP_ERR_DEVICE:       return "ERR_DEVICE";
  case LIBPPP_ERR_ALLOC:        return "ERR_ALLOC";
  case LIBPPP_ERR_USER:         return "ERR_USER";
  case LIBPPP_ERR_CONNECT:      return "ERR_CONNECT";
  case LIBPPP_ERR_AUTHFAIL:     return "ERR_AUTHFAIL";
  case LIBPPP_ERR_PROTOCOL:     return "ERR_PROTOCOL";
  case LIBPPP_ERR_PEERDEAD:     return "ERR_PEERDEAD";
  case LIBPPP_ERR_IDLETIMEOUT:  return "ERR_IDLETIMEOUT";
  case LIBPPP_ERR_CONNECTTIME:  return "ERR_CONNECTTIME";
  case LIBPPP_ERR_LOOPBACK:     return "ERR_LOOPBACK";
  default:                      return "<Unknown>";
  }
}

/// \brief Преобразует значение типа libppp_err_t в подробное описание.
const char* libppp_err_to_description(libppp_err_t value)
{
  switch (value) {
  case LIBPPP_ERR_NONE:         return "Connected";
  case LIBPPP_ERR_PARAM:        return "Invalid parameter";
  case LIBPPP_ERR_OPEN:         return "Unable to open PPP session";
  case LIBPPP_ERR_DEVICE:       return "Invalid I/O device for PPP";
  case LIBPPP_ERR_ALLOC:        return "Unable to allocate resources";
  case LIBPPP_ERR_USER:         return "User interrupt (disconnected)";
  case LIBPPP_ERR_CONNECT:      return "Connection lost";
  case LIBPPP_ERR_AUTHFAIL:     return "Failed authentication challenge";
  case LIBPPP_ERR_PROTOCOL:     return "Failed to meet protocol";
  case LIBPPP_ERR_PEERDEAD:     return "Connection timeout";
  case LIBPPP_ERR_IDLETIMEOUT:  return "Idle Timeout";
  case LIBPPP_ERR_CONNECTTIME:  return "Max connect time reached";
  case LIBPPP_ERR_LOOPBACK:     return "Loopback detected";
  default:                      return "";
  }
}

static int libppp_err_to_errno(err_t err)
{
  /* Table to quickly map an lwIP error (err_t) to a socket error
   * by using -err as an index */
  static const int err_to_errno_table[] = {
    0,             /* ERR_OK          0      No error, everything OK. */
    ENOMEM,        /* ERR_MEM        -1      Out of memory error.     */
    ENOBUFS,       /* ERR_BUF        -2      Buffer error.            */
    EWOULDBLOCK,   /* ERR_TIMEOUT    -3      Timeout                  */
    EHOSTUNREACH,  /* ERR_RTE        -4      Routing problem.         */
    EINPROGRESS,   /* ERR_INPROGRESS -5      Operation in progress    */
    EINVAL,        /* ERR_VAL        -6      Illegal value.           */
    EWOULDBLOCK,   /* ERR_WOULDBLOCK -7      Operation would block.   */
    EADDRINUSE,    /* ERR_USE        -8      Address in use.          */
    EALREADY,      /* ERR_ALREADY    -9      Already connecting.      */
    EISCONN,       /* ERR_ISCONN     -10     Conn already established.*/
    ENOTCONN,      /* ERR_CONN       -11     Not connected.           */
    ENOTRECOVERABLE,/*ERR_IF         -12     Low-level netif error    */
    ECONNABORTED,  /* ERR_ABRT       -13     Connection aborted.      */
    ECONNRESET,    /* ERR_RST        -14     Connection reset.        */
    ENOTCONN,      /* ERR_CLSD       -15     Connection closed.       */
    EIO            /* ERR_ARG        -16     Illegal argument.        */
  };
  if ((err > 0) || (-err >= (err_t)LWIP_ARRAYSIZE(err_to_errno_table))) {
    return EIO;
  }
  return err_to_errno_table[-err];
}

static const char* libppp_authtype_to_string(libppp_authtype_t value)
{
  switch(value) {
  case LIBPPP_AUTHTYPE_NONE:      return "AUTHTYPE_NONE";
  case LIBPPP_AUTHTYPE_PAP:       return "AUTHTYPE_PAP";
  case LIBPPP_AUTHTYPE_CHAP:      return "AUTHTYPE_CHAP";
  case LIBPPP_AUTHTYPE_MSCHAP:    return "AUTHTYPE_MSCHAP";
  case LIBPPP_AUTHTYPE_MSCHAP_V2: return "AUTHTYPE_MSCHAP_V2";
  case LIBPPP_AUTHTYPE_EAP:       return "AUTHTYPE_EAP";
  case LIBPPP_AUTHTYPE_ANY:       return "AUTHTYPE_ANY";
  default:                        return "<Unknown>";
  }
}


/// \brief Обработчик событий изменения состояния PPP сеанса связи.
static void libppp_status_cb(ppp_pcb* ppp, int err_code, void* ctx)
{
  libppp_t* libppp = (libppp_t*)ctx;
  DEBUGASSERT(libppp);

  libppp_trace(
    "%s status=%d (%s - %s)\n",
    libppp->tunname,
    err_code,
    libppp_err_to_string((libppp_err_t)err_code),
    libppp_err_to_description((libppp_err_t)err_code)
  );

  if (err_code == PPPERR_NONE) {
    // Соединение установлено. Переводим сетевой туннель в активное состояние.
    libppp_ifup(libppp);
  } else {
    // Любое другое значение говорит об ошибке.
    // Перевод сетевого туннеля в неактивное состояние.
    libppp_ifdown(libppp);
  }

  // Вызов пользовательского обработчика событий
  if (libppp->cb->on_ppp_link_status) {
    libppp->cb->on_ppp_link_status(libppp->cb_arg, (libppp_err_t)err_code);
  }
}

/// \brief Обработчик событий изменения состояния конечного автомата PPP.
static void libppp_phase_callback(ppp_pcb *pcb, u8_t phase, void *ctx)
{
  libppp_t* libppp = (libppp_t*)ctx;
  DEBUGASSERT(libppp);

  libppp_trace("%s phase=%u\n", libppp->tunname, phase);
}

/// \brief Отправка данных PPP сессии в канал связи.
static u32_t libppp_output_callback(ppp_pcb *pcb, u8_t *data, u32_t len, void *ctx)
{
  libppp_stream_dump("ppp_output", data, len);
  // uint32_t ret = uart_write_bytes(uart_num, (const char*)data, len);
  //   uart_wait_tx_done(uart_num, 10 / portTICK_RATE_MS);
  //   if (ret > 0) {
  //     xSemaphoreTake(pppos_mutex, PPPOSMUTEX_TIMEOUT);
  //     pppos_rx_count += ret;
  //    xSemaphoreGive(pppos_mutex);
  //   }

  libppp_t* libppp = (libppp_t*)ctx;
  DEBUGASSERT(libppp && libppp->cb->write);

  int ret = libppp->cb->write(libppp->cb_arg, data, len);
  if (ret < 0) {
    libppp_error(
      "ERROR: %s can't write, ret=%d (%s)\n",
      libppp->tunname,
      ret,
      strerror(-ret)
    );
    return 0;
  }
  return ret;
}


/// \brief Поиск NAT записи по известным непреобразованным адресам/портам.
nat_entry_t* libppp_nat_find_by_original(
  libppp_t*   libppp,
  uint8_t     proto,
  endpoint_t* local,
  endpoint_t* remote
)
{
  SQ_FOREACH(nat_entry_t, entry, &libppp->nat_entries) {
    if (   entry->proto == proto
        && endpoint_eq(&entry->local, local)
        && endpoint_eq(&entry->remote, remote)
    ) {
      return entry;
    }
  }
  return NULL;
}

/// \brief Поиск NAT записи по известным преобразованным адресам/портам
nat_entry_t* libppp_nat_find_by_translated(
  libppp_t*   libppp,
  uint8_t     proto,
  endpoint_t* translated,
  endpoint_t* remote
)
{
  SQ_FOREACH(nat_entry_t, entry, &libppp->nat_entries) {
    if (   entry->proto == proto
        && endpoint_eq(&entry->translated, translated)
        && endpoint_eq(&entry->remote, remote)
    ) {
      return entry;
    }
  }
  return NULL;
}

/// \brief Поиск NAT записи, которой осталось меньше всего жить.
nat_entry_t* libppp_nat_find_least_ttl(libppp_t* libppp)
{
  /// \todo Возможно оптимизировать, если изначально вести упорядоченную очередь.
  nat_entry_t* oldest = NULL;
  SQ_FOREACH(nat_entry_t, entry, &libppp->nat_entries) {
    if (!oldest) {
      oldest = entry;
      continue;
    }

    if (entry->ttl < oldest->ttl) {
      oldest = entry;
    }
  }
  return oldest;
}

/// \brief Продлевает срок жизни одной NAT записи.
static void libppp_nat_touch_entry(libppp_t* libppp, nat_entry_t* e)
{
  (void)libppp; // пока что не используется. В перспективе - настраиваемый таймаут.

  struct timespec ts = timespec_after_ms(CONFIG_LIB_PPP_NAT_ENTRIES_TTL_S*1000);
  e->ttl = ts.tv_sec;
}

/// \brief Создание и заполнение новой записи
nat_entry_t* libppp_nat_create_entry(
  libppp_t*         libppp,
  uint8_t           proto,
  const endpoint_t* local,
  const endpoint_t* remote
)
{
  // Попытка выделить запись из пула свободных
  nat_entry_t* e = libppp_nat_alloc();
  if (!e) {
    // Нет свободных. Попробуем найти самую редко используемую.
    libppp_warn("No spare NAT entry. Searching for oldest.\n");
    e = libppp_nat_find_least_ttl(libppp);
    if (!e) {
      libppp_error("Can't alloc NAT entry\n");
      return NULL;
    }
    sq_rem((sq_entry_t*)e, &libppp->nat_entries);
    nat_entry_dump("Discarded oldest NAT entry: ", e);
  }

  e->proto      = proto;
  e->local      = *local;
  e->remote     = *remote;

  e->translated.ip    = libppp->ouraddr; // Подставляем локальный адрес сетевого адаптера
  e->translated.port  = local->port;
  libppp_nat_touch_entry(libppp, e);

  // повторяем попытки, пока не получим уникальную комбинацию
  // из локального адреса, локального порта, удалённого адреса и удалённого порта.
  //
  // При этом вполне допустим вариант, когда на один и тот же локальный порт
  // есть записи для разных удалённых серверов.
  for (;;) {
    if (!libppp_nat_find_by_translated(libppp, e->proto, &e->translated, &e->remote)) {
      // Такой записи нет. можно завершать поиск свободных портов.
      break;
    }

    // Добавляем к номеру порта случайное значение, что бы получить
    // уникальную комбинацию. При этом ограничиваем номер порта в пределах (1000, 32767]
    e->translated.port = htons((e->translated.port + rand()) & 0x7FFF);
    if (e->translated.port < 1000) {
      e->translated.port += 1000;
    }
  } // for(;;)


  sq_addfirst((sq_entry_t*)e, &libppp->nat_entries);
  nat_entry_dump("Added NAT entry: ", e);
  return e;
}



static void libppp_update_ip(struct ip_hdr* iphdr, const struct ip4_changeset_s* change)
{
  struct ip_hdr  ex_hdr   = *iphdr;
  uint16_t hdr_bytes      = (u16_t)IPH_HL(iphdr) * 4;
  uint16_t protocol       = (u16_t)IPH_PROTO(iphdr);
  uint8_t* payload        = &((uint8_t*)iphdr)[hdr_bytes];

  // Шаг 1 - обновление заголовка IP, проще всего пересчитать полностью заголовок
  iphdr->src.addr  = change->srcaddr;
  iphdr->dest.addr = change->dstaddr;
  IPH_TTL_SET(iphdr, change->ttl);
  IPH_CHKSUM_SET(iphdr, 0);
  IPH_CHKSUM_SET(iphdr, inet_chksum(iphdr, hdr_bytes));

  // Шаг 2 - обновление заголовка TCP/UDP
  uint16_t*   srcport;
  uint16_t*   dstport;
  uint16_t*   chksum;

  if (protocol == IP_PROTO_UDP) {
    struct udp_hdr* udp = (struct udp_hdr*)payload;
    srcport = &udp->src;
    dstport = &udp->dest;
    chksum  = &udp->chksum;
    if (udp->chksum == 0) {
      // если заголовок не содержал контрольной суммы, то не будет и впредь
      *srcport = change->srcport;
      *dstport = change->dstport;
      return;
    }
  } else {
    struct tcp_hdr* tcp =  (struct tcp_hdr*)payload;
    srcport = &tcp->src;
    dstport = &tcp->dest;
    chksum  = &tcp->chksum;
  }

  // Частичное обновление контрольной суммы, включая псевдо-заголовок,
  // (вместо полного вычисления). Подробнее - см. RFC-1624.
  // Поскольку изменяется ограниченное количество слов, то
  // обработку переносов сделаем однажды - в конце.
  uint32_t sum = (uint16_t)(~(*chksum));

  // В псевдо-заголовке изменяются адреса источника и получателя
  sum += ((~ex_hdr.src.addr) >> 16) + ((~ex_hdr.src.addr) & 0xFFFF);  // адрес источника
  sum += ((~ex_hdr.dest.addr) >> 16) + ((~ex_hdr.dest.addr) & 0xFFFF);  // адрес получателя
  sum += (change->srcaddr >> 16) + (change->srcaddr & 0xFFFF);
  sum += (change->dstaddr >> 16) + (change->dstaddr & 0xFFFF);

  // В TCP или UDP заголовке изменяются номера портов
  sum += (~(*srcport) & 0xFFFF) + (~(*dstport) & 0xFFFF);
  sum += change->srcport + change->dstport;

  // Обработка битов перенова
  while (sum >> 16) {
    sum = (sum & 0xFFFF) + (sum >> 16);
  }
  sum = (uint16_t)(~sum);

  // сохранение изменений в TCP/UDP заголовок
  *srcport = change->srcport;
  *dstport = change->dstport;
  *chksum = (uint16_t)sum;
}


/// \brief Трансляция адресов для пакетов, уходящих в PPP туннель.
int libppp_nat_translate_local_to_ppp(libppp_t* libppp, struct pbuf* p)
{
  struct ip_hdr *iphdr    = (struct ip_hdr*)p->payload;
  uint16_t protocol       = (u16_t)IPH_PROTO(iphdr);
  uint16_t hdr_bytes      = (u16_t)IPH_HL(iphdr) * 4;
  uint8_t* payload        = &((uint8_t*)iphdr)[hdr_bytes];

  if (protocol != IP_PROTO_TCP && protocol != IP_PROTO_UDP) {
    return 0; // Не умеем транслировать пакеты, отличные от TCP и UDP.
  }

  // Получаем указатели на интересующие нас поля в TCP или UDP заголовке.
  uint16_t*   srcport;
  uint16_t*   dstport;

  if (protocol == IP_PROTO_TCP) {
    struct tcp_hdr* tcp =  (struct tcp_hdr*)payload;
    srcport = &tcp->src;
    dstport = &tcp->dest;
  } else {
    struct udp_hdr* udp = (struct udp_hdr*)payload;
    srcport = &udp->src;
    dstport = &udp->dest;
  }

  // Конечные точки отправителя и получателя (для удобства работы с NAT таблицей)
  endpoint_t  local   = { .ip = ip4_addr_get_u32(&iphdr->src), .port = *srcport };
  endpoint_t  remote  = { .ip = ip4_addr_get_u32(&iphdr->dest), .port = *dstport };


  // Ищем уже имеющуюся NAT запись
  nat_entry_t* nat_entry = libppp_nat_find_by_original(libppp, protocol, &local, &remote);
  if (!nat_entry) {
    // Данный маршрут связи ещё неизвестен. Создадим новый.
    nat_entry = libppp_nat_create_entry(libppp, protocol, &local, &remote);
    if (!nat_entry) {
      libppp_warn("Can't create NAT entry.\n");
      return -1; // Невозможно обработать пакет.
    }
  }

  // Увеличим срок жизни, т.к. запись активна
  libppp_nat_touch_entry(libppp, nat_entry);

  // Проверяем, нужно ли изменять заголовок
  if (endpoint_eq(&local, &nat_entry->translated)) {
    // пакет не требует изменения.
    libppp_trace("NAT: EP will not be changed\n");
    return 0;
  }

  // Заменяем IP адрес и порт отправителя
  struct ip4_changeset_s change;
  change.srcaddr  = nat_entry->translated.ip;
  change.srcport  = nat_entry->translated.port;

  change.dstaddr  = ip4_addr_get_u32(&iphdr->dest);
  change.dstport  = *dstport;
  change.ttl      = IPH_TTL(iphdr);

  libppp_update_ip(iphdr, &change);

  return 1;
}

/// \brief Трансляция адресов для пакетов, пришедших из PPP туннеля.
int libppp_nat_translate_ppp_to_local(libppp_t* libppp, struct pbuf* p)
{
  // Обработка заголовков пакета пришедшего из PPP туннеля
  struct ip_hdr *iphdr    = (struct ip_hdr*)p->payload;
  uint16_t protocol       = (u16_t)IPH_PROTO(iphdr);
  uint16_t hdr_bytes      = (u16_t)IPH_HL(iphdr) * 4;
  uint8_t* payload        = &((uint8_t*)iphdr)[hdr_bytes];

  if (protocol != IP_PROTO_TCP && protocol != IP_PROTO_UDP) {
    return 0; // Не умеем транслировать пакеты, отличные от TCP и UDP.
  }

  // Получаем указатели на интересующие нас поля в TCP или UDP заголовке.
  uint16_t*   srcport;
  uint16_t*   dstport;

  if (protocol == IP_PROTO_TCP) {
    struct tcp_hdr* tcp =  (struct tcp_hdr*)payload;
    srcport = &tcp->src;
    dstport = &tcp->dest;
  } else {
    struct udp_hdr* udp = (struct udp_hdr*)payload;
    srcport = &udp->src;
    dstport = &udp->dest;
  }

  // Конечные точки отправителя и получателя (для удобства работы с NAT таблицей)
  endpoint_t  translated  = { .ip = ip4_addr_get_u32(&iphdr->dest), .port = *dstport };
  endpoint_t  remote      = { .ip = ip4_addr_get_u32(&iphdr->src), .port = *srcport };


  // Ищем уже имеющуюся NAT запись
  nat_entry_t* nat_entry = libppp_nat_find_by_translated(libppp, protocol, &translated, &remote);
  if (!nat_entry) {
    // Данный маршрут связи ещё неизвестен. Не можем обработать пакет.
    // Новые маршруты создаются только локальной стороной.
    return -1; // Невозможно обработать пакет.
  }

  // Увеличим срок жизни, т.к. запись активна
  libppp_nat_touch_entry(libppp, nat_entry);

  // Проверяем, нужно ли изменять заголовок
  if (endpoint_eq(&translated, &nat_entry->local)) {
    // пакет не требует изменения.
    return 0;
  }

  // Заменяем IP адрес и порт получателя

  struct ip4_changeset_s change;
  change.srcaddr  = iphdr->src.addr;
  change.srcport  = *srcport;

  change.dstaddr  = nat_entry->local.ip;
  change.dstport  = nat_entry->local.port;
  change.ttl      = IPH_TTL(iphdr);

  libppp_update_ip(iphdr, &change);

  return 1;
}

void libppp_nat_delete_aged_entries(libppp_t* libppp)
{
  struct timespec ts = timespec_after_ms(0);
  time_t now = ts.tv_sec;

  nat_entry_t* e = (nat_entry_t*)sq_peek(&libppp->nat_entries);
  while (e) {
    nat_entry_t* current = e;
    e = sq_next(e);

    if (current->ttl > now) {
      continue;
    }

    sq_rem((sq_entry_t*)current, &libppp->nat_entries);
    nat_entry_dump("Retired NAT entry: ", current);
    libppp_nat_free(current);
  }
}

/// \brief  Вызывается из ppp когда готов ipv4 пакет.
/// \param  p   указатель на буффер с ip пакетом.
/// \param  inp Указатель на "сетевой интерфейс lwip", который вызвал функцию.
err_t ip4_input(struct pbuf *p, struct netif *inp)
{
  err_t result = ERR_OK;
  DEBUGASSERT(p && inp);

  ppp_pcb*  ppp     = (ppp_pcb*)inp->state;
  DEBUGASSERT(ppp);

  libppp_t* libppp  = (libppp_t*)ppp->ctx_cb;
  DEBUGASSERT(libppp);

  bool print_packet = true;
  if (libppp->use_nat) {
    libppp_ip4_debug_print(p, "ppp -> dev before NAT", libppp->tunname);
    // Получен ip4 пакет из PPP туннеля.
    // Если адресован не локальному сетевому интерфейсу,
    // то перед тем, как отдавать в сетевой стек, заменим отправителя на себя.
    int ret = libppp_nat_translate_ppp_to_local(libppp, p);
    if (ret < 0) {
      // Не получается преобразовать. Пакет потерян.
      libppp_trace("Can't NAT packet. Dropped.\n");
      return result;
    }
    print_packet = ret > 0;
  }

  if (print_packet) {
    libppp_ip4_debug_print(p, "ppp -> dev", libppp->tunname);
  }

  /// \todo HACK: Используем тот факт, что на момент написания ppp драйвер lwip
  /// использует только монолитные буфферы (а не цепочки).
  ssize_t   ret = file_write(libppp->tun, p->payload, p->len);
  if (ret < 0) {
    _warn("WARN: Can't write packet, ret=%d (%s)\n", ret, strerror(-ret));
    result = ERR_IF;
  }

  pbuf_free(p);
  return result;
}


/// \brief Неблокирующее чтение данных из канала связи.
static ssize_t libppp_do_receive_stream(libppp_t* libppp)
{
  DEBUGASSERT(libppp->cb->read);

  ssize_t rxsize = libppp->cb->read(libppp->cb_arg, libppp->rxbuf, sizeof(libppp->rxbuf));
  if (rxsize < 0 && rxsize ) {
    libppp_warn(
      "WARN: %s can't read tty, ret=%d (%s)\n",
      libppp->tunname,
      rxsize,
      strerror(-rxsize)
    );
  }

  if (!rxsize) {
    return 0;
  }

  libppp_stream_dump("ppp_input", libppp->rxbuf, rxsize);
  pppos_input(libppp->ppp, libppp->rxbuf, rxsize);
  return rxsize;
}

/// \brief Неблокирующее чтение данных из сетевого адаптера туннеля.
static ssize_t libppp_do_receive_tun(libppp_t* libppp)
{
  ssize_t rxsize = file_read(libppp->tun, libppp->rxbuf, sizeof(libppp->rxbuf));
  if (rxsize < 0) {
    int ret = -errno;
    _warn("WARN: %s can't read tun, ret=%d (%s)\n", libppp->tunname, ret, strerror(-ret));
    return ret;
  }

  if (!rxsize) {
    return 0;
  }

  /// \todo HACK: Здесь вручную изменяются поля `struct pbuf`.
  /// Это сделано, что бы избежать выделения памяти при получении
  /// каждого пакета из tcp/ip стека NuttX.
  /// В данном конкретном случае это допустимо, т.к. PPP модуль lwip
  /// не сохраняет в очередях пакеты, получаемые через функции
  /// `netif->output` и `netif->output_ip6`, равно как и не изменяет
  /// состояние буффера с этими пакетами.
  /// Тем не менее, при смене версии lwip следует проверить,
  /// что такое поведение не изменилось.
  libppp->pbuf->len = rxsize;
  libppp->pbuf->tot_len = rxsize;

  if (IP_HDR_GET_VERSION(libppp->rxbuf) != 4) {
    libppp_warn("WARN: %s drop packet with bad ip version\n", libppp->tunname);
    return 0;
  }

  DEBUGASSERT(libppp->netif.output);

  bool print_packet = true;
  if (libppp->use_nat) {
    libppp_ip4_debug_print(libppp->pbuf, "dev -> ppp before NAT", libppp->tunname);
    // Получен ip4 пакет из PPP туннеля.
    // Если адресован не локальному сетевому интерфейсу,
    // то перед тем, как отдавать в сетевой стек, заменим отправителя на себя.
    int ret = libppp_nat_translate_local_to_ppp(libppp, libppp->pbuf);
    if (ret < 0) {
      // Не получается преобразовать. Пакет потерян.
      libppp_trace("Can't NAT packet. Dropped.\n");
      return 0;
    }
    print_packet = ret > 0;
  }

  if (print_packet) {
    libppp_ip4_debug_print(libppp->pbuf, "dev -> ppp", libppp->tunname);
  }
  err_t err = libppp->netif.output(&libppp->netif, libppp->pbuf, NULL);

  if (err != ERR_OK) {
    libppp_warn(
      "WARN: %s can't process ip packet, ret=%d (%s)\n",
      libppp->tunname, err, libppp_err_to_description((libppp_err_t)err)
    );
    return -libppp_err_to_errno(err);
  }

  return rxsize;
}


////////////////////////////////////////////////////////////////////////////
//  Переопределённые функции LwIP

/// \brief Переопределение функции из lwip ipcp.c, вызываемой при получении DNS адреса.
int sdns(ppp_pcb *ppp, u32_t ns1, u32_t ns2) {
  DEBUGASSERT(ppp);

  libppp_t* libppp  = (libppp_t*)ppp->ctx_cb;
  DEBUGASSERT(libppp);


  if (!libppp->cb->set_dns) {
    return 1;
  }

  // LwIP-PPP поддерживает получение только IPv4 адресов DNS серверов
  // при этом используется стандартный порт.
  //
  // Значения ns1 и ns2 - изначально в сетевом порядке байт,
  // поэтому доп. преобразований не нужно.
  struct sockaddr_in  addr;
  addr.sin_family       = AF_INET;  // ip v4
  addr.sin_port         = 0;        // Использовать стандартный порт

  // Обрабатываем адрес DNS1
  addr.sin_addr.s_addr  = ns1;
  libppp->cb->set_dns(libppp->cb_arg, 0, (struct sockaddr*)&addr, sizeof(addr));

  // Обрабатываем адрес DNS2
  addr.sin_addr.s_addr  = ns2;
  libppp->cb->set_dns(libppp->cb_arg, 0, (struct sockaddr*)&addr, sizeof(addr));

  return 1;
}


/// \brief Переопределение функции из lwip ipcp.c, вызываемой для очистки DNS адресов.
int cdns(ppp_pcb *ppp, u32_t ns1, u32_t ns2) {
  DEBUGASSERT(ppp);

  libppp_t* libppp  = (libppp_t*)ppp->ctx_cb;
  DEBUGASSERT(libppp);

  if (libppp->cb->clr_dns) {
    libppp->cb->clr_dns(libppp->cb_arg);
  }

  return 1;
}

////////////////////////////////////////////////////////////////////////////
//  Заглушки для неиспользуемых функций LwIP

void dns_init(void)
{
  // Заглушка
}

void dns_tmr(void)
{
  // Заглушка
}

void tcp_netif_ip_addr_changed(const ip_addr_t *old_addr, const ip_addr_t *new_addr)
{
  // Заглушка
}

void udp_netif_ip_addr_changed(const ip_addr_t *old_addr, const ip_addr_t *new_addr)
{
  // Заглушка
}

void udp_init(void)
{
  // Заглушка
}

struct tcp_pcb *tcp_active_pcbs = NULL;

void tcp_init(void)
{
  // Заглушка
}

void tcp_tmr(void)
{
  // Заглушка
}

void tcp_free_ooseq(struct tcp_pcb *pcb)
{
  // Заглушка, без реализации
  PANIC();
}

void ip_reass_tmr(void)
{
  // Заглушка
}



////////////////////////////////////////////////////////////////////////////
//  Публичные функции

int libppp_create(
  void*       cb_arg,
  const struct libppp_cb_s* callbacks,
  char*       tunfmt,
  bool        use_nat,
  libppp_t**  result
)
{
  int ret;
  DEBUGASSERT(callbacks);
  DEBUGASSERT(callbacks->write && callbacks->read && callbacks->get_stream_file);
  DEBUGASSERT(result);

  if (!g_libppp_inited) {
    libppp_init();
  }

  // Попытка выделения экземпляра PPP модуля из пула свободных
  libppp_t* libppp = libppp_alloc();
  if (!libppp) {
    return -ENOMEM;
  }

  // Настройка обработчиков событий
  libppp->cb_arg  = cb_arg;
  libppp->cb      = callbacks;

  // Настройка NAT
  libppp->use_nat = use_nat;
  sq_init(&libppp->nat_entries);

  libppp->session_state = LIBPPP_SESSION_STATE_NOT_ACTIVE;

  // Временная строка форматирования имени tun интерфейса.
  // После успешного вызова libppp_tun_alloc в буффер libppp->tunname
  // будет скопировано имя созданного сетевого интерфейса.
  //
  // Это имя будет использовано при завершении работы,
  // что бы удалить ненужный более интерфейс.
  //
  // Так же, это имя используется при отладочном выводе.
  snprintf(
    libppp->tunname,
    sizeof(libppp->tunname),
    "%s",
    (tunfmt && *tunfmt) ? tunfmt : "ppp%d"
  );

  // Создание туннельного сетевого адаптера
  libppp->tun = NULL;
  ret = libppp_tun_alloc(libppp->tunname, &libppp->tun_instance);
  if (ret < 0) {
    *libppp->tunname = '\0'; // Интерфейс не создан. Очистка строки.
    libppp_error("ERROR: Can't create tun, ret=%d (%s)\n", ret, strerror(-ret));
    goto errout_with_instance;
  }
  libppp->tun = &libppp->tun_instance;

  // Создание экземпляра lwip ppp сессии.
  libppp->ppp = pppos_create(&libppp->netif, libppp_output_callback, libppp_status_cb, libppp);
  if (!libppp->ppp) {
    libppp_error("ERROR: Can't init PPPoS\n");
    ret = -ENOPROTOOPT;
    goto errout_with_tun;
  }

  // Установка обработчика изменения состояния конечного автомата lwip-ppp сессии.
  ppp_set_notify_phase_callback(libppp->ppp, libppp_phase_callback);

  *result = libppp;
  libppp_info("libppp: Created %s interface.\n", libppp->tunname);
  return 0;


errout_with_tun:
  if (libppp->tun) {
    file_close_detached(libppp->tun);
    libppp->tun = NULL;
  }

errout_with_instance:

  if (libppp) {
    libppp_free(libppp);
  }
  return ret;
}

void libppp_destroy(libppp_t* libppp)
{
  if (*libppp->tunname) {
    libppp_ifdown(libppp);
    *libppp->tunname = '\0';
  }

  if (libppp->ppp) {
    if (libppp->ppp->phase != PPP_PHASE_DEAD) {
      ppp_close(libppp->ppp, 1);
    }
    ppp_free(libppp->ppp);
    libppp->ppp = NULL;
  }

  if (libppp->tun >= 0) {
    file_close_detached(libppp->tun);
    libppp->tun = NULL;
  }

  libppp_free(libppp);
}

/// \brief Устанавливает тип используемой авторизации, имя пользователя и пароль.
///
/// Стандартное значение: без авторизации.
void libppp_set_auth(libppp_t* libppp, libppp_authtype_t authtype, const char *user, const char *passwd)
{
  DEBUGASSERT(libppp && libppp->ppp);
  libppp_info(
    "set_auth(%s, authtype=%s, user=%s, passwd=%s)\n",
    libppp->tunname,
    libppp_authtype_to_string(authtype),
    user ? user : "<NULL>",
    passwd ? passwd : "<NULL>"
  );
  ppp_set_auth(libppp->ppp, (int)authtype, user, passwd);
}

/// \brief Устанавливает, обязательно ли использовать авторизацию.
///
/// \note Обычно используется PPP сервером.
///
/// Стандартное значение: `false`.
void libppp_set_auth_required(libppp_t* libppp, bool required)
{
  DEBUGASSERT(libppp && libppp->ppp);
  libppp_info("set_auth_required(%s, required=%d)\n", libppp->tunname, (int)required);
  ppp_set_auth_required(libppp->ppp, required);
}

/// \brief Устанавливает локальный IPv4 адрес соединения.
///
/// Если необходимо получить этот адрес от удалённой точки,
/// то \p addr должен быть равен `0.0.0.0`.
///
/// Стандартное значение: `0.0.0.0`.
///
/// Обычно, ненулевой адрес устанавливается при работе в режиме PPP сервера.
void libppp_set_ouraddr(libppp_t* libppp, const struct in_addr* addr)
{
  char buffer[INET_ADDRSTRLEN];

  DEBUGASSERT(libppp && libppp->ppp && addr);

  buffer[0] = '\0';
  inet_ntop(AF_INET, addr, buffer, sizeof(buffer));
  libppp_info("set_ouraddr(%s, addr=%s)\n", libppp->tunname, buffer);

  ppp_set_ipcp_ouraddr(libppp->ppp, (struct ip4_addr*)addr);
}

/// \brief Устанавливает IPv4 адрес для удалённой стороны.
///
/// Если необходимо получить этот адрес от удалённой точки,
/// то \p addr должен быть равен `0.0.0.0`.
///
/// Стандартное значение: `0.0.0.0`.
///
/// Обычно, ненулевой адрес устанавливается при работе в режиме PPP сервера.
void libppp_set_hisaddr(libppp_t* libppp, const struct in_addr* addr)
{
  char buffer[INET_ADDRSTRLEN];

  DEBUGASSERT(libppp && libppp->ppp && addr);

  buffer[0] = '\0';
  inet_ntop(AF_INET, addr, buffer, sizeof(buffer));
  libppp_info("set_hisaddr(%s, addr=%s)\n", libppp->tunname, buffer);

  ppp_set_ipcp_hisaddr(libppp->ppp, (struct ip4_addr*)addr);
}

/// \brief Устанавливает IPv4 адрес DNS сервера, который будет отправлен удалённой стороне,
/// если она запросит его.
///
/// Стандартное значение: `0.0.0.0`.
///
/// Обычно, ненулевой адрес устанавливается при работе в режиме PPP сервера.
void libppp_set_dnsaddr(libppp_t* libppp, uint8_t index, const struct in_addr* addr)
{
  char buffer[INET_ADDRSTRLEN];

  DEBUGASSERT(libppp && libppp->ppp && addr);

  buffer[0] = '\0';
  inet_ntop(AF_INET, addr, buffer, sizeof(buffer));
  libppp_info("set_dnsaddr(%s, index=%u, addr=%s)\n", libppp->tunname, index, buffer);

  ppp_set_ipcp_dnsaddr(libppp->ppp, index, (struct ip4_addr*)addr);
}

/// \brief Если \p usepeerdns = true, то при установке соединения будет запрошен адрес DNS сервера.
///
/// Стандартное значение: `false`.
void libppp_set_usepeerdns(libppp_t* libppp, bool usepeerdns)
{
  DEBUGASSERT(libppp && libppp->ppp);
  libppp_info("set_usepeerdns(%s, usepeerdns=%d)\n", libppp->tunname, (int)usepeerdns);
  ppp_set_usepeerdns(libppp->ppp, usepeerdns);
}

/// \brief Если \p forcepeerdns = true, то при установке соединения будет
/// попытка принудительно установить адрес DNS сервера для удалённой стороны.
///
/// Стандартное значение: `false`.
void libppp_set_forcepeerdns(libppp_t* libppp, bool forcepeerdns)
{
  DEBUGASSERT(libppp && libppp->ppp);
  libppp_info("set_forcepeerdns(%s, forcepeerdns=%d)\n", libppp->tunname, (int)forcepeerdns);
  ppp_set_forcepeerdns(libppp->ppp, forcepeerdns);
}

/// \brief В режиме сервера устанавливает время ожидания входящего запроса подключения.
///
/// Стандартное значение: `0`.
void libppp_set_listen_time(libppp_t* libppp, uint16_t listen_time_ms)
{
  DEBUGASSERT(libppp && libppp->ppp);
  libppp_info("set_listen_time(%s, listen_time_ms=%u)\n", libppp->tunname, listen_time_ms);
  ppp_set_listen_time(libppp->ppp, listen_time_ms);
}

/// \brief Если \p passive = true, то при старте будет отправлен только один запрос подключения,
/// после чего модуль будет пассивно ожидать входящие запросы подключения.
///
/// Стандартное значение: `false`.
void libppp_set_passive(libppp_t* libppp, bool passive)
{
  DEBUGASSERT(libppp && libppp->ppp);
  libppp_info("set_passive(%s, passive=%d)\n", libppp->tunname, (int)passive);
  ppp_set_passive(libppp->ppp, passive);
}

/// \brief Если \p silent = true, то при старте модуль не будет отправлять исходящие
/// запросы подключения до тех пор пока не получит входящий запрос подключения.
///
/// Стандартное значение: `false`.
void libppp_set_silent(libppp_t* libppp, bool silent)
{
  DEBUGASSERT(libppp && libppp->ppp);
  libppp_info("set_silent(%s, silent=%d)\n", libppp->tunname, (int)silent);
  ppp_set_silent(libppp->ppp, silent);
}

/// \brief Устанавливает, нужно или нет договариваться о компрессии заголовков.
///
/// Стандартное значение: `true`.
void libppp_set_neg_pcomp(libppp_t* libppp, bool neg_pcomp)
{
  DEBUGASSERT(libppp && libppp->ppp);
  libppp_info("set_neg_pcomp(%s, neg_pcomp=%d)\n", libppp->tunname, (int)neg_pcomp);
  ppp_set_neg_pcomp(libppp->ppp, neg_pcomp);
}

/// \brief Устанавливает, нужно или нет договариваться о компрессии полей Address/Control.
///
/// Стандартное значение: `true`.
void libppp_set_neg_accomp(libppp_t* libppp, bool neg_accomp)
{
  DEBUGASSERT(libppp && libppp->ppp);
  libppp_info("set_neg_accomp(%s, neg_accomp=%d)\n", libppp->tunname, (int)neg_accomp);
  ppp_set_neg_accomp(libppp->ppp, neg_accomp);
}

/// \brief Устанавливает, нужно или нет договариваться о замене (escaping) управляющих символов.
///
/// Стандартное значение: `true`.
void libppp_set_neg_asyncmap(libppp_t* libppp, bool neg_asyncmap)
{
  DEBUGASSERT(libppp && libppp->ppp);
  libppp_info("set_neg_asyncmap(%s, neg_asyncmap=%d)\n", libppp->tunname, (int)neg_asyncmap);
  ppp_set_neg_asyncmap(libppp->ppp, neg_asyncmap);
}

/// \brief Устанавливает битмаску заменяемых управляющих символов.
void libppp_set_asyncmap(libppp_t* libppp, uint32_t asyncmap)
{
  DEBUGASSERT(libppp && libppp->ppp);
  libppp_info("set_asyncmap(%s, asyncmap=0x%08X)\n", libppp->tunname, asyncmap);
  ppp_set_asyncmap(libppp->ppp, asyncmap);
}

/// \brief Возвращает имя сетевого туннеля, используемого данным экземпляром libppp.
const char* libppp_get_tunname(libppp_t* libppp)
{
  DEBUGASSERT(libppp);
  return libppp->tunname;
}


/// \brief Возвращает текущее состояние конечного автомата подключения.
libppp_phase_t libppp_get_phase(libppp_t* libppp)
{
  DEBUGASSERT(libppp && libppp->ppp);
  return (libppp_phase_t)libppp->ppp->phase;
}

/// \brief  Начинает попытку подключения к удалённой стороне.
///
/// \param  libppp          Экземпляр ppp модуля
/// \param  holdoff_seconds Пауза (в секундах) перед непосредственно подключением.
///
/// \note Данный вызов возможен только из фазы LIBPPP_PHASE_DEAD
int libppp_connect(libppp_t* libppp, uint16_t holdoff_seconds)
{
  int ret;

  DEBUGASSERT(libppp && libppp->ppp);
  libppp_info("%s connecting...\n", libppp->tunname);


  // Установка вспомогательных данных для поллинга туннеля и потока ввода-вывода:
  libppp->pfd[0].fd       = -1;
  libppp->pfd[0].events   = POLLIN | POLLERR | POLLHUP;
  libppp->pfd[1].fd       = -1;
  libppp->pfd[1].events   = POLLIN | POLLERR | POLLHUP;

  libppp->pfs[0] = libppp->tun;

  ret = libppp->cb->get_stream_file(libppp->cb_arg, &libppp->pfs[1]);
  if (ret < 0) {
    libppp_error(
      "ERROR: %s can't get I/O file, ret=%d (%s)\n",
      libppp->tunname,
      ret,
      strerror(-ret)
    );
    return ret;
  }

  // Начало подключения.

  err_t err = ppp_connect(libppp->ppp, holdoff_seconds);
  if (err != ERR_OK) {
    libppp->session_state = LIBPPP_SESSION_STATE_NOT_ACTIVE;
    libppp_error(
      "ERROR: %s can't start connecting, ret=%d (%s)\n",
      libppp->tunname,
      err,
      libppp_err_to_description(err)
    );
    return -libppp_err_to_errno(err);
  }
  libppp->session_state = LIBPPP_SESSION_STATE_ACTIVE;
  return 0;
}

/// \brief  Начинает ожидание входящего запроса PPP соединения.
int libppp_listen(libppp_t* libppp)
{
  int ret;
  DEBUGASSERT(libppp && libppp->ppp);
  libppp_info("%s listening...\n", libppp->tunname);

  // Установка вспомогательных данных для поллинга туннеля и потока ввода-вывода:
  libppp->pfd[0].fd       = -1;
  libppp->pfd[0].events   = POLLIN | POLLERR | POLLHUP;
  libppp->pfd[1].fd       = -1;
  libppp->pfd[1].events   = POLLIN | POLLERR | POLLHUP;

  libppp->pfs[0] = libppp->tun;

  ret = libppp->cb->get_stream_file(libppp->cb_arg, &libppp->pfs[1]);
  if (ret < 0) {
    libppp_error(
      "ERROR: %s can't get I/O file, ret=%d (%s)\n",
      libppp->tunname,
      ret,
      strerror(-ret)
    );
    return ret;
  }

  err_t err = ppp_listen(libppp->ppp);
  if (err != ERR_OK) {
    libppp_error(
      "ERROR: %s can't start listening, ret=%d (%s)\n",
      libppp->tunname,
      err,
      libppp_err_to_description(err)
    );
    return -libppp_err_to_errno(err);
  }

  libppp->session_state = LIBPPP_SESSION_STATE_ACTIVE;
  return 0;
}

/// \brief  Начинает процесс закрытия PPP соединения.
/// \param  libppp          Экземпляр ppp модуля
/// \param  emergency       true=аварийное закрытие (если более недоступен поток обмена).
///
/// \note Удалять экземпляр можно только после того, как libppp_get_phase вернёт `LIBPPP_PHASE_DEAD`.
void libppp_close(libppp_t* libppp, bool emergency)
{
  DEBUGASSERT(libppp && libppp->ppp);
  if (libppp->session_state == LIBPPP_SESSION_STATE_NOT_ACTIVE) {
    return;
  }
  if (!emergency && libppp->session_state == LIBPPP_SESSION_STATE_CLOSING) {
    return;
  }

  libppp_info("%s closing (emergency=%d)... ppp_phase=\n", libppp->tunname, (int)emergency, libppp->ppp->phase);
  ppp_close(libppp->ppp, emergency);
  libppp->session_state = emergency
                        ? LIBPPP_SESSION_STATE_FORCE_CLOSING
                        : LIBPPP_SESSION_STATE_CLOSING;
}

/// \brief Обработчик ppp таймеров. Должен периодически вызываться из потока обработки.
void libppp_process_timeouts(libppp_t* libppp)
{
  (void)libppp;

  libppp_lock();
    // Необходимо выполнять в однопоточном режиме, т.к. может изменять
    // состояние любого экземпляра libppp
    sys_check_timeouts();
  libppp_unlock();

  libppp_nat_delete_aged_entries(libppp);
}

/// \brief Обработчик получения данных PPP из потока общения с удалённой точкой.
///
/// Обычно данный обработчик должен вызываться только когда в потоке
/// есть непрочитанные данные. Для ожидания данных следует использовать poll
/// или любой другой подходящий механизм.
ssize_t libppp_receive_stream(libppp_t* libppp)
{
  DEBUGASSERT(libppp && libppp->ppp);
  return libppp_do_receive_stream(libppp);
}

/// \brief Обработчик получения IP пакетов из туннеля.
///
/// Обычно данный обработчик должен вызываться только когда в потоке
/// есть непрочитанные данные. Для ожидания данных следует использовать poll
/// или любой другой подходящий механизм.
ssize_t libppp_receive_tun(libppp_t* libppp)
{
  DEBUGASSERT(libppp && libppp->ppp);
  return libppp_do_receive_tun(libppp);
}

int libppp_process(libppp_t* libppp)
{
  ssize_t ret;
  DEBUGASSERT(libppp);

  // Обработка таймеров
  libppp_process_timeouts(libppp);

  // Ожидание данных в туннеле или в потоке ввода-вывода
  libppp->pfd[0].revents = libppp->pfd[1].revents = 0;
  ret = poll_raw_files(libppp->pfs, libppp->pfd, 2, CONFIG_LIB_PPP_POLL_TIMEOUT_MS);

  if (ret == -EINTR) {
    // Отдаём внешнему коду возможность решить, нужно ли прерваться по EINTR.
    libppp_trace("%s poll interrupted by signal\n", libppp->tunname);
    return ret;
  }

  if (ret < 0) {
    // Если произошла ошибка поллинга, то считаем,
    // что более невозможно отправлять или получать данные.
    libppp_warn("WARN: %s can't poll, ret=%d (%s)\n", libppp->tunname, ret, strerror(-ret));

    // Завершаем сессию по потере канала данных и возвращаем 0,
    // что бы внешний код продолжил опрос конечного автомата ещё какое-то время
    // что бы конечный автомат корректно перешёл в состояние `LIBPPP_PHASE_DEAD`.
    libppp_close(libppp, true);
    return 0;
  }

  if (!ret) {
    // Нет данных ни в туннеле, ни в потоке ввода-вывода.
    return 0;
  }

  // Обработка событий туннеля
  ret = 0;
  if (libppp->pfd[0].revents & POLLIN) {
    ret = libppp_do_receive_tun(libppp);
    if (ret == -EINTR) {
      // Отдаём внешнему коду возможность решить, нужно ли прерваться по EINTR.
      libppp_trace("%s receive_tun interrupted by signal\n", libppp->tunname);
      return ret;
    }
  }
  if (ret < 0 || (libppp->pfd[0].revents & (POLLERR | POLLHUP))) {
    // Проблемы с туннелем. Закрываем PPP сессию в нормальном режиме,
    // т.к. канал ввода-вывода ещё доступен.
    libppp_trace("%s tunnel no longer available\n", libppp->tunname);
    libppp_close(libppp, false);
    // Не выходим, т.к. необходимо закрыть сеанс связи через канал ввода-вывода.
  }

  // Обработка событий канала ввода-вывода
  ret = 0;
  if (libppp->pfd[1].revents & POLLIN) {
    ret = libppp_do_receive_stream(libppp);
    if (ret == -EINTR) {
      // Отдаём внешнему коду возможность решить, нужно ли прерваться по EINTR.
      libppp_trace("%s receive_stream interrupted by signal\n", libppp->tunname);
      return ret;
    }
  }
  if (ret < 0 || (libppp->pfd[1].revents & (POLLERR | POLLHUP))) {
    // проблемы с каналом ввода-вывода. Аварийно закрываем сеанс связи.
    libppp_trace("%s tunnel I/O channel longer available\n", libppp->tunname);
    libppp_close(libppp, true);
  }

  return 0;
}
