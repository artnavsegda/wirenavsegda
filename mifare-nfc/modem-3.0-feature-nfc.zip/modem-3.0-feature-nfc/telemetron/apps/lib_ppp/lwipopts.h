#ifndef LWIPOPTS_H_INCLUDED
#define LWIPOPTS_H_INCLUDED

#define NO_SYS                      1
#define LWIP_SOCKET                 0
#define LWIP_NETCONN                0
#define LWIP_IPV4                   1
#define LWIP_DNS                    1
#define LWIP_ARP                    0
#define LWIP_ETHERNET               0
//#define LWIP_TCP                    0

// Похоже, PayKiosk не поддерживает или некорректно поддерживает
// компрессию Van Jacobsen
#define VJ_SUPPORT                  0

#define PBUF_POOL_BUFSIZE           1608

#define PPP_SUPPORT                 1
#define PPP_SERVER                  1
#define MEMP_NUM_PPP_PCB            2
#define PAP_SUPPORT                 1
#define PPP_IPV4_SUPPORT            1
#define PPPOS_SUPPORT               1
#define PPP_STATS_SUPPORT           0
#define PPP_NOTIFY_PHASE            1
#define PRINTPKT_SUPPORT            1
#define LCP_ECHOINTERVAL            5

#define LWIP_DEBUG                  LWIP_DBG_ON
#define PPP_DEBUG                   LWIP_DBG_OFF
#define IP_DEBUG                    LWIP_DBG_ON
#define LWIP_DBG_TYPES_ON           0xFFFF
#define LWIP_DBG_MIN_LEVEL          LWIP_DBG_LEVEL_ALL

#define PPP_MRU                     1500
#define PPP_DEFMRU                  1500
#define PPP_MAXMRU                  1600
#define PPP_MINMRU                  128
#define MAXNAMELEN                  64
#define MAXSECRETLEN                64
#define PPP_CUSTOM_SDNS_CDNS        1


#define TCP_OVERSIZE                0

#define LWIP_DISABLE_TCP_SANITY_CHECKS        1
#define MEMP_NUM_RAW_PCB                      0
#define MEMP_NUM_UDP_PCB                      1
#define MEMP_NUM_TCP_PCB                      1
#define MEMP_NUM_TCP_PCB_LISTEN               0
#define MEMP_NUM_TCP_SEG                      0
#define MEMP_NUM_ALTCP_PCB                    0
#define MEMP_NUM_REASSDATA                    0
#define MEMP_NUM_FRAG_PBUF                    0
#define MEMP_NUM_ARP_QUEUE                    0
#define MEMP_NUM_IGMP_GROUP                   0
#define MEMP_NUM_NETBUF                       0
#define MEMP_NUM_NETCONN                      0
#define MEMP_NUM_SELECT_CB                    0
#define MEMP_NUM_TCPIP_MSG_API                0
#define MEMP_NUM_TCPIP_MSG_INPKT              0
#define MEMP_NUM_NETDB                        0
#define MEMP_NUM_LOCALHOSTLIST                0
#define MEMP_NUM_API_MSG                      0
#define MEMP_NUM_DNS_API_MSG                  0
#define MEMP_NUM_SOCKET_SETGETSOCKOPT_DATA    0
#define MEMP_NUM_NETIFAPI_MSG                 0

#define PBUF_POOL_SIZE                        4

#endif
