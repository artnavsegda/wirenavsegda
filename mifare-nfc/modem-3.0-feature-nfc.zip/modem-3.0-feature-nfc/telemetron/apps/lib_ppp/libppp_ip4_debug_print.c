/// \file
/// \brief  Отладочная печать содержимого IP пакетов, передаваемых через libppp.
/// \author DL <dmitriy@linikov.ru>

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <ppp/libppp.h>
#include "lwip/ip4_addr.h"
#include "lwip/tcp.h"
#include "lwip/udp.h"
#include "lwip/prot/tcp.h"
#include "lwip/prot/udp.h"

#include <utils/string_utils.h>


////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Приватные функции


////////////////////////////////////////////////////////////////////////////
//  Публичные функции
// Извлечено из lwip/src/core/ipv4/ip4.c

#ifdef CONFIG_LIB_PPP_DEBUG_PRINT_IP_PACKETS
#ifdef CONFIG_LIB_PPP_DEBUG_PRINT_IP_PACKETS_VERBOSE
/**
 * Print tcp flags for debugging purposes.
 *
 * @param flags tcp flags, all active flags are printed
 */
static void libppp_tcp_flags_to_str(char* dst, size_t dstsize, u8_t flags)
{
  snprintf(dst, dstsize, "%s%s%s%s%s%s%s%s",
    (flags & TCP_FIN) ? "FIN " : "",
    (flags & TCP_SYN) ? "SYN " : "",
    (flags & TCP_RST) ? "RST " : "",
    (flags & TCP_PSH) ? "PSH " : "",
    (flags & TCP_ACK) ? "ACK " : "",
    (flags & TCP_URG) ? "URG " : "",
    (flags & TCP_ECE) ? "ECE " : "",
    (flags & TCP_CWR) ? "CWR " : ""
  );
}
/**
 * Print a tcp header for debugging purposes.
 *
 * @param tcphdr pointer to a struct tcp_hdr
 */
static void libppp_tcp_debug_print(struct tcp_hdr *tcphdr)
{
  char flags[33];
  libppp_tcp_flags_to_str(flags, sizeof(flags), TCPH_FLAGS(tcphdr));

  libppp_ip_trace("TCP header:\n");
  libppp_ip_trace("+-------------------------------+\n");
  libppp_ip_trace(
    "|    %5"U16_F"      |    %5"U16_F"      | (src port, dest port)\n",
    lwip_ntohs(tcphdr->src),
    lwip_ntohs(tcphdr->dest)
  );
  libppp_ip_trace("|           %010"U32_F"          | (seq no)\n", lwip_ntohl(tcphdr->seqno));
  libppp_ip_trace("|           %010"U32_F"          | (ack no)\n", lwip_ntohl(tcphdr->ackno));
  libppp_ip_trace(
    "| %2"U16_F" |   |%"U16_F"%"U16_F"%"U16_F"%"U16_F"%"U16_F"%"U16_F"|     %5"U16_F"     | (hdrlen, flags( %s), win)\n",
    TCPH_HDRLEN(tcphdr),
    (u16_t)(TCPH_FLAGS(tcphdr) >> 5 & 1),
    (u16_t)(TCPH_FLAGS(tcphdr) >> 4 & 1),
    (u16_t)(TCPH_FLAGS(tcphdr) >> 3 & 1),
    (u16_t)(TCPH_FLAGS(tcphdr) >> 2 & 1),
    (u16_t)(TCPH_FLAGS(tcphdr) >> 1 & 1),
    (u16_t)(TCPH_FLAGS(tcphdr)      & 1),
    lwip_ntohs(tcphdr->wnd),
    flags
  );
  libppp_ip_trace("|    0x%04"X16_F"     |     %5"U16_F"     | (chksum, urgp)\n",
                          lwip_ntohs(tcphdr->chksum), lwip_ntohs(tcphdr->urgp));
  libppp_ip_trace("+-------------------------------+\n");
}


static void libppp_udp_debug_print(struct udp_hdr *udphdr)
{
  libppp_ip_trace("UDP header:\n");
  libppp_ip_trace("+-------------------------------+\n");
  libppp_ip_trace("|     %5"U16_F"     |     %5"U16_F"     | (src port, dest port)\n", lwip_ntohs(udphdr->src), lwip_ntohs(udphdr->dest));
  libppp_ip_trace("|     %5"U16_F"     |     0x%04"X16_F"    | (len, chksum)\n", lwip_ntohs(udphdr->len), lwip_ntohs(udphdr->chksum));
  libppp_ip_trace("+-------------------------------+\n");
}

/* Print an IP header by using LWIP_DEBUGF
 * @param p an IP packet, p->payload pointing to the IP header
 */
void libppp_ip4_debug_print(struct pbuf *p, const char* msg, const char* dev)
{
  struct ip_hdr *iphdr = (struct ip_hdr *)p->payload;

  unsigned hdr_bytes      = (u16_t)IPH_HL(iphdr) * 4;
  unsigned total_bytes    = lwip_ntohs(IPH_LEN(iphdr));
  unsigned payload_bytes  = (total_bytes > p->len ? p->len : total_bytes) - hdr_bytes;
  uint8_t  protocol       = (u16_t)IPH_PROTO(iphdr);

  if (p->len < 20) {
    // Минимальный размер заголовка IP - 20 байт
    libppp_ip_dump("Invalid IP packet", p->payload, p->len);
    return;
  }

  libppp_ip_trace("%s: %s: IP header:\n", dev, msg);
  libppp_ip_trace("+-------------------------------+\n");
  libppp_ip_trace("|%2"S16_F" |%2"S16_F" |  0x%02"X16_F" |     %5"U16_F"     | (v, hl, tos, len)\n",
                         (u16_t)IPH_V(iphdr),
                         (u16_t)IPH_HL(iphdr),
                         (u16_t)IPH_TOS(iphdr),
                         lwip_ntohs(IPH_LEN(iphdr)));
  libppp_ip_trace("|    %5"U16_F"      |%"U16_F"%"U16_F"%"U16_F"|    %4"U16_F"   | (id, flags, offset)\n",
                         lwip_ntohs(IPH_ID(iphdr)),
                         (u16_t)(lwip_ntohs(IPH_OFFSET(iphdr)) >> 15 & 1),
                         (u16_t)(lwip_ntohs(IPH_OFFSET(iphdr)) >> 14 & 1),
                         (u16_t)(lwip_ntohs(IPH_OFFSET(iphdr)) >> 13 & 1),
                         (u16_t)(lwip_ntohs(IPH_OFFSET(iphdr)) & IP_OFFMASK));
  libppp_ip_trace("|  %3"U16_F"  |  %3"U16_F"  |    0x%04"X16_F"     | (ttl, proto, chksum)\n",
                         (u16_t)IPH_TTL(iphdr),
                         (u16_t)IPH_PROTO(iphdr),
                         lwip_ntohs(IPH_CHKSUM(iphdr)));
  libppp_ip_trace("|  %3"U16_F"  |  %3"U16_F"  |  %3"U16_F"  |  %3"U16_F"  | (src)\n",
                         ip4_addr1_16(&iphdr->src),
                         ip4_addr2_16(&iphdr->src),
                         ip4_addr3_16(&iphdr->src),
                         ip4_addr4_16(&iphdr->src));
  libppp_ip_trace("|  %3"U16_F"  |  %3"U16_F"  |  %3"U16_F"  |  %3"U16_F"  | (dest)\n",
                         ip4_addr1_16(&iphdr->dest),
                         ip4_addr2_16(&iphdr->dest),
                         ip4_addr3_16(&iphdr->dest),
                         ip4_addr4_16(&iphdr->dest));
  libppp_ip_trace("+-------------------------------+\n");

  if (hdr_bytes > 20) {
    libppp_ip_dump("ip-hdr-options", ((uint8_t*)p->payload) + 20, hdr_bytes - 20);
  }
  if (!payload_bytes) {
    return;
  }
  if (payload_bytes > CONFIG_NET_TUN_MTU) {
    libppp_ip_dump("Invalid IP packet", p->payload, p->len);
    return;
  }

  uint8_t* payload = ((uint8_t*)iphdr) + hdr_bytes;

  if (protocol == IP_PROTO_TCP) {
    struct tcp_hdr* tcp_header = (struct tcp_hdr*)payload;
    libppp_tcp_debug_print(tcp_header);
    payload += TCPH_HDRLEN_BYTES(tcp_header);
    payload_bytes -= TCPH_HDRLEN_BYTES(tcp_header);
  } else if (protocol == IP_PROTO_UDP) {
    struct udp_hdr* udp_header = (struct udp_hdr*)payload;
    libppp_udp_debug_print(udp_header);
    payload += 8;
    payload_bytes -= 8;
  } else if (protocol == IP_PROTO_ICMP) {
    libppp_ip_trace("ICMP");
  } else if (protocol == IP_PROTO_IGMP) {
    libppp_ip_trace("IGMP");
  }
  libppp_ip_dump("payload", payload, payload_bytes);
}

#else // !VERBOSE

static void libppp_udp4_debug_print(struct ip_hdr *iphdr, struct udp_hdr *udphdr, const char* msg, const char* dev)
{
  char buffer[33];
  DumpToHexString(buffer, sizeof(buffer), ((uint8_t*)udphdr) + 8, lwip_ntohs(udphdr->len));

  libppp_ip_trace(
    "%s: %s: UDPv4: {src:\"%d.%d.%d.%d:%d\", dst:\"%d.%d.%d.%d:%d\", datalen:%d, data:\"%s\", checksum:%#04X }\n",
    dev,
    msg,

    // src
    ip4_addr1_16(&iphdr->src),
    ip4_addr2_16(&iphdr->src),
    ip4_addr3_16(&iphdr->src),
    ip4_addr4_16(&iphdr->src),
    lwip_ntohs(udphdr->src),

    //dst
    ip4_addr1_16(&iphdr->dest),
    ip4_addr2_16(&iphdr->dest),
    ip4_addr3_16(&iphdr->dest),
    ip4_addr4_16(&iphdr->dest),
    lwip_ntohs(udphdr->dest),

    // datalen, data, checksum
    lwip_ntohs(udphdr->len),
    buffer,
    lwip_ntohs(udphdr->chksum)
  );

}

static void libppp_tcp4_debug_print(struct ip_hdr *iphdr, struct tcp_hdr *tcphdr, size_t length, const char* msg, const char* dev)
{
  u8_t flags = TCPH_FLAGS(tcphdr);
  length    -= TCPH_HDRLEN_BYTES(tcphdr);

  char buffer[33];
  DumpToHexString(buffer, sizeof(buffer), ((uint8_t*)tcphdr) + TCPH_HDRLEN_BYTES(tcphdr), length);

  libppp_ip_trace(
    "%s: %s: TCPv4: {src:\"%d.%d.%d.%d:%d\", dst:\"%d.%d.%d.%d:%d\", seq:%lu, ack:%lu, win:%d, flags:\" %s%s%s%s%s%s%s%s\", datalen:%d, data:\"%s\", checksum:%#04X }\n",
    dev,
    msg,

    // src
    ip4_addr1_16(&iphdr->src),
    ip4_addr2_16(&iphdr->src),
    ip4_addr3_16(&iphdr->src),
    ip4_addr4_16(&iphdr->src),
    lwip_ntohs(tcphdr->src),

    //dst
    ip4_addr1_16(&iphdr->dest),
    ip4_addr2_16(&iphdr->dest),
    ip4_addr3_16(&iphdr->dest),
    ip4_addr4_16(&iphdr->dest),
    lwip_ntohs(tcphdr->dest),

    // seq, ack, win
    lwip_ntohl(tcphdr->seqno),
    lwip_ntohl(tcphdr->ackno),
    lwip_ntohs(tcphdr->wnd),

    // flags
    (flags & TCP_FIN) ? "FIN " : "",
    (flags & TCP_SYN) ? "SYN " : "",
    (flags & TCP_RST) ? "RST " : "",
    (flags & TCP_PSH) ? "PSH " : "",
    (flags & TCP_ACK) ? "ACK " : "",
    (flags & TCP_URG) ? "URG " : "",
    (flags & TCP_ECE) ? "ECE " : "",
    (flags & TCP_CWR) ? "CWR " : "",

    // datalen, data, checksum
    length,
    buffer,
    lwip_ntohs(tcphdr->chksum)
  );
}

static void libppp_icmp4_debug_print(struct ip_hdr *iphdr, const char* msg, const char* dev)
{
  libppp_ip_trace(
    "%s: %s: ICMPv4: {src:\"%d.%d.%d.%d\", dst:\"%d.%d.%d.%d\" }\n",
    dev,
    msg,
    // src
    ip4_addr1_16(&iphdr->src),
    ip4_addr2_16(&iphdr->src),
    ip4_addr3_16(&iphdr->src),
    ip4_addr4_16(&iphdr->src),

    //dst
    ip4_addr1_16(&iphdr->dest),
    ip4_addr2_16(&iphdr->dest),
    ip4_addr3_16(&iphdr->dest),
    ip4_addr4_16(&iphdr->dest)
  );


}

static void libppp_igmp4_debug_print(struct ip_hdr *iphdr, const char* msg, const char* dev)
{
  libppp_ip_trace(
    "%s: %s: IGMPv4: {src:\"%d.%d.%d.%d\", dst:\"%d.%d.%d.%d\" }\n",
    dev,
    msg,

    // src
    ip4_addr1_16(&iphdr->src),
    ip4_addr2_16(&iphdr->src),
    ip4_addr3_16(&iphdr->src),
    ip4_addr4_16(&iphdr->src),

    //dst
    ip4_addr1_16(&iphdr->dest),
    ip4_addr2_16(&iphdr->dest),
    ip4_addr3_16(&iphdr->dest),
    ip4_addr4_16(&iphdr->dest)
  );
}

static void libppp_ip_nodata_debug_print(struct ip_hdr *iphdr, const char* msg, const char* dev)
{
  libppp_ip_trace(
    "%s: %s: IPv4-NoPayload: {src:\"%d.%d.%d.%d\", dst:\"%d.%d.%d.%d\" }\n",
    dev,
    msg,

    // src
    ip4_addr1_16(&iphdr->src),
    ip4_addr2_16(&iphdr->src),
    ip4_addr3_16(&iphdr->src),
    ip4_addr4_16(&iphdr->src),

    //dst
    ip4_addr1_16(&iphdr->dest),
    ip4_addr2_16(&iphdr->dest),
    ip4_addr3_16(&iphdr->dest),
    ip4_addr4_16(&iphdr->dest)
  );

}

void libppp_ip4_debug_print(struct pbuf *p, const char* msg, const char* dev)
{
  struct ip_hdr *iphdr = (struct ip_hdr *)p->payload;

  unsigned hdr_bytes      = (u16_t)IPH_HL(iphdr) * 4;
  unsigned total_bytes    = lwip_ntohs(IPH_LEN(iphdr));
  unsigned payload_bytes  = (total_bytes > p->len ? p->len : total_bytes) - hdr_bytes;
  uint8_t  protocol       = (u16_t)IPH_PROTO(iphdr);

  if (!dev) {
    dev = "";
  }

  if (p->len < 20 || payload_bytes > CONFIG_NET_TUN_MTU) {
    libppp_ip_trace("%s: %s: Invalid IP packet, len=%d, payload_len=%d\n", dev, msg, p->len, payload_bytes);
    return;
  }

  if (!payload_bytes) {
    libppp_ip_nodata_debug_print(iphdr, msg, dev);
    return;
  }

  uint8_t* payload = ((uint8_t*)iphdr) + hdr_bytes;
  if (protocol == IP_PROTO_TCP) {
    struct tcp_hdr* tcp_header = (struct tcp_hdr*)payload;
    libppp_tcp4_debug_print(iphdr, tcp_header, payload_bytes, msg, dev);

  } else if (protocol == IP_PROTO_UDP) {
    struct udp_hdr* udp_header = (struct udp_hdr*)payload;
    libppp_udp4_debug_print(iphdr, udp_header, msg, dev);

  } else if (protocol == IP_PROTO_ICMP) {
    libppp_icmp4_debug_print(iphdr, msg, dev);

  } else if (protocol == IP_PROTO_IGMP) {
    libppp_igmp4_debug_print(iphdr, msg, dev);
  }
}
#endif // CONFIG_LIB_PPP_DEBUG_PRINT_IP_PACKETS_VERBOSE
#endif // CONFIG_LIB_PPP_DEBUG_PRINT_IP_PACKETS
