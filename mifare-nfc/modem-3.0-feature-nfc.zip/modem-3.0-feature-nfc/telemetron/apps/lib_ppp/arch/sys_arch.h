#ifndef TELEMETRON_APPS_PPPD_ARCH_SYS_ARCH_H_INCLUDED
#define TELEMETRON_APPS_PPPD_ARCH_SYS_ARCH_H_INCLUDED

#define SYS_MBOX_NULL   NULL
#define SYS_SEM_NULL    NULL

typedef void * sys_prot_t;

typedef void * sys_sem_t;

typedef void * sys_mbox_t;

typedef void * sys_thread_t;

#endif // TELEMETRON_APPS_PPPD_ARCH_SYS_ARCH_H_INCLUDED
