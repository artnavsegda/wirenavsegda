#ifndef LWIP_CC_H_INCLUDED
#define LWIP_CC_H_INCLUDED

#include <nuttx/config.h>
#include <sched.h>

#include <stdint.h>
#include <sys/types.h>
#include <inttypes.h>
#include <arpa/inet.h>

#include <debug.h>
#include <assert.h>

typedef uint8_t   u8_t;
typedef uint16_t  u16_t;
typedef uint32_t  u32_t;

typedef int8_t    su8_t;
typedef int16_t   s16_t;
typedef int32_t   s32_t;

#define X8_F  "02" PRIx8
#define U16_F     PRIu16
#define S16_F     PRIi16
#define X16_F     PRIx16
#define U32_F     PRIu32
#define S32_F     PRIi32
#define X32_F     PRIx32
#define SZT_F     PRIuPTR

#ifdef CONFIG_ENDIAN_BIG
#define BYTE_ORDER    BIG_ENDIAN
#else
#define BYTE_ORDER    LITTLE_ENDIAN
#endif

#define LWIP_PLATFORM_BYTESWAP  1
#define lwip_htons(x)  htons(x)
#define lwip_htonl(x)  htonl(x)

// использовать функции hto* в виде lwip_hto*
#define LWIP_DONT_PROVIDE_BYTEORDER_FUNCTIONS 1


#define LWIP_CHKSUM_ALGORITHM   3         // считать по 32-бита



#define PACK_STRUCT_FIELD(x) x __attribute__((packed))
#define PACK_STRUCT_FLD_8(x) x
#define PACK_STRUCT_FLD_S(x) x
#define PACK_STRUCT_STRUCT __attribute__((packed))
#define PACK_STRUCT_BEGIN
#define PACK_STRUCT_END


#define LWIP_PLATFORM_INFO(format,...)  _info(format "\n", ##__VA_ARGS__)
#define LWIP_PLATFORM_DIAG(x)           LWIP_PLATFORM_INFO x
#define LWIP_PLATFORM_ASSERT(x) \
  do { _err("LWIP: Assertion \"%s\" failed\n", x); PANIC(); } while (0)

#define LWIP_NO_STDDEF_H 0
#define LWIP_NO_STDINT_H 0
#define LWIP_NO_INTTYPES_H 0
#define LWIP_NO_LIMITS_H 0
#define LWIP_NO_UNISTD_H 0
#define LWIP_NO_CTYPE_H 0
#define LWIP_ERRNO_STDINCLUDE 1

#ifdef CONFIG_HAVE_LONG_LONG
#define LWIP_HAVE_INT64 1
#endif

#define SYS_ARCH_DECL_PROTECT(lev)
#define SYS_ARCH_PROTECT(lev)       sched_lock()
#define SYS_ARCH_UNPROTECT(lev)     sched_unlock()


#define lwip_itoa(buf,bufsz,v)      snprintf(buf,bufsz,"%s",v)
#define lwip_strnicmp(s1,s2,len)    strncasecmp(s1,s2,len)
#define lwip_stricmp(s1,s2)         strcasecmp(s1,s2)

#endif
