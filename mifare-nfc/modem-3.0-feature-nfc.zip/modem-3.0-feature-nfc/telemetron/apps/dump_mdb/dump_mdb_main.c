/****************************************************************************
 * telemetron/apps/dump_mdb/dump_mdb_main.c
 *
 ****************************************************************************/

/****************************************************************************
 * Included Files
 ****************************************************************************/

#include <nuttx/config.h>
#include <sys/time.h>
#include <time.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>
#include <syslog.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <poll.h>

#include "utils/posix_iohelper.h"

/****************************************************************************
 * Public Functions
 ****************************************************************************/

/****************************************************************************
 * Private Functions
 ****************************************************************************/
static uint64_t get_now_ms(void)
{
  struct timespec   ts;
  if (clock_gettime(CLOCK_MONOTONIC, &ts) < 0) {
    return 0;
  }
  return (uint64_t)ts.tv_sec * 1000u + ts.tv_nsec / 1000000;
}

static int GetwTimeout(int fd, int timeout_ms)
{
  // Подготовка вспомогательных структур для вызова poll
  struct pollfd   pfd = {
    .fd       = fd,
    .events   = POLLIN,
    .revents  = 0
  };

  // Ожидание событий в течение timeout_ms
  int ret = poll(&pfd, 1, timeout_ms);

  if (ret < 0) {
    return -errno;
  }

  if (ret == 0 || 0 == (pfd.revents & POLLIN)) {
    // Вызов poll завершился по таймауту
    return -EAGAIN;
  }

  uint16_t buffer;
  ssize_t n = read(fd, &buffer, sizeof(buffer));
  if (n != sizeof(buffer)){
    // Такого после успешного poll быть не должно, вернём timeout
    syslog(LOG_CRIT, "GetwTimeout(%d, %d): read err=%d\n", fd, timeout_ms, errno);
    return -EAGAIN;
  }

  return (int)buffer;
}

/****************************************************************************
 * dump_mdb_main
 ****************************************************************************/

#ifdef CONFIG_BUILD_KERNEL
int main(int argc, FAR char *argv[])
#else
int dump_mdb_main(int argc, char *argv[])
#endif
{
  if (argc < 2) {
    fprintf(stderr,
            "Insufficient args.\n"
            "Usage: dump_mdb <path> [dump duration in ms]\n\n");
    return 1;
  }

  int           duration  = 15000; // Стандартно - 15 секунд
  const char*   path      = argv[1];

  if (argc >= 3) {
    duration = atol(argv[2]);
  }
  if (duration <= 0) {
    fprintf(stderr, "Invalid duration.\n");
    return 2;
  }


  int           port = SerialOpenRawNonblocking(path, B9600, SERIAL_WORDLEN_9_BIT, SERIAL_PARITY_NONE, SERIAL_FLOWCTL_NONE);
  if (port < 0) {
    fprintf(stderr, "Can't open port \"%s\" in 9-bit mode.\n", path);
    return 3;
  }

  int           result = 0;

  uint64_t      end_time = get_now_ms() + duration;
  while (get_now_ms() < end_time) {
    int value = GetwTimeout(port, 500);
    if (value >= 0) {
      syslog(LOG_DEBUG, "R:%04X\n", (uint16_t)value);
    }
  }

  if (port >= 0) {
    close(port);
    port = -1;
  }

  return result;
}
