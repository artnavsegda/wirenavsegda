/****************************************************************************
 * telemetron/apps/test_filequeue/test_filequeue_main.c
 *
 ****************************************************************************/

/****************************************************************************
 * Included Files
 ****************************************************************************/

#include <nuttx/config.h>
#include <errno.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <signal.h>

#include <filequeue/filequeue.h>
#include <utils/dbg.h>

#define QUEUE_NAME   "/qtest"

/****************************************************************************
 * Private Functions
 ****************************************************************************/
static int print_usage(void)
{
  printf( "Usage:\n"
          "\tfq reader [optional reader args]\n"
          "\t\tOR\n"
          "\tfq write <message>\n"
          "\t\tOR\n"
          "\tfq create [optional create args]\n"
          "\n");
  return -1;
}

static int read_queue(void)
{
  fq_id_t msg_id = fq_find_head(QUEUE_NAME);
  if (msg_id <= 0) {
    fprintf(stderr, "TFQ: Find head fail. err=%d\n", msg_id);
    return msg_id;
  }

  int fd = fq_read(QUEUE_NAME, msg_id);
  if (fd < 0) {
    fprintf(stderr, "TFQ: Can't open message. err=%d (%s)\n", fd, strerror(fd));
    return fd;
  }

  fprintf(stderr, "TFQ:MSG:");
  uint8_t buffer[64];
  for(;;) {
    ssize_t size = read(fd, buffer, sizeof(buffer));
    if (!size) {
      break;
    }

    fwrite(buffer, size, 1, stderr);
  }

  fprintf(stderr, "\n");
  close(fd);

  int ret = fq_unlink(QUEUE_NAME, msg_id);
  if (ret < 0) {
    fprintf(stderr, "TFQ: Can't unlink. err=%d (%s)\n", ret, strerror(ret));
  }
  return ret;
}

static int run_as_reader(int argc, FAR char* argv[])
{
  int ret;

  for (;;) {
    ret = fq_counter_wait_timeout(QUEUE_NAME, 10000);
    if (ret == -EINTR) {
      // Получено прерывание. Считаем, что необходимо завершить работу.
      fprintf(stderr, "TFQ: reader terminated by SIGINT.\n");
      return ret;
    }

    if (ret < 0) {
      fprintf(stderr, "TFQ: Wait queue '%s' failed. err=%d (%s)\n",
        QUEUE_NAME, -ret, strerror(-ret)
      );
      continue;
    }

    ret = fq_lock(QUEUE_NAME);
    if (ret < 0) {
      fq_counter_increment(QUEUE_NAME);
      continue;
    }

    ret = read_queue();

    fq_unlock(QUEUE_NAME);
  }
  return 0;
}

static int run_write(int argc, FAR char* argv[])
{
  if (argc < 1) {
    return print_usage();
  }
  fprintf(stderr, "TFQ:Write:'%s'\n", argv[1]);

  log_trace("TFQw:fq_lock...");
  int tmp;
  int ret = fq_lock(QUEUE_NAME);
  log_trace("TFQw:fq_lock returned %d", ret);
  if (ret < 0) {
    fprintf(stderr, "TFQ:Write:Can't lock, err=%d (%s)\n", -ret, strerror(-ret));
    goto cleanup_no_lock;
  }

  int     fd;
  fq_id_t msg_id;
  log_trace("TFQw:fq_push_new...");
  fd = fq_push_new(QUEUE_NAME, 0, &msg_id);
  log_trace("TFQw:fq_push_new returned %d", fd);
  if (fd < 0) {
    ret = fd;
    fprintf(stderr, "TFQ:Write:Can't push. err=%d (%s)\n", -ret, strerror(-ret));
    goto cleanup;
  }

  log_trace("TFQw:write...");
  ret = write(fd, argv[1], strlen(argv[1]));
  log_trace("TFQw:write returned %d", ret);
  if (ret < 0) {
    ret = -errno;
    fprintf(stderr, "TFQ:Write:Can't write. err=%d (%s)\n", -ret, strerror(-ret));
    goto cleanup;
  }

  log_trace("TFQw:close...");
  tmp = close(fd);
  log_trace("TFQw:close returned %d", tmp);
  ret = OK;
  fprintf(stderr, "TFQ:Write:written message, id=%08X\n", msg_id);

cleanup:
  log_trace("TFQw:fq_unlock...");
  tmp = fq_unlock(QUEUE_NAME);
  log_trace("TFQw:fq_unlock returned %d", tmp);

  cleanup_no_lock:
  log_trace("TFQ:Write returns %d", ret);
  return ret;
}

static int run_create(int argc, FAR char* argv[])
{
  int ret = fq_create(QUEUE_NAME, NULL);
  if (ret < 0) {
    fprintf(stderr, "ERROR: Can't create queue. err=%d (%s)\n", -ret, strerror(-ret));
    return 1;
  }
  
  printf("Created '%s'\n", QUEUE_NAME);
  return 0;
}

static int run_read_sem(int argc, FAR char* argv[])
{
  int count = 0;
  int ret = fq_counter_read(QUEUE_NAME, &count);
  if (ret != OK) {
    fprintf(stderr, "ERROR: Can't read sem, err=%d (%s)\n", -ret, strerror(-ret));
    return -1;
  }

  fprintf(stderr, "%d\n", count);
  return 0;
}

/****************************************************************************
 * test_filequeue_main
 ****************************************************************************/

typedef struct param_to_handler_s {
  const char* param;
  int (*handler)(int argc, char* argv[]);
} param_to_handler_t;

static const param_to_handler_t  ALL_CMDS[] = {
  { "reader", run_as_reader },
  { "r",      run_as_reader },

  { "write",  run_write },
  { "w",      run_write },

  { "create", run_create },
  { "init",   run_create },
  { "c",      run_create },

  { "read-sem", run_read_sem },
  { "sem",    run_read_sem },
  { "s",      run_read_sem },
  { "n",      run_read_sem },

  { NULL,     NULL },
};

#ifdef CONFIG_BUILD_KERNEL
int main(int argc, FAR char *argv[])
#else
int fq_main(int argc, char *argv[])
#endif
{
  if (argc < 1) {
    return print_usage();
  }

  for (const param_to_handler_t* p=ALL_CMDS; p->param != NULL; ++p) {
    if (strcmp(p->param, argv[1]) == 0 && p->handler) {
      return p->handler(argc-1, &argv[1]);
    }
  }

  return print_usage();
}
