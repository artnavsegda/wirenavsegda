/// \file
/// \brief  Библиотека хранения настроек.
/// \author DL <dmitriy@linikov.ru>

#ifndef CONFIG_TELEMETRON_APPS_LIB_SETTINGS_INCLUDED
#define CONFIG_TELEMETRON_APPS_LIB_SETTINGS_INCLUDED

#include <nuttx/config.h>
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_AUX_PORTS                     3
#define MAX_SENSORS                       4

#define SCHEDULE_TIME_MASK                0x7FFFu
#define SCHEDULE_LAST_ENTRY               0x8000u

#define UNKNOWN_VALUE                     0xFF

#define APN_SIZE                          20
#define APN_USER_SIZE                     20
#define APN_PSW_SIZE                      20

#define CONFIG_SETTINGS_FW_PARAMS_CRC_GUARD      0x000D
#define CONFIG_SETTINGS_APN_PARAMS_CRC_GUARD     0x8021


#define CONFIG_SETTINGS_FW_PARAMS_FILE    "/cfg/fw"
#define CONFIG_SETTINGS_APN_PARAMS_FILE   "/cfg/apn"


// Большинство настроек используются из Kconfig из состава fw или srvd
#define CFG_SETTINGS_DEFAULT_SERVER     CONFIG_LIB_SRVD_DEFAULT_SERVER_NAME
#define CFG_SETTINGS_DEFAULT_PORT       CONFIG_LIB_SRVD_DEFAULT_SERVER_PORT
#define CFG_SETTINGS_DEFAULT_PATH       CONFIG_LIB_SRVD_DEFAULT_SERVER_PATH
#define CFG_SETTINGS_DEFAULT_T_PING_MS  CONFIG_LIB_SRVD_DEFAULT_T_PING_MS

#define CONFIG_SETTINGS_DEFAULT_MDBEXE_ERR_TIMEOUT_MS 180000

#define CFG_SETTINGS_DEFAULT_PRINTER_TCP_PORT       "7778"
#define CFG_SETTINGS_DEFAULT_PRINTER_PSW            "30"




#ifdef CONFIG_SETTINGS_DEBUG_ERROR
#   define settings_error(format, ...) _err("CFG:" format, ##__VA_ARGS__)
#else
#   define settings_error(x...)
#endif

#ifdef CONFIG_SETTINGS_DEBUG_WARN
#   define settings_warn(format, ...) _warn("CFG:" format, ##__VA_ARGS__)
#else
#   define settings_warn(x...)
#endif

#ifdef CONFIG_SETTINGS_DEBUG_INFO
#   define settings_info(format, ...) _info("CFG:" format, ##__VA_ARGS__)
#else
#   define settings_info(x...)
#endif

#ifdef CONFIG_SETTINGS_DEBUG_DEBUG
#   define settings_debug(format, ...) _info("CFG:" format, ##__VA_ARGS__)
#   define settings_debugdump(msg, buf, sz) infodumpbuffer(("CFG:" msg), (const uint8_t*)(buf), (sz))
#else
#   define settings_debug(x...)
#   define settings_debugdump(msg, buf, sz)
#endif

#ifdef CONFIG_SETTINGS_DEBUG_TRACE
#   define settings_trace(format, ...) _info("CFG:" format, ##__VA_ARGS__)
#   define settings_dump(msg, buf, sz) infodumpbuffer(("CFG:" msg), (const uint8_t*)(buf), (sz))
#else
#   define settings_trace(x...)
#   define settings_dump(msg, buf, sz)
#endif

#define AUX1      0
#define AUX2      1
#define AUX3      2



/// \defgroup settings  Настройки - Формат данных для хранения настроек
/// @{

/// \defgroup settings_aux Настройки каждого из AUX каналов


/// \brief Тип данных для параметра, принимающего значения `on` и `off`.
typedef enum onoff_e {
  VALUE_OFF = 0,
  VALUE_ON  = 1,
} onoff_t;

/// \brief Тип шины торгового автомата
typedef enum mdbexe_bus_e {
  MDBEXE_BUS_MDB      = 0,
  MDBEXE_BUS_EXE      = 1,
} mdbexe_bus_t;

/// \ingroup settings settings_aux
/// \brief Тип аппаратного интерфейса AUX порта
typedef enum aux_interface_e {
  AUX_INTERFACE_OFF           = 0,
  AUX_INTERFACE_TTL           = 1,
  AUX_INTERFACE_RS232         = 2,
  AUX_INTERFACE_RS485         = 3,
  AUX_INTERFACE_AUTO          = 0xFF
} aux_interface_t;


/// \ingroup settings settings_aux
/// \brief Тип подключенного к AUX порту устройства
typedef enum aux_type_e {
  AUX_TYPE_OFF                = 0x00,   ///< Порт не используется
  AUX_TYPE_AUDIT_AUTO         = 0x01,   ///< автоматический выбор (поиск отклика) протокола обмена EVADTS
  AUX_TYPE_AUDIT_DEX          = 0x02,   ///< протокол DEX
  AUX_TYPE_AUDIT_DDCMP        = 0x03,   ///< протокол DDCMP
  AUX_TYPE_AUDIT_WMF1200      = 0x04,   ///< протокол WMF1200S
  AUX_TYPE_AUDIT_WMF1800      = 0x05,   ///< протокол WMF1800S
  AUX_TYPE_KKM_PRINTER        = 0x06,   ///< протокол принтера
  AUX_TYPE_AUDIT_GERHARDT     = 0x07,   ///< протокол Gerhardt CTG Series
  AUX_TYPE_CONSOLE            = 0xFF,   ///< Порт используется в качестве консоли.
} aux_type_t;

/// \ingroup settings settings_aux
/// \brief Состояние порта, когда не идёт обмен с торговым автоматом.
///
/// Используется только для портов с типами AUX_TYPE_AUDIT_xxx
typedef enum aux_idlestate_e {
  AUX_IDLESTATE_FLOAT         = 0,
  AUX_IDLESTATE_ZERO          = 1,
  AUX_IDLESTATE_ONE           = 2,
} aux_idlestate_t;


/// \ingroup settings settings_aux
/// \brief режим работы DDCMP
typedef enum ddcmp_mode_e {
  EVADTS_DDCMP_AUTO           = 0x00,   ///< автоматический выбор режима обмена по DDCMP
  EVADTS_DDCMP_EXT            = 0x01,   ///< принудительно расширенный режим обмена (стандартно для DDCMP)
  EVADTS_DDCMP_FIX            = 0x02,   ///< принудительно фиксированный режим работы (скорость задаем отдельно)
} ddcmp_mode_t;


/// \ingroup settings settings_aux
/// \brief ограничение скорости в расширеном режиме работы (полезно когда TTL и много шумов)
typedef enum ddcmp_extspeed_e {
  EVADTS_DDCMP_SPEED_UP_OFF   = 0x00,   ///< запретить в расширенном режиме поднимать скорость до максимально возможной аппарата
  EVADTS_DDCMP_SPEED_UP_ON    = 0x01,   ///< в расширенном режиме ограничить подъем скорости до 9600
} ddcmp_extspeed_t;


/// \ingroup settings settings_aux
/// \brief тип запроса аудита в DDCMP (просто EVADTS или EVADTS и настройки)
typedef enum ddcmp_auditmode_e {
  EVADTS_DDCMP_AUDIT          = 0x00,   ///< запрашиваем только EVADTS отчет (см DDCMP_E2_AUDIT_WOR)
  EVADTS_DDCMP_AUDIT_CFG      = 0x01,   ///< запрашиваем EVADTS и настройки (см DDCMP_E2_ALL_DATA)
  EVADTS_DDCMP_AUDIT_RST      = 0x02,   ///< запрос аудита и сброс параметров
} ddcmp_auditmode_t;

/// \ingroup settings settings_aux
/// \brief скорость работы DDCMP в фиксированном режиме
typedef enum ddcmp_fix_baud_e {
  EVADTS_DDCMP_FIX_9600       = 0x00,   ///< скорость обмена 9600
  EVADTS_DDCMP_FIX_2400       = 0x01,   ///< скорость обмена 2400
  EVADTS_DDCMP_FIX_19200      = 0x02,   ///< скорость обмена 19200 привет от Shpengler
  EVADTS_DDCMP_FIX_38400      = 0x03,   ///< скорость обмена 38400
  EVADTS_DDCMP_FIX_57600      = 0x04,   ///< скорость обмена 57600
  EVADTS_DDCMP_FIX_115200     = 0x05,   ///< скорость обмена 115200
} ddcmp_fix_baud_t;

/// \ingroup settings settings_aux
/// \brief режим корректировки работы DDCMP при общении с Saeco Cristallo 600 v0.13
typedef enum ddcmp_saeco_fix_e {
  EVADTS_DDCMP_FIX_SAECO_OFF              = 0x00, ///< Выключить костыли для Saeco
  EVADTS_DDCMP_FIX_SAECO_ON_TIMEOUT       = 0x01, ///< Включить костыли для Saeco
  EVADTS_DDCMP_FIX_SAECO_115200           = 0x02, ///< Включить максимальную скорость DDCMP
  EVADTS_DDCMP_FIX_JEDY_115200            = 0x03, ///< Включить максимальную скорость DDCMP с таймаутами неподтверждения (привет от JEDY)
  EVADTS_DDCMP_FIX_SAECO_OFF_NAK_TIMEOUT  = 0x04, ///< Включить таймаут неподтверждения (привет от JEDY), аналогично 00, но NAK формирует тишиной.
  EVADTS_DDCMP_FIX_end                    = EVADTS_DDCMP_FIX_SAECO_OFF_NAK_TIMEOUT,
} ddcmp_saeco_fix_t;

/// \brief Типы возможных сенсоров, подключенных к плате.
typedef enum sensor_type_e {
    SENSOR_OFF=VALUE_OFF,
    SENSOR_ON=VALUE_ON,
    SENSOR_POL,
    SENSOR_INV,
    SENSOR_OPT_POL,
    SENSOR_OPT_INV,
    SENSOR_OPEN,
    SENSOR_CLOSE,
    SENSOR_NOTINSTALL,
    SENSOR_PLUGIN,
    SENSOR_UNKNOW=UNKNOWN_VALUE
} sensor_type_t;


/// \brief Описатель URL к сервису на сервере
typedef struct url_s {
  char                address[30];
  char                directory[30];
  uint16_t            port;
  uint16_t            unused;           ///< Зарезервировано, например, для типа протокола: HTTP/HTTPS/...
} url_t;

/// \brief Настройки сервера
typedef struct server_params_s {
  uint16_t            ping_interval_s;
  url_t               url;
} server_params_t;

/// \brief Настройки планировщика
typedef struct sched_params_s {
  uint16_t            schedule[64];
} sched_params_t;


/// \ingroup settings settings_aux
/// \brief Настройки DDCMP порта
typedef struct ddcmp_params_s {
  ddcmp_mode_t      ddcmp_mode;         ///< режим работы DDCMP
  ddcmp_extspeed_t  ddcmp_extended;     ///< настройка расширенного режима работы (стандартный DDCMP)
  ddcmp_auditmode_t ddcmp_auditmode;    ///< тип запроса аудита (просто аудит или аудит+настройки)
  ddcmp_fix_baud_t  ddcmp_fix_baud;     ///< скорость работы в фиксированном режиме
  ddcmp_saeco_fix_t ddcmp_saeco_fix;    ///< включени режима обработки кривой реализации DDCMP аппарата Saeco Cristallo 600 v0.13
} ddcmp_params_t;


/// \ingroup settings settings_aux
/// \brief Настройки AUX порта.
typedef struct aux_params_s {
  aux_type_t          type;
  aux_interface_t     interface;
  aux_idlestate_t     idlestate;
  ddcmp_params_t      ddcmp_params;
} aux_params_t;

/// \brief структура настроек внешних датчиков
typedef struct sensor_params_s {
  onoff_t       on;                     ///< включить обрабтку внешнего датчика
  sensor_type_t type;                   ///< тип датчика (прямой, инверсный, оптический и т.д.)
} sensor_params_t;


/// \brief Настройки
typedef struct printer_params_s {
  uint16_t            printer_tcp_port;
  int                 printer_psw;
} printer_params_t;

/// \brief Настройки шины MDB/EXE
typedef struct mdbexe_params_s {
  mdbexe_bus_t        bus;
  onoff_t             MDB_EXE_log;                  // включает поток дебаговой информации
  onoff_t             bus_autodetect;
  uint32_t            error_timeout_ms;
} mdbexe_params_t;


/// \brief Структура, хранящая все настройки устройства.
///
/// \warning Внимание, если необходимо что-либо здесь изменить,
/// то следует добавлять поля в конец, иначе текущие настройки, хранящиеся во
/// флеш, будут неправильно интерпретированы.
///
/// \todo  Переделать хранение данной структуры на использование одной из библиотек
/// сериализации данных (например, protobuf), что бы избежать в дальнейшем конфликтов
/// при изменении формата или количества хранимых данных.
typedef struct fw_params_s {
  server_params_t     server;
  sched_params_t      schedule;
  mdbexe_params_t     mdbexe;
  aux_params_t        aux[MAX_AUX_PORTS];
  sensor_params_t     sensor[MAX_SENSORS];
  printer_params_t    printer;
  onoff_t             sensors_on;
  onoff_t             evadts_search;
  onoff_t             request_evadts_after_mdb_change;
  onoff_t             sms_raw;
  onoff_t             sms;
  onoff_t             beep;
  onoff_t             send_vend;
  onoff_t             encrypt;
  onoff_t             cell_locate;
  onoff_t             send_csq;
  onoff_t             punch_detect;
  uint16_t            door_time_s;
} fw_params_t;

/// \brief Структура, хранящая настройки точки доступа GSM сети
///
/// Данная структура используется совместно загрузчиком и основным ПО.
typedef struct apn_params_s {
  char      APN[APN_SIZE];
  char      user_apn[APN_USER_SIZE];
  char      psw_apn[APN_PSW_SIZE];
} apn_params_t;


/// \brief Формат заголовка, записываемого перед всеми настройками в файл.
typedef struct params_header_s {
  uint16_t            crc;          ///< Контрольная сумма данных
  uint16_t            size;         ///< Размер данных в байтах
  uint16_t            reserved;     ///< Не используется, должно быть равно 0
  uint16_t            header_chk;   ///< контрольная сумма для этого заголовка (crc ^ size ^ version)
} params_header_t;


/// \brief Менеджер настроек
typedef struct settings_s {
  fw_params_t         fw_params;            ///< Основные настройки
  apn_params_t        apn_params;           ///< Настройки APN
  uint32_t            fw_params_version;    ///< Счётчик изменений основных настроек
  uint32_t            apn_params_version;   ///< Счётчик изменений настроек APN
  uint32_t            version;              ///< Общий счётчик изменений настроек
  uint32_t            fw_params_vers_on_disk;   ///< Последняя записанная версия
  uint32_t            apn_params_vers_on_disk;  ///< Последняя записанная версия
} settings_t;

const server_params_t*    settings_get_server(const settings_t* settings);
const char*               settings_get_server_address(const settings_t* settings);
uint16_t                  settings_get_server_port(const settings_t* settings);
const char*               settings_get_server_path(const settings_t* settings);
uint16_t                  settings_get_server_ping_interval_s(const settings_t* settings);
const sched_params_t*     settings_get_schedule(const settings_t* settings);
const mdbexe_params_t*    settings_get_mdbexe(const settings_t* settings);
const aux_params_t*       settings_get_aux(const settings_t* settings, int n);
const sensor_params_t*    settings_get_sensor(const settings_t* settings, int n);
const printer_params_t*   settings_get_printer(const settings_t* settings);
const onoff_t*            settings_get_sensors_on(const settings_t* settings);
const onoff_t*            settings_get_evadts_search(const settings_t* settings);
const onoff_t*            settings_get_request_evadts_after_mdb_change(const settings_t* settings);
const onoff_t*            settings_get_sms_raw(const settings_t* settings);
const onoff_t*            settings_get_sms(const settings_t* settings);
const onoff_t*            settings_get_beep(const settings_t* settings);
const onoff_t*            settings_get_send_vend(const settings_t* settings);
const onoff_t*            settings_get_encrypt(const settings_t* settings);
const onoff_t*            settings_get_cell_locate(const settings_t* settings);
const onoff_t*            settings_get_send_csq(const settings_t* settings);
const onoff_t*            settings_get_punch_detect(const settings_t* settings);
const uint16_t*           settings_get_door_time_s(const settings_t* settings);

// Функции settings_set_xxx возвращают:
//  `-errno`  при ошибках,
//  `0`       если настройки не изменились
//  `1`       если настройки изменились

#define SETTINGS_NOT_CHANGED    0
#define SETTINGS_CHANGED        1

int settings_set_server(settings_t* settings, const server_params_t* server);
int settings_set_server_address(settings_t* settings, const char* address);
int settings_set_server_port(settings_t* settings, uint16_t port);
int settings_set_server_path(settings_t* settings, const char* path);
int settings_set_server_ping_interval_s(settings_t* settings, uint16_t ping_interval_s);
int settings_set_schedule(settings_t* settings, const sched_params_t* schedule);
int settings_set_mdbexe(settings_t* settings, const mdbexe_params_t* mdbexe);
int settings_set_mdbexe_bus(settings_t* settings, const mdbexe_bus_t* bus);
int settings_set_mdbexe_MDB_EXE_log(settings_t* settings, const onoff_t* MDB_EXE_log);
int settings_set_mdbexe_bus_autodetect(settings_t* settings, const onoff_t* bus_autodetect);
int settings_set_mdbexe_error_timeout_ms(settings_t* settings, const uint32_t* error_timeout_ms);
int settings_set_aux(settings_t* settings, int n, const aux_params_t* aux);
int settings_set_aux_type(settings_t* settings, int n, const aux_type_t* type);
int settings_set_aux_interface(settings_t* settings, int n, const aux_interface_t* interface);
int settings_set_aux_idlestate(settings_t* settings, int n, const aux_idlestate_t* idlestate);
int settings_set_sensor(settings_t* settings, int n, const sensor_params_t* sensor);
int settings_set_printer(settings_t* settings, const printer_params_t* printer);
int settings_set_sensors_on(settings_t* settings, const onoff_t* sensors_on);
int settings_set_evadts_search(settings_t* settings, const onoff_t* evadts_search);
int settings_set_request_evadts_after_mdb_change(settings_t* settings, const onoff_t* request_evadts_after_mdb_change);
int settings_set_sms_raw(settings_t* settings, const onoff_t* sms_raw);
int settings_set_sms(settings_t* settings, const onoff_t* sms);
int settings_set_beep(settings_t* settings, const onoff_t* beep);
int settings_set_send_vend(settings_t* settings, const onoff_t* send_vend);
int settings_set_encrypt(settings_t* settings, const onoff_t* encrypt);
int settings_set_cell_locate(settings_t* settings, const onoff_t* cell_locate);
int settings_set_send_csq(settings_t* settings, const onoff_t* send_csq);
int settings_set_punch_detect(settings_t* settings, const onoff_t* punch_detect);
int settings_set_door_time_s(settings_t* settings, const uint16_t* door_time_s);


const char*               settings_get_apn_name(const settings_t* settings);
const char*               settings_get_apn_user(const settings_t* settings);
const char*               settings_get_apn_pwd(const settings_t* settings);

int settings_set_apn_name(settings_t* settings, const char* apn_name);
int settings_set_apn_user(settings_t* settings, const char* apn_user);
int settings_set_apn_pwd(settings_t* settings, const char* apn_pwd);



uint32_t settings_get_fw_params_version(const settings_t* settings);
uint32_t settings_get_apn_params_version(const settings_t* settings);
uint32_t settings_get_fw_params_vers_on_disk(const settings_t* settings);
uint32_t settings_get_apn_params_vers_on_disk(const settings_t* settings);

int settings_create(settings_t* settings);
int settings_load_all(settings_t* settings);
int settings_load_fw_params(settings_t* settings);
int settings_load_apn_params(settings_t* settings);

int settings_default_all(settings_t* settings);
int settings_default_fw_params(settings_t* settings);
int settings_default_apn_params(settings_t* settings);

int settings_save_all(settings_t* settings);
int settings_save_fw_params(settings_t* settings);
int settings_save_apn_params(settings_t* settings);



// Преобразование в строку и обратно для перечислений.
//
// Все преобразования в строку возвращают указатель на INVALID_PARAM в случае ошибки.
// Все преобразования из строки возвращают отрицательный код ошибки или 0 в случае успеха.

extern const char INVALID_PARAM[];

const char* onoff_to_string(onoff_t value);
const char* mdbexe_bus_to_string(mdbexe_bus_t value);
const char* aux_interface_to_string(aux_interface_t value);
const char* aux_type_to_string(aux_type_t value);
const char* aux_idlestate_to_string(aux_idlestate_t value);
const char* ddcmp_mode_to_string(ddcmp_mode_t value);
const char* ddcmp_extspeed_to_string(ddcmp_extspeed_t value);
const char* ddcmp_auditmode_to_string(ddcmp_auditmode_t value);
const char* ddcmp_fix_baud_to_string(ddcmp_fix_baud_t value);
const char* ddcmp_saeco_fix_to_string(ddcmp_saeco_fix_t value);
const char* sensor_type_to_string(sensor_type_t value);

int onoff_parse(const char* text, onoff_t* result);
int mdbexe_bus_parse(const char* text, mdbexe_bus_t* result);
int aux_interface_parse(const char* text, aux_interface_t* result);
int aux_type_parse(const char* text, aux_type_t* result);
int aux_idlestate_parse(const char* text, aux_idlestate_t* result);
int ddcmp_mode_parse(const char* text, ddcmp_mode_t* result);
int ddcmp_extspeed_parse(const char* text, ddcmp_extspeed_t* result);
int ddcmp_auditmode_parse(const char* text, ddcmp_auditmode_t* result);
int ddcmp_fix_baud_parse(const char* text, ddcmp_fix_baud_t* result);
int ddcmp_saeco_fix_parse(const char* text, ddcmp_saeco_fix_t* result);
int sensor_type_parse(const char* text, sensor_type_t* result);

bool onoff_is_valid(onoff_t value);
bool mdbexe_bus_is_valid(mdbexe_bus_t value);
bool aux_interface_is_valid(aux_interface_t value);
bool aux_type_is_valid(aux_type_t value);
bool aux_idlestate_is_valid(aux_idlestate_t value);
bool ddcmp_mode_is_valid(ddcmp_mode_t value);
bool ddcmp_extspeed_is_valid(ddcmp_extspeed_t value);
bool ddcmp_auditmode_is_valid(ddcmp_auditmode_t value);
bool ddcmp_fix_baud_is_valid(ddcmp_fix_baud_t value);
bool ddcmp_saeco_fix_is_valid(ddcmp_saeco_fix_t value);
bool sensor_type_is_valid(sensor_type_t value);

bool onoff_equals(const onoff_t* a, const onoff_t* b);
bool mdbexe_bus_equals(const mdbexe_bus_t* a, const mdbexe_bus_t* b);
bool url_equals(const url_t* a, const url_t* b);
bool server_params_equals(const server_params_t* a, const server_params_t* b);
bool sched_params_equals(const sched_params_t* a, const sched_params_t* b);
bool ddcmp_params_equals(const ddcmp_params_t* a, const ddcmp_params_t* b);
bool aux_params_equals(const aux_params_t* a, const aux_params_t* b);
bool sensor_params_equals(const sensor_params_t* a, const sensor_params_t* b);
bool printer_params_equals(const printer_params_t* a, const printer_params_t* b);
bool mdbexe_params_equals(const mdbexe_params_t* a, const mdbexe_params_t* b);

#ifdef __cplusplus
} // extern "C"
#endif

/// @}

#endif // CONFIG_TELEMETRON_APPS_LIB_SETTINGS_INCLUDED
