/// \file
/// \brief  Очередь сообщений для использования в Telemetron Modem 3.0
/// \author DL <dmitriy@linikov.ru>

/// \defgroup fw_events События ПО, передаваемые через очередь сообщений eventq_t

#ifndef CONFIG_TELEMETRON_APPS_LIB_EVENTQ_INCLUDED
#define CONFIG_TELEMETRON_APPS_LIB_EVENTQ_INCLUDED

#include <nuttx/config.h>
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <time.h>

#if !defined(CONFIG_LIB_EVENTQ_BASEDIR) || defined(__DOXYGEN__)
/// \brief Папка, в которой следует хранить все очереди сообщений.
/// \note Обычно, задаётся через Kconfig
# define CONFIG_LIB_EVENTQ_BASEDIR          "/var/eq"
#endif



#if !defined(CONFIG_LIB_EVENTQ_MAX_PATH) || defined(__DOXYGEN__)
/// \brief Максимальное количество символов (без завершающего '\0') в пути к файлу очереди сообщений.
/// \note Обычно, задаётся через Kconfig
# define CONFIG_LIB_EVENTQ_MAX_PATH         19
#endif



#if !defined(CONFIG_LIB_EVENTQ_PAYLOAD_SIZE) || defined(__DOXYGEN__)
/// \brief Объем памяти, предварительно выделенный на тело каждого сообщения.
/// \note Обычно, задаётся через Kconfig
# define CONFIG_LIB_EVENTQ_PAYLOAD_SIZE     256
#endif



#if !defined(CONFIG_LIB_EVENTQ_EVENTS_COUNT) || defined(__DOXYGEN__)
/// \brief Максимальное количество сообщений, хранимых в очереди.
/// \note Обычно, задаётся через Kconfig
# define CONFIG_LIB_EVENTQ_EVENTS_COUNT       16
#endif


/// \brief  Создаёт событие типа \p event_type с идентификатором \p ID
///         в буффере \p buffer типа `eventq_event_t`
///
/// Данный макрос заменяет следующий кусок кода:
/// \code
/// void send_event(const specific_event_t* ev) {
///   // Буффер для хранения события
///   eventq_event_t    buffer;
///   specific_event_t* ev_in_buffer;
///
///   // Следующие 3 строчки можно заменить на `EVENTQ_CREATE_EVENT`:
///   eventq_init_event(&buffer, EV_ID_SPECIFIC_EVENT);
///   buffer.size = sizeof(specific_event_t);
///   ev_in_buffer = (specific_event_t)&buffer.data[0];
///
///   // Т.е. будет так:
///   ev_in_buffer = EVENTQ_CREATE_EVENT(&buffer, EV_ID_SPECIFIC_EVENT, specific_event_t);
/// }
/// \endcode
#define EVENTQ_CREATE_EVENT(buffer, id, event_type)     \
  ((event_type*)(eventq_init_event((buffer), (id)),     \
                ((buffer)->size = sizeof(event_type)),  \
                (buffer)->data))



/// \brief Структура предназначенная для хранения пути к файлам очереди сообщений.
typedef struct eventq_path_s {
  char                value[CONFIG_LIB_EVENTQ_MAX_PATH+1];
} eventq_path_t;



/// \brief Отдельное событие из очереди.
typedef struct eventq_event_s {
  int                 id;     ///< Тип события
  size_t              size;   ///< Размер данных
  struct timespec     time;   ///< Время добавления события
  uint8_t             data[CONFIG_LIB_EVENTQ_PAYLOAD_SIZE]; ///< Данные
} eventq_event_t;



/// \brief Очередь сообщений, работающая через FIFO pipe
typedef struct eventq_s {
  eventq_path_t       path;   ///< Путь к файлу FIFO
  int                 fd;     ///< Файловый дескриптор открытого FIFO
} eventq_t;


#ifdef __cplusplus
extern "C" {
#endif

int eventq_init(eventq_t* q);
int eventq_open(eventq_t* q, const char* name, int flags);
int eventq_close(eventq_t* q);
int eventq_write(eventq_t* q, int event, const void* data, size_t size);
int eventq_write_ex(eventq_t* q, const eventq_event_t* event);
int eventq_pollfd(eventq_t* q);
int eventq_waittx(eventq_t* q, int timeout_ms);
int eventq_waitrx(eventq_t* q, int timeout_ms);
int eventq_read(eventq_t* q, eventq_event_t* event);
int eventq_read_timeout(eventq_t* q, eventq_event_t* event, int timeout_ms);

int eventq_init_event(eventq_event_t* dst, int id);

int eventq_get_capacity(eventq_t* q);
int eventq_get_unread_count(eventq_t* q);
int eventq_get_free_count(eventq_t* q);
bool eventq_is_opened(eventq_t* q);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // CONFIG_TELEMETRON_APPS_LIB_EVENTQ_INCLUDED
