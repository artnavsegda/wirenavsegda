/// \file
/// \brief  Описание публичного API для библиотеки lib_ppp, основанной на LwIP-PPP
/// \author DL <dmitriy@linikov.ru>
///
/// Модуль PPP работает как конечный автомат.
/// Для сигнализации событий для внешнего кода есть набор колбэков.

#ifndef TELEMETRON_APPS_INCLUDE_PPP_LIBPPP_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_PPP_LIBPPP_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


// =========================================================================
//    Настройки библиотеки ppp

#if !defined(CONFIG_LIB_PPP_MAX_INSTANCE) || defined(__DOXYGEN__)
/// \brief  Количество одновременных PPP соединений.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_PPP_MAX_INSTANCE        2
#endif

#if !defined(CONFIG_LIB_PPP_NAT_ENTRIES) || defined(__DOXYGEN__)
/// \brief  Общее количество предварительно выделенных NAT записей для соединений.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_PPP_NAT_ENTRIES         16
#endif

#if !defined(CONFIG_LIB_PPP_NAT_ENTRIES_TTL_S) || defined(__DOXYGEN__)
/// \brief  Время жизни NAT записей в секундах.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_PPP_NAT_ENTRIES_TTL_S   300
#endif

#if !defined(CONFIG_LIB_PPP_POLL_TIMEOUT_MS) || defined(__DOXYGEN__)
/// \brief  Время ожидания (в миллисекундах) данных в туннеле или порте ввода-вывода
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_PPP_POLL_TIMEOUT_MS     200
#endif


// только для документации
#if !defined(CONFIG_LIB_PPP_DEBUG_PRINT_IP_PACKETS) && defined(__DOXYGEN__)
/// \brief  Параметр для отладки, Нужно ли выводить в лог содержимое ip пакетов.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_PPP_DEBUG_PRINT_IP_PACKETS    y
#endif

// только для документации
#if !defined(CONFIG_LIB_PPP_DEBUG_PRINT_STREAM) && defined(__DOXYGEN__)
/// \brief  Параметр для отладки, Нужно ли выводить в лог сырые данные канала связи.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_PPP_DEBUG_PRINT_STREAM    y
#endif


// =========================================================================
//    Настройки отладочного вывода

#ifdef CONFIG_LIB_PPP_DEBUG_ERROR
#   define libppp_error(format, ...) _err(format, ##__VA_ARGS__)
#else
#   define libppp_error(x...)
#endif

#ifdef CONFIG_LIB_PPP_DEBUG_WARN
#   define libppp_warn(format, ...) _warn(format, ##__VA_ARGS__)
#else
#   define libppp_warn(x...)
#endif

#ifdef CONFIG_LIB_PPP_DEBUG_INFO
#   define libppp_info(format, ...) _info(format, ##__VA_ARGS__)
#else
#   define libppp_info(x...)
#endif

#ifdef CONFIG_LIB_PPP_DEBUG_TRACE
#   define libppp_trace(format, ...) _info(format, ##__VA_ARGS__)
#   define libppp_dump(msg, buf, sz) infodumpbuffer((msg), (const uint8_t*)(buf), (sz))
#else
#   define libppp_trace(x...)
#   define libppp_dump(msg, buf, sz)
#endif

#ifdef CONFIG_LIB_PPP_DEBUG_PRINT_IP_PACKETS
#   define libppp_ip_trace(format, ...) _info(format, ##__VA_ARGS__)
#   define libppp_ip_dump(msg, buf, sz) infodumpbuffer((msg), (const uint8_t*)(buf), (sz))
#else
#   define libppp_ip_trace(x...)
#   define libppp_ip_dump(msg, buf, sz)
#endif

#ifdef CONFIG_LIB_PPP_DEBUG_PRINT_STREAM
#   define libppp_stream_trace(format, ...) _info(format, ##__VA_ARGS__)
#   define libppp_stream_dump(msg, buf, sz) infodumpbuffer((msg), (const uint8_t*)(buf), (sz))
#else
#   define libppp_stream_trace(x...)
#   define libppp_stream_dump(msg, buf, sz)
#endif



// =========================================================================
//    Проверка допустимости настроек

#if (CONFIG_LIB_PPP_MAX_INSTANCE > CONFIG_TUN_NINTERFACES)
// Каждый PPP сеанс использует отдельный tun интерфейс.
// Необходимо увеличить количество tun сетевых адаптеров в настройках NuttX.
#error Not enough 'tun' interfaces to create CONFIG_LIB_PPP_MAX_INSTANCE ppp sessions.
#endif


////////////////////////////////////////////////////////////////////////////
//  Типы данных

// Тип экземпляра модуля ppp.
// Скрытый тип, создание и удаление происходят внутри модуля.
struct libppp_s;

typedef struct libppp_s  libppp_t;

/// \brief Тип аутентификации, может быть использован как битмаска.
typedef enum {
  LIBPPP_AUTHTYPE_NONE      = 0x00,   ///< Без аутентификаци
  LIBPPP_AUTHTYPE_PAP       = 0x01,   ///< Использовать PAP аутентификацию
  LIBPPP_AUTHTYPE_CHAP      = 0x02,   ///< Использовать CHAP аутентификацию
  LIBPPP_AUTHTYPE_MSCHAP    = 0x04,   ///< Использовать MSCHAP аутентификацию
  LIBPPP_AUTHTYPE_MSCHAP_V2 = 0x08,   ///< Использовать MSCHAP_V2 аутентификацию
  LIBPPP_AUTHTYPE_EAP       = 0x10,   ///< Использовать EAP аутентификацию
  LIBPPP_AUTHTYPE_ANY       = 0xff,   ///< Использовать любой метод аутентификации
} libppp_authtype_t;

/// \brief Перечень состояний конечного автомата PPP связи.
///
/// \note Данные состояния просто скопированы из lwip/netif/ppp/ppp.h
/// и переименованы (что бы избежать коллизии имён).
typedef enum {
  LIBPPP_PHASE_DEAD         = 0,
  LIBPPP_PHASE_MASTER       = 1,
  LIBPPP_PHASE_HOLDOFF      = 2,
  LIBPPP_PHASE_INITIALIZE   = 3,
  LIBPPP_PHASE_SERIALCONN   = 4,
  LIBPPP_PHASE_DORMANT      = 5,
  LIBPPP_PHASE_ESTABLISH    = 6,
  LIBPPP_PHASE_AUTHENTICATE = 7,
  LIBPPP_PHASE_CALLBACK     = 8,
  LIBPPP_PHASE_NETWORK      = 9,
  LIBPPP_PHASE_RUNNING      = 10,
  LIBPPP_PHASE_TERMINATE    = 11,
  LIBPPP_PHASE_DISCONNECT   = 12,
} libppp_phase_t;


/// \brief Перечень возможных ошибок при установке PPP связи
///
/// \note Данные состояния просто скопированы из lwip/netif/ppp/ppp.h
/// и переименованы (что бы избежать коллизии имён).
typedef enum {
  LIBPPP_ERR_NONE           = 0,    ///< No error.
  LIBPPP_ERR_PARAM          = 1,    ///< Invalid parameter.
  LIBPPP_ERR_OPEN           = 2,    ///< Unable to open PPP session.
  LIBPPP_ERR_DEVICE         = 3,    ///< Invalid I/O device for PPP.
  LIBPPP_ERR_ALLOC          = 4,    ///< Unable to allocate resources.
  LIBPPP_ERR_USER           = 5,    ///< User interrupt.
  LIBPPP_ERR_CONNECT        = 6,    ///< Connection lost.
  LIBPPP_ERR_AUTHFAIL       = 7,    ///< Failed authentication challenge.
  LIBPPP_ERR_PROTOCOL       = 8,    ///< Failed to meet protocol.
  LIBPPP_ERR_PEERDEAD       = 9,    ///< Connection timeout
  LIBPPP_ERR_IDLETIMEOUT    = 10,   ///< Idle Timeout
  LIBPPP_ERR_CONNECTTIME    = 11,   ///< Max connect time reached
  LIBPPP_ERR_LOOPBACK       = 12,   ///< Loopback detected
} libppp_err_t;

// предварительное объявление
struct in_addr;
struct sockaddr;

/// \brief Перечень всех callback-ов модуля ppp.
struct libppp_cb_s {

  /// \brief Записывает \p bufsz байт из буффера \p buf в поток,
  /// через который должен общаться PPP модуль.
  ///
  /// \warning Это поле обязательно должно быть установлено.
  ssize_t         (*write)(void* arg, const void* buf, size_t bufsz);

  /// \brief Читает в буффер \p buf до bufsz байт из потока,
  /// через который должен общаться PPP модуль.
  /// \warning Если данных нет, то данная функция должна возвращать 0, а не -EAGAIN.
  /// \warning Если произошла ошибка, данная функция должна возвращать код ошибки (-errno)
  ///
  /// \warning Это поле обязательно должно быть установлено.
  ssize_t         (*read)(void* arg, void* buf, size_t bufsz);

  /// \brief Записывает файловый дескриптор, используя который можно ожидать данные
  /// из потока общения PPP модуля.
  ///
  /// \note Даннная функция использует `struct file*`, которая существует только в NuttX.
  /// При портировании необходимо будет придумать более общий вариант.
  ///
  /// \warning Это поле обязательно должно быть установлено.
  ///
  /// \return 0 в случае успеха или отрицательный код ошибки (-errno).
  int             (*get_stream_file)(void* arg, struct file** dst);

  /// \brief  callback, вызываемый при получении адреса dns сервера.
  /// \param  arg       Значение cb_arg
  /// \param  id        Номер dns сервера: 0=Первичный, 1=Вторичный.
  /// \param  addr      Адрес dns сервера (по факту типа sockaddr_in)
  /// \param  addrlen   Размер переменной, на которую указывает \p addr.
  void            (*set_dns)(void* arg, uint8_t id, const struct sockaddr* addr, socklen_t addrlen);

  /// \brief  callback, вызываемый при необходимости очистить dns адреса
  void            (*clr_dns)(void* arg);

  /// \brief  callback, вызываемый при завершении инициализации связи
  ///         для того, что бы была возможность настроить маршрутизацию.
  ///
  /// \note   В момент вызова сетевой адаптер туннеля уже имеет адрес.
  void            (*on_ifup)( void* arg,
                              const struct in_addr* ouraddr,
                              const struct in_addr* gateway,
                              const struct in_addr* mask);

  /// \brief  callback, вызываемый при разрыве связи для того,
  ///         что бы была возможность очистить таблици маршрутизации.
  ///
  /// \note   В момент вызова сетевой адаптер туннеля уже в состоянии ifdown.
  void            (*on_ifdown)(void* arg);

  /// \brief  callback, вызываемый из обработчика ppp_link_status_cb
  ///
  /// \note Данный обработчик следует использовать, например, для
  /// индикации. Нежелательно изменять состояние pppd из этого обработчика.
  void            (*on_ppp_link_status)(void* arg, libppp_err_t status);

  /// \brief  callback, вызываемый при изменении состояния конечного автомата ppp.
  void            (*on_ppp_phase)(void* arg, libppp_phase_t phase);
};


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int libppp_create(
  void*       cb_arg,
  const struct libppp_cb_s* callbacks,
  char*       tunfmt,
  bool        use_nat,
  libppp_t**  result
);

void  libppp_destroy(libppp_t* libppp);
void  libppp_set_auth(libppp_t* libppp, libppp_authtype_t authtype, const char *user, const char *passwd);
void  libppp_set_auth_required(libppp_t* libppp, bool required);
void  libppp_set_ouraddr(libppp_t* libppp, const struct in_addr* addr);
void  libppp_set_hisaddr(libppp_t* libppp, const struct in_addr* addr);
void  libppp_set_dnsaddr(libppp_t* libppp, uint8_t index, const struct in_addr* addr);
void  libppp_set_usepeerdns(libppp_t* libppp, bool usepeerdns);
void  libppp_set_forcepeerdns(libppp_t* libppp, bool forcepeerdns);
void  libppp_set_listen_time(libppp_t* libppp, uint16_t listen_time_ms);
void  libppp_set_passive(libppp_t* libppp, bool passive);
void  libppp_set_silent(libppp_t* libppp, bool silent);
void  libppp_set_neg_pcomp(libppp_t* libppp, bool neg_pcomp);
void  libppp_set_neg_accomp(libppp_t* libppp, bool neg_accomp);
void  libppp_set_neg_asyncmap(libppp_t* libppp, bool neg_asyncmap);
void  libppp_set_asyncmap(libppp_t* libppp, uint32_t asyncmap);
int   libppp_connect(libppp_t* libppp, uint16_t holdoff_seconds);
int   libppp_listen(libppp_t* libppp);
void  libppp_close(libppp_t* libppp, bool emergency);

const char*     libppp_err_to_string(libppp_err_t value);
const char*     libppp_err_to_description(libppp_err_t value);
const char*     libppp_get_tunname(libppp_t* libppp);
int             libppp_get_tunfd(libppp_t* libppp);
libppp_phase_t  libppp_get_phase(libppp_t* libppp);

int             libppp_process(libppp_t* libppp);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_INCLUDE_PPP_LIBPPP_H_INCLUDED
