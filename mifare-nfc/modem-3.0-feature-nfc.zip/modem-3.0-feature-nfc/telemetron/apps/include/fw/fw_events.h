/// \file   fw_events.h
/// \brief  Перечень внутренних событий программы FW.
/// \author DL <dmitriy@linikov.ru>



#ifndef TELEMETRON_APPS_FW_FW_EVENTS_H_INCLUDED
#define TELEMETRON_APPS_FW_FW_EVENTS_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <time.h>
#include "power_state.h"

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

// =========================================================================
//    Основные события ПО

/// \brief Начальный номер для основных событий ПО модема.
#define EV_FW_BASE              0x0000

/// \ingroup fw_events
/// \brief Уведомление, что изменились настройки.
///
/// Данное сообщение обязательно отправляется перед EV_START, так что
/// загружать настройки внутри обработчиков EV_START не нужно.
///
/// Далее при каждом изменении настроек в очередь отправляется событие
/// EV_CONFIGURE.
///
/// Данное сообщение всегда содержит вложение типа ev_settings_t
///
/// \warning Данное сообщение предназначено для передачи события изменения
/// настроек только внутри процесса FW, т.к. содержит прямые указатели
/// на данные настроек. Для отладочной проверки, что сообщение пришло
/// от текущего процесса служит поле sender_pid.
#define EV_CONFIGURE            (EV_FW_BASE + 0)

/// \ingroup fw_events
/// \brief Инициализация завершена, запуск всех модулей.
///
/// Содержит вложение типа ev_start_t
#define EV_START                (EV_FW_BASE + 1)

/// \ingroup fw_events
/// \brief Команда остановить все модули (например, перед сном).
///
/// Вложенные данные отсутствуют.
#define EV_STOP                 (EV_FW_BASE + 2)

/// \ingroup fw_events
/// \brief Периодические события таймера (период порядка 0.1-1 секунды)
///
/// Данное сообщение всегда содержит вложение типа \ref ev_timer_t.
///
/// Другие модули могут использовать данное событие, например,
/// для периодической проверки своего состояния.
#define EV_TIMER                (EV_FW_BASE + 3)

/// \ingroup fw_events
/// \brief Уведомления об изменении режима питания, о переходе в сон.
///
/// Данное сообщение всегда содержит вложение типа \ref ev_power_t
#define EV_POWER                (EV_FW_BASE + 4)


/// \ingroup fw_events
/// \brief Команда перезагрузиться
///
/// Вложенные данные отсутствуют.
#define EV_REBOOT               (EV_FW_BASE + 5)



// =========================================================================
//    События модуля кнопок

/// \brief Начальный номер для событий от модуля кнопок
#define EV_BTN_BASE             0x0010

/// \ingroup fw_events
/// \brief Событие нажатия кнопки
///
/// Данное событие всегда содержит вложение типа \ref button_event_t.
#define EV_BTN_PRESSED          (EV_BTN_BASE + 0)

/// \ingroup fw_events
/// \brief Событие отпускания кнопки.
///
/// Данное событие всегда содержит вложение типа \ref button_event_t.
#define EV_BTN_RELEASED         (EV_BTN_BASE + 1)





// =========================================================================
//    События модуля датчиков дверей

/// \brief Начальнй номер для событий от модуля датчиков дверей.
#define EV_DOOR_BASE             0x0012

/// \ingroup fw_events
/// \brief Событие активации датчика дверей
///
/// Данное событие всегда содержит вложение типа \ref door_event_t.
#define EV_DOOR_ACTIVATED        (EV_DOOR_BASE + 0)

/// \ingroup fw_events
/// \brief Событие деактивации датчика дверей
///
/// Данное событие всегда содержит вложение типа \ref door_event_t.
#define EV_DOOR_DEACTIVATED      (EV_DOOR_BASE + 1)



////////////////////////////////////////////////////////////////////////////
//  Типы данных

/// \brief  Данные, прикладываемые к событию EV_TIMER
typedef struct ev_timer_s {
  struct timespec           now;              ///< Текущее время.
} ev_timer_t;


/// \brief  Данные, прикладываемые к событию EV_CONFIGURE
///
/// \warning Данное сообщение предназначено для передачи события изменения
/// настроек только внутри процесса FW, т.к. содержит прямые указатели
/// на данные настроек. Для отладочной проверки, что сообщение пришло
/// от текущего процесса служит поле sender_pid.
typedef struct ev_configure_s {
  int                             sender_pid;       ///< pid процесса отправителя
  const struct settings_s*        settings;         ///< менеджер настроек
} ev_configure_t;

/// \brief  Данные, прикладываемые к событиям EV_BTN_PRESSED и EV_BTN_RELEASED
struct button_event_s {
  size_t            button_id;
};
typedef struct button_event_s   button_event_t;


/// \brief Данные, прикладываемые к событиям EV_DOOR_ACTIVATED и EV_DOOR_DEACTIVATED
typedef struct door_event_s {
  size_t            door_id;
} door_event_t;

/// \brief Данные, прикладываемые к событияю EV_START
typedef struct ev_start_s {
  uint32_t          csr_value;
  const char*       reset_reason;
} ev_start_t;

/// \brief Данные, прикладываемые к событию EV_POWER
typedef struct ev_power_s {
  power_state_t     state;
} ev_power_t;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_FW_FW_EVENTS_H_INCLUDED
