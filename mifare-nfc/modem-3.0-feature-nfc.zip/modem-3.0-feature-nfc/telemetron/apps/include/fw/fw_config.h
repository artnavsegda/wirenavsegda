/// \file
/// \brief  Настройки времени компиляции для приложения `fw`.
/// \author DL <dmitriy@linikov.ru>

#ifndef TELEMETRON_APPS_FW_FW_CONFIG_H_INCLUDED
#define TELEMETRON_APPS_FW_FW_CONFIG_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <nuttx/config.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

#if !defined(CONFIG_TELEMETRON_FW_EVENTQ_NAME) || defined(__DOXYGEN__)
/// \brief  Имя основной очереди событий.
///
/// Имя должно начинаться на символ '/', например, "/eventq".
///
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_EVENTQ_NAME     "/eventq"
#endif

#if !defined(CONFIG_TELEMETRON_FW_SRVD_QUEUE_NAME) || defined(__DOXYGEN__)
/// \brief  Имя очереди файлов, передаваемых устройством на сервер.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_SRVD_QUEUE_NAME "/sq"
#endif


#if !defined(CONFIG_TELEMETRON_FW_SRVD_LOWPRIO_DIR) || defined(__DOXYGEN__)
/// \brief  Путь к директории, хранящей сообщения на сервер с низким приоритетом
///
/// Обычно такие сообщения хранятся во флеш памяти.
///
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_SRVD_LOWPRIO_DIR  "/mnt/storage/sq0"
#endif


#if !defined(CONFIG_TELEMETRON_FW_FLOW3_FILE_PATH) || defined(__DOXYGEN__)
/// \brief  Имя файла, хранящего текущие параметры системы (т.н. "третий поток")
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_FLOW3_FILE_PATH "/tmp/flow3"
#endif

#if !defined(CONFIG_TELEMETRON_FW_BTN_PATH) || defined(__DOXYGEN__)
/// \brief  Путь к файлу драйвера кнопок.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_BTN_PATH        "/dev/buttons"
#endif

#if !defined(CONFIG_TELEMETRON_FW_DOORS_PATH) || defined(__DOXYGEN__)
/// \brief  Путь к файлу драйвера концевых датчиков дверей.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_DOORS_PATH      "/dev/doors"
#endif

#if !defined(CONFIG_TELEMETRON_FW_MDBMASTER_PATH) || defined(__DOXYGEN__)
/// \brief  Путь к файлу драйвера ведущего MDB/EXE порта (MASTER -> SLAVES)
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_MDBMASTER_PATH  "/dev/ttymdb1"
#endif

#if !defined(CONFIG_TELEMETRON_FW_MDBSLAVE_PATH) || defined(__DOXYGEN__)
/// \brief  Путь к файлу драйвера ведомого MDB/EXE порта (SLAVES -> MASTER)
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_MDBSLAVE_PATH   "/dev/ttymdb2"
#endif

#if !defined(CONFIG_TELEMETRON_FW_AUX1_PATH) || defined(__DOXYGEN__)
/// \brief  Путь к файлу драйвера порта AUX1
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_AUX1_PATH       "/dev/ttyaux1"
#endif

#if !defined(CONFIG_TELEMETRON_FW_AUX2_PATH) || defined(__DOXYGEN__)
/// \brief  Путь к файлу драйвера порта AUX2
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_AUX2_PATH       "/dev/ttyaux2"
#endif

#if !defined(CONFIG_TELEMETRON_FW_AUX3_PATH) || defined(__DOXYGEN__)
/// \brief  Путь к файлу драйвера порта AUX3
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_AUX3_PATH       "/dev/ttyaux3"
#endif

#if !defined(CONFIG_TELEMETRON_FW_AUDIT1_REPORT_PATH) || defined(__DOXYGEN__)
/// \brief  Путь к файлу со снятым отчётом аудита для порта AUX1
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_AUDIT1_REPORT_PATH    "/tmp/audit1"
#endif

#if !defined(CONFIG_TELEMETRON_FW_AUDIT2_REPORT_PATH) || defined(__DOXYGEN__)
/// \brief  Путь к файлу со снятым отчётом аудита для порта AUX2
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_AUDIT2_REPORT_PATH    "/tmp/audit2"
#endif

#if !defined(CONFIG_TELEMETRON_FW_AUDIT3_REPORT_PATH) || defined(__DOXYGEN__)
/// \brief  Путь к файлу со снятым отчётом аудита для порта AUX3
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_AUDIT3_REPORT_PATH    "/tmp/audit3"
#endif

#if !defined(CONFIG_TELEMETRON_FW_GSM_DRIVER_PATH) || defined(__DOXYGEN__)
/// \brief  Путь к драйверу gsm модема.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_GSM_DRIVER_PATH "/dev/gsm0"
#endif

#if !defined(CONFIG_TELEMETRON_FW_TTY_PPP_PATH) || defined(__DOXYGEN__)
/// \brief  Путь к драйверу порта модема, через который поднимать PPP сессию
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_TTY_PPP_PATH    "/dev/ttygsm01"
#endif

#if !defined(CONFIG_TELEMETRON_FW_TTY_SMS_PATH) || defined(__DOXYGEN__)
/// \brief  Путь к драйверу порта модема, через который получать sms сообщения
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_TTY_SMS_PATH    "/dev/ttygsm02"
#endif

#if !defined(CONFIG_TELEMETRON_FW_TTY_GSM_PATH) || defined(__DOXYGEN__)
/// \brief  Путь к драйверу порта модема для второстепенных запросов.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_TTY_GSM_PATH    "/dev/ttygsm03"
#endif

#if !defined(CONFIG_TELEMETRON_FW_ADC_VIN_PATH) || defined(__DOXYGEN__)
/// \brief  Путь к драйверу, хранящему текущее значение входного напряжения
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_ADC_VIN_PATH    "/adc/vin"
#endif

#if !defined(CONFIG_TELEMETRON_FW_ADC_MCUTEMP_PATH) || defined(__DOXYGEN__)
/// \brief  Путь к драйверу, измеряющему текущую температуру микроконтроллера
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_ADC_MCUTEMP_PATH    "/adc/mcutemp"
#endif





#if !defined(CONFIG_TELEMETRON_FW_TIMER_FAST_MS) || defined(__DOXYGEN__)
/// \brief  Период самого быстрого из используемых таймера (период порядка 1 .. 100 мс)
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_TIMER_FAST_MS   25
#endif

#if !defined(CONFIG_TELEMETRON_FW_TIMER_MEDIUM_MS) || defined(__DOXYGEN__)
/// \brief  Период среднего по продолжительности таймера (период порядка 0.1 .. 1 секунды)
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_TIMER_MEDIUM_MS 100
#endif

#if !defined(CONFIG_TELEMETRON_FW_MAX_BUTTONS) || defined(__DOXYGEN__)
/// \brief  Максимально поддерживаемое количество кнопок
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_MAX_BUTTONS     3
#endif

#if !defined(CONFIG_TELEMETRON_FW_VMCD_RAWLOG_SIZE) || defined(__DOXYGEN__)
/// \brief  Максимальный размер сырого лога из MDB/EXE порта
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_VMCD_RAWLOG_SIZE    512
#endif

#if !defined(CONFIG_TELEMETRON_FW_AUDIT_TIMEOUT_MS) || defined(__DOXYGEN__)
/// \brief  Максимальное время снятия отчёта аудита
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_AUDIT_TIMEOUT_MS    120000
#endif

#if !defined(CONFIG_TELEMETRON_FW_SRVD_TRANSACTION_TIMEOUT_MS) || defined(__DOXYGEN__)
/// \brief  Максимальное время для получения одной транзакции от сервера
///
/// Поскольку информация о том, что сервис srvd начал и закончил обрабатывать
/// ответ сервера передаётся через очередь сообщений конечного размера,
/// то возможны ситуации, когда событие завершения транзакции будет потеряно.
/// А поскольку в обработчике события завершения транзакции основной код
/// отправляет ответ на команды настроек, то потеря данного события крайне
/// нежелательна.
///
/// Поэтому добавлен таймаут, обрабатываемый из событий таймера.
/// Если с момента начала транзакции прошло больше времени, чем задаётся
/// данным параметром. то программа обрабатывает такое событие таймера так же,
/// как событие завершения транзакции.
///
/// Соответственно, косвенно данный параметр устанавливает время до первого
/// ответа на сервер, если обработка команд затягивается.
///
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_SRVD_TRANSACTION_TIMEOUT_MS    1000
#endif

#if !defined(CONFIG_TELEMETRON_FW_SERVICE_TERMINATE_TIMEOUT_MS) || defined(__DOXYGEN__)
/// \brief  Стандартное время ожидания завершения используемых сервисов.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_TELEMETRON_FW_SERVICE_TERMINATE_TIMEOUT_MS   5000
#endif

////////////////////////////////////////////////////////////////////////////
//  Отладочные настройки. Для использования необходимо #include <debug.h>

#ifdef CONFIG_TELEMETRON_FW_DEBUG_ERROR
#   define fw_error(format, ...) _err("FW:" format, ##__VA_ARGS__)
#else
#   define fw_error(x...)
#endif

#ifdef CONFIG_TELEMETRON_FW_DEBUG_WARN
#   define fw_warn(format, ...) _warn("FW:" format, ##__VA_ARGS__)
#else
#   define fw_warn(x...)
#endif

#ifdef CONFIG_TELEMETRON_FW_DEBUG_INFO
#   define fw_info(format, ...) _info("FW:" format, ##__VA_ARGS__)
#else
#   define fw_info(x...)
#endif

#ifdef CONFIG_TELEMETRON_FW_DEBUG_DEBUG
#   define fw_debug(format, ...) _info("FW:" format, ##__VA_ARGS__)
#   define fw_debugdump(msg, buf, sz) infodumpbuffer(("FW:" msg), (const uint8_t*)(buf), (sz))
#else
#   define fw_debug(x...)
#   define fw_debugdump(msg, buf, sz)
#endif

#ifdef CONFIG_TELEMETRON_FW_DEBUG_TRACE
#   define fw_trace(format, ...) _info("FW:" format, ##__VA_ARGS__)
#   define fw_dump(msg, buf, sz) infodumpbuffer(("FW:" msg), (const uint8_t*)(buf), (sz))
#else
#   define fw_trace(x...)
#   define fw_dump(msg, buf, sz)
#endif


////////////////////////////////////////////////////////////////////////////
//  Типы данных


#ifdef __cplusplus
extern "C" {
#endif

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_FW_FW_CONFIG_H_INCLUDED
