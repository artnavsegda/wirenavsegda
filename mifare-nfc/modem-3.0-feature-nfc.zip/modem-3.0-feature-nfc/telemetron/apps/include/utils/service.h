/// \file
/// \brief  Утилита для упрощения создания процессов в NuttX
/// \author DL <dmitriy@linikov.ru>


#ifndef TELEMETRON_APPS_INCLUDE_UTILS_THREAD_BASE_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_UTILS_THREAD_BASE_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <semaphore.h>
#include <unistd.h>

#include <nuttx/wdog.h>


////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

////////////////////////////////////////////////////////////////////////////
//  Типы данных
typedef struct service_s service_t;

/// \brief дескриптор сервиса.
///
/// \note Данная структура содержит 2 переменных с номером процесса: pid и
/// pid_on_enter. Они отличаются тем, что pid_on_enter заполняется в момент входа
/// в основную функцию сервиса, а pid заполняется в момент создания "процесса"
/// сервиса. Это позволяет определять ситуации, когда сервис был создан, но ещё
/// не вошёл в основную функцию.
struct service_s {
  // Первое поле - для глобальной регистрации в списке сервисов
  service_t*      flink;

  // настройки
  const char*     name;
  int             priority;
  int             stacksize;
  void*           arg;
  int             (*service_main)(void* arg);

  // состояние
  sem_t           lock;         ///< Семафор для монопольного доступа к объекту
  volatile int    pid;          ///< Номер процесса при создании процесса
  volatile int    pid_on_enter; ///< Номер процесса при входе в основную функцию
  volatile bool   starting;     ///< Сервис в процессе запуска
  volatile bool   should_stop;  ///< Сервис получил прерывание

  struct wdog_s   wdog;         ///< Сторожевой таймер
};



////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

// =========================================================================
//    Внешние функции

int   service_create(
  service_t* service,
  const char* name,
  int priority,
  int stacksize,
  int (*entry)(void* arg),
  void* arg
);
int   service_delete(service_t* service);
int   service_start(service_t* service);
int   service_kill(service_t* service);
int   service_wait_terminated(service_t* service, int timeout_ms);
int   service_kill_and_wait(service_t* service, int timeout_ms);
bool  service_is_started(service_t* service);
bool  service_is_alive(service_t* service);
int   service_lock(service_t* service);
void  service_force_lock(service_t* service);
int   service_lock_timeout(service_t* service, int timeout_ms);
int   service_unlock(service_t* service);

// =========================================================================
//    Функции для использования из потока самого сервиса
bool  service_should_stop(service_t* service);

int service_wdog_restart(service_t* service, uint32_t timeout_ms);
int service_wdog_cancel(service_t* service);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_INCLUDE_UTILS_THREAD_BASE_H_INCLUDED
