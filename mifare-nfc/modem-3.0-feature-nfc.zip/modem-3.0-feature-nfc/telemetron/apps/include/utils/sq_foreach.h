/// \file
/// \brief  Оболочка над for(;;) для прохода по односвязному списку
///         типа `sq_queue_t`.
/// \author DL <dmitriy@linikov.ru>
///
///

#ifndef TELEMETRON_APPS_INCLUDE_UTILS_SQ_FOREACH_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_UTILS_SQ_FOREACH_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <queue.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

/// \brief Оболочка над for, которая проходит весь односвязный список типа sq_queue_t.
/// \brief vartype    Тип переменной, который следует использовать для хранения
///                   указателя на каждый прочитанный элемент списка.
/// \param varname    Имя переменной, которое следует использовать для хранения
///                   указателя на каждый прочитанный элемент списка.
/// \param plist      Указатель на односвязный список.
///
/// пример:
/// \code
/// #include <queue.h>
/// struct data_item_s {
///   struct data_item* flink;  // Указатель на следующий, для организации списка
///   int               data1;  // данные 1
///   int               data2;  // данные 2
/// };
/// typedef struct data_item_s data_item_t;
///
/// static sq_queue_t   g_data_list;
/// static data_item_t  a, b, c;
/// void create_queue(void) {
///   a.data1 = 1; a.data2 = 2;
///   b.data1 = 3; b.data2 = 4;
///   c.data1 = 5; c.data2 = 6;
///
///   sq_init(&g_data_list);
///   sq_addlast((sq_entry_t*)&a, &g_data_list);
///   sq_addlast((sq_entry_t*)&b, &g_data_list);
///   sq_addlast((sq_entry_t*)&c, &g_data_list);
/// }
/// void dump_queue(void) {
///   SQ_FOREACH(data_item_t, item, &g_data_list) {
///     printf("item: data1=%d, data2=%d\n", item->data1, item->data2);
///   }
/// }
/// \endcode
#define SQ_FOREACH(vartype, varname, plist) \
  for (FAR vartype* varname = (FAR vartype*)sq_peek(plist); \
      varname != NULL; \
      varname = (FAR vartype*)sq_next(varname))



////////////////////////////////////////////////////////////////////////////
//  Типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_INCLUDE_UTILS_SQ_FOREACH_H_INCLUDED
