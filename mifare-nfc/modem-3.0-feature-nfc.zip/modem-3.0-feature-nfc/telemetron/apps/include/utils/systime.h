/// \file
/// \brief Функции для доступа к системному таймеру.
/// \author DL <dmitriy.linikov@gmail.com>

#ifndef SYS_TIMER_H_INCLUDED
#define SYS_TIMER_H_INCLUDED

#include <stdint.h>
#include <stdbool.h>
#include <sched.h>
#include <nuttx/clock.h>  // systime_t

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

// В NuttX уже есть свой тип systime_t, служащий для этих же целей.
//typedef uint32_t      systime_t;

/// \brief Возвращает текущее значение системного таймера.
systime_t   systime_get(void);

/// \brief Возвращает количество отсчётов системного таймера, прошедших
/// с момента времени \p past_timestamp.
systime_t   systime_ticks_from_timestamp(systime_t past_timestamp);

/// \brief Возвращает true, если текущее значение системного таймера находится
/// в диапазоне [start  ... end)  - исключая end.
/// \note Данная функция полезна для учёта таймаутов с учётом возможного
/// переполнения значения системного таймера таймера.
bool  systime_is_within(systime_t start, systime_t end);

/// \brief Увеличивает системный таймер на единицу.
/// \note Данная функция предназначена для использования из прерываний
/// какого-либо аппаратного таймера с фиксированным периодом в 1мс.
void __systime_tick(void);

/// \brief Приостанавливает выполнение программы на \p ms миллисекунд.
void delay_ms(uint32_t ms);

/// \brief Выполняет \p iterations итераций пустого цикла.
void spin_wait(uint32_t iterations);
#ifdef __cplusplus
}
#endif // __cplusplus

#endif // SYS_TIMER_H_INCLUDED
