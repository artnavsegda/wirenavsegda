/// \file
/// \brief  Отладочные сообщения и asseriton-ы
/// \author DL <dmitriy.linikov@gmail.com>

#ifndef TELEMETRON_APPS_UTILS_DBG_H_INCLUDED
#define TELEMETRON_APPS_UTILS_DBG_H_INCLUDED

#include <stdarg.h>
#include <stddef.h>
#include <syslog.h>
#include "utils/system_utils.h"

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

// ---------------------------------------------------------------------------
// Привязка старого кода к возможности настройки через Kconfig,
// у которого все создаваемые настройки имеют префикс CONFIG_
// и нет возможности задать сложные определения
// (потому выбор CFG_LOG_LEVEL реализован через #if/#elif ... #elif/#endif)
#undef CFG_LOG_LEVEL
#undef CFG_USE_LOG
#undef CFG_ASSERT_ENABLED

#ifdef CONFIG_DBG_USE_LOG
#define CFG_USE_LOG       1
#endif

#if   defined(CONFIG_DBG_LOG_LEVEL_ALL)
#         define CFG_LOG_LEVEL      LOG_LEVEL_ALL
#elif defined(CONFIG_DBG_LOG_LEVEL_TRACE)
#         define CFG_LOG_LEVEL      LOG_LEVEL_TRACE
#elif defined(CONFIG_DBG_LOG_LEVEL_DEBUG)
#         define CFG_LOG_LEVEL      LOG_LEVEL_DEBUG
#elif defined(CONFIG_DBG_LOG_LEVEL_INFO)
#         define CFG_LOG_LEVEL      LOG_LEVEL_INFO
#elif defined(CONFIG_DBG_LOG_LEVEL_WARN)
#         define CFG_LOG_LEVEL      LOG_LEVEL_WARN
#elif defined(CONFIG_DBG_LOG_LEVEL_ERROR)
#         define CFG_LOG_LEVEL      LOG_LEVEL_ERROR
#elif defined(CONFIG_DBG_LOG_LEVEL_FATAL)
#         define CFG_LOG_LEVEL      LOG_LEVEL_FATAL
#elif defined(CONFIG_DBG_LOG_LEVEL_OFF)
#         define CFG_LOG_LEVEL      LOG_LEVEL_OFF
#endif

#ifdef CONFIG_DBG_ASSERT_ENABLED
#define CFG_ASSERT_ENABLED  1
#endif

#ifdef CONFIG_DBG_STOPPOINTS_ENABLED
#define CFG_STOPPOINTS_ENABLED 1
#endif

#ifdef CONFIG_DBG_LOG_USE_COLORS
#define CFG_LOG_USE_COLORS 1
#endif

//
// ---------------------------------------------------------------------------


#define LOG_LEVEL_ALL     LOG_LEVEL_TRACE
#define LOG_LEVEL_TRACE   0
#define LOG_LEVEL_DEBUG   1
#define LOG_LEVEL_INFO    2
#define LOG_LEVEL_WARN    3
#define LOG_LEVEL_ERROR   4
#define LOG_LEVEL_FATAL   5
#define LOG_LEVEL_OFF     128

#ifndef CFG_LOG_LEVEL
#define CFG_LOG_LEVEL     LOG_LEVEL_TRACE
#endif

#ifndef CFG_FILE_LOG_LEVEL
#define CFG_FILE_LOG_LEVEL  LOG_LEVEL_ALL
#endif // CFG_FILE_LOG_LEVEL

// Выбор уровня логов, использованного для текущего .c файла:
// Если глобальная настройка минимального уровня сообщений более строгая,
// чем установлено локально для текущего файла, то используется глобальная настройка
#if (CFG_LOG_LEVEL > CFG_FILE_LOG_LEVEL)
#define USED_LOG_LEVEL      CFG_LOG_LEVEL
#else
#define USED_LOG_LEVEL      CFG_FILE_LOG_LEVEL
#endif


#ifndef CFG_ASSERT_ENABLED
#define CFG_ASSERT_ENABLED  1
#endif

#if !defined(CFG_USE_LOG)
// Возможность полного отключения логов.

#define dbg_set_port(...)     ((void)0)
#define dbg_print(...)        ((void)0)
#define dbg_printhex(...)     ((void)0)
#define dbg_printhex_chunk(...) ((void)0)
#define __log_print(...)      ((void)0)
#define __log_print_va(...)   ((void)0)
#define __assert_failed(...)  HaltWithReason("AssertionFailed.", Halt_Assert_Failed, false)

#else

// //void dbg_set_port(UartDriver* port);
// void dbg_print(const char* format, ...);
// void __log_print(const char* level, const char* format, ...);
// void __log_print_va(const char* level, const char* format, va_list args);
void dbg_printhex_chunk(size_t offset, const void* data, size_t buflen);
void dbg_printhex(const void* buffer, size_t size);
void __assert_failed(const char* file, int line, const char* function,
                     const char* expression, const char* comment);

#define dbg_print(...)          syslog(LOG_NOTICE, __VA_ARGS__)


#endif // if !defined(CFG_USE_LOG)

#if defined(CFG_LOG_USE_COLORS)
# define LOG_RED          "\x1b[31m"
# define LOG_GREEN        "\x1b[32;2m"
# define LOG_YELLOW       "\x1b[33m"
# define LOG_BLUE         "\x1b[34m"
# define LOG_MAGENTA      "\x1b[35m"
# define LOG_CYAN         "\x1b[36m"
# define LOG_GRAY         "\x1b[37m"
# define LOG_WHITE        "\x1b[37;3m"
# define LOG_DEF_COLOR    "\x1b[0m"
#else
# define LOG_RED
# define LOG_GREEN
# define LOG_YELLOW
# define LOG_BLUE
# define LOG_MAGENTA
# define LOG_CYAN
# define LOG_GRAY
# define LOG_WHITE
# define LOG_DEF_COLOR
#endif


#if (USED_LOG_LEVEL <= LOG_LEVEL_TRACE)
#define log_trace(format, ...)        syslog(LOG_DEBUG,  format "\n" , ##__VA_ARGS__)
#define log_trace_va(format, args)    vsyslog(LOG_DEBUG, format "\n", (args))
#else
#define log_trace(...)                ((void)0)
#define log_trace_va(format, args)    ((void)0)
#endif

#if (USED_LOG_LEVEL <= LOG_LEVEL_DEBUG)
#define log_debug(format, ...)    syslog(LOG_DEBUG, format "\n", ##__VA_ARGS__)
#else
#define log_debug(...)    ((void)0)
#endif

#if (USED_LOG_LEVEL <= LOG_LEVEL_INFO)
#define log_info(format, ...)     syslog(LOG_INFO, LOG_WHITE format LOG_DEF_COLOR "\n", ##__VA_ARGS__)
#else
#define log_info(...)     ((void)0)
#endif

//#ifdef CFG_FW_TCPIP
#if (USED_LOG_LEVEL <= LOG_LEVEL_INFO)
#define log_lwip(format, ...)     syslog(LOG_NOTICE, format "\n", ##__VA_ARGS__)
#else
#define log_lwip(...)     ((void)0)
#endif
//#endif // CFG_FW_TCPIP

#if (USED_LOG_LEVEL <= LOG_LEVEL_WARN)
#define log_warn(format, ...)     syslog(LOG_WARNING, LOG_YELLOW format LOG_DEF_COLOR "\n", ##__VA_ARGS__)
#else
#define log_warn(...)     ((void)0)
#endif

#if (USED_LOG_LEVEL <= LOG_LEVEL_ERROR)
#define log_error(format, ...)    syslog(LOG_ERR, LOG_RED format LOG_DEF_COLOR "\n", ##__VA_ARGS__)
#else
#define log_error(...)    ((void)0)
#endif


#if defined(CFG_STOPPOINTS_ENABLED) && !defined(CFG_FILE_STOPPOINTS_DISABLE)
void dbg_stoppoint(const char* message);
void dbg_stoppoint_continue(void);
void dbg_stoppoint_enable(bool enable);
#else
#define dbg_stoppoint(msg)          ((void)msg)
#define dbg_stoppoint_continue()    ((void)0)
#define dbg_stoppoint_enable(en)    ((void)en)
#endif



#define log_func()          log_trace("%s", __PRETTY_FUNCTION__)
#define log_func_result(ok) log_debug("%s: %s.", __PRETTY_FUNCTION__, \
                                      (ok) ? "Ok" : "Fail")

#if (CFG_ASSERT_ENABLED != 0)

#ifndef CFG_ASSERT_FAILED_CALL
/// Стандартная реализация вызова функции уведомления об ошибке.
/// При необходимости её можно переопределить.
#define CFG_ASSERT_FAILED_CALL(file, line, func, cond, msg)           \
  __assert_failed(file, line, func, cond, msg)

#endif // CFG_ASSERT_FAILED_CALL

#define dbg_assert(condition, message)                                \
    ((condition)                                                      \
      ? (void)0                                                       \
      : CFG_ASSERT_FAILED_CALL(__FILE__,                              \
                               __LINE__,                              \
                               __PRETTY_FUNCTION__,                   \
                               #condition,                            \
                               (message))                             \
    )

#else
#define dbg_assert(condition, message)    ((void)0)
#endif



#ifdef __cplusplus
}
#endif // __cplusplus

#endif // TELEMETRON_APPS_UTILS_DBG_H_INCLUDED
