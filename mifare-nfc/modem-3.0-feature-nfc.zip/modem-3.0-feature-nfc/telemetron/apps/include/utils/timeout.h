/// \file
/// \brief Функции для более удобного отслеживания таймаутов.
/// \author DL <dmitriy.linikov@gmail.com>

#ifndef TELEMETRON_APPS_INCLUDE_UTILS_TIMEOUT_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_UTILS_TIMEOUT_H_INCLUDED

#include <utils/systime.h>

#define TIMEOUT_FOREVER     (((systime_t)0) - 1)

#define MS2ST(ms)     MSEC2TICK(ms)
#define ST2MS(ticks)  TICK2MSEC(ticks)

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

typedef struct TimeoutStateTag {
  /// \brief Время старта данного таймаута
  systime_t   start;
  /// \brief Время завершения данного таймаута
  systime_t   end;
} timeout_t;

/// \brief Настраивает таймаута \p state на обратный отсчёт
/// с длительностью \p duration системных тиков.
static inline void timeout_start(timeout_t* state, systime_t duration) {
  systime_t now = systime_get();
  state->start = now;
  state->end = now + duration;
}

static inline bool timeout_is_elapsed(timeout_t* state) {
  if (!state->start && !state->end) {
    return true;
  }
  return !systime_is_within(state->start, state->end);
}

static inline systime_t   timeout_ticks_left(timeout_t* state) {
  return timeout_is_elapsed(state)
          ? 0
          : state->end - systime_get();
}

/// \brief Возвращает количество миллисекунд (с округлением вверх до целого),
/// оставшихся до истечения таймера.
static inline uint32_t  timeout_ms_left(timeout_t* state) {
  systime_t   ticks = timeout_ticks_left(state);
  if (!ticks) {
    // Таймер истёк - возвращаем 0
    return 0;
  }

  uint32_t    ms = ST2MS(ticks);
  if (!ms) {
    // Таймер ещё не истёк, но из-за преобразований tick->ms получили 0.
    // Обычно, данная функция используется для передачи таймаута в poll
    // или другие системные функции, ожидающие определённое количество миллисекунд.
    // Что бы такие вызовы не перешли в неблокирующий режим работы,
    // возвратим 1.
    return 1;
  }
  return ms;
}

static inline timeout_t timeout_create_and_start(systime_t duration) {
  systime_t now = systime_get();
  timeout_t result = {
    .start  = now,
    .end    = now + duration
  };
  return result;
}

static inline timeout_t timeout_create_expired(void) {
  timeout_t result = {
    .start = 0,
    .end = 0
  };
  return result;
}

#define timeout_create_and_start_ms(ms) timeout_create_and_start(MS2ST(ms))

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // TELEMETRON_APPS_INCLUDE_UTILS_TIMEOUT_H_INCLUDED
