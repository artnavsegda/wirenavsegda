/// \file
/// \brief  Модуль вычисления CRC16 контрольной суммы для использования
///         совместно со smartio потоком.
/// \author DL <dmitriy@linikov.ru>

#ifndef TELEMETRON_APPS_INCLUDE_UTILS_SMARTIO_CRC16_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_UTILS_SMARTIO_CRC16_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <utils/smartio.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Типы данных

typedef struct smartio_crc16_s {
  smartio_crc_t         base;
  uint16_t              value;
} smartio_crc16_t;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int   smartio_crc16_create(smartio_crc16_t* crc);
int   smartio_crc16_destroy(smartio_crc16_t* crc);
int   smartio_crc16_set_initial(smartio_crc16_t* crc, uint16_t initial_crc);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_INCLUDE_UTILS_SMARTIO_CRC16_H_INCLUDED
