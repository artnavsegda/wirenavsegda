/// \file
/// \brief  Определение сигналов, не определённых в заголовочных файлах Nuttx.
/// \author DL <dmitriy@linikov.ru>

#ifndef TELEMETRON_APPS_UTILS_SIGNAL_H_INCLUDED
#define TELEMETRON_APPS_UTILS_SIGNAL_H_INCLUDED

#include <signal.h>

#if !defined(SIGINT)
/// \brief Сигнал остановки процесса пользователем.
///
/// \note В NuttX сигнал SIGINT не определён. Выбрал для него значение, которое
/// на единицу меньше, чем первый из "нестандартных" сигналов в signal.h.
/// Так можно ожидать, что ни увеличение количества стандартных сигналов,
/// ни увеличение количества нестандартных сигналов, ещё долго не пересекутся
/// с данным определением.
# define SIGINT  15
#endif

#endif
