/// @file
/// @brief Функции для разбивки запроса на отдельные части.
/// @author DL <dmitriy.linikov@gmail.com>

#ifndef REQUEST_TOKENIZER_H_INCLUDED
#define REQUEST_TOKENIZER_H_INCLUDED

#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct RequestEntityTag {
  char* name;
  char* value;
} RequestEntity;

/// \brief Разбивает строку вида name1=value1&name2=value2&...&nameN=valueN на
/// отдельные токены типа RequestEntity.
/// \param dst          Указатель на массив записей типа RequestEntity,
///                     в который будет помещён результат обработки.
/// \param max_entities Количество записей, доступное в массиве \p dst.
/// \param request_str  Текст запроса
/// \return Возвращает количество разобранных параметров. Если в строке
/// присутствует большее количество параметров, чем есть в буффере \p dst,
/// то только первые \p max_entities параметров будут разобраны.
/// \note Параметры, у которых нельзя выделить имя, будут проигнорированы.
/// (например, при обработке строки `name1=value1&=value2&&name4`,
/// данная функция сохранит только параметры name1=value1, name4).
size_t SplitRequest(RequestEntity* dst, size_t max_entities, char* request_str);

#ifdef __cplusplus
}
#endif


#endif // REQUEST_TOKENIZER_H_INCLUDED
