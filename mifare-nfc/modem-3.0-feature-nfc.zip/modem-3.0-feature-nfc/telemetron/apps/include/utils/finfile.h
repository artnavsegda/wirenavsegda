/// \file
/// \brief  Файл с ограниченным максимальным размером.
/// \author DL <dmitriy@linikov.ru>


#ifndef TELEMETRON_APPS_INCLUDE_UTILS_FINITE_FILE_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_UTILS_FINITE_FILE_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <nuttx/streams.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Типы данных

/// \brief Настройки, что делать при превышении допустимого размера файла
typedef enum finfile_overflow_e {
  FINFILE_OVERFLOW_IGNORE,  ///< Не выдавать ошибки при переполнении и записи в закрытый файл
  FINFILE_OVERFLOW_ERROR    ///< Переполнение и запись в закрытый файл - ошибка.
} finfile_overflow_t;

/// \brief Как себя вести, если при вызове finfile_write в файле ещё есть
/// свободное место, но его недостаточно для того, что бы полностью
/// записать данные.
typedef enum finfile_partwrite_e {
  FINFILE_PARTWRITE_PROHIBIT, ///< Вернуь ошибку, если нельзя записать целиком
  FINFILE_PARTWRITE_ALLOWED   ///< Записать максимум данных
} finfile_partwrite_t;


typedef struct finitefile_s {
  struct lib_outstream_s  public;     // Для совместимости с lib_vsprintf

  int                     fd;
  size_t                  max_size;
  size_t                  size;
  finfile_overflow_t      overflow;
  finfile_partwrite_t     partwrite;
} finfile_t;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int finfile_create(
  finfile_t*          f,
  size_t              max_size,
  finfile_overflow_t  overflow,
  finfile_partwrite_t partwrite
);
int       finfile_destroy(finfile_t* f);
int       finfile_open(finfile_t* f, const char* path, int oflag);
int       finfile_close(finfile_t* f);
ssize_t   finfile_write(finfile_t* f, const void* buffer, size_t size);
int       finfile_putc(finfile_t* f, int ch);


bool      finfile_isopen(finfile_t* f);
bool      finfile_hasspace(finfile_t* f, size_t required_bytes);
bool      finfile_isoverflow(finfile_t* f);
size_t    finfile_virtual_size(finfile_t* f);
size_t    finfile_size(finfile_t* f);
ssize_t   finfile_printf(finfile_t* f, const char* format, ...);



#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_INCLUDE_UTILS_FINITE_FILE_H_INCLUDED
