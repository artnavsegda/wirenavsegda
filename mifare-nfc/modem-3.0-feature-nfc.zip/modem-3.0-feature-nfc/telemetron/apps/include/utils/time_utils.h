/// \file
/// \brief Функции для работы с датой и временем.
/// \author DL <dmitriy.linikov@gmail.com>

#ifndef TIME_UTILS_H_INCLUDED
#define TIME_UTILS_H_INCLUDED

#include <stdint.h>
#include <stdbool.h>
#include <unistd.h>
#include <time.h>
#include <nuttx/clock.h>

/// \brief Строка форматирования для strftime, дающая формат `ГГГГ-ММ-ДД ЧЧ:ММ:СС`
/// \note Строго-говоря, это не совсем ISO формат, т.к. дата от времени
/// отделена пробелом, а не символом `T`.
#define TIME_FORMAT_ISO               "%Y-%m-%d %H:%m:%s"

/// \brief Размер буффера, необходимый что бы уместить строку в формате TIME_FORMAT_ISO
#define TIME_FORMAT_ISO_BUFFER_SIZE   20

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

typedef struct UnpackedTimeTag {
  uint8_t year;
  uint8_t month;
  uint8_t day;
  uint8_t hour;
  uint8_t minute;
  uint8_t second;
  int8_t  timezone;
} UnpackedTime;


/// \brief Разбирает строку в формате ГГГГ/ММ/ДД,чч:мм:сс, и сохраняет
/// её в переменную \p dst.
bool TimeParseSim900Format(UnpackedTime* dst, const char* time_str);

bool TimeParseServerFormat(UnpackedTime* dst, const char* time_str);


/// \brief  Добавляет (ули отнимает) к переменной \p ts миллисекунды в количестве \p ms.
/// \return 0 в случае успеха, или отрицательный код ошибки (\see errno)
void timespec_add_ms(struct timespec* ts, int ms);

/// \brief  Сравнивает два значения времени.
/// \return Значение, показывающее отношение \p a и \p b.
/// \retval `< 0`   означает, что `a < b`
/// \retval `0`     означает, что `a == b`
/// \retval `> 0`   означает, что `a > b`
long timespec_compare(const struct timespec* a, const struct timespec* b);

/// \brief  Проверяет, прошло ли время, заданное \p ts.
bool timespec_is_passed(const struct timespec* ts);

static inline bool timespec_is_cleared(const struct timespec* ts) {
  return !ts || (!ts->tv_sec && !ts->tv_nsec);
}

/// \brief  Проверяет, установлено ли время в \p ts.
static inline bool timespec_is_set(const struct timespec* ts) {
  return !timespec_is_cleared(ts);
}

/// \brief Очищает переменную типа `struct timespec` \p ts
static inline void timespec_clear(struct timespec* ts) {
  if (ts) {
    ts->tv_sec  = 0;
    ts->tv_nsec = 0;
  }
}

static inline struct timespec timespec_plus_ms(struct timespec* ts, int ms)
{
  struct timespec result;
  if (ts) {
    result = *ts;
    timespec_add_ms(&result, ms);
  } else {
    timespec_clear(&result);
  }
  return result;
}

/// \brief Возвращает текущее время в виде struct timespec, используя CLOCK_REALTIME
struct timespec timespec_now(void);

/// \brief Возвращает время, которое будет через \p ms миллисекунд.
struct timespec timespec_after_ms(int ms);

/// \brief Вычисляет значение разницы `(ts1 - ts2)`
struct timespec timespec_diff(const struct timespec* ts1, const struct timespec* ts2);

/// \brief  Преобразовывает в текст значение времени \p value,
/// используя strftime-совместимую строку форматирования \p format.
/// \param  buffer          Буффер, в который будет сохранена получанная строка
/// \param  size            размер буффера
/// \param  value           Значение времени, которое следует преобразовать.
/// \param  format          Строка форматирования, передаваемая в strftime
/// \return Указатель на буффер в случае успеха, или NULL, если время
/// не поместилось в указанный буффер.
const char* format_time(char* buffer, size_t size, char* format, time_t value);



/// \brief  Преобразовывает значение времени \p value в текст формата `ГГГГ-ММ-ДД ЧЧ:ММ:СС`
/// \param  buffer          Буффер, в который будет сохранена получанная строка
/// \param  size            размер буффера
/// \param  value           Значение времени, которое следует преобразовать.
/// \return Указатель на буффер в случае успеха, или NULL, если время
/// не поместилось в указанный буффер.
const char* format_time_iso(char* buffer, size_t size, time_t value);



/// \brief Преобразовывает текущее время в текст формата `ГГГГ-ММ-ДД ЧЧ:ММ:СС`
///
/// Данная функция использует время, возвращаемое функцией `clock_gettime(CLOCK_REALTIME, ...)`
/// \param  buffer          Буффер, в который будет сохранена получанная строка
/// \param  size            размер буффера
/// \return Указатель на буффер в случае успеха, или NULL, если время
/// не поместилось в указанный буффер.
const char* format_realtime_iso(char* buffer, size_t size);


#ifdef __cplusplus
}
#endif // __cplusplus

#endif // TIME_UTILS_H_INCLUDED
