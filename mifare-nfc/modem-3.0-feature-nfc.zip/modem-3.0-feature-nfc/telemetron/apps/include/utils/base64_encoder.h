﻿/// \file
/// \brief Преобразование произвольных данных в Base64 кодировку.
/// \author DL <dmitriy.linikov@gmail.com>



#ifndef BASE64_ENC_H_INCLUDED
#define BASE64_ENC_H_INCLUDED

#include <stdint.h>
#include <stdbool.h>

/// \brief "Объект", через который происходит вывод преобразованного в Base64 текста.
typedef struct Base64PrinterTag {
  /// \brief Функция, печатающая очередной байт в выходной поток.
  /// \return true в случае успеха, иначе - false.
  bool (*PutC)(void* writer, int value);
} Base64Printer;

/// \brief Внутреннее строение Base64 кодировщика.
typedef struct Base64EncoderTag {
  uint8_t         input_buffer_[3];
  uint8_t         input_size_;
  Base64Printer*  output_;
  uint8_t         alive_;
} Base64Encoder;

/// \brief Заполняет поля \p encoder стандартными значениями для начала работы с модулем
/// Base64Encoder.
/// \param encoder    Указатель на структуру, которую следует проинициализировать.
///                   Обязательный параметр, не может быть NULL.
/// \param output     Указатель на объект, через который будет производиться вывод
///                   преобразованных данных. Обязательный параметр, не может быть NULL.
void Base64Encoder_ObjInit(Base64Encoder* encoder, Base64Printer* output);

/// \brief Записывает в выходной поток один байт @p byte.
/// Непосредственная запись будет отложена до накопления
/// в буффере трёх байт.
///
/// \return Возвращает статус записи в нижележащий поток.
/// Если в какой-либо момент времени запись в нижележащий
/// поток закончилась ошибкой, то все последующие вызовы
/// функций Base64Encoder_Put, Base64Encoder_Write
/// или Base64Encoder_Flush будут возвращать false.
bool Base64Encoder_Put(Base64Encoder* encoder, uint8_t byte);

/// \brief Записывает в выходной поток произвольный буффер
/// данных @p data размеро @p size байт.
///
/// \return Возвращает статус записи в нижележащий поток.
/// Если в какой-либо момент времени запись в нижележащий
/// поток закончилась ошибкой, то все последующие вызовы
/// функций Base64Encoder_Put, Base64Encoder_Write
/// или Base64Encoder_Flush будут возвращать false.
bool Base64Encoder_Write(Base64Encoder* encoder, const void* data, uint16_t size);

/// \brief Завершает форматирование текущего набора байт и
/// добавляет в конец вывода 0, 1 или 2 знака '=', указывая
/// на количество реально использованных байт в последнем
/// квартете символов. И выводит все накопленные в буффере
/// байты в выходной поток.
///
/// \return Возвращает статус записи в нижележащий поток.
/// Если в какой-либо момент времени запись в нижележащий
/// поток закончилась ошибкой, то все последующие вызовы
/// функций Base64Encoder_Put, Base64Encoder_Write
/// или Base64Encoder_Flush будут возвращать false.
bool Base64Encoder_Flush(Base64Encoder* encoder);

/// \brief Сбрасывает состояние данного объекта к свежесозданному
/// состоянию, удаляя из буффера все накопленные байты.
/// Данный метод следует использовать, когда необходимо вывести
/// в один и тот же поток несколько различных base64 полей, и
/// нет желания для каждого из полей создавать отдельный экземпляр
/// данного объекта.
void Base64Encoder_Reset(Base64Encoder* encoder);


// ==================== Принтер для вывода в буффер ===========================
typedef struct Base64BufferPrinterTag {
  Base64Printer       base;
  uint8_t*            dst;
  uint16_t            size;
  uint16_t            length;
} Base64BufferPrinter;

void Base64BufferPrinter_ObjInit(Base64BufferPrinter* obj, void* buffer, uint16_t size);

static inline uint16_t Base64BufferPrinter_Length(Base64BufferPrinter* obj) {
  return obj->length;
}

// ==================== Служебные функции, упрощающие работу с библиотекой ====
/// \brief Преобразует данные из буффера \p src длиной \p src_size байт в кодировку Base64
/// и сохраняет их в строковой буффер \p dst длиной \p dst_size.
///
/// \return Количество символов (исключая завершающий нуль), записанных в целевой буффер \p dst,
/// или -1, если символов в целевом буффере недостаточно для хранения исходных данных.
int Base64Encoder_Encode(char* dst, uint16_t dst_size, const void* src, uint16_t src_size);

#endif // BASE64_ENC_H_INCLUDED
