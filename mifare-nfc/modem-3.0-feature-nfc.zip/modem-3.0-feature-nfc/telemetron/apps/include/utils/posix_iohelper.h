/// \file
/// \brief Функции для чтения и записи из файла по его имени.
/// \author DL <dmitriy.linikov@gmail.com>

#ifndef POSIX_IOHELPER__INCLIDED
#define POSIX_IOHELPER__INCLIDED

#include <stddef.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <termios.h>

struct file;   /* Forward reference */
struct pollfd; /* Forward reference */


typedef enum {
    SERIAL_WORDLEN_8_BIT = CS8,
    SERIAL_WORDLEN_9_BIT = CS9
} serial_wordlen_t;

typedef enum {
    SERIAL_PARITY_NONE  = 0,
    SERIAL_PARITY_ODD   = (PARENB | PARODD),
    SERIAL_PARITY_EVEN  = (PARENB | 0)
} serial_parity_t;

typedef enum {
    SERIAL_FLOWCTL_NONE     = 0,
    SERIAL_FLOWCTL_CTS      = CCTS_OFLOW,
    SERIAL_FLOWCTL_RTS      = CRTS_IFLOW,
    SERIAL_FLOWCTL_RTSCTS   = CRTSCTS
} serial_flowctl_t;

// Наиболее значимые ошибки при вызове GetcTimeout и подобных
#define IO_OK               0
#define IO_ERR_TIMEOUT      -EAGAIN
#define IO_ERR_INTERRUPTED  -EINTR

// значение, которое следует использовать для обозначения неоткрытых файлов.
#define INVALID_FD          -1

// Стандартные настройки доступа к файлам:
// Всем можно читать и записывать, но не исполнять.
#ifndef DEFFILEMODE
# define DEFFILEMODE (S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH)
#endif

/// \brief Открытие файла \p name, запись в него и закрытие.
/// \return количество записанных байт, в случае успеха, иначе - `-errno`;
extern FAR ssize_t WriteFile(const char* name, const void* data, size_t length);

/// \brief Открытие файла \p name, запись в него и закрытие.
/// \return true, в случае успеха, иначе - false;
extern FAR bool WriteHelper(const char* name, const void* data, size_t length);

/// \brief Открытие файла \p name, чтение из него и закрытие.
/// \return количество прочитанных байт, в случае успеха, иначе - `-errno`;
extern FAR ssize_t ReadFile(const char* name, void* data, size_t length);

/// \brief Читает текстовый файл в буффер \p text, обязательно завершая нулём.
/// \return количество прочитанных байт (без учета нуля в конце строки)
///  в случае успеха, иначе - `-errno`;
ssize_t ReadTextFile(const char* name, char* text, size_t buffer_size);

/// \brief Открытие файла \p name, чтение из него и закрытие.
/// \return true, в случае успеха, иначе - false;
extern FAR bool ReadHelper(const char* name, void* data, size_t length);


/// \brief Читает в буффер данные, пока не будет прочитан стоп-символ.
/// \return Количество символов (исключая '\0'), которое было бы записано в буффер,
/// если бы в нём было достаточно места. или отрицательный код ошибки.
/// \note Символы конца строки и сам стоп-символ в буффер не пишутся.
ssize_t ReadUntil(int fd, char* buffer, size_t buffer_size, char stopchar);

/// \brief Читает из файла \p fd строку текста, завершающуюся на \r\n.
/// символы завершения строку в буффер не попадают.
/// \return количество символов в строке, которое бы попало в буффер,
/// будь он достаточного размера, или отрицательный код ошибки.
ssize_t ReadLineCRLF(int fd, char* buffer, size_t buffer_size);

/// \brief Открытие файла \p name, выполнение ioctl и закрытие.
/// \return >=0, в случае успеха, иначе - отрицательное значение;
int IoctlHelper(const char* name, int req, unsigned long arg);

/// \brief Открытие файла, выделение памяти, загрузка полного содержимого в память и закрытие.
/// \return указатель на память с содержимым файла, NULL в случае ошибки.
char* ReadWholeTextFile(const char* name);

/// \brief Переводит файл в неблокирующий режим работы
/// \return 0, если завершено удачно, или отрицательный код ошибки
extern FAR int TtySetNonblock(int fd);

/// \brief  Читает один символ из файла fd, ожидая не более timeout_ms миллисекунд.
/// \note   Только для файлов в неблокирующем режиме
/// \return В случае успеха возвращает (uint8_t) значение - полученный байт, или отрицательное число при ошибке.
extern FAR int GetcTimeout(int fd, int timeout_ms);

/// \brief  Читает один символ из файла fd без ожидания.
/// \note   Только для файлов в неблокирующем режиме
/// \return В случае успеха возвращает (uint8_t) значение - полученный байт, или отрицательное число при ошибке.
extern FAR int GetcImmediate(int fd);


/// \brief  Записывае один символ в файл, ожидая доступности буффера не более timeout_ms миллисекунд.
/// \note   Только для файлов в неблокирующем режиме
/// \return 0 в случае успеха, отрицательное значение в случае ошибки.
extern FAR int PutcTimeout(int fd, int value, int timeout_ms);

/// \brief  Записывае один символ в файл ожидая доступности буффера без ограничения времени.
/// \note   Только для файлов в неблокирующем режиме
/// \return 0 в случае успеха, отрицательное значение в случае ошибки.
extern FAR int PutcBlocking(int fd, int value);

/// \brief Устанавливает параметры последовательного порта и отключает дополнительную tty обработку
extern FAR bool SerialSetupRaw(int fd, speed_t baudrate, serial_wordlen_t wordlen, serial_parity_t parity, serial_flowctl_t flowctl);

/// \brief Возвращает текущие параметры последовательного порта.
extern FAR bool SerialGetCommParams(int fd, speed_t* baudrate, serial_wordlen_t* wordlen, serial_parity_t* parity, serial_flowctl_t* flowctl);

/// \brief Открывает последовательный порт \p path, устанавливает неблокирующий режим и настраивает его.
extern FAR int SerialOpenRawNonblocking(const char* path, speed_t baudrate, serial_wordlen_t wordlen, serial_parity_t parity, serial_flowctl_t flowctl);

static inline int SerialOpenRawNonblockingDefCfg(const char* path, speed_t baudrate)
{
  return SerialOpenRawNonblocking(path, baudrate, SERIAL_WORDLEN_8_BIT, SERIAL_PARITY_NONE, SERIAL_FLOWCTL_NONE);
}

static inline int SerialSetupRawDefCfg(int fd, speed_t baudrate)
{
  return SerialSetupRaw(fd, baudrate, SERIAL_WORDLEN_8_BIT, SERIAL_PARITY_NONE, SERIAL_FLOWCTL_NONE);
}

/// \brief  Создаёт именованный семафор.
/// \param  name        Имя семафора в формате "/name".
/// \param  init_value  Начальное значение семафора.
/// \param  is_counting Семафор будет использоваться как счётчик.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int NamedSemCreate(const char* name, int init_value, bool is_counting);

/// \brief  Ожидает положительного значения именованного семафора.
/// \param  name        Имя семафора в формате "/name".
/// \param  timeout_ms  Максимальная продолжительность ожидания в миллисекундах.
///                     Если отрицательное число, то бесконечное ожидание.
///                     Если ноль, то выполняется без блокировки.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int NamedSemWaitTimeout(const char* name, int32_t timeout_ms);

/// \brief  Добавляе 1 к значению именованного семафора.
/// \param  name        Имя семафора в формате "/name".
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int NamedSemPost(const char* name);

/// \brief  Читает текущее значение именованного семафора.
/// \param  name        Имя семафора в формате "/name".
/// \param  dst         Указатель на переменную, куда нужно записать результат.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int NamedSemGetValue(const char* name, int* dst);

/// \brief Аналог poll но для struct file
int poll_raw_files(struct file** files, struct pollfd* pfd, size_t count, int timeout_ms);

/// \brief Выводит содержимое файла в системных лог, от текущей позиции до конца файла.
extern FAR void DumpFile(const char* message, int fd);


#endif
