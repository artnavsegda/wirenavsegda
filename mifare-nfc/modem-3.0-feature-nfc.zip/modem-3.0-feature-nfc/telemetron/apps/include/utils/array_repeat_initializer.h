/// \file
/// \brief  Макрос для инициализации массива ненулевым значением.
/// \author DL <dmitriy@linikov.ru>

#ifndef UTILS__ARRAY_REPEAT_INITIALIZER_H_INCLUDED
#define UTILS__ARRAY_REPEAT_INITIALIZER_H_INCLUDED

/// \brief  Макрос для инициализации массива ненулевым значением.
///
/// При определении константного массива, размер которого задан через #define,
/// бывает сложно задать значения, отличающиеся от нуля.
/// Обычно это требует длинной вереницы из #if #else #endif. Например:
/// \code
/// // Длина массива может меняться настройками компилятора
/// #ifndef DATA_LENGTH
/// #  define DATA_LENGTH 5
/// #endif
///
/// // Все элементы этого массива должны быть равны 10.
/// // из-за того, что DATA_LENGTH может изменяться настройками компилятора,
/// // приходится добавлять #if/#endif, которые ухудшают читаемость модуля.
/// static const int ALL_TENS[DATA_LENGTH] = {
///   10,
///
/// #if (DATA_LENGTH >= 2)
///   10,
/// #endif
///
/// #if (DATA_LENGTH >= 3)
///   10,
/// #endif
///
/// #if (DATA_LENGTH >= 4)
///   10,
/// #endif
///
/// #if (DATA_LENGTH >= 5)
///   10,
/// #endif
///
/// #if (DATA_LENGTH > 5)
/// #  error "Define more array values"
/// #endif
/// };
/// \endcode
///
/// Данный файл предоставляет макрос `ARRAY_REPEAT_INITIALIZER(size, value)`,
/// который создаёт инициализатор массива размером size, каждый элемент которого
/// имеет значение value.
///
/// Используя данный макрос предыдущий пример можно переписать так:
/// \code
/// // Длина массива может меняться настройками компилятора
/// #ifndef DATA_LENGTH
/// #  define DATA_LENGTH 5
/// #endif
///
/// // Все элементы этого массива должны быть равны 10.
/// // из-за того, что DATA_LENGTH может изменяться настройками компилятора,
/// // приходится добавлять #if/#endif, которые ухудшают читаемость модуля.
/// static const int ALL_TENS[DATA_LENGTH]
///   = ARRAY_REPEAT_INITIALIZER(DATA_LENGTH, 10);
/// \endcode
#define ARRAY_REPEAT_INITIALIZER(size, value) \
  { ___CONCAT(___REPEAT,size)(value) }


#define ___CONCAT(a, ...) a ## __VA_ARGS__

#define ___REPEAT0(v)
#define ___REPEAT1(v)   v
#define ___REPEAT2(v)   v,v
#define ___REPEAT3(v)   v,v,v
#define ___REPEAT4(v)   v,v,v,v
#define ___REPEAT5(v)   v,v,v,v,v
#define ___REPEAT6(v)   v,v,v,v,v,v
#define ___REPEAT7(v)   v,v,v,v,v,v,v
#define ___REPEAT8(v)   v,v,v,v,v,v,v,v
#define ___REPEAT9(v)   v,v,v,v,v,v,v,v,v

#define ___REPEAT10(v)  v,v,v,v,v,v,v,v,v,v
#define ___REPEAT20(v)  ___REPEAT10(v),___REPEAT10(v)
#define ___REPEAT30(v)  ___REPEAT20(v),___REPEAT10(v)
#define ___REPEAT40(v)  ___REPEAT30(v),___REPEAT10(v)
#define ___REPEAT50(v)  ___REPEAT40(v),___REPEAT10(v)
#define ___REPEAT60(v)  ___REPEAT50(v),___REPEAT10(v)
#define ___REPEAT70(v)  ___REPEAT60(v),___REPEAT10(v)
#define ___REPEAT80(v)  ___REPEAT70(v),___REPEAT10(v)
#define ___REPEAT90(v)  ___REPEAT80(v),___REPEAT10(v)

// 10s
#define ___REPEAT11(v)  ___REPEAT10(v),___REPEAT1(v)
#define ___REPEAT12(v)  ___REPEAT10(v),___REPEAT2(v)
#define ___REPEAT13(v)  ___REPEAT10(v),___REPEAT3(v)
#define ___REPEAT14(v)  ___REPEAT10(v),___REPEAT4(v)
#define ___REPEAT15(v)  ___REPEAT10(v),___REPEAT5(v)
#define ___REPEAT16(v)  ___REPEAT10(v),___REPEAT6(v)
#define ___REPEAT17(v)  ___REPEAT10(v),___REPEAT7(v)
#define ___REPEAT18(v)  ___REPEAT10(v),___REPEAT8(v)
#define ___REPEAT19(v)  ___REPEAT10(v),___REPEAT9(v)

// 20s
#define ___REPEAT21(v)  ___REPEAT20(v),___REPEAT1(v)
#define ___REPEAT22(v)  ___REPEAT20(v),___REPEAT2(v)
#define ___REPEAT23(v)  ___REPEAT20(v),___REPEAT3(v)
#define ___REPEAT24(v)  ___REPEAT20(v),___REPEAT4(v)
#define ___REPEAT25(v)  ___REPEAT20(v),___REPEAT5(v)
#define ___REPEAT26(v)  ___REPEAT20(v),___REPEAT6(v)
#define ___REPEAT27(v)  ___REPEAT20(v),___REPEAT7(v)
#define ___REPEAT28(v)  ___REPEAT20(v),___REPEAT8(v)
#define ___REPEAT29(v)  ___REPEAT20(v),___REPEAT9(v)

// 30s
#define ___REPEAT31(v)  ___REPEAT30(v),___REPEAT1(v)
#define ___REPEAT32(v)  ___REPEAT30(v),___REPEAT2(v)
#define ___REPEAT33(v)  ___REPEAT30(v),___REPEAT3(v)
#define ___REPEAT34(v)  ___REPEAT30(v),___REPEAT4(v)
#define ___REPEAT35(v)  ___REPEAT30(v),___REPEAT5(v)
#define ___REPEAT36(v)  ___REPEAT30(v),___REPEAT6(v)
#define ___REPEAT37(v)  ___REPEAT30(v),___REPEAT7(v)
#define ___REPEAT38(v)  ___REPEAT30(v),___REPEAT8(v)
#define ___REPEAT39(v)  ___REPEAT30(v),___REPEAT9(v)

// 40s
#define ___REPEAT41(v)  ___REPEAT40(v),___REPEAT1(v)
#define ___REPEAT42(v)  ___REPEAT40(v),___REPEAT2(v)
#define ___REPEAT43(v)  ___REPEAT40(v),___REPEAT3(v)
#define ___REPEAT44(v)  ___REPEAT40(v),___REPEAT4(v)
#define ___REPEAT45(v)  ___REPEAT40(v),___REPEAT5(v)
#define ___REPEAT46(v)  ___REPEAT40(v),___REPEAT6(v)
#define ___REPEAT47(v)  ___REPEAT40(v),___REPEAT7(v)
#define ___REPEAT48(v)  ___REPEAT40(v),___REPEAT8(v)
#define ___REPEAT49(v)  ___REPEAT40(v),___REPEAT9(v)

// 50s
#define ___REPEAT51(v)  ___REPEAT50(v),___REPEAT1(v)
#define ___REPEAT52(v)  ___REPEAT50(v),___REPEAT2(v)
#define ___REPEAT53(v)  ___REPEAT50(v),___REPEAT3(v)
#define ___REPEAT54(v)  ___REPEAT50(v),___REPEAT4(v)
#define ___REPEAT55(v)  ___REPEAT50(v),___REPEAT5(v)
#define ___REPEAT56(v)  ___REPEAT50(v),___REPEAT6(v)
#define ___REPEAT57(v)  ___REPEAT50(v),___REPEAT7(v)
#define ___REPEAT58(v)  ___REPEAT50(v),___REPEAT8(v)
#define ___REPEAT59(v)  ___REPEAT50(v),___REPEAT9(v)

// 60s
#define ___REPEAT61(v)  ___REPEAT60(v),___REPEAT1(v)
#define ___REPEAT62(v)  ___REPEAT60(v),___REPEAT2(v)
#define ___REPEAT63(v)  ___REPEAT60(v),___REPEAT3(v)
#define ___REPEAT64(v)  ___REPEAT60(v),___REPEAT4(v)
#define ___REPEAT65(v)  ___REPEAT60(v),___REPEAT5(v)
#define ___REPEAT66(v)  ___REPEAT60(v),___REPEAT6(v)
#define ___REPEAT67(v)  ___REPEAT60(v),___REPEAT7(v)
#define ___REPEAT68(v)  ___REPEAT60(v),___REPEAT8(v)
#define ___REPEAT69(v)  ___REPEAT60(v),___REPEAT9(v)

// 70s
#define ___REPEAT71(v)  ___REPEAT70(v),___REPEAT1(v)
#define ___REPEAT72(v)  ___REPEAT70(v),___REPEAT2(v)
#define ___REPEAT73(v)  ___REPEAT70(v),___REPEAT3(v)
#define ___REPEAT74(v)  ___REPEAT70(v),___REPEAT4(v)
#define ___REPEAT75(v)  ___REPEAT70(v),___REPEAT5(v)
#define ___REPEAT76(v)  ___REPEAT70(v),___REPEAT6(v)
#define ___REPEAT77(v)  ___REPEAT70(v),___REPEAT7(v)
#define ___REPEAT78(v)  ___REPEAT70(v),___REPEAT8(v)
#define ___REPEAT79(v)  ___REPEAT70(v),___REPEAT9(v)

// 80s
#define ___REPEAT81(v)  ___REPEAT80(v),___REPEAT1(v)
#define ___REPEAT82(v)  ___REPEAT80(v),___REPEAT2(v)
#define ___REPEAT83(v)  ___REPEAT80(v),___REPEAT3(v)
#define ___REPEAT84(v)  ___REPEAT80(v),___REPEAT4(v)
#define ___REPEAT85(v)  ___REPEAT80(v),___REPEAT5(v)
#define ___REPEAT86(v)  ___REPEAT80(v),___REPEAT6(v)
#define ___REPEAT87(v)  ___REPEAT80(v),___REPEAT7(v)
#define ___REPEAT88(v)  ___REPEAT80(v),___REPEAT8(v)
#define ___REPEAT89(v)  ___REPEAT80(v),___REPEAT9(v)

// 90s
#define ___REPEAT91(v)  ___REPEAT90(v),___REPEAT1(v)
#define ___REPEAT92(v)  ___REPEAT90(v),___REPEAT2(v)
#define ___REPEAT93(v)  ___REPEAT90(v),___REPEAT3(v)
#define ___REPEAT94(v)  ___REPEAT90(v),___REPEAT4(v)
#define ___REPEAT95(v)  ___REPEAT90(v),___REPEAT5(v)
#define ___REPEAT96(v)  ___REPEAT90(v),___REPEAT6(v)
#define ___REPEAT97(v)  ___REPEAT90(v),___REPEAT7(v)
#define ___REPEAT98(v)  ___REPEAT90(v),___REPEAT8(v)
#define ___REPEAT99(v)  ___REPEAT90(v),___REPEAT9(v)



#endif //UTILS__ARRAY_REPEAT_INITIALIZER_H_INCLUDED
