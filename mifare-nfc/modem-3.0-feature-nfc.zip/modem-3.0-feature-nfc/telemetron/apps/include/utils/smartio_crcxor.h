/// \file
/// \brief  Модуль вычисления XOR контрольной суммы для использования
///         совместно со smartio потоком.
/// \author DL <dmitriy@linikov.ru>

#ifndef TELEMETRON_APPS_INCLUDE_UTILS_SMARTIO_CRCXOR_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_UTILS_SMARTIO_CRCXOR_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <utils/smartio.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Типы данных

typedef struct smartio_crcxor_s {
  smartio_crc_t         base;
  uint8_t               value;
} smartio_crcxor_t;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int   smartio_crcxor_create(smartio_crcxor_t* crc);
int   smartio_crcxor_destroy(smartio_crcxor_t* crc);
int   smartio_crcxor_set_initial(smartio_crcxor_t* crc, uint8_t initial_crc);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_INCLUDE_UTILS_SMARTIO_CRCXOR_H_INCLUDED
