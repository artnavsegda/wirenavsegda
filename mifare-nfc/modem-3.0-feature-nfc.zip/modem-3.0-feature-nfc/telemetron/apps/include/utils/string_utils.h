/// \file
/// \brief Вспомогательные строковые функции, которых нет
/// в стандартной библиотеке.
/// \author DL <dmitriy.linikov@gmail.com>

#ifndef STRING_UTILS_H_INCLUDED
#define STRING_UTILS_H_INCLUDED

#include <stdbool.h>
#include <stdlib.h>
#include <stdint.h>
#include <sys/types.h>
#include <unistd.h>

/// \brief Строковой сегмент - оболочка над буффером, позволяющая
/// использовать форматирование, без необходимости проверять переполнения.
typedef struct {
  char* str;      ///< Указатель на начало буффера строки
  char* ptr;      ///< Указатель на текущее положение завершающего '\\0'-символа
  char* end;      ///< Указатель на последний возможный ненулевой символ буффера
} str_segment_t;



#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

/// \brief  Создаёт строковой сегмент.
/// \return 0 в случае успеха или отрицательный код ошибки.
int ss_init(str_segment_t* s, char* buffer, size_t size);

/// \brief  Аналог snprintf для работы со строковым сегментом
/// \return Количество символов (без учёта нуля), которое было бы добавлено,
///         если бы в строковом сегменте было достаточно места.
int ss_printf(str_segment_t* s, const char* format, ...);

/// \brief  Добавляет один символ в строковой сегмент.
int ss_putc(str_segment_t* s, int c);

/// \brief  Проверяет состояние строкового сегмента.
/// \return 0, если сегмент существует и в нём есть место, или отрицательный код ошибки.
int ss_state(str_segment_t* s);

/// \brief  Вычисляет, сколько всего места под символы (без учёта '\\0') в строковом сегменте \p s.
/// \return `>= 0` полученное значение, или отрицательный код ошибки.
/// \retval -EINVAL   Ошибка, аргумент \p s равен NULL.
ssize_t ss_get_size(str_segment_t* s);

/// \brief  Вычисляет, сколько символов (без учёта '\\0') использовано в строковом сегменте \p s.
/// \return `>= 0` полученное значение, или отрицательный код ошибки.
/// \retval -EINVAL   Ошибка, аргумент \p s равен NULL.
ssize_t ss_get_used(str_segment_t* s);

/// \brief  Вычисляет, сколько ещё символов (не считая '\\0') можно записать
///         в строковой сегмент \p s.
/// \return `>= 0` полученное значение, или отрицательный код ошибки.
/// \retval -EINVAL   Ошибка, аргумент \p s равен NULL.
ssize_t ss_get_free(str_segment_t* s);

/// \brief  Вычисляет, сколько всего байт (в том числе после переполнения) было
///         записано в строковой сегмент \p s.
/// \warning Данная функция считает все байты, которые пытались записать в
///         данный строковой сегмент, вне зависимости от того, удалось это, или нет.
/// \return `>= 0` полученное значение, или отрицательный код ошибки.
/// \retval -EINVAL   Ошибка, аргумент \p s равен NULL.
ssize_t ss_get_written(str_segment_t* s);


/// \brief Возвращает true, если строка \p str содержит только непечатные
/// символы, либо её длина равна нулю, либо она равна NULL.
bool IsWhiteOrEmptyString(const char* str);


/// \brief Заменяет в строке \p string все вхождения символов из \p subject
/// на соответствующие им символы из \p substitution.
///
/// \warning Размерность массивов \p subject и \p substitution должны совпадать,
/// а сами массивы обязаны заканчиваться нуль-символом.
///
/// \example
/// Например, в результате выполнения следующего кода:
/// \code
/// char  buffer[] = "this is a test string";
/// ReplaceMultipleChars(buffer, "tig",
///                              "TIG");
/// \endcode
///
/// в исходной строке все символы t будут заменены на T, i - на I, g - на G.
/// И, в результате, строка примет вид `ThIs Is a TesT sTrInG`.
void ReplaceMultipleChars(char* string, const char subject[],
                          const char substitution[]);

/// \brief Преобразует младшие 4 бита числа \p value в одну 16-ричную цифру.
char DigitToHex(uint8_t value);

/// \brief Преобразует одну 16-ричную цифру \p value в число.
/// \return Преобразованное значение от 0 до 15 в случае успеха,
/// или -1, если \p value не является 16-ричной цифрой.
int16_t HexToDigit(char value);

/// \brief Преобразовывает байт \p value в его 16-ричное представление и
/// сохраняет результат в буффер \p dst.
/// \warning Данная функция не добавляет ноль в конец полученной строки.
void EncodeByteToHex(char dst[2], uint8_t value);

/// Преобразует строку в шестнадцетиричном формате в число
int32_t DecodeHexToInt(char* src, size_t len);


/// Преобразовывает байт в BCD формат
uint8_t BinToBCD(uint8_t bin);

/// \brief Преобразовывает \p length байт массива \p src в HEX-строку и
/// помещает результат в буффер \p dst.
/// \warning Данная функция не добавляет ноль в конец полученной строки,
/// если такая функциональность нужна, то следует использовать
/// функцию \see CopyHexBytesToString.
void EncodeBytesToHex(char* dst, const void* src, size_t length);

/// \brief Преобразовывает \p length байт массива \p src в HEX-строку и
/// помещает результат в буффер \p dst. В отличие от функции
/// \see EncodeBytesToHex, данная функция добавляет в конец полученной строки
/// завершающий нуль-символ.
void CopyHexBytesToString(char* dst, const void* src, size_t length);

/// \brief Преобразовывает \p datasize байт массива \p data в HEX-строку
/// и помещает результат в буффер \p dst размером \p bufsize.
///
/// Если данные не помещаются в буффер целиком, то копируются только
/// помещающиеся 16-ричные данные, а в конце строки добавляется многоточие.
///
/// Данная функция всегда добавляет завершающий '\0' в строку,
/// параметр bufsize - полный размер буффера, включая завершающий нуль.
void DumpToHexString(char* dst, size_t bufsize, const void* data, size_t datasize);

/// \brief Копирует в буффер \p dst строку \p src и возвращает указатель на
/// конец полученной строки (на завершающий нуль-символ).
/// \return Возвращает указатель на нуль-символ полученной строки.
char* strcpy_ex(char* dst, const char* src);

/// \brief Копирует до \p max_chars_without_zero символов из строки \p src
/// в строку \p dst и возвращает указатель на завершающий нуль-символ,
/// добавленный в целевой буффер.
///
/// Копирование останавливается как только в строке \p src будет обнаружен
/// завершающий нуль-символ, либо будут скопированы max_chars_without_zero
/// символов. После этого в буффер \p dst обязательно добавляется завершающий
/// нуль-символ. Поэтому, в отличие от стандартного strncpy,
/// целевой буффер \p dst обязан быть размером не менее
/// (\p max_chars_without_zero + 1) символов.
///
/// \note Если \p dst равен NULL, то копирование не производится.
/// Если \p src равен NULL, по в целевой буффер \p dst записывается только
/// завершающий нуль-символ.
///
/// \return Возвращает указатель на нуль-символ полученной строки, в отличие
/// от стандартного strncpy, который возвращает указатель на начало буффера.
char* strncpy_ex(char* dst, const char* src, size_t max_chars_without_zero);

/// \brief Аналогично strstr, ищет в строке \p searchee первое вхождение
/// строки \p look_for, НО возвращает указатель на первый символ ПОСЛЕ
/// найденной строки. Если строка \p look_for пуста, то возвращает \p searchee.
/// \example `strstr_ex("12345678", "345")` вернёт строку "678".
/// \return Если искомая строка найдена, то возвращает указатель на символ в
/// строке \p searchee, который следует сразу за найденной строкой. Если же
/// искомая строка не найдена, то возвращает NULL.
char* strstr_ex(const char* searchee, const char* look_for);

char * memcmpstr_ext(const char* searchee, const char* look_for, volatile size_t size);

/// \brief Регистро-независимая версия strstr_ex.
char* stristr_ex(const char* searchee, const char* look_for);

/// \brief Возвращает \true если строка \p str начинается со строки \p prefix.
bool StartsWith(const char* str, const char* prefix);

/// \brief Разбивает строку на токены, ограниченные символами из массива delim.
/// \param dst          Массив строковых указателей, в который будут
///                     сохранены указатели на первые символы найденных токенов.
/// \param max_tokens   Размер массива \p dst.
/// \param s            Строка, которую следует разбить на токены. При разбиении
///                     символы-разделители в данной строке будут заменены
///                     нуль-символами.
/// \param delim        Строка, содержащая все символы-разделители токенов.
/// \param ignore_empty_tokens Если true, то пусные токены будут проигнорированы
/// \param continue_after_dst_full   Если false, то при переполнении
///                     массива токенов данная функция завершится с ошибкой
///                     (т.е. вернёт 0). Если true, то разбор продолжится
///                     до конца строки и функция вернёт полное количество
///                     найденных токенов (даже если их больше, чем max_tokens),
///                     но в массив dst будет сохранено только первые
///                     max_tokens найденных токенов. Для избежания ошибок
///                     следует использовать константы SPLITSTRING_OVERFLOW_IGNORE
///                     и SPLITSTRING_OVERFLOW_ERROR
///
/// \return Количество найденных токенов, или 0 в случае ошибки.
size_t SplitStringEx(char** dst, uint8_t max_tokens, char* s, const char* delim,
                    bool ignore_empty_tokens, bool continue_after_dst_full);

/// \brief Разбивает строку на токены, ограниченные символами из массива delim.
/// \param dst          Массив строковых указателей, в который будут
///                     сохранены указатели на первые символы найденных токенов.
/// \param max_tokens   Размер массива \p dst.
/// \param s            Строка, которую следует разбить на токены. При разбиении
///                     символы-разделители в данной строке будут заменены
///                     нуль-символами.
/// \param delim        Строка, содержащая все символы-разделители токенов.
/// \param ignore_empty_tokens Если true, то пусные токены будут проигнорированы
///
/// \return Количество найденных токенов, или 0 в случае ошибки.
uint8_t SplitString(char** dst, uint8_t max_tokens, char* s, const char* delim,
                    bool ignore_empty_tokens);
#define SPLITSTRING_REMOVE_EMPTY    true
#define SPLITSTRING_KEEP_EMPTY      false
#define SPLITSTRING_OVERFLOW_IGNORE true
#define SPLITSTRING_OVERFLOW_ERROR  false

/// \brief Ищет подстроку \p needle размером \p needlelen в области
/// памяти \p haystack размером \p haystacklen.
/// \return Указатель на первый символ найденной строки или NULL.
void* MemMem(const void *haystack, size_t haystacklen,
             const void *needle,   size_t needlelen);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // STRING_UTILS_H_INCLUDED
