/// @file
/// @brief Системные утилиты, такие, как остановка работы, рестарт, заглушки для
/// системных вызовов компиллятора, и т.д.
/// @author DL <dmitriy.linikov@gmail.com>

#ifndef SYSTEM_UTILS_H_INCLUDED
#define SYSTEM_UTILS_H_INCLUDED

#include "dbg.h"

// Константа для вызова HaltWithReason из dbg.c:__assert_failed()
// Значение выбрано таким для совместимости с предыдущей версией прошивки,
// где не было разделения на библиотеку dbg и приватные для прошивки функции.
// Поскольку в lib_utils больше нет вызовов HaltWithReason,
// то здесь ограничусть только одной константой.
#define SYSUTILS_HALT_REASON_ASSERT_FAILED   0xF0000002

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

#ifdef __GNUC__
// Даём понять gcc компиллятору, что помеченная данным макросом функция
// ни когда не завершается, что бы он мог отпимизировать её вызов.
#define ATTRIBUTE_NORETURN  __attribute__((noreturn))
#else
// Не мешаем работать другим компилляторам, которые не знают,
// что такое аттрибуты.
#define ATTRIBUTE_NORETURN
#define __attribute__(a)
#endif

/// \brief Глобальная переменная, указывающая на причину остановки прошивки.
extern const char* g_halt_reason;

uint32_t Get_Halt_Position(void);
void Set_Halt_Position(uint32_t state);

/// \brief Останавливает работу прошивки с указанием причины остановки.
/// В зависимости от реализации может описание либо выводить в какой-либо
/// порт, либо просто сохранять для возможности проверки отладчиком.
void HaltWithReason(const char* reason, uint32_t state, bool reset) ATTRIBUTE_NORETURN;

/// \brief Необходимая для компилляции заглушка для стандартной библиотеки -
/// Вызывается при выходе из main().
//void _exit(int code) ATTRIBUTE_NORETURN;

/// Оставляет включенным питание RTC часов
void SystemRTCEnabled(bool power_down);

/// перевод числа Big-Little endian 16 бит
uint16_t Change_BL_Endian_UINT16(uint16_t input);
/// перевод числа Big-Little endian 32 бита
uint32_t Change_BL_Endian_UINT32(uint32_t input);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // SYSTEM_UTILS_H_INCLUDED
