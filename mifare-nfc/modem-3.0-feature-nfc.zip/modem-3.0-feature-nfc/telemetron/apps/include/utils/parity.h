/// \file
/// \brief  Данный файл содержит inline функции вычисления чётности
/// \author DL <dmitriy@linikov.ru>

#ifndef TELEMETRON_APPS_INCLUDE_UTILS_PARITY_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_UTILS_PARITY_H_INCLUDED

#include <stdint.h>
#include <stdbool.h>
// The method first shifts and XORs the eight nibbles of the 32-bit value together,
// leaving the result in the lowest nibble of v.
// Next, the binary number 0110 1001 1001 0110 (0x6996 in hex) is shifted
// to the right by the value represented in the lowest nibble of v.
//
// This number is like a miniature 16-bit parity-table indexed by the low
// four bits in v.
// The result has the parity of v in bit 1, which is masked and returned.



static inline bool is_odd8(uint8_t v)
{
  v ^= v >> 4;
  v &= 0xf;
  return (0x6996 >> v) & 1;
}

static inline bool is_odd16(uint16_t v)
{
  v ^= v >> 8;
  v ^= v >> 4;
  v &= 0xf;
  return (0x6996 >> v) & 1;
}

static inline bool is_odd(uint32_t v)
{
  v ^= v >> 16;
  v ^= v >> 8;
  v ^= v >> 4;
  v &= 0xf;
  return (0x6996 >> v) & 1;
}

static inline bool is_even8(uint8_t v)
{
  v ^= v >> 4;
  v &= 0xf;
  return (0x9669 >> v) & 1;
}

static inline bool is_even16(uint16_t v)
{
  v ^= v >> 8;
  v ^= v >> 4;
  v &= 0xf;
  return (0x9669 >> v) & 1;
}

static inline bool is_even(uint32_t v)
{
  v ^= v >> 16;
  v ^= v >> 8;
  v ^= v >> 4;
  v &= 0xf;
  return (0x9669 >> v) & 1;
}


#endif // TELEMETRON_APPS_INCLUDE_UTILS_PARITY_H_INCLUDED
