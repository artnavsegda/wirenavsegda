/// \file
/// \brief  Поток ввода-вывода для использования в модулях ККМ и EVADTS.
/// \author DL <dmitriy@linikov.ru>
///
/// Данный модуль предоставляет единый интерфейс для общения с аппаратурой
/// как через файлы драйверов символьных устройств (например,
/// последовательный порт), так и через потоковые сокеты (например, tcp/ip).
///
/// Дополнительные функции модуля:
///
/// - автоматческий подсчёт контрольных сумм для читаемых и записываемых данных
/// - ведение "сырого" лога записываемых и читаемых данных, возможность
///   записывать так же и произвольную текстовую информацию в этот лог
/// - использование в качестве "логгера" абстрактного потока, который может
///   быть чем угодно: файлом, областью памяти, просто функцией.
/// - работа в неблокирующем режиме и эмуляция блокирующего режима
/// - опциональная буфферизация записи
///
/// \note Данный модуль разрабатывался для NuttX, при портировании в Linux
/// структуру lib_sostream_s, через которую записывается лог,
/// можно заменить на FILE*, возвращаемый функцией fopencookie.


#ifndef TELEMETRON_APPS_INCLUDE_UTILS_SMARTIO_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_UTILS_SMARTIO_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов


#include <stdbool.h>
#include <stdint.h>
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>

#include <nuttx/streams.h>

#include <utils/posix_iohelper.h>
#include <nuttx/telemetron/aux.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Типы данных

// Предварительное объявление типа данных из nuttx/fs/fs.h
struct file;

// Объявлено в <arpa/inet.h>
struct sockaddr_in;

/// Поведение в буфферизованном режиме при переполнении буффера.
typedef enum smartio_buffer_overflow_e {
  /// При переполнении буффера отправлять его данные.
  SMARTIO_BUFOVF_FLUSH,

  /// При переполнении буффера выдавать ошибку -ENOBUFS при вызове
  /// функций `smartio_nbwrite` и `smartio_write` - т.е. непосредственно
  /// в момент возникновения ошибки.
  SMARTIO_BUFOVF_FAIL_ON_WRITE,

  /// При переполнении буффера функции `smartio_nbwrite` или `smartio_write`
  /// всегда возвращают OK, а при вызове функций `smartio_flush` или `smartio_nbflush`
  /// осуществляется проверка на переполнение буффера и в случае переполнения
  /// возвращается код ошибки -ENOBUFS.
  ///
  /// Использование данного подхода позволяет гарантировать, что запись произведётся
  /// за одно действие и при этом нет необходимости проверять каждый вызов write/nbwrite
  SMARTIO_BUFOVF_FAIL_ON_FLUSH
} smartio_buffer_overflow_t;

/// \brief Объект, считающий контрольную сумму при вводе-выводе smartio
typedef struct smartio_crc_s {
  void (*process_byte)(struct smartio_crc_s* crc, uint8_t byte);
  void (*clear)(struct smartio_crc_s* crc);
} smartio_crc_t;


/// \brief  "Умный" поток ввода-вывода для использования в модулях ККМ и EVADTS.
typedef struct smartio_s {
  int                     fd;       ///< Файл для ввода-вывода
  smartio_crc_t*          crc_rx;   ///< Счётчик контрольной суммы принимаемых байт
  smartio_crc_t*          crc_tx;   ///< Счётчик контрольной суммы передаваемых байт
  struct lib_sostream_s*  logger;   ///< Поток, в который записывать сырые данные.
  uint8_t*                txbuf;    ///< Буффер для записываемых данных.
  size_t                  txbuf_sz; ///< Размер буффера для записываемых данных
  size_t                  txbuf_off;///< Количество байт в буффере записываемых данных
  uint8_t                 is_tcp;   ///< 1=сокет, 0=файл
  uint8_t                 txbuf_ovf;  ///< Действие при переполнении буффера.
} smartio_t;


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int     smartio_create(smartio_t* smartio);
int     smartio_destroy(smartio_t* smartio);
int     smartio_open_file(smartio_t* smartio, const char* target);
int     smartio_open_socket(smartio_t* smartio, const char* target, uint32_t timeout_ms);
int     smartio_open_socket_sa(smartio_t* smartio, const struct sockaddr_in* endpoint, uint32_t timeout_ms);
int     smartio_set_comm_params(smartio_t* smartio, speed_t baudrate, serial_wordlen_t wordlen, serial_parity_t parity, serial_flowctl_t flowctl);
int     smartio_get_comm_params(smartio_t* smartio, speed_t* baudrate, serial_wordlen_t* wordlen, serial_parity_t* parity, serial_flowctl_t* flowctl);
int     smartio_set_aux_params(smartio_t* smartio, const aux_settings_t* aux_settings);
int     smartio_get_aux_params(smartio_t* smartio, aux_settings_t* aux_settings);
int     smartio_send_brake(smartio_t* smartio, bool brake_enable);
bool    smartio_isopen(smartio_t* smartio);
int     smartio_close(smartio_t* smartio);
ssize_t smartio_read(smartio_t* smartio, void* buffer, size_t nbytes);
ssize_t smartio_write(smartio_t* smartio, const void* buffer, size_t nbytes);
ssize_t smartio_nbread(smartio_t* smartio, void* buffer, size_t nbytes, int timeout_ms);
ssize_t smartio_nbwrite(smartio_t* smartio, const void* buffer, size_t nbytes, int timeout_ms);
int     smartio_nbputc(smartio_t* smartio, uint8_t ch, int timeout_ms);
int     smartio_nbgetc(smartio_t* smartio, int timeout_ms);
int     smartio_nbputc_flush(smartio_t* smartio, uint8_t ch, int timeout_ms);
int     smartio_flush(smartio_t* smartio);
int     smartio_nbflush(smartio_t* smartio, int timeout_ms);
ssize_t smartio_discard_rx(smartio_t* smartio, int timeout_ms);
int     smartio_set_crc_rx(smartio_t* smartio, smartio_crc_t* crc_rx);
int     smartio_set_crc_tx(smartio_t* smartio, smartio_crc_t* crc_tx);
int     smartio_clear_crc_rx(smartio_t* smartio);
int     smartio_clear_crc_tx(smartio_t* smartio);
int     smartio_set_logger(smartio_t* smartio, struct lib_sostream_s* logger);
int     smartio_logger_flush(smartio_t* smartio);
off_t   smartio_logger_seek(smartio_t* smartio, off_t offset, int whence);
int     smartio_logger_putc(smartio_t* smartio, int ch);
int     smartio_logger_printf(smartio_t* smartio, const char* formatstr, ...);
int     smartio_logger_dump_x8(smartio_t* smartio, uint8_t value);
int     smartio_logger_dump(smartio_t* smartio, const void* array, size_t nbytes);
int     smartio_set_txbuf(smartio_t* smartio, void* buffer, size_t bufsize, smartio_buffer_overflow_t tx_overflow);
int     smartio_get_file(smartio_t* smartio, struct file** dst);


#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_INCLUDE_UTILS_SMARTIO_H_INCLUDED
