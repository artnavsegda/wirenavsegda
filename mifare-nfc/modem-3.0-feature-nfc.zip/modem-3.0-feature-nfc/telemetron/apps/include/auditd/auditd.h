/// \file
/// \brief  Сервис снятия отчётов из торгового автомата.
/// \author DL <dmitriy@linikov.ru>
///
/// Основная задача сервиса - висеть в режиме ожидания и ждать команды
/// снятия отчёта. Если при этом настройками включено автоопределение
/// подключенного типа торгового автомата, то в процессе ожидания
/// сервис так же будет периодически делать попытки подключения.
///
/// Данные, полученные от автомата сохраняются в заданный настройками файл.
///
/// Поскольку auditd_t унаследован от service_t, то указатель на него можно
/// передавать в функци, работающие с service_t.
#ifndef CONFIG_TELEMETRON_APPS_LIB_AUDITD_INCLUDED
#define CONFIG_TELEMETRON_APPS_LIB_AUDITD_INCLUDED

#include "auditd_config.h"
#include "audit_protocol.h"
#include <utils/service.h>



typedef struct auditd_s     auditd_t;




#ifdef __cplusplus
extern "C" {
#endif


int       auditd_create(auditd_t** dst, int id, const char* tty_path, const char* out_path, const char* queue);
int       auditd_destroy(auditd_t* auditd);
auditd_t* auditd_find_instance(int id);
int       auditd_setup(auditd_t* auditd, const aux_params_t* settings, bool use_autodetect);
int       auditd_wake(auditd_t* auditd);

const aux_params_t* auditd_get_settings(auditd_t* auditd);
bool                auditd_get_autodetect(auditd_t* auditd);
bool                auditd_is_enabled(auditd_t* auditd);

//audit_protocol_t    auditd_get_protocol(auditd_t* auditd);
//audit_interface_t   auditd_get_interface(auditd_t* auditd);
//bool                auditd_get_saeco_fix(auditd_t* auditd);
#ifdef __cplusplus
} // extern "C"
#endif



static inline int auditd_start(auditd_t* auditd)
{
  return service_start((service_t*)auditd);
}

static inline int auditd_kill(auditd_t* auditd)
{
  return service_kill((service_t*)auditd);
}

static inline int auditd_wait_terminated(auditd_t* auditd, int timeout_ms)
{
  return service_wait_terminated((service_t*)auditd, timeout_ms);
}

static inline int auditd_kill_and_wait(auditd_t* auditd, int timeout_ms)
{
  return service_kill_and_wait((service_t*)auditd, timeout_ms);
}

static inline bool auditd_is_started(auditd_t* auditd)
{
  return service_is_started((service_t*)auditd);
}


#endif // CONFIG_TELEMETRON_APPS_LIB_AUDITD_INCLUDED
