/// \file
/// \brief  Определение всех событий сервиса аудита.
/// \author DL <dmitriy@linikov.ru>


#ifndef TELEMETRON_APPS_INCLUDE_AUDITD_AUDIT_EVENTS_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_AUDITD_AUDIT_EVENTS_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "auditd_config.h"
#include "audit_state.h"
#include "audit_protocol.h"

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

#define AUDIT_EV_BASE    150

/// \ingroup fw_events
/// \brief Событие об изменении состояния сервиса auditd
///
/// Всегда имеет вложение типа ev_audit_state_t
#define EV_AUDIT_STATE      (AUDIT_EV_BASE + 0)

/// \ingroup fw_events
/// \brief Событие, отправляемое при завершении (или ошибке) снятия отчёта
///
/// Всегда имеет вложение типа ev_audit_report_t
#define EV_AUDIT_REPORT     (AUDIT_EV_BASE + 1)

////////////////////////////////////////////////////////////////////////////
//  Типы данных

typedef struct ev_audit_state_s {
  int               instance_id;            ///< номер экземпляра сервиса
  audit_protocol_t  protocol;               ///< Код протокола
  audit_interface_t interface;              ///< Аппаратный интерфейс (232,ttl,485)
  ddcmp_saeco_fix_t saeco_fix;              ///< Использован ли фикс для Saeco
  audit_state_t     state;                  ///< Текущее состояние
} ev_audit_state_t;

typedef struct ev_audit_report_s {
  int               instance_id;            ///< номер экземпляра сервиса
  audit_protocol_t  protocol;               ///< Код протокола
  audit_interface_t interface;              ///< Аппаратный интерфейс (232,ttl,485)
  uint32_t          error_code;             ///< Код ошибки отчёта
  size_t            report_size;            ///< Размер отчёта
  ddcmp_saeco_fix_t saeco_fix;              ///< Использован ли фикс для Saeco
  char              path[AUDITD_TTYPATH_MAX];   ///< Путь к отчёту
} ev_audit_report_t;


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_INCLUDE_AUDITD_AUDIT_EVENTS_H_INCLUDED
