/// \file
/// \brief  Настройки времени компиляции для модуля lib_auditd
/// \author DL <dmitriy@linikov.ru>


#ifndef TELEMETRON_APPS_INCLUDE_AUDITD_AUDITD_CONFIG_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_AUDITD_AUDITD_CONFIG_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <nuttx/config.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

#if !defined(CONFIG_LIB_AUDITD_MAX_INSTANCES) || defined(__DOXYGEN__)
/// \brief  Количество статически созданных экземпляров сервиса auditd.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_AUDITD_MAX_INSTANCES          3
#endif


#if !defined(CONFIG_LIB_AUDITD_MAX_REPORT_SIZE) || defined(__DOXYGEN__)
/// \brief  Максимально возможный размер отчёта аудита (если больше - будет усечён)
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_AUDITD_MAX_REPORT_SIZE    60000
#endif



#if !defined(CONFIG_LIB_AUDITD_AUTODETECT_MINUTTES) || defined(__DOXYGEN__)
/// \brief  Время в минутах между попытками обнаружить используемый протокол
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_AUDITD_AUTODETECT_MINUTTES    15
#endif


#if !defined(CONFIG_LIB_AUDITD_DAEMON_PRIORITY) || defined(__DOXYGEN__)
/// \brief  Приоритет потока сервиса auditd
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_AUDITD_DAEMON_PRIORITY        104
#endif


#if !defined(CONFIG_LIB_AUDITD_DAEMON_STACKSIZE) || defined(__DOXYGEN__)
/// \brief  Размер стека для потока сервиса auditd
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_AUDITD_DAEMON_STACKSIZE       2048
#endif





#ifdef CONFIG_LIB_AUDITD_DEBUG_ERROR
#   define auditd_error(format, ...) _err(format, ##__VA_ARGS__)
#   define auditd_perror(what, ret)  _err("ERROR: %s. ret=%d (%s)\n", (ret), strerror((ret)))
#else
#   define auditd_error(x...)
#   define auditd_perror(what, ret)
#endif

#ifdef CONFIG_LIB_AUDITD_DEBUG_WARN
#   define auditd_warn(format, ...) _warn(format, ##__VA_ARGS__)
#else
#   define auditd_warn(x...)
#endif

#ifdef CONFIG_LIB_AUDITD_DEBUG_INFO
#   define auditd_info(format, ...) _info(format, ##__VA_ARGS__)
#else
#   define auditd_info(x...)
#endif

#ifdef CONFIG_LIB_AUDITD_DEBUG_DEBUG
#   define auditd_debug(format, ...) _info(format, ##__VA_ARGS__)
#else
#   define auditd_debug(x...)
#endif

#ifdef CONFIG_LIB_AUDITD_DEBUG_TRACE
#   define auditd_trace(format, ...) _info(format, ##__VA_ARGS__)
#   define auditd_dump(msg, buf, sz) infodumpbuffer((msg), (const uint8_t*)(buf), (sz))
#else
#   define auditd_trace(x...)
#   define auditd_dump(msg, buf, sz)
#endif


#define AUDITD_PROTONAME_MAX        15
#define AUDITD_TTYPATH_MAX          16
#define AUDITD_OUTPATH_MAX          24



#endif // TELEMETRON_APPS_INCLUDE_AUDITD_AUDITD_CONFIG_H_INCLUDED
