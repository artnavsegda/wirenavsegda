/// \file
/// \brief  Перечисление известных протоколов аудита
/// \author DL <dmitriy@linikov.ru>


#ifndef TELEMETRON_APPS_INCLUDE_AUDITD_AUDIT_PROTOCOL_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_AUDITD_AUDIT_PROTOCOL_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <settings/settings.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Типы данных

/// \brief  Протокол общения с торговым автоматом для снятия отчёта
typedef aux_type_t  audit_protocol_t;

/// \brief Аппаратный интерфейс подключения к торговому автомату для снятия отчёта
typedef aux_interface_t audit_interface_t;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

const char* audit_protocol_to_string(audit_protocol_t value);
const char* audit_interface_to_string(audit_interface_t value);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_INCLUDE_AUDITD_AUDIT_PROTOCOL_H_INCLUDED
