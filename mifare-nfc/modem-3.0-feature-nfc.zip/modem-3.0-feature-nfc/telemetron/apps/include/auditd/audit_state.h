/// @file
/// @brief Перечисление всех доступных состояний обмена по шинам DEX/DDCMP
/// @author DL <dmitriy.linikov@gmail.com>

#ifndef ENUM_AUDIT_STATE_H_INCLUDED
#define ENUM_AUDIT_STATE_H_INCLUDED

typedef enum {
  AUDIT_STATE_UNDEFINED = 0,
  AUDIT_STATE_IDLE,
  AUDIT_STATE_CONNECTING,
  AUDIT_STATE_DATA_TRANSFER,
  AUDIT_STATE_DDCMP_CONNECTING,
  AUDIT_STATE_DDCMP_DATA_TRANSFER,
  AUDIT_STATE_ERROR,
  AUDIT_STATE_FAST_DATA_TRANSFER,
} audit_state_t;

typedef void (*dex_state_listener_t)(audit_state_t state);

#endif // ENUM_AUDIT_STATE_H_INCLUDED
