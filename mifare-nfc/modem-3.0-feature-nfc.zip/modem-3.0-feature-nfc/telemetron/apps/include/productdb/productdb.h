/// \file
/// \brief  Библиотека для работы с базой данных напитков.
/// \author DL <dmitriy@linikov.ru>

#ifndef CONFIG_TELEMETRON_APPS_LIB_PRODUCTDB_INCLUDED
#define CONFIG_TELEMETRON_APPS_LIB_PRODUCTDB_INCLUDED

#include <nuttx/config.h>
#include <stdint.h>
#include <semaphore.h>

/// \brief Максимальный размер наименования продукта
#define DB_PRODUCT_NAME_LEN                 (256-2-2)

/// \brief Полином записи БД
#define DB_GUARD_POLINOM                    0x1205

/// \brief Максимальная длина (включая '\0') имени базы данных
#define DB_DBNAME_LENGTH                    8

/// \brief Максимальная длина (включая '\0') пути к файлу базы данных
#define DB_MAXPATH                          24


#if !defined(CONFIG_LIB_PRODUCTDB_MAX_FILESIZE) || defined(__DOXYGEN__)
/// \brief  Максимальный размер файла базы данных
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_PRODUCTDB_MAX_FILESIZE  65536
#endif


#ifdef CONFIG_LIB_PRODUCTDB_DEBUG_ERROR
#   define productdb_error(format, ...) _err("DB:" format, ##__VA_ARGS__)
#else
#   define productdb_error(x...)
#endif

#ifdef CONFIG_LIB_PRODUCTDB_DEBUG_WARN
#   define productdb_warn(format, ...) _warn("DB:" format, ##__VA_ARGS__)
#else
#   define productdb_warn(x...)
#endif

#ifdef CONFIG_LIB_PRODUCTDB_DEBUG_INFO
#   define productdb_info(format, ...) _info("DB:" format, ##__VA_ARGS__)
#else
#   define productdb_info(x...)
#endif

#ifdef CONFIG_LIB_PRODUCTDB_DEBUG_DEBUG
#   define productdb_debug(format, ...) _info("DB:" format, ##__VA_ARGS__)
#   define productdb_debugdump(msg, buf, sz) infodumpbuffer(("DB:" msg), (const uint8_t*)(buf), (sz))
#else
#   define productdb_debug(x...)
#   define productdb_debugdump(msg, buf, sz)
#endif

#ifdef CONFIG_LIB_PRODUCTDB_DEBUG_TRACE
#   define productdb_trace(format, ...) _info("DB:" format, ##__VA_ARGS__)
#   define productdb_dump(msg, buf, sz) infodumpbuffer(("DB:" msg), (const uint8_t*)(buf), (sz))
#else
#   define productdb_trace(x...)
#   define productdb_dump(msg, buf, sz)
#endif

/// \brief Структура записи продукта в БД
typedef struct product_rec_s {
  uint16_t  crc;
  uint16_t  id;
  char      name[DB_PRODUCT_NAME_LEN];
} product_rec_t;

typedef struct productdb_s {
  int       fd;
  sem_t*    lock;
} productdb_t;




#ifdef __cplusplus
extern "C" {
#endif

int productdb_create(productdb_t* db, const char* dbname);
int productdb_destroy(productdb_t* db);
int productdb_find(productdb_t* db, uint16_t rec_id, product_rec_t* rec);
int productdb_clean(productdb_t* db);
int productdb_add(productdb_t* db, product_rec_t* rec);
int productdb_readfirst(productdb_t* db, product_rec_t* rec);
int productdb_readnext(productdb_t* db, product_rec_t* rec);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // CONFIG_TELEMETRON_APPS_LIB_PRODUCTDB_INCLUDED
