/// \file
/// \brief  Перечень событий, отправляемых сервисом в вышестоящий код
/// \author DL <dmitriy@linikov.ru>

#ifndef CONFIG_TELEMETRON_APPS_INCLUDE_SRVD_EVENTS_H_INCLUDED
#define CONFIG_TELEMETRON_APPS_INCLUDE_SRVD_EVENTS_H_INCLUDED

#include <time.h>
#include <srvd/srvd_http_rsp.h>

#define SRVD_COMMAND_MAX_SIZE     255

/// \brief Начальный номер событий от srvd
#define EV_SRVD_BASE              0x0200

/// \ingroup fw_events
/// \brief Событие изменения состояния сервиса связи с сервером
///
/// Данное событие всегда имеет вложение типа \ref ev_srvd_state_t
#define EV_SRVD_STATE             (EV_SRVD_BASE + 0)

/// \ingroup fw_events
/// \brief Событие получения команды от сервера
///
/// Данное событие всегда имеет вложение типа \ref ev_srvd_command_t
#define EV_SRVD_COMMAND           (EV_SRVD_BASE + 1)

/// \ingroup fw_events
/// \brief Событие начала обработки ответа сервера.
///
/// \todo Решить, нужно ли дублировать SERVER_STATE_NOT_AVAILABLE,
/// отправляя ещё и EV_SRVD_TRANSACTION_START для ошибочных ответов сервера.
///
/// Данное событие отправляется каждый раз при получении ответа сервера
/// в том числе и в случаях получения HTTP ответов с отличным от 200 кодом
///
/// Данное событие всегда имеет вложение типа \ref ev_srvd_transaction_start_t
#define EV_SRVD_TRANSACTION_START (EV_SRVD_BASE + 2)

/// \ingroup fw_events
/// \brief Событие завершения обработки ответа сервера
///
/// Данное событие отправляется каждый раз при завершении обработки ответа
/// сервера.
///
/// Данное событие всегда имеет вложение типа \ref ev_srvd_transaction_end_t
#define EV_SRVD_TRANSACTION_END   (EV_SRVD_BASE + 3)

typedef enum srvd_state_e {
  SERVER_STATE_UNDEFINED = 0,

  // Переименовал состояние SERVER_STATE_UNDEFINED в SERVER_STATE_CHECK_NET
  // что бы не пришлось менять существующий внешний код и при этом
  // используемая здесь константа больше соответствовала смыслу.
  SERVER_STATE_CHECK_NET = SERVER_STATE_UNDEFINED,

  SERVER_STATE_DISCONNECTED,
  SERVER_STATE_CONNECTING,
  SERVER_STATE_DATA_EXCHANGE,
  SERVER_STATE_ONLINE,
  SERVER_STATE_SERVER_NOT_AVAILABLE,
  SERVER_STATE_INVALID_SERVER_RESPONSE,

  // Начальное состояние сервиса. Обычно не для использования внешним кодом.
  SERVER_STATE_INITIAL = 255
} srvd_state_t;


/// \brief Данные события изменения состояния сервиса общения с сервером.
struct ev_srvd_state_s {
  srvd_state_t          state;
};

/// \brief Данные события изменения состояния сервиса общения с сервером.
typedef struct ev_srvd_state_s ev_srvd_state_t;


/// \brief Данные события получения команды от сервера
/// \warning Актуальная длина данных хранится в поле eventq_event_t::size,
/// При этом сами данные всегда заверешны нуль-символом, нульсимвол
/// входит в размер данных пакета.
struct ev_srvd_command_s {
  char                  text[SRVD_COMMAND_MAX_SIZE+1];
};

/// \brief Данные события получения команды от сервера
typedef struct ev_srvd_command_s ev_srvd_command_t;

/// \brief Информация о полученом от сервера пакете с данными
struct ev_srvd_transaction_start_s {
  srvd_http_rsp_t       http_response;      ///< Информация об HTTP ответе сервера
  struct timespec       ts_connected;       ///< Время, когда подключились к серверу
  struct timespec       ts_request_end;     ///< Время, когда передали последний байт запроса
  struct timespec       ts_response_start;  ///< Время, когда получили первый байт ответа
  struct timespec       ts_response_end;    ///< Время. когда получили последний байт ответа
};

/// \brief Информация о полученом от сервера пакете с данными
typedef struct ev_srvd_transaction_start_s    ev_srvd_transaction_start_t;


/// \brief Данные события завершения обработки пакета от сервера
struct ev_srvd_transaction_end_s {
  int                   processing_result;  ///< Результат парсинга HTTP ответа.
};

/// \brief Данные события завершения обработки пакета от сервера
typedef struct ev_srvd_transaction_end_s      ev_srvd_transaction_end_t;

#ifdef __cplusplus
extern "C" {
#endif

const char* srvd_state_to_string(srvd_state_t value);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // CONFIG_TELEMETRON_APPS_INCLUDE_SRVD_EVENTS_H_INCLUDED
