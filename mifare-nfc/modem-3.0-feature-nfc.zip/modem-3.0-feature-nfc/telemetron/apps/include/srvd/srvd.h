/// \file
/// \brief  Server communication daemon - сервис общения с сервером.
/// \author DL <dmitriy@linikov.ru>

#ifndef CONFIG_TELEMETRON_APPS_LIB_SRVD_INCLUDED
#define CONFIG_TELEMETRON_APPS_LIB_SRVD_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов


#include <utils/service.h>


////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


#if !defined(CONFIG_LIB_SRVD_DAEMON_PRIORITY) || defined(__DOXYGEN__)
/// \brief  Приоритет потока сервиса общения с сервером.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_SRVD_DAEMON_PRIORITY                    102
#endif


#if !defined(CONFIG_LIB_SRVD_DAEMON_STACK_SIZE) || defined(__DOXYGEN__)
/// \brief  Размер стека потока сервиса общения с сервером
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_SRVD_DAEMON_STACK_SIZE                  3072
#endif


#if !defined(CONFIG_LIB_SRVD_T_NET_RECOVERY_MS) || defined(__DOXYGEN__)
/// \brief Время ожидания после неудачной проверки наличия доступа в сеть.
# define CONFIG_LIB_SRVD_T_NET_RECOVERY_MS                  10000
#endif


#if !defined(CONFIG_LIB_SRVD_T_NOT_AVAIL_RECOVERY_MS) || defined(__DOXYGEN__)
/// \brief Время ожидания после ошибки "сервер недоступен"
# define CONFIG_LIB_SRVD_T_NOT_AVAIL_RECOVERY_MS            60000
#endif


#if !defined(CONFIG_LIB_SRVD_T_INVALID_RESPONSE_RECOVERY_MS) || defined(__DOXYGEN__)
/// \brief Время ожидания после ошибки "неправильный ответ сервера"
# define CONFIG_LIB_SRVD_T_INVALID_RESPONSE_RECOVERY_MS     60000
#endif


#if !defined(CONFIG_LIB_SRVD_DEFAULT_T_PING_MS) || defined(__DOXYGEN__)
/// \brief Максимальное время между запросами к серверу.
///
/// Если с момента любого последнего запроса к серверу
/// (при условии наличия доступа в сеть) прошло CONFIG_LIB_SRVD_DEFAULT_T_PING_MS миллисекунд,
/// то при отсутствии других сообщений в очереди, сервис самостоятельно
/// отправить ping запрос серверу.
///
/// Если же по истечение данного таймаута сеть была недоступна,
/// то ping запрос будет отправлен на сервер как только появится доступ к сети.
///
/// \note Данный параметр задаёт лишь стандартное значение, используемое,
/// если настройками явно не было задано другое.
# define CONFIG_LIB_SRVD_DEFAULT_T_PING_MS                  30000
#endif


#if !defined(CONFIG_LIB_SRVD_T_OUTPUT_QUEUE_WAIT_MS) || defined(__DOXYGEN__)
/// \brief Максимальное время ожидания наличия места в исходящей очереди сообщений
# define CONFIG_LIB_SRVD_T_OUTPUT_QUEUE_WAIT_MS             500
#endif


#if !defined(CONFIG_LIB_SRVD_T_LOCK_INPUT_MS) || defined(__DOXYGEN__)
/// \brief Максимальное время ожидания получения монопольного доступа к входящей очереди
# define CONFIG_LIB_SRVD_T_LOCK_INPUT_MS                    500
#endif


#if !defined(CONFIG_LIB_SRVD_DEFAULT_SERVER_NAME) || defined(__DOXYGEN__)
/// \brief Имя сервера (без пути), используемое, если не задано настройками.
# define CONFIG_LIB_SRVD_DEFAULT_SERVER_NAME    "my.rc.telemetron.net"
#endif


#if !defined(CONFIG_LIB_SRVD_DEFAULT_SERVER_PORT) || defined(__DOXYGEN__)
/// \brief Порт сервера, используемый, если не задано настройками.
# define CONFIG_LIB_SRVD_DEFAULT_SERVER_PORT    80
#endif


#if !defined(CONFIG_LIB_SRVD_DEFAULT_SERVER_PATH) || defined(__DOXYGEN__)
/// \brief Путь к сервису приёма данных на сервере, используемый, если не задано настройками.
# define CONFIG_LIB_SRVD_DEFAULT_SERVER_PATH    "/data/"
#endif

#if !defined(CONFIG_LIB_SRVD_IMEI_PATH) || defined(__DOXYGEN__)
/// \brief  Путь к файлу, хранящему номер GSM модуля (IMEI).
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_SRVD_IMEI_PATH              "/proc/gsm0/imei"
#endif

#if !defined(CONFIG_LIB_SRVD_ICCID_PATH) || defined(__DOXYGEN__)
/// \brief  Путь к файлу, хранящему номер симкарты ICCID
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_SRVD_ICCID_PATH             "/proc/gsm0/iccid"
#endif

#ifdef CONFIG_LIB_SRVD_DEBUG_ERROR
#   define srvd_error(format, ...) _err("SRVD:" format, ##__VA_ARGS__)
#else
#   define srvd_error(x...)
#endif

#ifdef CONFIG_LIB_SRVD_DEBUG_WARN
#   define srvd_warn(format, ...) _warn("SRVD:" format, ##__VA_ARGS__)
#else
#   define srvd_warn(x...)
#endif

#ifdef CONFIG_LIB_SRVD_DEBUG_INFO
#   define srvd_info(format, ...) _info("SRVD:" format, ##__VA_ARGS__)
#else
#   define srvd_info(x...)
#endif

#ifdef CONFIG_LIB_SRVD_DEBUG_DEBUG
#   define srvd_debug(format, ...) _info("SRVD:" format, ##__VA_ARGS__)
#   define srvd_debugdump(msg, buf, sz) infodumpbuffer(("SRVD:" msg), (const uint8_t*)(buf), (sz))
#else
#   define srvd_debug(x...)
#   define srvd_debugdump(msg, buf, sz)
#endif

#ifdef CONFIG_LIB_SRVD_DEBUG_TRACE
#   define srvd_trace(format, ...) _info("SRVD:" format, ##__VA_ARGS__)
#   define srvd_dump(msg, buf, sz) infodumpbuffer(("SRVD:" msg), (const uint8_t*)(buf), (sz))
#else
#   define srvd_trace(x...)
#   define srvd_dump(msg, buf, sz)
#endif



#define CONFIG_SRVD_IMEI_BUFFER_SIZE    16
#define CONFIG_SRVD_ICCID_BUFFER_SIZE   21


////////////////////////////////////////////////////////////////////////////
//  Типы данных


typedef struct srvd_settings_s {
  /// \brief Имя очереди входящих (для сервиса) сообщений
  ///        т.е. сообщений, отправляемых устройством на сервер.
  const char* in_queue_name;

  /// \brief Имя очереди исходящих сообщений, т.е. сообщений,
  ///        получаемых от сервера.
  ///
  /// Если NULL, то не используется.
  const char* out_queue_name;

  /// \brief Путь к файлу с данными, которые нужно прикладывать к любому запросу.
  ///
  /// Если NULL, то не используется.
  const char* third_flow_path;

  /// \brief Доменное имя сервера (или IP адрес)
  const char* server_name;

  /// \brief Номер порта, на котором слушает сервер.
  int         server_port;

  /// \brief Путь к сервису обработки данных на сервере.
  const char* server_path;

  /// \brief Информация об отправителе
  const char* user_agent;

  /// \brief Время между ping запросами.
  ///
  /// Если 0, то используется `CONFIG_SRVD_T_PING_MS`.
  long        t_ping_ms;
} srvd_settings_t;


typedef struct srvd_s     srvd_t;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант


#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


#ifdef __cplusplus
extern "C" {
#endif

srvd_t* srvd_get_instance(void);

int     srvd_setup          (srvd_t* me, const srvd_settings_t* settings);
int     srvd_set_server_name(srvd_t* me, const char* server_name);
int     srvd_set_server_port(srvd_t* me, int         server_port);
int     srvd_set_server_path(srvd_t* me, const char* server_path);
int     srvd_set_t_ping_ms  (srvd_t* me, long        t_ping_ms);


#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  inline функции для упрощения операций над базовым объектом service_t


/// \brief Запускает процесс сервиса.
///
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno)
/// \retval `0`           Функция завершилась успешно.
/// \retval `-ESRCH`      Экземпляр сервиса \p service не зарегистрирован.
/// \retval `-EALREADY`   Процесс сервиса \p service уже запущен.
static inline int srvd_start(srvd_t* me)
{
  return service_start((service_t*)me);
}

/// \brief Отправляет сервису сигнал SIGINT что бы он завершил
/// свою работу.
///
/// \note Узнать, завершился ли процесс, можно поллингом
/// функции service_is_started
static inline int srvd_kill(srvd_t* me)
{
  return service_kill((service_t*)me);
}

/// \brief Ожидание завершения процесса сервиса.
///
///
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno)
/// \retval `0`           Функция завершилась успешно.
/// \retval `-EINVAL`     Некорректные параметры функции.
/// \retval `-EINTR`     Было получено внешнее прерывание.
/// \retval `-ETIMEDOUT` Истекло время ожидания доступности семафора.
static inline int srvd_wait_terminated(srvd_t* me, int wait_ms)
{
  return service_wait_terminated((service_t*)me, wait_ms);
}

/// \brief Возвращает true, если сервисный процесс был создан.
/// \note  Это не обязательно означает, что процесс уже вошёл
/// в свою основную функцию.
static inline int srvd_is_started(srvd_t* me)
{
  return service_is_started((service_t*)me);
}

/// \brief Возвращает true, если сервисный процесс выполняется.
/// \note  Если возвращается true, то процесс уже точно вошёл
/// в свою основную функцию
static inline int srvd_is_alive(srvd_t* me)
{
  return service_is_alive((service_t*)me);
}

/// \brief Получение монопольного доступа к сервису.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno)
/// \retval `0`          Функция завершилась успешно.
/// \retval `-EINVAL`    Некорректные параметры функции.
/// \retval `-EINTR`     Было получено внешнее прерывание.
static inline int srvd_lock(srvd_t* me)
{
  return service_lock((service_t*)me);
}

/// \brief Получение монопольного доступа к сервису, игнорируя прерывания.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno)
/// \retval `0`          Функция завершилась успешно.
static inline void srvd_force_lock(srvd_t* me)
{
  service_force_lock((service_t*)me);
}

/// \brief Получение монопольного доступа к процессу с ограничением
/// максимального времени ожидания доступности семафора.
///
/// - Если `timeout_ms < 0`, то данная функция ожидает, пока
///   не дождётся доступности семафора, либо пока не будет
///   прервана внешним сигналом.
///
/// - Если `timeout_ms == 0`, то данная функция выполняется
///   без блокировки потока.
///
/// - Если `timeout_ms > 0`, то данная функция ожидает
///   доступности семафора до \p timeout_ms миллисекунд.
///
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno)
/// \retval `0`          Функция завершилась успешно.
/// \retval `-EINVAL`    Некорректные параметры функции.
/// \retval `-EINTR`     Было получено внешнее прерывание.
/// \retval `-ETIMEDOUT` Истекло время ожидания доступности семафора.
static inline int srvd_lock_timeout(srvd_t* me, int timeout_ms)
{
  return service_lock_timeout((service_t*)me, timeout_ms);
}

/// \brief Освобождение сервиса от блокировки монопольного доступа.
static inline int srvd_unlock(srvd_t* me)
{
  return service_unlock((service_t*)me);
}

/// \brief Возвращает true, если было получено прерывание SIGINT
static inline bool srvd_should_stop(srvd_t* me)
{
  return service_should_stop((service_t*)me);
}

////////////////////////////////////////////////////////////////////////////
//  Прочие inline функции

static inline int srvd_setup_and_start(srvd_t* me, const srvd_settings_t* settings)
{
  int ret = srvd_setup(me, settings);
  if (ret < 0) {
    return ret;
  }
  return srvd_start(me);
}


#endif // CONFIG_TELEMETRON_APPS_LIB_SRVD_INCLUDED
