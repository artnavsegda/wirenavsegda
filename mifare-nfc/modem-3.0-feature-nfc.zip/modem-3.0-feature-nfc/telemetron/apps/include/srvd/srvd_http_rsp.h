/// \file
/// \brief  Внутреннее для srvd описание HTTP ответа сервера
/// \author DL <dmitriy@linikov.ru>


#ifndef TELEMETRON_APPS_INCLUDE_SRVD_SRVD_HTTP_RSP_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_SRVD_SRVD_HTTP_RSP_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <stdint.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Типы данных

/// \brief  Внутреннее для srvd описание HTTP ответа сервера
typedef struct srvd_http_rsp_s {
  char      http_version_major;   ///< Версия HTTP протокола (старший байт)
  char      http_version_minor;   ///< Версия HTTP протокола (младший байт)
  int       http_status;          ///< Статус HTTP запроса (например, 200)
  int       content_length;       ///< Значение заголовка Content-Length
  long      content_offset;       ///< Смещение тела ответа от начала ответа сервера
  long      response_length;      ///< Полный размер ответа сервера в байтах
  int32_t   x_checksum;           ///< Значение заголовка X-Checksum
  uint16_t  calc_checksum;        ///< Контрольная сумма, вычисленная для ответа сервера.
} srvd_http_rsp_t;


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_INCLUDE_SRVD_SRVD_HTTP_RSP_H_INCLUDED
