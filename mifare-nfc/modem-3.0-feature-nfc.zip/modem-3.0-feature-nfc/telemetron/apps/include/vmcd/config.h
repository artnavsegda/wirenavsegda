/// \file
/// \brief  Константы настроек сервиса `vmcd`, задаваемые через Kconfig.
/// \author DL <dmitriy@linikov.ru>

#ifndef TELEMETRON_APPS_INCLUDE_VMCD_CONFIG_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_VMCD_CONFIG_H_INCLUDED


#include <nuttx/config.h>   // Автоматически сгенерирован утилитой Kconfig


#if !defined(CONFIG_LIB_VMCD_DEV_MAXPATH) || defined(__DOXYGEN__)
/// \brief Размер буффера для хранения пути к драйверам и файлам
///
/// Поскольку vmcd подразумевает запуск из nsh, то для экономии памяти
/// будет логичным перед запуском удалить все переменные среды, в том числе
/// путь запуска и параметры. Из-за этого не стоит передавать имена используемых
/// драйверов указателями на строки, а лучше хранить напрямую в структуре
/// с настройками. Что бы уменьшить количество необходимой памяти, следует
/// держать эти буфферы как можно меньше.
///
/// Стандартный размер в 20 байт выбран исходя из использования максимального
/// имени файла `/tmp/vmcd0/status` и выравнивания до 4 байт.
///
/// Значение данной константы задаётся параметром LIB_VMCD_DEV_MAXPATH
/// через утилиту настроек `make menuconfig`
# define VMCD_MAXPATH       20
#else
# define VMCD_MAXPATH       CONFIG_LIB_VMCD_DEV_MAXPATH
#endif



#if !defined(CONFIG_LIB_VMCD_MAX_INSTANCE_COUNT) || defined(__DOXYGEN__)
/// \brief Максимальное одновременное количество работающих экземпляров сервиса vmcd
///
/// Данная константа задаётся параметром LIB_VMCD_MAX_INSTANCE_COUNT
/// через утилиту настроек `make menuconfig`.
///
/// Стандартно, поддерживается единственный экземпляр сервиса.
# define VMCD_MAX_INSTANCE_COUNT  1
#else
# define VMCD_MAX_INSTANCE_COUNT  CONFIG_LIB_VMCD_MAX_INSTANCE_COUNT
#endif



#if !defined(CONFIG_LIB_VMCD_BASEDIR) || defined(__DOXYGEN__)
/// \brief Имя директории, в которой следует хранить директории состояния сервиса vmcd
///
/// Данная константа задаётся параметром LIB_VMCD_BASEDIR
/// через утилиту настроек `make menuconfig`.
///
/// Стандартное значение - "/tmp"
# define VMCD_BASEDIR       "/tmp"
#else
# define VMCD_BASEDIR       CONFIG_LIB_VMCD_BASEDIR
#endif


#if !defined(CONFIG_LIB_VMCD_EVENTQUEUE_DEPTH) || defined(__DOXYGEN__)
/// \brief Максимальное количество непрочитанных сообщений в очереди исходящих.
# define VMCD_EVENTQ_DEPTH  5
#else
# define VMCD_EVENTQ_DEPTH  CONFIG_LIB_VMCD_EVENTQUEUE_DEPTH
#endif


#endif // TELEMETRON_APPS_INCLUDE_VMCD_CONFIG_H_INCLUDED
