/// \file
/// \brief  Структура, хранящая настройки (времени исполнения) сервиса `vmcd`.
/// \author DL <dmitriy@linikov.ru>

#ifndef CONFIG_TELEMETRON_APPS_INCLUDE_VMCD_VMCD_SETTINGS_H_INCLUDED
#define CONFIG_TELEMETRON_APPS_INCLUDE_VMCD_VMCD_SETTINGS_H_INCLUDED

#include <stddef.h>
#include <vmcd/vmcbus_id.h>
#include <vmcd/vmcd_path.h>

#define VMCD_DEFAULTS_VMCBUS_RX_TIMEOUT_MS      200
#define VMCD_DEFAULTS_VMCBUS_ERROR_TIMEOUT_MS   180000

/// \brief Структура, описывающая настройки сервиса vmcd
typedef struct vmcd_settings_s {
  /// \brief Номер экземпляра
  int                     instance_id;

  /// \brief Имя драйвера, через который слушать передачи от ведущего ведомым
  vmcd_path_t             tty_master_to_slave;

  /// \brief Имя драйвера, через который слушать передачи от ведомых ведущему
  vmcd_path_t             tty_slave_to_master;

  /// \brief ожидаемый тип шины.
  ///
  /// Если данное значение равно нулю, то используется автообнаружение типа.
  ///
  /// Если данное значение равно положительному числу, то используется шина
  /// с типом `bus_id`, но в случае ошибок осуществляется автообнаружение.
  ///
  /// Если данное значение равно отрищательному числу, то используется шина
  /// с типом `-bus_id`, в случае ошибок автообнаружение не осуществляется.
  /// \note Перечень доступных типов шины: \ref vmcbus_id_t.
  int           bus_id;


  /// \brief Максимальное время ожидания данных из последовательного порта.
  /// Если <= 0, то будет использовано стандартное значение.
  int           vmcbus_rx_timeout_ms;

  /// \brief Время без данных, через которое шина переходит в состояние аварии.
  /// Если <= 0, то будет использовано стандартное значение.
  int           vmcbus_error_timeout_ms;
} vmcd_settings_t;



#endif // CONFIG_TELEMETRON_APPS_INCLUDE_VMCD_VMCD_SETTINGS_H_INCLUDED
