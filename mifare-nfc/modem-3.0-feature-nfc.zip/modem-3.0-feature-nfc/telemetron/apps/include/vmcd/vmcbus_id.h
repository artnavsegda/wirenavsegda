/// \file
/// \brief  Перечисление констант типов шины, поддерживаемых сервисом `vmcd`.
/// \author DL <dmitriy@linikov.ru>

#ifndef TELEMETRON_APPS_INCLUDE_VMCD_VMCBUS_ID_T_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_VMCD_VMCBUS_ID_T_H_INCLUDED

typedef enum {
  VMCBUS_ID_INVALID = 0,
  VMCBUS_ID_EXE = 1,
  VMCBUS_ID_MDB = 2,
} vmcbus_id_t;

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

extern const char* vmcbus_id_2_string(vmcbus_id_t id);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // TELEMETRON_APPS_INCLUDE_VMCD_VMCBUS_ID_T_H_INCLUDED
