/// \file
/// \brief  Перечисление констант типов шины, поддерживаемых сервисом `vmcd`.
/// \author DL <dmitriy@linikov.ru>

#ifndef TELEMETRON_APPS_INCLUDE_VMCD_VMCD_EVENT_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_VMCD_VMCD_EVENT_H_INCLUDED

#include <stdint.h>
#include <time.h>
#include <vmcd/vmcbus_id.h>
#include <vmcd/vmcbus_state.h>

#ifndef VMCD_EV_BASE
#define VMCD_EV_BASE      0x00000100
#endif

/// \brief Перечисление событий, генерируемых сервисом vmcd
enum vmcd_events_e {
  VMCD_EV_BUS_CHANGE = VMCD_EV_BASE,///< Автообнаружением был изменён тип шины.
  VMCD_EV_VEND,                     ///< Торговый автомат что-то продал.
  VMCD_EV_RAWLOG,                   ///< Накоплена очередная порция сырых данных из шины.



  // -- Далее - служебные константы -----------------------------------------

  /// Идентификатор последнего события в данном перечислении.
  __VMCD_LAST_EVENT,
  /// Количество известных событий VMC. \note Это Не событие!
  VMCD_EVENTS_COUNT = (__VMCD_LAST_EVENT - VMCD_EV_BASE)
};


/// Тип платежа, используемый в `vmcd_event_sale_t`
typedef enum vmcd_payment_type_e {
  VMCD_PAYTYPE_CASH = 0,
  VMCD_PAYTYPE_CASHLESS
} vmcd_paytype_t;


// Событие изменения состояния шины
typedef struct {
  vmcbus_id_t     bus_id;
  vmcbus_state_t  bus_state;
} vmcd_event_bus_change_t;

// структура одной записи о продаже
typedef struct{
  time_t          dt;             ///< Абсолютное время продажи
  int32_t         price;
  uint16_t        product_name;
  uint16_t        dot;            ///< делитель для price (1, 10, 100, ...)
  uint16_t        currency;
  vmcd_paytype_t  paytype;
  vmcbus_id_t     bus_id;
} vmcd_event_sale_t; //14 байт

// Событие переполнения лог-файла.
typedef struct {
  uint8_t   unused;
} vmcd_event_rawlog_t;


#endif // TELEMETRON_APPS_INCLUDE_VMCD_VMCD_EVENT_H_INCLUDED
