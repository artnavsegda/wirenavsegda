/// \file
/// \brief  Структура, хранящая пути к файлам сервиса `vmcd`.
/// \author DL <dmitriy@linikov.ru>

#ifndef CONFIG_TELEMETRON_APPS_INCLUDE_VMCD_VMCD_PATH_H_INCLUDED
#define CONFIG_TELEMETRON_APPS_INCLUDE_VMCD_VMCD_PATH_H_INCLUDED

#include <vmcd/config.h>

/// \brief Структура, хранящая путь к файлу для сервиса `vmcd`.
typedef struct vmcd_path_s {
  /// \brief Путь к файлу
  char          value[VMCD_MAXPATH];
} vmcd_path_t;



#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

vmcd_path_t vmcd_path_create(int instance_id, const char* filename);
vmcd_path_t vmcd_devpath_create(int instance_id, const char* devname);

#ifdef __cplusplus
}
#endif // __cplusplus


#endif // CONFIG_TELEMETRON_APPS_INCLUDE_VMCD_VMCD_PATH_H_INCLUDED
