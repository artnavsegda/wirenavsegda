/// @file
/// @author DL <dmitriy.linikov@gmail.com>

#ifndef ENUM_VMCBUS_STATE_H_INCLUDED
#define ENUM_VMCBUS_STATE_H_INCLUDED

typedef enum {
  VMCBUS_STATE_UNDEFINED = 0,
  VMCBUS_STATE_OK,
  VMCBUS_STATE_ERROR,
} vmcbus_state_t;

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

extern const char* vmcbus_state_2_string(vmcbus_state_t state);

#ifdef __cplusplus
}
#endif // __cplusplus


#endif // ENUM_VMCBUS_STATE_H_INCLUDED
