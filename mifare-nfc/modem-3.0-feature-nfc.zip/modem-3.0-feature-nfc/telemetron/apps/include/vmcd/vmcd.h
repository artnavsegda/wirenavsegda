/// \file
/// \brief  Модуль vmcd (vmc daemon).
/// \author DL <dmitriy@linikov.ru>
///
/// Описание публичного интерфейса сервиса поддержки торгового автомата.

#ifndef CONFIG_TELEMETRON_APPS_INCLUDE_VMCD_VMCD_H_INCLUDED
#define CONFIG_TELEMETRON_APPS_INCLUDE_VMCD_VMCD_H_INCLUDED

#include <stdint.h>
#include <nuttx/config.h>
#include <utils/systime.h>
#include <utils/service.h>
#include <vmcd/config.h>
#include <vmcd/vmcd_path.h>
#include <vmcd/vmcd_settings.h>


#if !defined(CONFIG_LIB_VMCD_DAEMON_PRIORITY) || defined(__DOXYGEN__)
/// \brief  Приоритет потока сервиса vmcd.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_VMCD_DAEMON_PRIORITY    160
#endif

#if !defined(CONFIG_LIB_VMCD_DAEMON_STACKSIZE) || defined(__DOXYGEN__)
/// \brief  Размер стека потока сервиса vmcd.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_VMCD_DAEMON_STACKSIZE         2048
#endif

#ifdef CONFIG_LIB_VMCD_DEBUG_ERROR
#   define vmcd_error(format, ...) _err("VMCD:" format, ##__VA_ARGS__)
#else
#   define vmcd_error(x...)
#endif

#ifdef CONFIG_LIB_VMCD_DEBUG_WARN
#   define vmcd_warn(format, ...) _warn("VMCD:" format, ##__VA_ARGS__)
#else
#   define vmcd_warn(x...)
#endif

#ifdef CONFIG_LIB_VMCD_DEBUG_INFO
#   define vmcd_info(format, ...) _info("VMCD:" format, ##__VA_ARGS__)
#else
#   define vmcd_info(x...)
#endif

#ifdef CONFIG_LIB_VMCD_DEBUG_TRACE
#   define vmcd_trace(format, ...) _info("VMCD:" format, ##__VA_ARGS__)
#   define vmcd_dump(msg, buf, sz) infodumpbuffer(("VMCD:" msg), (const uint8_t*)(buf), (sz))
#else
#   define vmcd_trace(x...)
#   define vmcd_dump(msg, buf, sz)
#endif

#ifdef CONFIG_LIB_VMCD_DEBUG_DUMP_RXTX
#   define vmcd_dumprx(bus,value)   syslog(LOG_DEBUG, "VMCD:BUS%d:RX:%04X\n", bus, value)
#   define vmcd_dumptx(bus,value)   syslog(LOG_DEBUG, "VMCD:BUS%d:TX:%04X\n", bus, value)
#else
#   define vmcd_dumprx(bus,value)
#   define vmcd_dumptx(bus,value)
#endif

#define vmcd_debug  vmcd_trace
// Последний символ в буффере текущей продажи по шине MDB.
// (ноль использовать нельзя, т.к. допустим внутри пакета).
#define MDBEXE_TERMINATOR         0xFFFF

struct vmcd_s;
typedef struct vmcd_s   vmcd_t;



#ifdef __cplusplus
extern "C" {
#endif


int vmcd_create(
  vmcd_t**    dst,
  int         instance_id,
  const char* tty_master_to_slave,
  const char* tty_slave_to_master,
  const char* eventq_name,
  size_t      rawlog_max_size
);

int vmcd_destroy(vmcd_t* vmcd);

vmcd_t* vmcd_find_instance(int instance_id);

int     vmcd_setup(vmcd_t* vmcd, int bus_id, int error_timeout_ms);


#ifdef __cplusplus
} // extern "C"
#endif


static inline int vmcd_start(vmcd_t* vmcd)
{
  return service_start((service_t*)vmcd);
}

static inline int vmcd_kill(vmcd_t* vmcd)
{
  return service_kill((service_t*)vmcd);
}

static inline int vmcd_wait_terminated(vmcd_t* vmcd, int timeout_ms)
{
  return service_wait_terminated((service_t*)vmcd, timeout_ms);
}

static inline bool vmcd_is_started(vmcd_t* vmcd)
{
  return service_is_started((service_t*)vmcd);
}



#endif // CONFIG_TELEMETRON_APPS_INCLUDE_VMCD_VMCD_H_INCLUDED
