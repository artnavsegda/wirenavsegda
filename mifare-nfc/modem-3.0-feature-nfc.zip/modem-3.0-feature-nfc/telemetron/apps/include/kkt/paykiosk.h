/// \file
/// \brief ККТ PayKiosk

#ifndef TELEMETRON_APPS_INCLUDE_KKT_PAYKIOSK_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_KKT_PAYKIOSK_H_INCLUDED

#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

#include <utils/smartio.h>
#include <utils/smartio_crcxor.h>
#include <utils/timeout.h>
#include "kkt_config.h"
#include "kkt.h"
#include "paykiosk_pppd.h"
// #include <buffered_uart.h>
//#include <enum_evadts_state.h>
// #include "protocol_ofd.h"



typedef enum paykiosk_conntype_e {
  PAYKIOSK_CONNTYPE_SERIAL  = 0x00,
  PAYKIOSK_CONNTYPE_PPPOS   = 0x01
} paykiosk_conntype_t;

typedef struct paykiosk_s {
  kkt_t                 base;       ///< Наследуемся от kkt_t
  paykiosk_pppd_t       pppd;       ///< PPP сервис.

  smartio_crcxor_t      rxcrc;
  smartio_crcxor_t      txcrc;
  uint8_t               txbuf[256];
  timeout_t             timer_c;

  uint8_t               status;
  uint8_t               type;
  uint8_t               nalog;
  paykiosk_conntype_t   conntype;
  bool                  pppd_created;
  uint8_t               is_net;     ///< Данный экземпляр использует сетевое подключение

  uint32_t              timeout_getc_ms;
  uint32_t              timeout_enq_ms;
  uint32_t              timeout_discard_ms;
} paykiosk_t;




#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

/// Дефолтный пароль
#define PAYKIOSK_DEFAULT_PSW        30





#define KKM_NOT_INSTALL         0
#define KKM_ERROR               2
#define KKM_INITED              1


///  Типы ККМ машин ШТРИХ (PAYKIOSK)
typedef enum kkmtype_paykiosk_e {
  //UNKNOW_KKM_TYPE          = 0,
  KKMTYPE_PAYONLINE_01     = 255,
}kkmtype_paykiosk_t;

// значение минимальное денежной единицы
#define PAYKIOSK_MDE            100

// Максимально возможная сумма к оплате (в теории). Должна превышщать стоимость товара
#define PAYKIOSK_MAX_PAY        1000000

// Режитмы работы PAYKIOSK ККТ
#define PAYKIOSK_KKT_MODE_2     0x02        // Смена открыта и не закончилась
#define PAYKIOSK_KKT_MODE_3     0x03        // Смена открыта и она закончилась
#define PAYKIOSK_KKT_MODE_4     0x04        // Смена закрыта
#define PAYKIOSK_KKT_MODE_8     0x08        // Чек открыт (надо закрыть)
// Подрежимы рабоыт PAYKIOSK ККТ
#define PAYKIOSK_KKT_SUBMODE_0  0x00        // Нормальный режим работы
#define PAYKIOSK_KKT_SUBMODE_1  0x01        // Пассивное отсутствие бумаги
#define PAYKIOSK_KKT_SUBMODE_2  0x02        // Активное отсутствие бумаги
#define PAYKIOSK_KKT_SUBMODE_3  0x03        // После активного отсутствия бумаги. Ждет команду продолженеи печати
#define PAYKIOSK_KKT_SUBMODE_4  0x04        // Фаза печати полных фискальных отчетов
#define PAYKIOSK_KKT_SUBMODE_5  0x05        // Фаза печати операции

#define OPENCLOSE_PORT          true
#define DONT_OPENCLOSE_PORT     false

// Структура команды 0xFF01 - связано с ОФД
//typedef _fn_status _paykiosk_cmdFF01;

//#include "printer.h"
#if 0
/// Отрезка чека
///
/// \callgraph
/// \callergraph
bool paykiosk_cut_order(paykiosk_t* kkm);

/// Печать произвольной строки (обычным шрифтом)
///
/// \callgraph
/// \callergraph
bool paykiosk_print_string(paykiosk_t* kkm, char * src);

/// Процедура инициализации принтера
///
/// \callgraph
/// \callergraph
//bool paykiosk_init_printer(paykiosk_t* kkm, int evadts_channel, bool raw_log);
int paykiosk_init_printer(paykiosk_t* me, const char* address);

// Процедура деинициализации принтера
///
/// \callgraph
/// \callergraph
void paykiosk_deinit_printer(paykiosk_t* kkm);

// Проверка наличия принтера
///
/// \callgraph
/// \callergraph
int paykiosk_check_printer(paykiosk_t* me, kkt_state_t* bak_params, bool openclose_port);

// Открыть/Закрыть чек
///
/// \callgraph
/// \callergraph
bool paykiosk_open_close_order(paykiosk_t* kkm, bool open, uint32_t summ, bool cash, bool openclose_port);
// Регистрация продажи в открытый чек
///
/// \callgraph
/// \callergraph
bool paykiosk_reg_order(paykiosk_t* kkm, uint32_t price, uint32_t quant, char * name, uint16_t section, bool openclose_port);
// Вывод картинки на чек
///
/// \callgraph
/// \callergraph
bool paykiosk_print_image(paykiosk_t* kkm, const uint8_t * image, uint16_t x, uint16_t y);
// Записывает адрес ОФД
///
/// \callgraph
/// \callergraph
bool paykiosk_set_OFDserv(paykiosk_t* kkm);
// Записывает порт ОФД
///
/// \callgraph
/// \callergraph
bool paykiosk_set_OFDport(paykiosk_t* kkm);

///++++++++++++++++++++++++++++++ процедуры работы с ФН +++++++++++++++++++++++++
// Проверка состояния ФН
///
/// \callgraph
/// \callergraph
bool paykiosk_check_fn_status(paykiosk_t* kkm);
// Установка транспортного соединения в ФН
///
/// \callgraph
/// \callergraph
bool paykiosk_set_fn_transport(paykiosk_t* kkm);

#endif

///=============== Типы документов =======================
#define PAYKIOSK_DOCTYPE_INPUT          0x00
#define PAYKIOSK_DOCTYPE_OUT            0x01
#define PAYKIOSK_DOCTYPE_RETURN_INPUT   0x02
#define PAYKIOSK_DOCTYPE_RETURN_OUT     0x03

///=============== Флаги ККТ =============================
#define PRINTER_OPTIC_PAPER_ON          0x0080    // Оптический датчик ленты на входе принтера (1 - бумага присутствует, 0 - бумаги нет)

#define PAYKIOSK_KKTERROR_BASE          __ELASTERROR
#define PAYKIOSK_FNERROR_BASE           __ELASTERROR

/// \brief Преобразует код ошибки, возвращённый ККМ, в совместимый с errno
/// \note Данный макрос создаёт положительное число!
#define PAYKIOSK_KKTERROR(value)          (PAYKIOSK_KKTERROR_BASE \
                                          + (uint8_t)(value))

/// \brief Преобразует код ошибки фискального накопителя в код, совместимый с errno
#define PAYKIOSK_FNERROR(value)           (PAYKIOSK_FNERROR_BASE \
                                          + (uint8_t)(value))

/// \brief Проверяет, что код ошибки (положительное число) получен от ККМ
#define PAYKIOSK_IS_KKTERROR(value)       (    (value) > PAYKIOSK_KKTERROR_BASE         \
                                            && (value) <= (PAYKIOSK_KKTERROR_BASE + 255)\
                                          )

/// \brief Проверяет, что код ошибки (положительное число) получен от ФН
#define PAYKIOSK_IS_FNERROR(value)        (    (value) > PAYKIOSK_FNERROR_BASE         \
                                            && (value) <= (PAYKIOSK_FNERROR_BASE + 255)\
                                          )

/// \brief Преобразует код ошибки, полученный от ККМ, в сырое значение от 1 до 255.
/// \note Если код errcode не является корректным расширенным кодом ошибки
/// (а, например, просто кодом errno), то данный макрос вернёт 0.
#define PAYKIOSK_GET_KKTERROR(errcode)    ( PAYKIOSK_IS_KKTERROR(errcode) \
                                            ? ((errcode) - PAYKIOSK_KKTERROR_BASE)  \
                                            : 0 \
                                          )

/// \brief Преобразует код ошибки, полученный от ФН, в сырое значение от 1 до 255.
/// \note Если код errcode не является корректным расширенным кодом ошибки
/// (а, например, просто кодом errno), то данный макрос вернёт 0.
#define PAYKIOSK_GET_FNERROR(errcode)     ( PAYKIOSK_IS_FNERROR(errcode) \
                                            ? ((errcode) - PAYKIOSK_FNERROR_BASE)  \
                                            : 0 \
                                          )


/// Таблицы в ККТ
typedef enum {
  PAYKIOSK_TABLE_01  =                1,        // Тип и режим кассы
  PAYKIOSK_TABLE_02  =                2,        // Пароли кассиров и администраторов
  PAYKIOSK_TABLE_03  =                3,        // Не используется
  PAYKIOSK_TABLE_04  =                4,        // Текст в чеке
  PAYKIOSK_TABLE_05  =                5,        // Наименования типов оплаты
  PAYKIOSK_TABLE_06  =                6,        // Налоговые ставки
  PAYKIOSK_TABLE_07  =                7,        // Наименование отделов
  PAYKIOSK_TABLE_08  =                8,        // Настройка шрифтов
  PAYKIOSK_TABLE_09  =               9,        // Таблица формата чека
  PAYKIOSK_TABLE_10  =               10,        // Служебная
  PAYKIOSK_TABLE_11  =               11,        // Параметры кодирования QR кодов
  PAYKIOSK_TABLE_12  =               12,        // Веб ссылка
  PAYKIOSK_TABLE_13  =               13,        // Параметры термопечати
  PAYKIOSK_TABLE_14  =               14,        // SDcard status
  PAYKIOSK_TABLE_15  =               15,        // Сервер транзакций
  PAYKIOSK_TABLE_16  =               16,        // Сетевой адрес
  PAYKIOSK_TABLE_17  =               17,        // Региональные настройки
  PAYKIOSK_TABLE_18  =               18,        // Параметры ФН
  PAYKIOSK_TABLE_19  =               19,        // Параметры ОФД
  PAYKIOSK_TABLE_20  =               20,        // Статус обмена ФН
  PAYKIOSK_TABLE_21  =               21,        // Сетевые интерфейсы
  PAYKIOSK_TABLE_22  =               22,        // Сетевой адрес WiFi
  PAYKIOSK_TABLE_23  =               23,        // Удаленный мониторинг и администрирование
  PAYKIOSK_TABLE_24  =               24,        // Встраиваемая и интернет техника

  PAYKIOSK_TABLE_UNK =               0xFF,      // неопределенная таблица
} paykiosk_tables_t;

/// Ошибки ККТ
typedef enum{
  PAYKIOSK_OK = 0x00,
  PAYKIOSK_ERR_50   = PAYKIOSK_KKTERROR(0x50),  ///< Ошибка, ККТ занят идет печать документа (чек в ФН не попал, можно чек анулировать и печатать егно в ФН)
  PAYKIOSK_ERR_58   = PAYKIOSK_KKTERROR(0x58),  ///< Ошибка, ККТ ждет команды продолжения печати (Документ попал в ФН. Нужно установить чековую ленту иначе ККТ не работает)
  // Ошибки ФН
  PAYKIOSK_ERR_01   = PAYKIOSK_FNERROR(0x01),   ///< Ошибка, неизвестная команда или формат
  PAYKIOSK_ERR_02   = PAYKIOSK_FNERROR(0x02),   ///< Ошибка, неверное состояние ФН
  PAYKIOSK_ERR_03   = PAYKIOSK_FNERROR(0x03),   ///< Ошибка, ФН (запросить расширенные сведения об ошибке)
  PAYKIOSK_ERR_04   = PAYKIOSK_FNERROR(0x04),   ///< Ошибка, КС (криптографический сопроцессор) (запросить расширенные сведения об ошибке)
  PAYKIOSK_ERR_05   = PAYKIOSK_FNERROR(0x05),   ///< Ошибка, Закончен срок эксплуатации ФН
  PAYKIOSK_ERR_06   = PAYKIOSK_FNERROR(0x06),   ///< Ошибка, Архив ФН переполнен
  PAYKIOSK_ERR_07   = PAYKIOSK_FNERROR(0x07),   ///< Ошибка, Неверная дата или время
  PAYKIOSK_ERR_08   = PAYKIOSK_FNERROR(0x08),   ///< Ошибка, Нет запрошенных данных
  PAYKIOSK_ERR_09   = PAYKIOSK_FNERROR(0x09),   ///< Ошибка, Некорректное значенеи параметров
  PAYKIOSK_ERR_10   = PAYKIOSK_FNERROR(0x10),   ///< Ошибка, Превышение размеров TLV данных
  PAYKIOSK_ERR_11   = PAYKIOSK_FNERROR(0x11),   ///< Ошибка, Нет транспортного соединенеия
  PAYKIOSK_ERR_12   = PAYKIOSK_FNERROR(0x12),   ///< Ошибка, Исчерпан ресурс КС (криптографический сопроцессор)
  PAYKIOSK_ERR_14   = PAYKIOSK_FNERROR(0x14),   ///< Ошибка, Исчерпан ресурс хранения документов для отправки в ОФД. Срочно выгрузить
  PAYKIOSK_ERR_15   = PAYKIOSK_FNERROR(0x15),   ///< Ошибка, Исчерпан ресурс ожидания передачи сообщения
  PAYKIOSK_ERR_16   = PAYKIOSK_FNERROR(0x16),   ///< Ошибка, Продожительность смены более 24 часов
  PAYKIOSK_ERR_17   = PAYKIOSK_FNERROR(0x17),   ///< Ошибка, Неверная разница во времени между двумя операциями (разница более 5 минут)
  PAYKIOSK_ERR_20   = PAYKIOSK_FNERROR(0x20),   ///< Ошибка, Сообщенеи от ОФД не может быть принято
  PAYKIOSK_ERR_2F   = PAYKIOSK_FNERROR(0x2F),   ///< Ошибка, Отсутствует ФН (завис, сдох и т.д.)
  PAYKIOSK_ERR_6B   = PAYKIOSK_FNERROR(0x6B),   ///< Ошибка, Отсутствует чековая лента. Работать не можем
  PAYKIOSK_ERR_45   = PAYKIOSK_FNERROR(0x45),   ///< Ошибка, Сумма всех типов оплаты меньше итога чека. Надо закрыть чек большей суммой.

  //PAYKIOSK_ERR_UNK =               0xFF,        // Наш код ошибки (не ККТ)
}kkt_paykiosk_errorlevel_t;

typedef enum paykiosk_printdoc_e {
  PAYKIOSK_PRINTDOC_ON_ALWAYS     = 0,
  PAYKIOSK_PRINTDOC_OFF_NEXT_DOC  = 1,
  PAYKIOSK_PRINTDOC_OFF           = 2
} paykiosk_printdoc_t;


int paykiosk_create(paykiosk_t* me);
// int paykiosk_destroy(paykiosk_t* me);  // Удаление - через базовый класс

const char* paykiosk_conntype_to_string(paykiosk_conntype_t value);
#ifdef __cplusplus
}
#endif // __cplusplus

#endif // TELEMETRON_APPS_INCLUDE_KKT_PAYKIOSK_H_INCLUDED
