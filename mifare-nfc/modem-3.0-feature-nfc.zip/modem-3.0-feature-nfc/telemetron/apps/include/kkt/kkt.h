/// \file
/// \brief  Абстрактный базовый класс для протоколов связи с ККМ/ККТ
/// \author DL <dmitriy@linikov.ru>


#ifndef TELEMETRON_APPS_INCLUDE_KKT_KKTLINK_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_KKT_KKTLINK_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <kkt/kkt_config.h>

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <utils/smartio.h>
#include <settings/settings.h>
#include <kkt/ofd.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

/// \brief Стандартный таймаут передачи одного символа через kktlink
#define CONFIG_KKTLINK_PUTC_TIMEOUT_MS      5000

#if !defined(CONFIG_KKTLINK_MAXPATH) || defined(__DOXYGEN__)
/// \brief  Максимальная длина пути к драйверу последовательного порта
///
/// Данный параметр задаёт размер буффера, который хранит путь к драйверу
/// используемого последовательного порта.
///
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_KKTLINK_MAXPATH    24
#endif


////////////////////////////////////////////////////////////////////////////
//  Типы данных

/// \brief Описание текущего состояния ККТ: отсутствует в системе, работает, в ошибке.
typedef enum kkt_workstate_e {
  KKT_NOT_INSTALL,
  KKT_ERROR,
  KKT_INITED
} kkt_workstate_t;

/// \brief  Перечисление состояний бумаги в принтере.
///
/// \note   Используются только три состояния, т.к. в оригинальной
///         прошивке для модема 2.7 использовались именно они.
typedef enum kkt_paperstate_e {
  KKT_PAPER_OK,
  KKT_PAPER_WARNING,
  KKT_PAPER_ERROR,
} kkt_paperstate_t;

/// \brief Набор флагов, описывающих возможности конкретной реализации ККТ.
typedef struct kkt_capabilities_s {
  bool can_print_item             : 1;      ///< Может печатать строку с товаром
  bool can_print_text             : 1;      ///< Может печатать произвольный текст
  bool can_print_image            : 1;      ///< Может печатать графику
  bool can_print_leading_banner   : 1;      ///< Допускает печать баннера перед телом чека
  bool can_print_trailing_banner  : 1;      ///< Допускает печать баннера после тела чека (после закрытия чека)
  bool can_cut                    : 1;      ///< Может ли отрезать чек
  bool has_fn                     : 1;      ///< Имеет фискальный накопитель
  bool has_ofd_interface          : 1;      ///< Может соединяться с ОФД сервером

  int16_t   paper_width_chars;              ///< Ширина бумаги в символах, -1 = неизвестно
  int16_t   paper_width_dots;               ///< Ширина бумаги в точках (при печати графики), -1 = неизвестно
  int16_t   line_length;                    ///< Максимальное количество символов в одной команде печати строки.
} kkt_caps_t;


/// \brief Информация о ККТ, отправляемая на сервер.
typedef struct kkt_info_s {
  kkt_workstate_t workstate; // то, что раньше называлось status
  char            bus[32];
  char            name[32];
  char            serial[30];
  char            fw_version[30];
  speed_t         baudrate;
  uint16_t        rereg;
  uint16_t        rereg_rest;
  char            inn[30];
  char            ofd_serv[64];
  uint16_t        ofd_port;
  char            fn_sn[17];
  char            fn_kkt_sn[21];
  char            fn_kkt_rnm[21];
  char            ta_sn[12];

  uint16_t        last_cmd;
  int             last_error_code;
} kkt_info_t;

// Параметры состояния KKT взятые из ККТ (настройка и т.д.)
typedef struct kkt_params_s {
  char            name[32];
  uint32_t        sn;
  uint16_t        sn_hi;
  char            inn[17];
  uint16_t        flags;
  uint8_t         mode;
  uint8_t         submode;
  uint16_t        last_cmd;
  int             last_error_code;
  uint16_t        FW_version;
  uint16_t        FW_build;
  struct{
    uint8_t day;
    uint8_t month;
    uint8_t year;
  }FW_date;
  uint8_t         rereg;
  uint8_t         rereg_rest;
  char            OFDserv[64];
  uint16_t        OFDport;
  char            printer_ip[64];
  uint8_t         doc_mode;
  /// Время в ККТ
  struct{
    uint8_t day;
    uint8_t month;
    uint8_t year;
    uint8_t hour;
    uint8_t min;
    uint8_t sec;
  }KKT_date_time;
} kkt_state_t;

typedef struct{
  /// Статус ФН
  uint8_t         FN_exch_state;  // Стадия обмена
  uint8_t         FN_read_state;  //
  uint16_t        FN_msgs;        // Количество сообщенйи в очереди на отправку
  int32_t         FN_doc_num;     // Номер (уникальный) докуменат в очереди на отправку
  char            FN_doc_dt[33];  // Дата и время создания неотправленного документа
  /// Параметры регистрации ККТ в ФН
  char            FN_kkt_sn[21];
  char            FN_kkt_rnm[21];
  char            FN_sn[17];
  char            FN_ta_sn[12];
} fn_state_t; // бывший _type_fn_status

/// \brief Перечень известных валют. Нумерация - согласно ISO 4217
typedef enum currency_e {
  CURRENCY_ANY      = 0,          ///< Неизвестная валюта, или не важно, какая валюта.
  CURRENCY_CNY      = 156,        ///< Китайский юань женьминьби (¥)
  CURRENCY_RUB      = 643,        ///< Российский рубль (₽)
  CURRENCY_USD      = 840,        ///< Доллар США ($)
  CURRENCY_EUR      = 978,        ///< Евро (€)
} currency_t;

typedef enum kkt_paytype_e {
  KKT_PAYTYPE_ANY       = 0,      ///< Неизвестный тип оплаты. Используется, если тип не важен.
  KKT_PAYTYPE_CASH,               ///< Оплата наличными.
  KKT_PAYTYPE_CASHLESS,           ///< Оплата безналичным методом.
} kkt_paytype_t;

/// \brief Структура, описывающая количество денег или цену.
///
/// Внутренне, храним все денежные значения в минимальных денежных единицах.
/// Для российских рублей это будут копейки.
///
/// Кроме того, неотъемлемым параметром денежной суммы является валюта,
/// в которой эта сумма представлена. Что бы исключить сложение 100 USD и 100 RUB,
/// код валюты должен хранится вместе с описанием количества денег.
typedef struct kkt_money_s {
  uint32_t        value;        ///< Количество денег в минимальных денежных единицах
  uint16_t        dot;          ///< Количество минимальных денежных единиц в единице денег. Например, для рубля МДЕ=копейки, dot=100
  currency_t      currency;     ///< Валюта, в которой представлено данное количество денег/цена
} kkt_money_t;

/// \brief Структура, описывающая отдельных платёж
///
/// Платёж описывается количеством денег и
typedef struct kkt_pay_s {
  kkt_money_t     summ;         ///< Сумма платежа
  kkt_paytype_t   paytype;      ///< Тип платежа (нал, безнал, и т.д.)
} kkt_pay_t;

/// \brief Число, представленное в тысячных долях.
typedef uint32_t  thousandths_t;

typedef struct kkt_s kkt_t;

/// \brief Таблица методов драйвера принтера/ккт/ккм
typedef struct kkt_vmt_s {
  /// \brief Возвращает текущие характеристики драйвера и принтера.
  /// \warning Это один из немногих обязательных виртуальных методов.
  /// \warning Данный метод обязан всегда возвращать значение. Время жизни
  ///          переменной, на которую указывает возвращаемое значение
  ///          должно быть не меньше времени жизни самого объекта.
  const kkt_caps_t* (*get_caps)(kkt_t* kkt);

  /// \brief [ОПЦИЯ] Уничтожение экземпляра конкретного драйвера.
  ///
  /// Данный метод может отсутствовать, если не нужен конкретному драйверу.
  /// При этом даже при его отсутствии вызов kkt_destroy завершится успешно.
  ///
  /// \warning Вызывается из функции kkt_destroy, поэтому не должен её вызывать.
  int (*destroy)(kkt_t* kkt);

  /// \brief [ОПЦИЯ] Инициализация экземпляра драйвера.
  ///
  /// Данный метод вызывается из kkt_init после сохранения настроек,
  /// но до установки поля kkt_s::inited
  ///
  /// Данный метод может отсутствовать, если не нужен конкретному драйверу.
  /// При этом даже при его отсутствии вызов kkt_init завершится успешно.
  int (*init)(kkt_t* kkt);

  /// \brief [ОПЦИЯ] Остановка экземпляра драйвера.
  ///
  /// Данный метод вызывается из kkt_deinit до сброса поля kkt_s::inited
  ///
  /// Данный метод может отсутствовать, если не нужен конкретному драйверу.
  /// При этом даже при его отсутствии вызов kkt_deinit завершится успешно.
  int (*deinit)(kkt_t* kkt);

  /// \brief Возвращает текущее имя шины.
  ///
  /// \note сделано виртуальным методом, т.к. некоторые драйверы могут
  /// поддерживать одновременно несколько типов (или подтипов) шин,
  /// например, paykiosk поддерживает типы "PAYKIOSK" и "PAYKIOSK_PPP"
  ///
  /// Строки, возвращаемые данным методом должны иметь время жизни
  /// не меньше, чем сам объект, и при этом не требовать освобождения.
  const char* (*bus_name)(kkt_t* kkt);

  /// \brief Проверка состояния ККТ.
  /// \return 0, если ККТ подключен, или -errno код ошибки.
  ///
  /// Данный метод является обязательным для реализации, если в конкретном драйвере
  /// он не реализован, то kkt_status_check вернёт -ENOSYS
  int (*status_check)(kkt_t* kkt);

  /// \brief [ОПЦИЯ] Возвращает текущее время в ККТ.
  /// \note  Данный метод вызывается из kkt_status_check после
  /// вызова status_check, поэтому, если в протоколе обмена конкретного ККТ
  /// не предусмотрено отдельной команды для запроса даты и времени,
  /// то данная функция может возвращать значение, полученное при
  /// выполнении метода status_check.
  ///
  /// Если данный метод не реализован, то синхронизация часов с часами ККТ
  /// выполняться не будет.
  int (*datetime_get)(kkt_t* kkt, struct timespec* dst);

  /// \brief Открытие чека
  int (*order_open)(kkt_t* kkt);

  /// \brief Закрытие чека
  int (*order_close)(kkt_t* kkt, const kkt_pay_t* summ);

  /// \brief Добавление товара в чек И ПЕЧАТЬ ОПИСАНИЯ ТОВАРА НА ЧЕКЕ.
  /// \param kkt            Экземпляр драйвера
  /// \param price          Цена единицы товара
  /// \param quant          Количество единиц товара в тысячных долях
  /// \param name           Наименование товара
  /// \param section        ?Номер отдела торговой точки?
  int (*order_reg)(kkt_t* kkt, const kkt_money_t* price, thousandths_t quant, const char* name, uint16_t section);

  /// \brief Отрезка чека
  int (*order_cut)(kkt_t* kkt);

  /// \brief Печать произвольной строки на чеке
  int (*print_string)(kkt_t* kkt, const char* str);

  /// \brief Печать произвольного изображения на чеке
  int (*print_image)(kkt_t* kkt, const uint8_t* image, uint16_t x, uint16_t y);

  /// \brief Установка нового сервера ОФД
  int (*ofd_set_server)(kkt_t* kkt, const char* server);

  /// \brief Установка нового порта для сервера ОФД
  int (*ofd_set_port)(kkt_t* kkt, uint16_t port);

  /// \brief Проверка состояния фискального накопителя
  int (*fn_check_status)(kkt_t* kkt);

  /// \brief ХЗ, что делает. Возможно, установка связи с фискальным накопителем.
  int (*fn_set_transport)(kkt_t* kkt);

  /// \brief ХЗ, что делает. Возможно, разрыв связи с фискальным накопителем.
  int (*fn_reset_transport)(kkt_t* kkt);
} kkt_vmt_t;


/// \brief  Абстрактный базовый класс для протоколов связи с ККМ/ККТ.
///
/// Предполагается такая последовательность действий с драйвером:
/// xxx_create -> kkt_init -> .... -> [kkt_deinit] -> kkt_destroy
struct kkt_s {
  /// \brief Таблица методов конкретной реализации драйвера
  const kkt_vmt_t*          vmt;

  /// \brief Путь к драйверу последовательного порта, через который работать.
  char                      ttypath[CONFIG_KKTLINK_MAXPATH];

  /// \brief Дополнительные настройки драйвера
  printer_params_t          params;

  /// \brief Признак, что kkt_init уже был вызван.
  ///
  /// Если данное поле true, то поля ttypath и params содержат
  /// соответствующие настройки.
  bool                      inited;

  ///
  uint8_t                   status;

  /// \brief Наличие бумаги в принтере.
  ///
  /// Данное поле используется, что бы в модуле kkt_t не было
  /// зависимостей от аппаратно-зависимых констант.
  kkt_paperstate_t          paperstate;

  /// \brief Если true, то поле fn_state имеет значение.
  bool                      has_fn_state;

  /// \brief Объект-обёртка над драйвером последовательного порта или сокетом.
  smartio_t                 port;

  /// \brief Вспомогательный объект для вывода отладочной информации
  /// о вводе-выводе через smartio_t
  struct lib_rawsostream_s  logger;

  /// \brief Текущее состояние ккт
  kkt_state_t               kkt_state;

  /// \brief Текущее состояние ФН
  fn_state_t                fn_state;

  // структуры ФН
  fn_t                      fn;

  // структуры ОФД
  ofd_state_t               ofd;

  //sem_t           lock;
};


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

const kkt_caps_t* kkt_caps(kkt_t* kkt);

int kkt_create(kkt_t* kkt, const kkt_vmt_t* vmt);
int kkt_destroy(kkt_t* kkt);
int kkt_init(kkt_t* kkt, const char* ttypath, printer_params_t* printer_params);
int kkt_deinit(kkt_t* kkt);
int kkt_status_check(kkt_t* kkt);
int kkt_datetime_get(kkt_t* kkt, struct timespec* dst);
int kkt_order_open(kkt_t* kkt);
int kkt_order_close(kkt_t* kkt, const kkt_pay_t* summ);
int kkt_order_reg(kkt_t* kkt, const kkt_money_t* price, thousandths_t quant, const char* name, uint16_t section);
int kkt_order_cut(kkt_t* kkt);
int kkt_print_string(kkt_t* kkt, const char* str);
int kkt_print_image(kkt_t* kkt, const uint8_t* image, uint16_t x, uint16_t y);
int kkt_ofd_set_server(kkt_t* kkt, const char* server);
int kkt_ofd_set_port(kkt_t* kkt, uint16_t port);
int kkt_fn_check_status(kkt_t* kkt);
int kkt_fn_set_transport(kkt_t* kkt);
int kkt_fn_reset_transport(kkt_t* kkt);

void kkt_fnstatus_ofdstatus_clear(kkt_t* kkt);
void kkt_ofdstatus_set(kkt_t* kkt, void* ofd_status, size_t size);
void kkt_fnstatus_set(kkt_t* kkt, void* fn_status, size_t size);


const char*   PrinterGetSerial(kkt_t* kkt, char* ptr, size_t size);
uint8_t       PrinterGetFNStatus(kkt_t* kkt);
uint16_t      PrinterGetFNMessages(kkt_t* kkt);
const char*   PrinterGetFNFirstDocDataTime(kkt_t* kkt);
const char*   PrinterGetFNSerialKKT(kkt_t* kkt);
const char*   PrinterGetFNRnmKKT(kkt_t* kkt);
const char*   PrinterGetFNSerial(kkt_t* kkt);
const char*   PrinterGetTASerial(kkt_t* kkt);
const char*   PrinterGetOFDserv(kkt_t* kkt);
uint16_t      PrinterGetOFDport(kkt_t* kkt);
bool          PrinterSetOFDServ(kkt_t* kkt, const char * OFD_Serv);
uint16_t      PrinterGetFlags(kkt_t* kkt);
uint8_t       PrinterGetMode(kkt_t* kkt);
uint8_t       PrinterGetSubMode(kkt_t* kkt);
uint8_t       PrinterGetReRegist(kkt_t* kkt);
uint8_t       PrinterGetReRegistRest(kkt_t* kkt);
const char*   PrinterGetFWVersion(kkt_t* kkt, char * ptr, size_t size);
const char*   PrinterGetINN(kkt_t* kkt, char * ptr, size_t size);
uint16_t      PrinterGetLastError(kkt_t* kkt);
uint16_t      PrinterGetLastCmd(kkt_t* kkt);
const char*   PrinterGetName(kkt_t* kkt);
uint32_t      PrinterGetBaud(kkt_t* kkt);
uint8_t       PrinterGetStatus(kkt_t* kkt);
int8_t        PrinterGetBusType(kkt_t* kkt);
const char*   PrinterGetBusTypeString(kkt_t* kkt);
const char*   PrinterGetStatusPaper(kkt_t* kkt);
int           PrinterPrintOrder(kkt_t* kkt, uint32_t price, uint16_t dot, uint32_t quant, uint16_t number, bool cash, bool print_banner);


#ifdef __cplusplus
} // extern "C"
#endif

////////////////////////////////////////////////////////////////////////////
//  inline функции для доступа к настройкам и прочим полям
//  из унаследованных объектов.
//
//  Что бы не писать приведения типов здесь параметр kkt представлен в виде void*,
//  т.к. предполагается, что все переданные указатели - указатели на унаследованные
//  объекты, и могут быть приведены к `kkt_t*`.

static inline smartio_t* kkt_port(void* kkt)
{
  return &((kkt_t*)kkt)->port;
}

static inline const char* kkt_ttypath(void* kkt)
{
  return ((kkt_t*)kkt)->ttypath;
}

static inline const printer_params_t* kkt_params(void* kkt)
{
  return &((kkt_t*)kkt)->params;
}

static inline bool kkt_inited(void* kkt)
{
  return ((kkt_t*)kkt)->inited;
}

static inline kkt_state_t* kkt_state(void* kkt)
{
  return &((kkt_t*)kkt)->kkt_state;
}

static inline bool kkt_has_fn_state(void* kkt)
{
  return ((kkt_t*)kkt)->has_fn_state;
}

static inline void kkt_set_has_fn_state(void* kkt, bool value)
{
  ((kkt_t*)kkt)->has_fn_state = value;
}

static inline fn_state_t* kkt_fn_state(void* kkt)
{
  return &((kkt_t*)kkt)->fn_state;
}

static inline fn_t* kkt_fn(void* kkt)
{
  return &((kkt_t*)kkt)->fn;
}

static inline ofd_state_t* kkt_ofd(void* kkt)
{
  return &((kkt_t*)kkt)->ofd;
}

static inline void kkt_save_error(void* kkt, uint16_t cmd, int error)
{
  kkt_state_t* s = kkt_state(kkt);

  s->last_cmd         = cmd;
  s->last_error_code  = error;
}

static inline void kkt_set_paperstate(void* kkt, kkt_paperstate_t value)
{
  ((kkt_t*)kkt)->paperstate = value;
}

static inline kkt_paperstate_t kkt_paperstate(void* kkt)
{
  return ((kkt_t*)kkt)->paperstate;
}

////////////////////////////////////////////////////////////////////////////
//  inline функции для работы с портом ввода-вывода из унаследованных объектов
//
//  Что бы не писать приведения типов здесь параметр kkt представлен в виде void*,
//  т.к. предполагается, что все переданные указатели - указатели на унаследованные
//  объекты, и могут быть приведены к `kkt_t*`.

static inline int kktport_open_file(void* kkt, const char* path)
{
  return smartio_open_file(kkt_port(kkt), path);
}

static inline int kktport_open_socket(
  void* kkt, const char* endpoint, uint32_t timeout_ms
)
{
  return smartio_open_socket(kkt_port(kkt), endpoint, timeout_ms);
}

static inline int kktport_open_socket_sa(
  void* kkt, const struct sockaddr_in* endpoint, uint32_t timeout_ms
)
{
  return smartio_open_socket_sa(kkt_port(kkt), endpoint, timeout_ms);
}

static inline int kktport_set_comm_params(
  void*             kkt,
  speed_t           baudrate,
  serial_wordlen_t  wordlen,
  serial_parity_t   parity,
  serial_flowctl_t  flowctl
)
{
  return smartio_set_comm_params(kkt_port(kkt), baudrate, wordlen, parity, flowctl);
}

static inline int kktport_get_comm_params(
  void*             kkt,
  speed_t*          baudrate,
  serial_wordlen_t* wordlen,
  serial_parity_t*  parity,
  serial_flowctl_t* flowctl
)
{
  return smartio_get_comm_params(kkt_port(kkt), baudrate, wordlen, parity, flowctl);
}

static inline int kktport_set_aux_params(
  void* kkt, const aux_settings_t* aux_settings
)
{
  return smartio_set_aux_params(kkt_port(kkt), aux_settings);
}


static inline int kktport_close(void* kkt)
{
  return smartio_close(kkt_port(kkt));
}

static inline int kktport_nbgetc(void* kkt, int timeout_ms)
{
  return smartio_nbgetc(kkt_port(kkt), timeout_ms);
}

static inline int kktport_nbputc(void* kkt, uint8_t ch, int timeout_ms)
{
  return smartio_nbputc(kkt_port(kkt), ch, timeout_ms);
}

static inline int kktport_putc(void* kkt, uint8_t ch)
{
  return smartio_nbputc(kkt_port(kkt), ch, CONFIG_KKTLINK_PUTC_TIMEOUT_MS);
}

static inline int kktport_putc_flush(void* kkt, uint8_t ch)
{
  return smartio_nbputc_flush(kkt_port(kkt), ch, CONFIG_KKTLINK_PUTC_TIMEOUT_MS);
}

static inline ssize_t kktport_nbwrite(void* kkt, const void* data, size_t size, int timeout_ms)
{
  return smartio_nbwrite(kkt_port(kkt), data, size, timeout_ms);
}

static inline ssize_t kktport_write(void* kkt, const void* data, size_t size)
{
  return smartio_nbwrite(kkt_port(kkt), data, size, CONFIG_KKTLINK_PUTC_TIMEOUT_MS);
}

static inline int kktport_flush(void* kkt)
{
  return smartio_nbflush(kkt_port(kkt), CONFIG_KKTLINK_PUTC_TIMEOUT_MS);
}

static inline int kktport_discard_rx(void* kkt, int timeout_ms)
{
  return smartio_discard_rx(kkt_port(kkt), timeout_ms);
}

static inline bool kktport_isopen(void* kkt)
{
  return smartio_isopen(kkt_port(kkt));
}

static inline int kktport_set_crc_rx(void* kkt, smartio_crc_t* crc_rx)
{
  return smartio_set_crc_rx(kkt_port(kkt), crc_rx);
}

static inline int kktport_set_crc_tx(void* kkt, smartio_crc_t* crc_tx)
{
  return smartio_set_crc_tx(kkt_port(kkt), crc_tx);
}

static inline void kktport_clear_crc_tx(void* kkt)
{
  smartio_clear_crc_tx(kkt_port(kkt));
}

static inline void kktport_clear_crc_rx(void* kkt)
{
  smartio_clear_crc_rx(kkt_port(kkt));
}

static inline int kkt_set_logger(void* kkt, struct lib_sostream_s* logger)
{
  return smartio_set_logger(kkt_port(kkt), logger);
}

static inline int kktport_set_txbuf(
  void*   kkt,
  void*   buffer,
  size_t  bufsize,
  smartio_buffer_overflow_t   tx_overflow
)
{
  return smartio_set_txbuf(
    kkt_port(kkt), buffer, bufsize, tx_overflow
  );
}




#endif // TELEMETRON_APPS_INCLUDE_KKT_KKTLINK_H_INCLUDED
