/// \file
/// \brief  Типы данных и константы для взаимодействия с ОФД
/// \author DL <dmitriy@linikov.ru>


#ifndef TELEMETRON_APPS_INCLUDE_KKT_OFD_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_KKT_OFD_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <stdint.h>
#include <utils/timeout.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

// Период опроса ОФД сервера на предмет входящих сообщений (Таймер С) Лучше брать это число из настроек (допустимое значение 0-3600 сек "Описание протокола ККТ-ОФД в1_0.pdf")
#define OFD_RECHECK_PERIOD                      600000
// Период ожидания ответного сообщения от ОФД сервера. Константа из документа "Описание протокола ККТ-ОФД в1_0.pdf"
#define GFD_SERVER_RESP_PERIOD                  300000


/// Статусы ОФД  (биты)
// Транспортное соединенеи установлено
#define OFD_INFO_T_SESSION              0x01
// Есть сообщение для передачи в ОФД
#define OFD_INFO_MSGOFD                 0x02
// Ожидание квитанции от ОФД
#define OFD_INFO_RECEIPT                0x04
// Есть команда от ОФД
#define OFD_INFO_CMDOFD                 0x08
// Изменилась настройка ОФД
#define OFD_INFO_CHGOFD                 0x10
// Ожидание ответа на команду от ОФД
#define OFD_INFO_WAIT_CMD               0x20


////////////////////////////////////////////////////////////////////////////
//  Типы данных


// Структура статуса ФН
typedef struct{
  uint8_t     phase_of_life;          // Состояние фазы жизни
  uint8_t     cur_doc;                // Текущий документ
  uint8_t     data_doc;               // Данные документа
  uint8_t     state_work_period;      // Состояние смены
  uint8_t     flags;                  // Флаги
  struct{
    uint8_t day;
    uint8_t month;
    uint8_t year;
    uint8_t hour;
    uint8_t min;
  }time_last_doc;                     // Дата и время последнего документа DATE_TIME
  char        fn_number[16];          // Номер ФН (фискального накоптеля) ASCII 16 байт
  uint32_t    fdata_last_number;      // Номер последнего ФД (фискального документа)
} __attribute__((packed)) _fn_status;

// Структура статуса информационного обмена с ОФД
typedef struct{
  uint8_t     ofd_status;             // Статус информационного обмена
  uint8_t     msg_ofd_read;           // Начато чтение сообщения для ОФД?
  uint16_t    msg_ofd_count;          // Количество сообщений для отправки в ОФД
  uint32_t    msg_ofd_number;         // Номер первого в очереди документа
  struct{
    uint8_t day;
    uint8_t month;
    uint8_t year;
    uint8_t hour;
    uint8_t min;
  }msg_ofd_time;                     // Дата и время первого в очереди документа DATE_TIME
} __attribute__((packed)) _fn_ofd_status;



/// Структура состояния ФН
typedef struct{
    _fn_status          fn_status;              // Статус ФН
    _fn_ofd_status      fn_ofd_status;          // Статус информационного обмена с ОФД
}fn_t;

/// Рабочая структура ОФД
typedef struct{
    bool            needtosend;                 // Флаг для внешних процедур о необходимости прелоставить все ресурсы процедуре взаимодействия с ОФД
    timeout_t       time;
}ofd_state_t;

///  Типы режимов информационного соединения с ОФД для ФН
typedef enum OFDINFOTag_mode {
    OFDINFO_MODE_SET_T       = 0,
    OFDINFO_MODE_RESET_T     = 1,
}OFDINFO_mode;



////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_INCLUDE_KKT_OFD_H_INCLUDED
