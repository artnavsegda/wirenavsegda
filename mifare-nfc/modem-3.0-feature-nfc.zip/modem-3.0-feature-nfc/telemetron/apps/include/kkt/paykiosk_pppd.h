/// \file
/// \brief  Сервис связи с ККМ Paykiosk через PPP протокол
/// \author DL <dmitriy@linikov.ru>
///
/// Данный сервис поднимает и поддерживает PPP сессию связи с ККМ,
/// осуществляя так же маршрутизацию IP4 траффика во внешнюю сеть
/// при необходимости.

#ifndef TELEMETRON_APPS_INCLUDE_KKT_PAYKIOSK_PPPD_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_KKT_PAYKIOSK_PPPD_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <ppp/libppp.h>
#include <utils/service.h>
#include <utils/smartio.h>
#include "kkt_config.h"

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора




////////////////////////////////////////////////////////////////////////////
//  Типы данных

/// \brief Тип дескриптора сервиса PPP для paykiosk. Унаследован от service_t.
typedef struct paykiosk_pppd_s {
  service_t           base;           ///< Наследуемся от service_t
  char                ttypath[CONFIG_PAYKIOSK_MAXPATH]; ///< Путь к драйверу uart/aux
  speed_t             baudrate;       ///< Скорость uart

  smartio_t           port;           ///< Порт общения с ККТ
  libppp_t*           ppp;            ///< Модуль PPP связи
  struct in_addr      kkt_addr;       ///< IPv4 адрес ККТ, полученный из PPP
  volatile bool       has_kkt_addr;   ///< Признак, что получили адрес ККТ
  bool                is_server_mode; ///< Режим работы PPP интрефейса: ведущий или ведомый
  libppp_err_t        ppp_err;        ///< Последний код ошибки от PPP
} paykiosk_pppd_t;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int paykiosk_pppd_create(
  paykiosk_pppd_t*  paykiosk_pppd,
  const char*       ttypath,
  speed_t           baudrate
);
int paykiosk_pppd_destroy(paykiosk_pppd_t* paykiosk_pppd);

int paykiosk_pppd_connect(paykiosk_pppd_t* paykiosk_pppd, int timeout_ms);
int paykiosk_pppd_disconnect(paykiosk_pppd_t* paykiosk_pppd, int timeout_ms);
int paykiosk_pppd_get_kkt_ip(paykiosk_pppd_t* paykiosk_pppd, struct in_addr* addr);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_INCLUDE_KKT_PAYKIOSK_PPPD_H_INCLUDED
