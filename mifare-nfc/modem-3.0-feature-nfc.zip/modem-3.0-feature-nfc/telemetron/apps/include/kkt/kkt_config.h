/// \file
/// \brief  Объявление настроек модуля paykiosk, настраиваемых через kconfig
/// \author DL <dmitriy@linikov.ru>


#ifndef TELEMETRON_APPS_INCLUDE_KKT_KKT_CONFIG_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_KKT_KKT_CONFIG_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <nuttx/config.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


#ifdef CONFIG_LIB_KKT_DEBUG_ERROR
#   define kkt_error(format, ...)  _err("KKT: " format, ##__VA_ARGS__)
#else
#   define kkt_error(x...)
#endif

#ifdef CONFIG_LIB_KKT_DEBUG_WARN
#   define kkt_warn(format, ...)   _warn("KKT: " format, ##__VA_ARGS__)
#else
#   define kkt_warn(x...)
#endif

#ifdef CONFIG_LIB_KKT_DEBUG_INFO
#   define kkt_info(format, ...)   _info("KKT: " format, ##__VA_ARGS__)
#else
#   define kkt_info(x...)
#endif

#ifdef CONFIG_LIB_KKT_DEBUG_TRACE
#   define kkt_trace(format, ...)  _info("KKT: " format, ##__VA_ARGS__)
#   define kkt_dump(msg, buf, sz)  infodumpbuffer((msg), (const uint8_t*)(buf), (sz))
#else
#   define kkt_trace(x...)
#   define kkt_dump(msg, buf, sz)
#endif


#if !defined(CONFIG_PAYKIOSK_PPP_CONNECT_TIMEOUT_MS) || defined(__DOXYGEN__)
/// \brief  Таймаут в мс на подключение PPP сессии при установке связи с paykiosk.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_PAYKIOSK_PPP_CONNECT_TIMEOUT_MS       45000
#endif

#if !defined(CONFIG_PAYKIOSK_SOCKET_CONNECT_TIMEOUT_MS) || defined(__DOXYGEN__)
/// \brief  Таймаут в мс на подключение к TCP сокету при установке связи с paykiosk.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_PAYKIOSK_SOCKET_CONNECT_TIMEOUT_MS    30000
#endif

////////////////////////////////////////////////////////////////////////////
//  Настройки сервиса paykiosk_pppd

#if !defined(CONFIG_PAYKIOSK_MAXPATH) || defined(__DOXYGEN__)
/// \brief  Максимальная длина пути к любому из файлов, используемых модулем
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_PAYKIOSK_MAXPATH    16
#endif

#if !defined(CONFIG_PAYKIOSK_PPP_WAIT_FOR_CLIENT_MS) || defined(__DOXYGEN__)
/// \brief  Время ожидания от ККТ строки "CLIENT" перед началом PPP сеанса
///
/// Если в paykiosk настройками задано, что PPP работает в режиме клиента,
/// то paykiosk постоянно отправляет в порт строку "CLIENT" и ожидает в ответ
/// получить строку "SERVER". Без этого не получается начать PPP сессию.
///
/// Поэтому, перед попыткой соединиться с paykiosk, модуль paykiosk_ppp
/// ожидает до CONFIG_PAYKIOSK_PPP_WAIT_FOR_CLIENT_MS миллисекунд
/// получения строки "CLIENT" и как только её обнаруживает, то отправляет
/// ответ и переключается в режим PPP мастера.
///
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_PAYKIOSK_PPP_WAIT_FOR_CLIENT_MS     5000
#endif

#if !defined(CONFIG_PAYKIOSK_PPP_RECOVERY_PAUSE_MS) || defined(__DOXYGEN__)
/// \brief  Задержка перед повторной попыткой подключения PPP сеанса
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_PAYKIOSK_PPP_RECOVERY_PAUSE_MS      2000
#endif

#if !defined(CONFIG_PAYKIOSK_PPP_SOFT_CLOSE_TIMEOUT_MS) || defined(__DOXYGEN__)
/// \brief  Максимальное время в мс на "мягкое" закрытие ppp сессии,
///         после которого сессия будет принудительно закрыта без
///         возможности обмена сообщениями.
///
/// Закрытие PPP сессии в LwIP происходит двумя методами:
/// - с оповещением удалённой точки о закрытии сеанса связи
/// - принудительно, без оповещения.
///
/// Данный параметр задаёт максимальное время, в течение которого происходит
/// попытка закрыть PPP сессию и оповестить об этом удалённую точку.
/// Если в течение CONFIG_PAYKIOSK_PPP_SOFT_CLOSE_TIMEOUT_MS миллисекунд
/// PPP сессия так и не будет закрыта, то произойдёт принудительное закрытие
/// без оповещения удалённой точки.
///
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_PAYKIOSK_PPP_SOFT_CLOSE_TIMEOUT_MS  5000
#endif

#if !defined(CONFIG_PAYKIOSK_PPP_KILL_TIMEOUT_MS) || defined(__DOXYGEN__)
/// \brief  Стандартное время на остановку сервиса.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_PAYKIOSK_PPP_KILL_TIMEOUT_MS        15000
#endif

#if !defined(CONFIG_LIB_KKT_PPP_DAEMON_PRIORITY) || defined(__DOXYGEN__)
/// \brief  Приоритет потока сервиса PPP связи с ККТ paykiosk.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_KKT_PPP_DAEMON_PRIORITY    85
#endif

#if !defined(CONFIG_LIB_KKT_PPP_DAEMON_STACK_SIZE) || defined(__DOXYGEN__)
/// \brief  Размер стека потока сервиса PPP связи с ККТ paykiosk
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_KKT_PPP_DAEMON_STACK_SIZE  4096
#endif

#endif // TELEMETRON_APPS_INCLUDE_KKT_KKT_CONFIG_H_INCLUDED
