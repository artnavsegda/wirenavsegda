/// \file
/// \brief  Сервис приёма и отправки sms сообщений
/// \author DL <dmitriy@linikov.ru>

#ifndef CONFIG_TELEMETRON_APPS_LIB_SMSD_INCLUDED
#define CONFIG_TELEMETRON_APPS_LIB_SMSD_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

int smsd_get_pid(void);
int smsd_start(int argc, const char* argv[]);
int smsd_stop(int argc, const char* argv[]);
int smsd_send(int argc, const char* argv[]);
const char* smsd_default_gsm_port(void);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // CONFIG_TELEMETRON_APPS_LIB_SMSD_INCLUDED
