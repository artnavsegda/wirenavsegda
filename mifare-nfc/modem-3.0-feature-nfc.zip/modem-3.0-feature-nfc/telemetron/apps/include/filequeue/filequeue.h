/// \file
/// \brief  FIFO очередь, реализованная через файловую систему.
/// \author DL <dmitriy@linikov.ru>
///
/// Файловая очередь представляет собой директорию, в которой хранятся файлы.
/// Все файлы хранятся в поддиректориях с именами 0..F, означающих приоритет
/// файлов в этой директории.
/// Сами файлы имеют имена в следующем формате (всего - 7 шестнадцатерчных чисел):
///   ABBBBBB
///   где
///     A       - шестнадцатеричная цифра, означающая приоритет файла
///     BBBBBB  - шестнадцатеричное число, означающее id сообщения.
///
/// Таким образом, полный путь к файлу можно узнать по одному 32-битному целому
/// числу, которое, к тому же, может быть знаковым, т.к. при таком
/// именовании файлов остаётся неиспользованным старший ниббл.
///
/// Папки с данными (для каждого из приоритетов) могут быть внешними.
/// В этом случае можно получить персистентное хранилище для части файлов.
/// Из-за ограничения в NuttX на создание файловых ссылок (файловые ссылки
/// можно создать только в корневой директории), доступ к самим файлам
/// будет осуществляться не через директории в папке /имяочереди,
/// а через символьные ссылки в корневой директории:
///   - /имяочереди_X, где X - шестнадцатеричная цифра, означающая приоритет.
///
/// Кроме непосредственно файлов данных в директории присутствует ещё ряд
/// вспомогательных файлов:
///   - /имяочереди
///       Именованный бинарный семафор, использующийся для
///       эксклюзивного доступа к директории с очередью.
///
///   - /имяочереди_cnt
///       Именованный семафор, считающий количество сообщений в очереди.
///
///   - /var/имяочереди/cfg
///       Файл с настройками очереди.
///       В него записывается одна запись типа fq_settings_t.
///
///   - /var/имяочереди/lastid
///       Файл с идентификатором файла, добавленного последним.
///       Идентификатор записывается в сыром виде (4 байта)
///       в натуральном для данного процессора порядке байт.
///       Данный идентификатор хранит и приоритет и id сообщения.
///       Используя значение в этом файле, очередь вычисляет
///       id следующего файла (отбрасывая поле приоритета,
///        т.к. у каждого файла свой приоритет).
///
/// Общие правила чтения из очереди:
///   1. Перед чтением необходимо дождаться наличия файла в очереди
///   2. Сразу после этого необходимо получить монопольный доступ к очереди
///   3. Получить id файла для чтения
///   4. В зависимости от времени обработки файла:
///      4.1. Если предполагается быстрая обработка файла:
///           4.1.1. Открыть файл
///           4.1.2. Прочитать и обработать файл
///           4.1.3. Закрыть файл
///           4.1.4. Удалить файл
///           4.1.5. Снять блокировку монопольного доступа к очереди.
///
///      4.2. Если предполагается длительная обработка файла:
///           4.2.1. Перенести файл из очереди в другое место, желательно
///                  в пределах той же файловой системы, что и хранилище,
///                  используемое для файлов соответствующего приоритета.
///           4.2.2. Снять блокировку монопольного доступа к очереди.
///           4.2.3. Открыть файл (теперь уже - используя стандартный open)
///           4.2.4. Прочитать и обработать файл
///           4.2.5. Закрыть файл
///           4.2.6. Удалить временный файл.
///
///   5. Если по какой-либо причине файл остался в очереди, то необходимо
///      обратно увеличить счётчик сообщений на единицу.


#ifndef CONFIG_TELEMETRON_APPS_LIB_FILEQUEUE_INCLUDED
#define CONFIG_TELEMETRON_APPS_LIB_FILEQUEUE_INCLUDED

#include <stdint.h>
#include <stdbool.h>


/// \brief Максимальное количество различных приоритетов сообщений в очереди.
///
/// Несмотря на то, что под приоритеты выделено 4 бита, данное значение выбрано
/// таким образом, что бы размер fq_settings_t оказался равным 32 байтам.
#define CONFIG_LIB_FILEQUEUE_MAX_PRIORITY_COUNT     14


/// \brief Стандартное количество различных приоритетов сообщений в очереди
#define CONFIG_LIB_FILEQUEUE_DEF_PRIORITY_COUNT     1


/// \brief Стандартное макс. количество файлов для каждого приоритета в очереди.
#define CONFIG_LIB_FILEQUEUE_DEF_FILES_PER_PRIORITY 64



#ifdef CONFIG_LIB_FILEQUEUE_DEBUG_ERROR
#   define fq_error(format, ...) _err("FQ:" format, ##__VA_ARGS__)
#else
#   define fq_error(x...)
#endif

#ifdef CONFIG_LIB_FILEQUEUE_DEBUG_WARN
#   define fq_warn(format, ...) _warn("FQ:" format, ##__VA_ARGS__)
#else
#   define fq_warn(x...)
#endif

#ifdef CONFIG_LIB_FILEQUEUE_DEBUG_INFO
#   define fq_info(format, ...) _info("FQ:" format, ##__VA_ARGS__)
#else
#   define fq_info(x...)
#endif

#ifdef CONFIG_LIB_FILEQUEUE_DEBUG_DEBUG
#   define fq_debug(format, ...) _info("FQ:" format, ##__VA_ARGS__)
#   define fq_debugdump(msg, buf, sz) infodumpbuffer(("FQ:" msg), (const uint8_t*)(buf), (sz))
#else
#   define fq_debug(x...)
#   define fq_debugdump(msg, buf, sz)
#endif

#ifdef CONFIG_LIB_FILEQUEUE_DEBUG_TRACE
#   define fq_trace(format, ...) _info("FQ:" format, ##__VA_ARGS__)
#   define fq_dump(msg, buf, sz) infodumpbuffer(("FQ:" msg), (const uint8_t*)(buf), (sz))
#else
#   define fq_trace(x...)
#   define fq_dump(msg, buf, sz)
#endif




/// Настройки файловой очереди.
typedef struct fq_settings_s {
  /// \brief Количество уровней приоритета, используемых данной очередью.
  ///
  /// Для поля приоритета выделено 4 бита. Однако, что бы не создавать
  /// лишних директорий, можно уменьшить количество используемых
  /// уровней приоритета.
  uint8_t   priority_count;

  /// \brief Зарезервировано под дополнительные настройки.
  ///
  /// В настоящее время не используется, нужно для выравнивания полей.
  uint8_t   flags;

  /// \brief Максимальное количество файлов для каждого из уровней приоритета.
  ///
  /// Данный массив описывает ограничение для каждой из директорий приоритета.
  /// Если соответствующее приоритету значение равно нулю, то
  /// директория с данным приоритетом не имеет ограничения по количеству файлов.
  ///
  /// Если \see priority_count меньше, чем CONFIG_LIB_FILEQUEUE_MAX_PRIORITY_COUNT,
  /// то ограничения количества файлов для неиспользуемых уровней приоритета
  /// не используются.
  uint16_t  max_files_per_priority[CONFIG_LIB_FILEQUEUE_MAX_PRIORITY_COUNT];

  /// \brief Контрольная сумма записи.
  ///
  /// Для вычисления используется библиотека telemetron/apps/lib_utils
  /// (CRC-16, полином 0xA001).
  uint16_t  crc;
} fq_settings_t;


/// \brief Тип данных, описывающих идентификатор сообщения в очереди.
typedef int32_t     fq_id_t;

#ifdef __cplusplus
extern "C" {
#endif

int fq_create(const char* queue_name, const fq_settings_t* settings);
int fq_create_ex( const char*           queue_name,
                  const fq_settings_t*  settings,
                  const char* const     dir_links[]);
int fq_lock(const char* queue_name);
int fq_lock_timeout(const char* queue_name, int32_t timeout_ms);
int fq_unlock(const char* queue_name);
int fq_push_new(const char* queue_name, int priority, fq_id_t* created_id);
int fq_push_or_replace_id(const char* queue_name, fq_id_t msg_id);
int fq_push_existing(const char* queue_name, int priority,
                    const char* existing, fq_id_t* created_id);
fq_id_t fq_find_head(const char* queue_name);
int fq_read(const char* queue_name, fq_id_t msg_id);
int fq_unlink(const char* queue_name, fq_id_t msg_id);

int fq_counter_wait_timeout(const char* queue_name, int32_t timeout_ms);
int fq_counter_increment(const char* queue_name);
int fq_counter_read(const char* queue_name, int* value);

int fq_has_message(const char* queue_name, fq_id_t msg_id);


#ifdef __cplusplus
} // extern "C"
#endif

#endif // CONFIG_TELEMETRON_APPS_LIB_FILEQUEUE_INCLUDED
