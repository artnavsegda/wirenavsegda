/// \file
/// \brief  Объявление перечисления всех состояний сервиса GSMD gsmd_state_t
/// \author DL <dmitriy@linikov.ru>


#ifndef TELEMETRON_APPS_INCLUDE_GSMD_GSMD_STATE_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_GSMD_GSMD_STATE_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов


////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Типы данных

typedef enum {
  GSMD_STATE_UNINITED = 0,
  GSMD_STATE_START_RECOVER_FROM_HARD_ERROR,
  GSMD_STATE_START_RECOVER_FROM_SIMCARD_ERROR,
  GSMD_STATE_START_RECOVER_FROM_GSM_ERROR,
  GSMD_STATE_START_RECOVER_FROM_GPRS_ERROR,
  GSMD_START_RECOVERING_FROM_ERROR_WITH_POWERCYCLE,
  GSMD_STATE_START_CHANGING_SETTINGS,
  GSMD_STATE_RECOVERING_SLEEP,
  GSMD_STATE_TURNING_ON,
  GSMD_STATE_WAITING_FOR_AT_READY,
  GSMD_STATE_START_WAITING_SIM_READY,
  GSMD_STATE_START_WAITING_NET_REGISTRATION,
  GSMD_STATE_WAITING_NET_REGISTRATION,
  GSMD_STATE_PPP_INIT,
  GSMD_STATE_PPP_HANDSHAKING,
  GSMD_STATE_PPP_ONLINE,
  GSMD_STATE_PPP_CLOSING,
  GSMD_STATE_PPP_CLOSED,
} gsmd_state_t;


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_INCLUDE_GSMD_GSMD_STATE_H_INCLUDED
