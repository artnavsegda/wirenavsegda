/// \file
/// \brief  Сервис поддержания ppp сеанса связи через GSM модуль.
/// \author DL <dmitriy@linikov.ru>

#ifndef CONFIG_TELEMETRON_APPS_LIB_GSMD_INCLUDED
#define CONFIG_TELEMETRON_APPS_LIB_GSMD_INCLUDED


////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <nuttx/config.h>

#include <arpa/inet.h>
#include <netinet/in.h>
#include <poll.h>

#include <nuttx/gsm/atport.h>
#include <nuttx/gsm/modem.h>
#include <utils/service.h>
#include <eventq/eventq.h>
#include <ppp/libppp.h>

#include "gsmd_state.h"
#include "gsmd_events.h"



////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

// =========================================================================
//    Объявление логгеров для модуля gsmd

#ifdef CONFIG_LIB_GSMD_DEBUG_ERROR
#   define gsmd_error(format, ...) _err("GSMD: " format, ##__VA_ARGS__)
#else
#   define gsmd_error(x...)
#endif

#ifdef CONFIG_LIB_GSMD_DEBUG_WARN
#   define gsmd_warn(format, ...) _warn("GSMD: " format, ##__VA_ARGS__)
#else
#   define gsmd_warn(x...)
#endif

#ifdef CONFIG_LIB_GSMD_DEBUG_INFO
#   define gsmd_info(format, ...) _info("GSMD: " format, ##__VA_ARGS__)
#else
#   define gsmd_info(x...)
#endif

#ifdef CONFIG_LIB_GSMD_DEBUG_TRACE
#   define gsmd_trace(format, ...) _info("GSMD: " format, ##__VA_ARGS__)
#   define gsmd_dump(msg, buf, sz) infodumpbuffer(("GSMD: " msg), (const uint8_t*)(buf), (sz))
#else
#   define gsmd_trace(x...)
#   define gsmd_dump(msg, buf, sz)
#endif


// =========================================================================
//    Настройки времени компиляции модуля gsmd


#if !defined(CONFIG_LIB_GSMD_DAEMON_PRIORITY) || defined(__DOXYGEN__)
/// \ingroup compiletime_params
/// \brief  Приоритет потока сервиса gsmd
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_GSMD_DAEMON_PRIORITY      122
#endif

#if !defined(CONFIG_LIB_GSMD_DAEMON_STACK_SIZE) || defined(__DOXYGEN__)
/// \ingroup compiletime_params
/// \brief  Размер стека для потока сервиса gsmd
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_GSMD_DAEMON_STACK_SIZE    2048
#endif

#if !defined(CONFIG_LIB_GSMD_MAX_PATH) || defined(__DOXYGEN__)
/// \brief  Максимальное количество символов (без учёта завершающего нуля)
///         в строках настроек путей и прочих имён.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_GSMD_MAX_PATH             15
#endif

#if !defined(CONFIG_LIB_GSMD_HARD_RECOVERY_MS) || defined(__DOXYGEN__)
/// \brief  Время восстановления (в миллисекундах) после серьёзных ошибок
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_GSMD_HARD_RECOVERY_MS     30000
#endif

#if !defined(CONFIG_LIB_GSMD_BAUDRATE) || defined(__DOXYGEN__)
/// \brief  Скорость работы последовательного порта GSM модема.
///
/// Поддерживаются только следующие значения:
///   9600, 19200, 38400, 57600, 115200, 230400 и 460800
///
/// Данный параметр имеет значение только если данный сервис запускается
/// напрямую для последовательного порта модема, а не через драйвер мультиплексирования
/// портов модема.
///
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_GSMD_BAUDRATE             115200
#endif

#if !defined(CONFIG_LIB_GSMD_IDLE_SLEEP_MS) || defined(__DOXYGEN__)
/// \brief  Время спячки потока сервиса в состоянии простоя.
///
/// Так же этим параметром задаётся длительность поллинга I/O портов.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_GSMD_IDLE_SLEEP_MS        1000
#endif

#if !defined(CONFIG_LIB_GSMD_WAIT_AT_READY_MS) || defined(__DOXYGEN__)
/// \brief  Максимальное время (в мс) ожидания ответа на первую после включения AT-команду
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_GSMD_WAIT_AT_READY_MS     15000
#endif

#if !defined(CONFIG_LIB_GSMD_WAIT_SIMCARD_READY_MS) || defined(__DOXYGEN__)
/// \brief  Максимальное время (в мс) ожидания готовности симкарты.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_GSMD_WAIT_SIMCARD_READY_MS      15000
#endif

#if !defined(CONFIG_LIB_GSMD_WAIT_NET_REGISTRATION_MS) || defined(__DOXYGEN__)
/// \brief  Максимальное время (в мс) ожидания регистрации GSM модуля в сети.
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_GSMD_WAIT_NET_REGISTRATION_MS   120000
#endif

#if !defined(CONFIG_LIB_GSMD_T_OUTPUT_QUEUE_WAIT_MS) || defined(__DOXYGEN__)
/// \brief  Максимальное время ожидания наличия места в исходящей очереди
/// \note   Обычно данный параметр задаётся через Kconfig (make menuconfig)
# define CONFIG_LIB_GSMD_T_OUTPUT_QUEUE_WAIT_MS    500
#endif


#define GSMD_PATHSZ       (CONFIG_LIB_GSMD_MAX_PATH + 1)


////////////////////////////////////////////////////////////////////////////
//  Типы данных



struct gsmd_s {
  // состояния сервиса
  service_t         base;                     ///< Наследуемся от service_t
  atport_t          port;                     ///< Открытый последовательный порт GSM модуля
  int               gsm;                      ///< Файловый дескриптор драйвера GSM модуля
  struct pollfd     fds[2];                   ///< Для использования в poll_raw_files
  struct file*      files[2];                 ///< Для использования в poll_raw_files
#ifdef CONFIG_LIB_EVENTQ
  eventq_t          output;                   ///< Очередь сообщений для отправки уведомлений основному модулю
#endif
  gsmd_state_t      state;                    ///< Текущее состояние сервиса
  struct timespec   timer;                    ///< Таймаут для текущего состояния (используется не всеми состояниями)
  struct timespec   connect_timer;            ///< Таймаут на установление PPP сеанса
  volatile bool     settings_changed;         ///< Флаг, что изменены настройки и сервис должен перечитать их
  modem_iccid_t     iccid;                    ///< Идентификатор текущей sim-карты
  bool              roaming;                  ///< Устройство в роуминге
  libppp_t*         ppp;                      ///< Экземпляр ppp сеанса
  libppp_err_t      ppp_err;                  ///< Код ошибки, устанавливается в момент сбоя PPP

  bool                have_route;             ///< Маршрут установлен.
  struct sockaddr_in  route_target;           ///< Целевая сеть.
  struct sockaddr_in  route_netmask;          ///< Маска целевой сети.
  struct sockaddr_in  route_gateway;          ///< Маршрутизатор.


  // настройки сервиса
  char              gsm_path[GSMD_PATHSZ];    ///< Путь к драйверу GSM модуля
  char              tty_path[GSMD_PATHSZ];    ///< Путь к драйверу последовательного порта GSM модуля
  char              eventq_name[GSMD_PATHSZ]; ///< Имя очереди сообщений. Присутствует, даже если библиотека не подключена.
  bool              ppp_override_apn;         ///< Как использовать ppp_apn/user/pwd: true=всегда, false=если нет в базе.
  char              ppp_apn[GSMD_PATHSZ];     ///< Имя точки доступа
  char              ppp_user[GSMD_PATHSZ];    ///< Имя пользователя точки доступа
  char              ppp_pwd[GSMD_PATHSZ];     ///< Пароль пользователя точки доступа
};

/// \brief Настройки сервиса gsmd -
typedef struct gsmd_settings_s {
  const char*   gsm_path;             ///< Путь к драйверу gsm модуля
  const char*   tty_path;             ///< Путь к драйверу последовательного порта
  const char*   eventq_name;          ///< Имя очереди сообщений для уведомления о состоянии. Используется, если CONFIG_LIB_EVENTQ=y
  bool          ppp_override_apn;     ///< Как использовать ppp_apn/user/pwd: true=всегда, false=если нет в базе.
  const char*   ppp_apn;              ///< Точка доступа
  const char*   ppp_user;             ///< Имя пользователя
  const char*   ppp_pwd;              ///< Пароль
} gsmd_settings_t;

typedef struct gsmd_s   gsmd_t;



////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

gsmd_t* gsmd_get_instance(void);
int     gsmd_setup(gsmd_t* gsmd, const gsmd_settings_t* settings);

const char* gsmd_state_to_string(gsmd_state_t value);

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  inline функции

static inline int gsmd_start(gsmd_t* gsmd)
{
  return service_start((service_t*)gsmd);
}

static inline int gsmd_kill(gsmd_t* gsmd)
{
  return service_kill((service_t*)gsmd);
}

static inline int gsmd_wait_terminated(gsmd_t* gsmd, int timeout_ms)
{
  return service_wait_terminated((service_t*)gsmd, timeout_ms);
}

static inline bool gsmd_is_started(gsmd_t* gsmd)
{
  return service_is_started((service_t*)gsmd);
}

#endif // CONFIG_TELEMETRON_APPS_LIB_GSMD_INCLUDED
