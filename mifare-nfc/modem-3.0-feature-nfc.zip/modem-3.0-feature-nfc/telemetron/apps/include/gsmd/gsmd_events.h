/// \file
/// \brief  Перечень событий, отправляемых сервисом GSMD в очередь сообщений.
/// \author DL <dmitriy@linikov.ru>


#ifndef TELEMETRON_APPS_INCLUDE_GSMD_GSMD_EVENTS_H_INCLUDED
#define TELEMETRON_APPS_INCLUDE_GSMD_GSMD_EVENTS_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "gsmd_state.h"

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

/// \brief Начальный номер событий от srvd
#define EV_GSMD_BASE              0x0300

/// \ingroup fw_events
/// \brief Событие изменения состояния сервиса связи с сервером
///
/// Данное событие всегда имеет вложение типа \ref ev_gsmd_state_t
#define EV_GSMD_STATE             (EV_GSMD_BASE + 0)


////////////////////////////////////////////////////////////////////////////
//  Типы данных

/// \brief Тип данных, описывающий вложение в событие EV_GSMD_STATE.
typedef struct ev_gsmd_state_s {
  gsmd_state_t          state;    ///< Текущее состояние сервиса GSMD.
} ev_gsmd_state_t;


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_INCLUDE_GSMD_GSMD_EVENTS_H_INCLUDED
