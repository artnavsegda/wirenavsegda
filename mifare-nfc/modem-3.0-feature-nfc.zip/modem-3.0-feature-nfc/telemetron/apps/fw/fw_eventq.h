/// \file
/// \brief  Объявления функций для работы с очередью сообщений из основного модуля прошивки.
/// \author DL <dmitriy@linikov.ru>


#ifndef TELEMETRON_APPS_FW_FW_EVENTQ_H_INCLUDED
#define TELEMETRON_APPS_FW_FW_EVENTQ_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов


////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Типы данных

// Предварительные объявления использованных типов данных
typedef struct fw_s             fw_t;
typedef struct eventq_event_s   eventq_event_t;

#ifdef __cplusplus
extern "C" {
#endif

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций
int fw_evq_create(FAR fw_t* fw);
int fw_evq_close(FAR fw_t* fw);
int fw_evq_read_timeout(FAR fw_t* fw, int timeout_ms);
int fw_evq_write(FAR fw_t* fw, int event, const void* data, size_t size);
int fw_evq_write_ex(FAR fw_t* fw, FAR const eventq_event_t* event);
int fw_evq_get_pollfd(FAR fw_t* fw);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_FW_FW_EVENTQ_H_INCLUDED
