/// \file
/// \brief  Модуль, отвечающий за отправку отчётов на сервер
/// \author DL <dmitriy@linikov.ru>


#ifndef TELEMETRON_APPS_FW_SENDER_H_INCLUDED
#define TELEMETRON_APPS_FW_SENDER_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <semaphore.h>

#include <filequeue/filequeue.h>
#include "serverq.h"
#include <settings/settings.h>
#include <nuttx/version.h>

#include <vmcd/vmcd_event.h>
#include <auditd/audit_events.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Типы данных

typedef struct fw_s   fw_t;

// Пока не используется. Нужно для добавления других протоколов
typedef struct sender_s {
  fw_t*           fw;
  sem_t           lock;
  int             fd;
  fq_id_t         msgid;
  serverq_prio_t  prio;
} sender_t;


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int sender_create(sender_t* sender, fw_t* fw);
int sender_destroy(sender_t* sender);

int sender_send_reset(
  sender_t* sender,
  uint32_t csr_value,
  const char* reason,
  const settings_t* settings
);

int sender_send_event_with_settings(
  sender_t*       sender,
  const char*     event,
  const settings_t* settings
);

int sender_send_response_settings(
  sender_t*       sender,
  const char*     reason,
  const settings_t* settings
);

int sender_send_set_settings_confirmation(
  sender_t*             sender,
  bool                  ok
);

int sender_send_bus_state(
  sender_t*     sender,
  const char*   protocol_name,
  bool          is_ok
);

int sender_send_vend_report(
  sender_t*           sender,
  vmcd_event_sale_t*  sale,
  const char*         product_caption,
  bool                high_price,
  uint16_t            max_price
);

int sender_send_audit(
  sender_t*           sender,
  const char*         reason,
  ev_audit_report_t*  audit
);

int sender_send_event_btn(
  sender_t*             sender
);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_FW_SENDER_H_INCLUDED
