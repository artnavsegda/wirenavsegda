/// \file
/// \author DL <dmitriy.linikov@gmail.com>

#ifndef INDICATORS_H_INCLUDED
#define INDICATORS_H_INCLUDED

#include "sequencer.h"
#include "red_green_led.h"

#define BEEPER_ON   1
#define BEEPER_OFF  0

extern const Led    LedPower;
extern const Led    LedGsm;
extern const Led    LedServer;
extern const Led    LedAux1;
extern const Led    LedAux2;
extern const Led    LedAux3;
extern const Led    LedMdbExe1;
extern const Led    LedMdbExe2;

extern Sequencer    LedPowerController;
extern Sequencer    LedGsmController;
extern Sequencer    LedServerController;
extern Sequencer    LedAux1Controller;
extern Sequencer    LedAux2Controller;
extern Sequencer    LedAux3Controller;
extern Sequencer    LedMdbExe1Controller;
extern Sequencer    LedMdbExe2Controller;

// void UpdateLeds(void);
// void UpdateBeeper(void);

void IndicatorsStop(void);
void IndicatorsStart(void);

void BeepSetEnabled(bool enabled);
void BeepOnce(uint32_t duration_ms);
void BeepError(void);
void BeepSuccess(void);
void BeepSequence(const Sequence* sequence);
void BeepCancell(void);

sequencer_mutex_t BeepSequenceMutex(const Sequence* sequence, sequencer_mutex_t mutex);
sequencer_mutex_t BeepOnceMutex(uint32_t duration_ms, sequencer_mutex_t mutex);
sequencer_mutex_t BeepErrorMutex(sequencer_mutex_t mutex);
sequencer_mutex_t BeepClearMutex(void);

#endif // LEDS_H_INCLUDED
