/// \file
/// \brief Оболочка над двумя GPIO каналами для управления двухцветным
/// (красный-зелёный) светодиодом.
/// \author DL <dmitriy.linikov@gmail.com>

#ifndef RED_GREEN_LED_H_INCLUDED
#define RED_GREEN_LED_H_INCLUDED

#include <stdint.h>


#define MAKE_RGB(r, g, b) ( (((uint32_t)(r) & 0xFF) << 0) \
                          | (((uint32_t)(g) & 0xFF) << 8) \
                          | (((uint32_t)(b) & 0xFF) << 16)\
                          )

/// \brief Перечисление доступных цветов для светодиода.
typedef enum LedColorTag {
  LED_COLOR_BLACK   = 0,
  LED_COLOR_RED     = MAKE_RGB(0xFF,  0,    0),
  LED_COLOR_GREEN   = MAKE_RGB(0,     0xFF, 0),
  LED_COLOR_YELLOW  = MAKE_RGB(0xFF,  0xFF, 0),

  // нужен больше для того, что бы размер типа данных оказался больше, чем 2
  LED_COLOR_WHITE   = MAKE_RGB(0xFF,  0xFF, 0xFF),
} LedColor;


// предварительное объявление.
struct GpioChannelTag;

/// \brief Дескриптор, описывающий двухцветный светодиод.
typedef struct {
  const char* dev_name;
  // const struct GpioChannelTag*  red_channel;
  // const struct GpioChannelTag*  green_channel;
} RedGreenLed;

/// \brief Сокращённая запись для удобства использования.
typedef RedGreenLed   Led;

/// \brief Устанавливает новый цвет \p color светодиоду \p led.
void LedSetColor(const Led* led, LedColor color);

#endif // RED_GREEN_LED_H_INCLUDED
