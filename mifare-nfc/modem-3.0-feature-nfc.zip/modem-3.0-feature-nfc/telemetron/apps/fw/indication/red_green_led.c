/// \file
/// \author DL <dmitriy.linikov@gmail.com>
/// \see red_green_led.h

// #include <gpio.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <utils/posix_iohelper.h>
#include "red_green_led.h"



void LedSetColor(const Led* led, LedColor color)
{
  if (!led) {
    return;
  }
  if (!led->dev_name) {
  	return;
  }

  uint32_t led_color = color;
  WriteHelper(led->dev_name, &led_color, sizeof(led_color));
}
