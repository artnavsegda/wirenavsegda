/// \file
/// \author DL <dmitriy.linikov@gmail.com>
/// \see sequencer.h

#include <stddef.h>
#include "sequencer.h"

static sequencer_mutex_t cur_mutex=0;

static void SequencerClearSave(Sequencer* me)
{
  me->save_value = CLEAR_VALUE;
  me->save_sequence = NULL;
}

static void SequencerClear(Sequencer* me)
{
  me->current_sequence = NULL;
  me->current_step = 0;
}

static void SequencerUpdateValue(Sequencer* me, sequencer_value_t new_value)
{
  if (me->update) {
    me->update(me->update_arg, new_value);
  }
}

static void SequencerSetStep(Sequencer* me, uint8_t step)
{
  if (!me->current_sequence) {
    return;
  }

  if (!me->current_sequence->steps_count || !me->current_sequence->steps) {
    SequencerClear(me);
    return;
  }

  if (step >= me->current_sequence->steps_count) {
    if (!me->current_sequence->repeat) {
      // Последовательность закончилась и её не нужно повторять.
      SequencerClear(me);
      return;
    }

    // Необходимо начать последовательность заново
    step = 0;
  }

  // устанавливаем выбранный шаг анимации
  me->current_step = step;
  const SequencerStep*  current_step = &me->current_sequence->steps[step];
  timeout_start(&me->current_timeout, (systime_t)MS2ST(current_step->duration));
  SequencerUpdateValue(me, current_step->value);
}

static void SequencerNextStep(Sequencer* me)
{
  SequencerSetStep(me, me->current_step + 1);
}

static void SequencerProcessLocked(Sequencer* me)
{
  if (!me->current_sequence) {
    return;
  }

  if (!timeout_is_elapsed(&me->current_timeout)) {
    return;
  }

  SequencerNextStep(me);
}

static void SequencerSetValueLocked(Sequencer* me, sequencer_value_t value)
{
  SequencerClear(me);
  SequencerUpdateValue(me, value);
}

static void SequencerSetValueSave(Sequencer* me, sequencer_value_t value)
{
  SequencerClearSave(me);
  me->save_value=value;
}

static void SequencerPlayLocked(Sequencer* me, const Sequence* sequence)
{
  SequencerClear(me);
  me->current_sequence = sequence;
  SequencerSetStep(me, 0);
}

static void SequencerPlaySave(Sequencer* me, const Sequence* sequence)
{
  SequencerClearSave(me);
  me->save_sequence = sequence;
}

void SequencerProcess(Sequencer* me)
{
  //__disable_irq();
  SequencerProcessLocked(me);
  //__enable_irq();
}

void SequencerSetValue(Sequencer* me, LedColor value)
{
  /// \todo DL: SequencerSetValue Возможно следует эмулировать запрет прерываний как-то ещё

  // __disable_irq();
  if (!me->mutex)
    SequencerSetValueLocked(me, value);
  SequencerSetValueSave(me, value);
  // __enable_irq();
}

void SequencerPlay(Sequencer* me, const Sequence* sequence)
{
  /// \todo DL: SequencerPlay Возможно следует эмулировать запрет прерываний как-то ещё
  // __disable_irq();
  if (!me->mutex)
    SequencerPlayLocked(me, sequence);
  SequencerPlaySave(me, sequence);
  // __enable_irq();
}

sequencer_mutex_t SequencerPlayMutex(Sequencer* me, const Sequence* sequence, sequencer_mutex_t mutex)
{
  /// \todo DL: SequencerPlayMutex Возможно следует эмулировать запрет прерываний как-то ещё
  // __disable_irq();
  sequencer_mutex_t ret=0;
  if (mutex==me->mutex)
  {
    if (!mutex)
    {
        if (!(cur_mutex+1)) cur_mutex++;
        me->mutex=++cur_mutex;
    }
    SequencerPlayLocked(me, sequence);
    ret=me->mutex;
  }
  // __enable_irq();
  return(ret);
}

sequencer_mutex_t SequencerSetMutexValue(Sequencer* me, LedColor value, sequencer_mutex_t mutex)
{
  /// \todo DL: SequencerSetMutexValue Возможно следует эмулировать запрет прерываний как-то ещё
  // __disable_irq();
  sequencer_mutex_t ret=0;
  if (mutex==me->mutex)
  {
    if (!mutex)
    {
        if (!(cur_mutex+1)) cur_mutex++;
        me->mutex=++cur_mutex;
    }
    SequencerSetValueLocked(me, value);
    ret=me->mutex;
  }
  // __enable_irq();
  return(ret);
}

sequencer_mutex_t SequencerClearMutex(Sequencer* me)
{
  if (me->mutex)
  {
      me->mutex=0;
      if (me->save_value!=CLEAR_VALUE)
          SequencerSetValue(me,me->save_value);
      if (me->save_sequence)
          SequencerPlay(me,me->save_sequence);
  }
  return(me->mutex);
}
