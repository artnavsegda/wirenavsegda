/// \file
/// \author DL <dmitriy.linikov@gmail.com>
/// \see leds.h

#include <stdio.h>
#include <unistd.h>
#include <semaphore.h>
#include <signal.h>
#include <sched.h>
#include <errno.h>

#include <nuttx/wqueue.h>
#include <nuttx/wdog.h>

#include <dbg.h>
#include <utils/posix_iohelper.h>
#include "indicators.h"

#ifndef LED_POWER_DEV_NAME
#define LED_POWER_DEV_NAME  "/dev/ledpower"
#endif

#ifndef LED_GSM_DEV_NAME
#define LED_GSM_DEV_NAME    "/dev/lednet"
#endif

#ifndef LED_SERVER_DEV_NAME
#define LED_SERVER_DEV_NAME "/dev/ledserver"
#endif

#ifndef LED_AUX1_DEV_NAME
#define LED_AUX1_DEV_NAME    "/dev/ledaux1"
#endif

#ifndef LED_AUX2_DEV_NAME
#define LED_AUX2_DEV_NAME    "/dev/ledaux2"
#endif

#ifndef LED_AUX3_DEV_NAME
#define LED_AUX3_DEV_NAME    "/dev/ledaux3"
#endif

#ifndef LED_MDBEXE1_DEV_NAME
#define LED_MDBEXE1_DEV_NAME "/dev/ledmdb1"
#endif

#ifndef LED_MDBEXE2_DEV_NAME
#define LED_MDBEXE2_DEV_NAME "/dev/ledmdb2"
#endif

#ifndef BUZZER_DEV_NAME
#define BUZZER_DEV_NAME     "/dev/buzzer"
#endif






const Led LedPower = {
  .dev_name = LED_POWER_DEV_NAME
};

const Led LedGsm = {
  .dev_name = LED_GSM_DEV_NAME
};

const Led LedServer = {
  .dev_name = LED_SERVER_DEV_NAME
};

const Led LedAux1 = {
  .dev_name = LED_AUX1_DEV_NAME
};

const Led LedAux2 = {
  .dev_name = LED_AUX2_DEV_NAME
};

const Led LedAux3 = {
  .dev_name = LED_AUX3_DEV_NAME
};

const Led LedMdbExe1 = {
  .dev_name = LED_MDBEXE1_DEV_NAME
};

const Led LedMdbExe2 = {
  .dev_name = LED_MDBEXE2_DEV_NAME
};

static void BeeperUpdateFxn(void* unused, sequencer_value_t new_value);

static volatile bool    g_indicators_timer_exist = false;

// В данном случае все приведения безопасны, но нужно быть осторожным, если
// изменятся параметры вызова LedSetColor или GpioWrite
DECLARE_SEQUENCER(LedPowerController,  (SequencerUpdateFxn)LedSetColor, (void*)&LedPower);
DECLARE_SEQUENCER(LedGsmController,    (SequencerUpdateFxn)LedSetColor, (void*)&LedGsm);
DECLARE_SEQUENCER(LedServerController, (SequencerUpdateFxn)LedSetColor, (void*)&LedServer);
DECLARE_SEQUENCER(LedAux1Controller,   (SequencerUpdateFxn)LedSetColor, (void*)&LedAux1);
DECLARE_SEQUENCER(LedAux2Controller,   (SequencerUpdateFxn)LedSetColor, (void*)&LedAux2);
DECLARE_SEQUENCER(LedAux3Controller,   (SequencerUpdateFxn)LedSetColor, (void*)&LedAux3);
DECLARE_SEQUENCER(LedMdbExe1Controller,(SequencerUpdateFxn)LedSetColor, (void*)&LedMdbExe1);
DECLARE_SEQUENCER(LedMdbExe2Controller,(SequencerUpdateFxn)LedSetColor, (void*)&LedMdbExe2);

// Для того, что бы не было возможности запустить писк в обход функций
// BeepOnce и BeepSequence, в которых учитывается, разрешён ли сейчас
// писк или нет, данный секвенсер объявлен статическим.
static DECLARE_SEQUENCER(BeeperController,    BeeperUpdateFxn,   NULL);
static volatile bool g_beeper_enabled = false;

static void BeeperUpdateFxn(void* unused, sequencer_value_t new_value)
{
  char value = '0' + !!new_value;
  WriteHelper(BUZZER_DEV_NAME, &value, 1);
}


static void UpdateLeds(void)
{
  SequencerProcess(&LedPowerController);
  SequencerProcess(&LedGsmController);
  SequencerProcess(&LedServerController);
  SequencerProcess(&LedAux1Controller);
  SequencerProcess(&LedAux2Controller);
  SequencerProcess(&LedAux3Controller);
  SequencerProcess(&LedMdbExe1Controller);
  SequencerProcess(&LedMdbExe2Controller);
  SequencerProcess(&BeeperController);
}

#if 1
// Использование POSIX таймеров оказалось очень накладной операцией для организации
// периодического опроса светодиодов, т.к. в текущей реализации в NuttX  на каждый
// вызов функции опроса POSIX-таймер создаёт новый поток (и удаляет его после выхода
// из функции опроса). Это довольно сильно нагружает процессор и не позволяет
// делать быстрый опрос.
//
// Вместо этого использовал связку из "сторожевых таймеров" и "рабочей очереди" из NuttX.
// И сторожевые таймеры и рабочая очередь используют статически выделенный объект
// для хранения своего состояния и при использовании не используют динамическую память.
//
// Работает это так:
//  1. Таймер вызываются из контекста прерывания таймера. Поскольку в данном прерывании
//     - не следует выполнять продолжительные задачи
//     - и нельзя использовать posix функции, которые



struct wdog_s g_indication_wdog = WDOG_INITIAILIZER;
struct work_s g_indication_worker = {0};

void IndicatorsWorkerCallback(void* arg)
{
  UpdateLeds();
}

static void IndicatorsWdTimerCallback(int argc, wdparm_t arg1, ...)
{
  (void)argc;
  (void)arg1;

  // Перезапуск таймера
  IndicatorsStart();

  // Переводим из контекста прерывания в контекст потока
  if (work_available(&g_indication_worker)) {
    work_queue(USRWORK, &g_indication_worker, IndicatorsWorkerCallback, NULL, 0);
  }
}

void IndicatorsStop(void)
{
  SequencerSetValue(&LedPowerController, LED_COLOR_BLACK);
  SequencerSetValue(&LedGsmController, LED_COLOR_BLACK);
  SequencerSetValue(&LedServerController, LED_COLOR_BLACK);
  SequencerSetValue(&LedAux1Controller, LED_COLOR_BLACK);
  SequencerSetValue(&LedAux2Controller, LED_COLOR_BLACK);
  SequencerSetValue(&LedAux3Controller, LED_COLOR_BLACK);
  SequencerSetValue(&LedMdbExe1Controller, LED_COLOR_BLACK);
  SequencerSetValue(&LedMdbExe2Controller, LED_COLOR_BLACK);

  BeepCancell();

  wd_cancel(&g_indication_wdog);
}

void IndicatorsStart(void)
{
  wd_start(&g_indication_wdog, MS2ST(100), IndicatorsWdTimerCallback, 1, 0);
}

#else

#ifndef INDICATORS_CALLBACK_VAL
// Просто случайное число, которое будет передано в обработчик события таймера
#define INDICATORS_CALLBACK_VAL   47
#endif

static timer_t          g_indicators_timer;


static void IndicatorsTimerCallback(FAR void *sival_ptr)
{
  // Значение, которое было передано в timer_create.
  // Сейчас не используется, но оставим на будущее.
  int sival_int = (int)((intptr_t)sival_ptr);
  (void)sival_int;

  UpdateLeds();
}


void IndicatorsStop(void)
{
  if (!g_indicators_timer_exist) {
    return;
  }

  if (timer_delete(g_indicators_timer) != OK) {
    log_warn("IndicatorsStop:timer_delete: errno=%d\n", errno);
    return;
  }

  g_indicators_timer_exist = false;
}


void IndicatorsStart(void)
{
  int result;


  // Создаём таймер, который будет вызывать callback при переполнении.
  struct sigevent notify;
  notify.sigev_notify            = SIGEV_THREAD;
  notify.sigev_notify_function   = IndicatorsTimerCallback;
  notify.sigev_notify_attributes = NULL;
  notify.sigev_value.sival_int   = INDICATORS_CALLBACK_VAL;

  result = timer_create(CLOCK_REALTIME, &notify, &g_indicators_timer);
  if (result != OK) {
    log_warn("IndicatorsStart:timer_create: errno=%d\n", errno);
    return;
  }
  g_indicators_timer_exist = true;


  // Настраиваем данный таймер на период 100мс и запускаем его
  struct itimerspec timer;
  timer.it_value.tv_sec     = 0;          // Время до первого события таймера (секунды + наносекунды)
  timer.it_value.tv_nsec    = 100000000;

  timer.it_interval.tv_sec  = 0;          // Период между последующими событиями таймера (секунды + наносекунды)
  timer.it_interval.tv_nsec = 100000000;

  result = timer_settime(g_indicators_timer, 0, &timer, NULL);
  if (result != OK) {
    log_warn("IndicatorsStart:timer_settime: errno=%d\n", errno);
    IndicatorsStop();
    return;
  }
}
#endif

void BeepSetEnabled(bool enabled)
{
  g_beeper_enabled = enabled;
  if (!enabled) {
    BeepCancell();
  }
}

void BeepSequence(const Sequence* sequence)
{
  if (g_beeper_enabled) {
    SequencerPlay(&BeeperController, sequence);
  }
}


void BeepOnce(uint32_t duration_ms)
{
  static SequencerStep  single_beep_steps[] = {
    { .value = 1, .duration = 0 },
    { .value = 0, .duration = 0 }
  };

  static const Sequence       single_beep = {
    .steps = single_beep_steps,
    .steps_count = 2,
    .repeat = false
  };

  single_beep_steps[0].duration = duration_ms;
  BeepSequence(&single_beep);
}

void BeepError()
{
  static const SequencerStep  error_beep_steps[] = {
    { .value = 1, .duration = 200 },
    { .value = 0, .duration = 200 },
    { .value = 1, .duration = 200 },
    { .value = 0, .duration = 200 },
    { .value = 1, .duration = 200 },
    { .value = 0, .duration = 200 },
    { .value = 1, .duration = 200 },
    { .value = 0, .duration = 200 },
    { .value = 1, .duration = 200 },
    { .value = 0, .duration = 200 }
  };

  static const Sequence    error_beep = {
    .steps = error_beep_steps,
    .steps_count = 10,
    .repeat = false
  };

  BeepSequence(&error_beep);
}

void BeepSuccess()
{
  BeepOnce(500);
}

void BeepCancell()
{
  SequencerSetValue(&BeeperController, 0);
}

sequencer_mutex_t BeepSequenceMutex(const Sequence* sequence, sequencer_mutex_t mutex)
{
  sequencer_mutex_t ret=0;
  if (g_beeper_enabled) {
    ret=SequencerPlayMutex(&BeeperController, sequence, mutex);
  }
  return(ret);
}

sequencer_mutex_t BeepOnceMutex(uint32_t duration_ms, sequencer_mutex_t mutex)
{
  static SequencerStep  single_beep_steps[] = {
    { .value = 1, .duration = 0 },
    { .value = 0, .duration = 0 }
  };

  static const Sequence       single_beep = {
    .steps = single_beep_steps,
    .steps_count = 2,
    .repeat = false
  };

  single_beep_steps[0].duration = duration_ms;
  return(BeepSequenceMutex(&single_beep, mutex));
}

sequencer_mutex_t BeepErrorMutex(sequencer_mutex_t mutex)
{
  static const SequencerStep  error_beep_steps[] = {
    { .value = 1, .duration = 200 },
    { .value = 0, .duration = 200 },
    { .value = 1, .duration = 200 },
    { .value = 0, .duration = 200 },
    { .value = 1, .duration = 200 },
    { .value = 0, .duration = 200 },
    { .value = 1, .duration = 200 },
    { .value = 0, .duration = 200 },
    { .value = 1, .duration = 200 },
    { .value = 0, .duration = 200 }
  };

  static const Sequence    error_beep = {
    .steps = error_beep_steps,
    .steps_count = 10,
    .repeat = false
  };

  return(BeepSequenceMutex(&error_beep, mutex));
}

sequencer_mutex_t BeepClearMutex(void)
{
    return(SequencerClearMutex(&BeeperController));
}
