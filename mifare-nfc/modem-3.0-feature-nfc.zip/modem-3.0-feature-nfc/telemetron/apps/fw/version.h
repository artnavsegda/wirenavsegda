/// \file
/// \brief Функции для получения информации о версии текущей прошивки.
/// \author DL <dmitriy.linikov@gmail.com>

#ifndef VERSION_H_INCLUDED
#define VERSION_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

const char* VersionGet(void);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // VERSION_H_INCLUDED
