/// \file
/// \brief  Отправка данных на сервер
/// \author DL <dmitriy@linikov.ru>


////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "sender.h"

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include <utils/posix_iohelper.h>
#include <utils/string_utils.h>

#include <fw/fw_config.h>
#include <settings/settings.h>



#include "serverq.h"

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора

#define CHECK(op)                                                         \
  do {                                                                    \
    int __ret = (op);                                                     \
    if (__ret < 0) {                                                      \
      fw_trace("\"%s\" fail, ret=%d (%s)\n", #op, __ret, strerror(__ret));\
      return __ret;                                                       \
    }                                                                     \
  } while (0)

////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы

////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Приватные функции

static bool ReadTextOrDefault(const char* file, char* buf, size_t bufsize, const char* def_value)
{
  ssize_t ret = ReadTextFile(file, buf, bufsize);
  if (ret < 0) {
    ret = snprintf(buf, bufsize, def_value);
    DEBUGASSERT(ret < bufsize);
  }
  return ret;
}




int sender_create_report(sender_t* sender, serverq_prio_t prio)
{
  int ret = serverq_lock();
  if (ret < 0) {
    return ret;
  }

  DEBUGASSERT(sender->fd < 0);  // Частая ошибка - незакрытый отчёт.
  sender->prio = prio;
  sender->fd    = serverq_push_new(prio, &sender->msgid);
  if (sender->fd < 0) {
    serverq_unlock();
    return sender->fd;
  }
  return 0;
}

int sender_undo_report(sender_t* sender)
{
  if (sender->fd >= 0) {
    close(sender->fd);
    sender->fd = -1;
  }
  serverq_unlink(sender->msgid);
  serverq_unlock();
  return 0;
}

int sender_complete_report(sender_t* sender)
{
  if (sender->fd >= 0) {
    close(sender->fd);
    sender->fd = -1;
  }
  serverq_unlock();
  return 0;
}

static int format_header(sender_t* sender)
{
  // поля imei и time заполняются самим отправщиком, больше нечего делать
  return 0;
}





static int format_settings(sender_t* sender, const settings_t* settings)
{
  char buffer[32];
  ReadTextOrDefault("/proc/gsm0/id", buffer, sizeof(buffer), "UNKNOWN");
  dprintf(sender->fd, "gsm_module=%s&", buffer);

  ReadTextOrDefault("/proc/gsm0/rev", buffer, sizeof(buffer), "UNKNOWN");
  dprintf(sender->fd, "gsm_module_sw_version=%s&", buffer);

  ReadTextOrDefault("/proc/gsm0/iccid", buffer, sizeof(buffer), "ERRORERRORERRORERRO");
  dprintf(sender->fd, "iccid=%s&", buffer);

  dprintf(sender->fd, "apn=%s&login=%s&pass=%s&",
    settings_get_apn_name(settings), settings_get_apn_user(settings), settings_get_apn_pwd(settings)
  );

  dprintf(sender->fd, "server=%s&port=%u&path=%s&",
    settings_get_server_address(settings),
    settings_get_server_port(settings),
    settings_get_server_path(settings)
  );

  dprintf(sender->fd, "sound=%d,timeout=%d&",
    settings_get_beep(settings), settings_get_server_ping_interval_s(settings)
  );

  const mdbexe_params_t* mdb = settings_get_mdbexe(settings);
  dprintf(sender->fd,  "delay=%d&door=%d&bus=%s&send_vend=%d&",
    mdb->error_timeout_ms / 1000,
    *settings_get_door_time_s(settings),
    mdbexe_bus_to_string(mdb->bus),
    *settings_get_send_vend(settings)
  );

  for (size_t i=0; i < MAX_AUX_PORTS; ++i) {
    const aux_params_t* aux = settings_get_aux(settings, i);
    dprintf(sender->fd, "evadts_port_%c=%s&type_evadts_port_%c=%s&",
      'a'+i,
      aux_interface_to_string(aux->interface),
      'a'+i,
      aux_type_to_string(aux->type)
    );

    dprintf(sender->fd, "cfg_evadts_port_%c=%d,%d,%d,%d,%d&evadts_port_%c_saeco_fix=%d&",
      'a'+i,
      aux->ddcmp_params.ddcmp_mode,
      aux->ddcmp_params.ddcmp_extended,
      aux->ddcmp_params.ddcmp_auditmode,
      aux->ddcmp_params.ddcmp_fix_baud,
      aux->idlestate,
      'a'+i,
      aux->ddcmp_params.ddcmp_saeco_fix
    );
  }


  dprintf(sender->fd, "encrypt=%d&",  *settings_get_encrypt(settings));

  dprintf(sender->fd, "version=%s&",  VERSINFO_VERSION_STRING);

  //dst = AppendSchedule    (dst, end, pref, "schedule=", settings->schedule,
  return 0;
}


static int create_event_without_settings(
  sender_t* sender,
  const char* event
)
{
  CHECK(format_header(sender));
  CHECK(dprintf(sender->fd, "event=%s&", event) );
  return 0;
}

static int create_event_with_settings(
  sender_t* sender,
  const char* event,
  const settings_t* settings
)
{
  CHECK(create_event_without_settings(sender, event));
  CHECK(format_settings(sender, settings));
  return 0;
}

static int create_response_settings(
  sender_t*   sender,
  const char* reason,
  const settings_t* settings
)
{
  CHECK(format_header(sender));
  CHECK(dprintf(sender->fd, "reason=%s&", reason ? reason : ""));
  CHECK(format_settings(sender, settings));
  return 0;
}

static int create_event_reset(
  sender_t* sender,
  uint32_t csr_value,
  const char* reason,
  const settings_t* settings
)
{
  CHECK(create_event_with_settings(sender, "TRES", settings));
  CHECK(
    dprintf(
      sender->fd,
      "dbg_reg_csr=0x%08X&"
      "dbg_reset=%s&"
      "dbg_software_position=sw_main_loop_0&",

      csr_value,
      reason ? reason : "unknown"
    )
  );
  return 0;
}


static int create_event_btn(
  sender_t* sender
)
{
  CHECK(create_event_without_settings(sender, "BTN"));
  return 0;
}

static int create_bus_status_packet(
  sender_t*     sender,
  const char*   protocol_name,
  bool          is_ok
)
{
  CHECK(create_event_without_settings(sender, is_ok ? "TXX_" : "TYY_"));
  CHECK(dprintf(sender->fd, "dbg_%s_status=%s&",  protocol_name, is_ok ? "ok" : "error"));
  return 0;
}

static int format_vend_price(
  sender_t* sender,
  int32_t   value,
  int16_t   dot
)
{
  if (value < 0) {
    return (dprintf(sender->fd, "0"));
  }


  if (dot < 0) {
    dot = 1;
  }

  int32_t decimal     = value / dot;
  int32_t fractional  = value % dot;

  int digits = 0;
  while (dot >= 10) {
    dot = dot / 10;
    ++digits;
  }

  CHECK(dprintf(sender->fd, "%d", decimal));
  if (!digits) {
    return 0;
  }

  char fractional_format[8];
  snprintf(fractional_format, sizeof(fractional_format), "%%0%dd");

  CHECK(dprintf(sender->fd, fractional_format, fractional));
  return 0;
}

static int create_vend_packet(
  sender_t*           sender,
  vmcd_event_sale_t*  sale,
  const char*         product_caption,
  bool                high_price,
  uint16_t            max_price
)
{
  const char* bus_name = sale->bus_id == VMCBUS_ID_EXE ? "exe" : "mdb";
  CHECK(format_header(sender));
  CHECK(dprintf(sender->fd, "%s=vend&", bus_name));
  CHECK(dprintf(sender->fd, "%s_product[]=%d", sale->product_name));
  if (sale->price > 0) {
    CHECK(dprintf(sender->fd, ","));
    CHECK(format_vend_price(sender, sale->price, sale->dot));
  } else if (!sale->price) {
    CHECK(dprintf(sender->fd, ",free"));
  } else {
    fw_error("ERROR: Product price is NEGATIVE!\n");
    CHECK(dprintf(sender->fd, ",NEGATIVE"));
  }

  // дата продажи
  struct tm   t;
  localtime_r(&sale->dt, &t);
  CHECK(
    dprintf(
      sender->fd, ",%04d-%02d-%02d %02d:%02d:%02d"
    )
  );

  // название продукта (текст)
  CHECK(dprintf(sender->fd, ",%s", product_caption ? product_caption : ""));

  // Тип продажи
  // Параметр payment - тип продажи. Для EXE пусто, так как не хнаем как продали.
  CHECK(
    dprintf(
      sender->fd, ",%s",

      sale->bus_id != VMCBUS_ID_MDB
      ? ""
      : sale->paytype == VMCD_PAYTYPE_CASHLESS
        ? "cashless"
        : "cash"
    )
  );

  if (sale->currency > 0 && sale->currency < 0xFFFF) {
    CHECK(dprintf(sender->fd,",%d", sale->currency));
  } else {
    CHECK(dprintf(sender->fd, ","));
  }

  if (high_price) {
    CHECK(dprintf(sender->fd, ",price_higher_%d", max_price));
  }
  return 0;
}

static inline bool ShouldReplace(char c)
{
  const char chars_to_replace[] = "/#=$%?;:@&+ !(){}[],-.\x27\"";
  return strchr(chars_to_replace, c) != NULL;
}

static inline void BoundedWrite(char* ptr, char c, char* buffer_end)
{
  if (ptr < buffer_end) {
    *ptr = c;
  }
}

char* UrlEncodeInplace(char* start, char* end, char* buffer_end)
{
  // Действуем в 2 прохода:
  // Сначала ищем все неподходящие символы, а затем при обратном проходе
  // заменяем неподходящие символы.
  char*   p = start;
  size_t  n = 0;
  while (p != end) {
    if (ShouldReplace(*p++)) {
      ++n;
    }
  }

  if (!n) {
    return end;
  }

  size_t  delta_chars = n * 2; // один символ заменяется тремя, например # = %23

  while (delta_chars) {
    char c = *(--p);
    if (!ShouldReplace(c)) {
      // если не заменяем
      BoundedWrite(p + delta_chars, c, buffer_end);
    } else {
      // символ нужно заменить.
      delta_chars -= 2;
      BoundedWrite(p + delta_chars, '%', buffer_end);
      BoundedWrite(p + delta_chars + 1, DigitToHex(c >> 4), buffer_end);
      BoundedWrite(p + delta_chars + 2, DigitToHex(c & 0x0F), buffer_end);
    }
  }

  if (end + n*2 < buffer_end) {
    buffer_end = end + n*2;
  }
  *buffer_end = '\0';

  return buffer_end;
}

static int sender_urlencode_file(
  sender_t*           sender,
  int                 fd,
  size_t              file_size
)
{
#define CHUNK_SIZE    32
  char   buf[CHUNK_SIZE*3];


  while(file_size) {
    size_t bytes_to_read = file_size > CHUNK_SIZE ? CHUNK_SIZE : file_size;
    ssize_t nread = read(fd, buf, bytes_to_read);

    if (nread < 0) {
      return -errno;
    }

    if (!nread) {
      // Файл закончился рано
      return -ENODATA;
    }

    file_size -= nread;

    // Преобразование прочитанной части данных
    char* ptr = UrlEncodeInplace(buf,  buf+nread, buf + sizeof(buf));;

    // и запись в целевой файл.
    size_t nconverted = ptr - buf;
    ptr = buf;
    while (nconverted) {
      ssize_t nwritten = write(fd, ptr, nconverted);
      if (nwritten < 0) {
        return -errno;
      }
      if (!nwritten) {
        return -ENOSPC;
      }
      ptr += nwritten;
      nconverted -= nwritten;
    }
  }
  return 0;
}

static int create_audit_packet(
  sender_t*           sender,
  const char*         reason,
  ev_audit_report_t*  audit
)
{
  int           ret;
  int           fd = -1;
  size_t        report_size = 0;


  const char* port_name     = audit->instance_id == 1 ? "B"
                            : audit->instance_id == 2 ? "C"
                            : "A";

  const char* instance_name = audit->instance_id == 1 ? "b"
                            : audit->instance_id == 2 ? "c"
                            : "a";

  fw_debug(
    "Sending audit report: reason:%d, instance_id:%d, protocol:%d (%s), interface: %d (%s), error_code:%08X, filename:\"%s\", size:%u\n",
    reason ? reason : "",
    audit->instance_id,
    audit->protocol,
    audit_protocol_to_string(audit->protocol),
    audit->interface,
    audit_interface_to_string(audit->interface),
    audit->error_code,
    audit->path,
    audit->report_size
  );

  CHECK(format_header(sender));
  CHECK(dprintf(sender->fd, "reason=%s&", reason ? reason : ""));
  CHECK(dprintf(sender->fd, "evadts_port=%s&", port_name));
  CHECK(dprintf(sender->fd, "evadts_saeco_fix=%d&", audit->saeco_fix));
  CHECK(dprintf(sender->fd, "evadts_port_%s=%s&", instance_name, audit_interface_to_string(audit->interface) ));
  CHECK(dprintf(sender->fd, "dbg_evadts_type=%s&", audit_protocol_to_string(audit->protocol) ));
  //dst_middle = AppendIntValue    (dst_middle, end_middle, BRAKE_SYMBOL, "dbg_evadts_time_ms=", time, INT_VALUE);
  //dst_middle = AppendIntValue    (dst_middle, end_middle, BRAKE_SYMBOL, "dbg_buffer_size=", end-enter_dst, INT_VALUE);
  //dst_middle = AppendIntValue    (dst_middle, end_middle, ",", " ", end-enter_evadts_data, INT_VALUE);

  // rawlog не поддерживается
  if (audit->error_code != 0) {
    // Произошла ошибка при снятии отчёта
    CHECK(dprintf(sender->fd, "dbg_evadts_error=0x%08X&evadts=error", audit->error_code));
    return 0;
  }

  // Попытка открытия файла с отчётом
  fd = open(audit->path, O_RDONLY);
  if (fd >= 0) {
    struct stat   fileinfo;

    ret = fstat(fd, &fileinfo);
    if (ret < 0) {
      ret = -errno;
      close(fd);
      fd = ret;
    } else {
      report_size = fileinfo.st_size;
    }
  } else {
    fd = -errno;
  }

  if (fd < 0) {
    // Не удалось открыть файл с отчётом
    CHECK(dprintf(sender->fd, "dbg_evadts_fileerror=%d&evadts=error", -fd));
    return 0;
  }

  // снято без ошибок

  CHECK(dprintf(sender->fd, "dbg_evadts_size=%s,%s&", report_size, report_size));
  CHECK(dprintf(sender->fd, "dbg_evadts_%s_connection=%d&", audit_protocol_to_string(audit->protocol), audit->error_code));
  CHECK(dprintf(sender->fd, "evadts="));
  CHECK(sender_urlencode_file(sender, fd, report_size));
  CHECK(dprintf(sender->fd, "&"));
  close(fd);

  return 0;
}

int create_settings_confirmation(
  sender_t*             sender,
  bool                  ok
) {
  CHECK(format_header(sender));
  CHECK(dprintf(sender->fd, "set=%s&", ok ? "ok" : "error"));
  return 0;
}


////////////////////////////////////////////////////////////////////////////
//  Публичные функции
int sender_create(sender_t* sender, fw_t* fw)
{
  DEBUGASSERT(sender);
  memset(sender, 0, sizeof(*sender));

  int ret = sem_init(&sender->lock, 0, 1);
  if (ret < 0) {
    return ret;
  }

  sender->fw = fw;
  sender->fd = -1;
  sender->msgid = 0;

  return 0;
}

int sender_destroy(sender_t* sender)
{
  DEBUGASSERT(sender);
  if (!sender->fw) {
    return 0;
  }

  sem_destroy(&sender->lock);
  sender->fw = NULL;
  return 0;
}

int sender_send_reset(
  sender_t* sender,
  uint32_t csr_value,
  const char* reason,
  const settings_t* settings
)
{
  int ret;
  DEBUGASSERT(sender && sender->fw);
  ret = sem_wait(&sender->lock);
  if (ret < 0) {
    ret = -errno;
    return ret;
  }

  ret = sender_create_report(sender, SERVERQ_PRIO_LOW);
  if (ret < 0) {
    goto cleanup;
  }

  ret = create_event_reset(sender, csr_value, reason, settings);
  if (ret < 0) {
    // Ошибка создания отчёта.
    goto cleanup_with_report;
  }

  sender_complete_report(sender);
  ret = 0;
  goto cleanup;

cleanup_with_report:
  sender_undo_report(sender);

cleanup:
  sem_post(&sender->lock);
  return ret;
}


int sender_send_event_with_settings(
  sender_t*       sender,
  const char*     event,
  const settings_t* settings
)
{
  int ret;
  DEBUGASSERT(sender && sender->fw);
  ret = sem_wait(&sender->lock);
  if (ret < 0) {
    ret = -errno;
    return ret;
  }

  ret = sender_create_report(sender, SERVERQ_PRIO_LOW);
  if (ret < 0) {
    goto cleanup;
  }

  ret = create_event_with_settings(sender, event, settings);
  if (ret < 0) {
    // Ошибка создания отчёта.
    goto cleanup_with_report;
  }


  sender_complete_report(sender);
  ret = 0;
  goto cleanup;

cleanup_with_report:
  sender_undo_report(sender);

cleanup:
  sem_post(&sender->lock);
  return ret;
}

int sender_send_response_settings(
  sender_t*       sender,
  const char*     reason,
  const settings_t* settings
)
{
  int ret;
  DEBUGASSERT(sender && sender->fw);
  ret = sem_wait(&sender->lock);
  if (ret < 0) {
    ret = -errno;
    return ret;
  }

  ret = sender_create_report(sender, SERVERQ_PRIO_LOW);
  if (ret < 0) {
    goto cleanup;
  }

  ret = create_response_settings(sender, reason, settings);
  if (ret < 0) {
    // Ошибка создания отчёта.
    goto cleanup_with_report;
  }


  sender_complete_report(sender);
  ret = 0;
  goto cleanup;

cleanup_with_report:
  sender_undo_report(sender);

cleanup:
  sem_post(&sender->lock);
  return ret;

}


int sender_send_bus_state(
  sender_t*     sender,
  const char*   protocol_name,
  bool          is_ok
)
{
  int ret;
  DEBUGASSERT(sender && sender->fw);
  ret = sem_wait(&sender->lock);
  if (ret < 0) {
    ret = -errno;
    return ret;
  }

  ret = sender_create_report(sender, SERVERQ_PRIO_HIGH);
  if (ret < 0) {
    goto cleanup;
  }

  ret = create_bus_status_packet(sender, protocol_name, is_ok);
  if (ret < 0) {
    // Ошибка создания отчёта.
    goto cleanup_with_report;
  }

  sender_complete_report(sender);
  ret = 0;
  goto cleanup;

cleanup_with_report:
  sender_undo_report(sender);

cleanup:
  sem_post(&sender->lock);
  return ret;
}



int sender_send_vend_report(
  sender_t*           sender,
  vmcd_event_sale_t*  sale,
  const char*         product_caption,
  bool                high_price,
  uint16_t            max_price
)
{
  int ret;
  DEBUGASSERT(sender && sender->fw);
  ret = sem_wait(&sender->lock);
  if (ret < 0) {
    ret = -errno;
    return ret;
  }

  ret = sender_create_report(sender, SERVERQ_PRIO_LOW);
  if (ret < 0) {
    goto cleanup;
  }

  ret = create_vend_packet(sender, sale, product_caption, high_price, max_price);
  if (ret < 0) {
    // Ошибка создания отчёта.
    goto cleanup_with_report;
  }

  sender_complete_report(sender);
  ret = 0;
  goto cleanup;

cleanup_with_report:
  sender_undo_report(sender);

cleanup:
  sem_post(&sender->lock);
  return ret;
}



int sender_send_audit(
  sender_t*           sender,
  const char*         reason,
  ev_audit_report_t*  audit
)
{
  int ret;
  DEBUGASSERT(sender && sender->fw);
  ret = sem_wait(&sender->lock);
  if (ret < 0) {
    ret = -errno;
    return ret;
  }

  ret = sender_create_report(sender, SERVERQ_PRIO_LOW);
  if (ret < 0) {
    goto cleanup;
  }

  ret = create_audit_packet(sender, reason, audit);
  if (ret < 0) {
    // Ошибка создания отчёта
    goto cleanup_with_report;
  }

  sender_complete_report(sender);
  ret = 0;
  goto cleanup;

cleanup_with_report:
  sender_undo_report(sender);

cleanup:
  sem_post(&sender->lock);
  return ret;
}


int sender_send_event_btn(
  sender_t*             sender
)
{
  int ret;
  DEBUGASSERT(sender && sender->fw);
  ret = sem_wait(&sender->lock);
  if (ret < 0) {
    ret = -errno;
    return ret;
  }

  ret = sender_create_report(sender, SERVERQ_PRIO_LOW);
  if (ret < 0) {
    goto cleanup;
  }

  ret = create_event_btn(sender);
  if (ret < 0) {
    // Ошибка создания отчёта
    goto cleanup_with_report;
  }

  sender_complete_report(sender);
  ret = 0;
  goto cleanup;

cleanup_with_report:
  sender_undo_report(sender);

cleanup:
  sem_post(&sender->lock);
  return ret;
}

int sender_send_set_settings_confirmation(
  sender_t*             sender,
  bool                  ok
) {
  int ret;
  DEBUGASSERT(sender && sender->fw);
  ret = sem_wait(&sender->lock);
  if (ret < 0) {
    ret = -errno;
    return ret;
  }

  ret = sender_create_report(sender, SERVERQ_PRIO_LOW);
  if (ret < 0) {
    goto cleanup;
  }

  ret = create_settings_confirmation(sender, ok);
  if (ret < 0) {
    // Ошибка создания отчёта
    goto cleanup_with_report;
  }

  sender_complete_report(sender);
  ret = 0;
  goto cleanup;

cleanup_with_report:
  sender_undo_report(sender);

cleanup:
  sem_post(&sender->lock);
  return ret;
}
