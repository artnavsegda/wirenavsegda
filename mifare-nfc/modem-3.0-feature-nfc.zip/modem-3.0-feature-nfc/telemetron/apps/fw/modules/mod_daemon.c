/// \file
/// \brief  Базовый класс для модуля управления каким-либо сервисом
/// \author DL <dmitriy@linikov.ru>
///
/// Модуль управления сервисом обрабатывает следующие события:
///   - EV_START  - Пытается запустить сервис
///   - EV_STOP   - Пытается остановить сервис
///   - EV_TIMER  - Проверяет, запущен ли сервис и пытается его запустить повторно.
///
/// Унаследованные модули должны реализовать лишь функции:
///   - start_service
///   - stop_service
///   - check_service
///
/// А обработку сообщений и периодическую проверку состояния реализует
/// данный модуль.

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "mod_daemon.h"
#include <fw/fw_config.h>
#include <fw/fw_events.h>
#include <utils/time_utils.h>

#include <assert.h>
#include <debug.h>
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>



////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Приватные функции

static int mod_daemon_start_daemon(FAR mod_daemon_t* instance)
{
  int ret = -ENOSYS;

  if (instance->vmt->start_daemon) {
    ret = instance->vmt->start_daemon(instance);
  }

  if (ret < 0) {
    fw_error("Can't start \"%s\" instance, ret=%d (%s)\n",
      instance->name, ret, strerror(-ret)
    );
  }
  return ret;
}

static int mod_daemon_stop_daemon(FAR mod_daemon_t* instance)
{
  int ret = -ENOSYS;

  if (instance->vmt->stop_daemon) {
    ret = instance->vmt->stop_daemon(instance);
  }

  if (ret < 0) {
    fw_error("Can't stop \"%s\" instance, ret=%d (%s)\n",
      instance->name, ret, strerror(-ret)
    );
  }
  return ret;
}

static int mod_daemon_check_daemon(FAR mod_daemon_t* instance)
{
  int ret = -ENOSYS;
  if (instance->vmt->check_daemon) {
    ret = instance->vmt->check_daemon(instance);
  }
  // Не выводим в лог, т.к. проверка происходит довольно часто
  return ret;
}

static void mod_daemon_on_ev_start(FAR mod_daemon_t* instance, FAR eventq_event_t* event)
{
  // Вызов обработчика унаследованных объектов
  if (instance->vmt->on_ev_start) {
    instance->vmt->on_ev_start(instance, event);
  }

  // запуск сервиса
  if (instance->state != MOD_DAEMON_STATE_STOPPED) {
    // Не позволяем запускать из неподходящих состояний
    return;
  }

  if (mod_daemon_start_daemon(instance) < 0) {
    // Уходим на pause_ms миллисекунд в состояние паузы
    instance->state         = MOD_DAEMON_STATE_ERROR;
    instance->restart_time  = timespec_plus_ms(&event->time, instance->pause_ms);
    return;
  }

  // Сервис успешно запущен.
  instance->state = MOD_DAEMON_STATE_STARTED;
}

static void mod_daemon_on_ev_stop(FAR mod_daemon_t* instance, FAR eventq_event_t* event)
{
  // Вызов обработчика унаследованных объектов
  if (instance->vmt->on_ev_stop) {
    instance->vmt->on_ev_stop(instance, event);
  }

  // остановка сервиса
  if (instance->state == MOD_DAEMON_STATE_STARTED) {
    int ret = mod_daemon_stop_daemon(instance);
    if (ret < 0) {
      // ошибка остановки. остаёмся в состоянии STARTED.
      return;
    }

    instance->state = MOD_DAEMON_STATE_STOPPED;
    return;
  }

  // Из состояния ошибки и состояния STOPPED останавливать не нужно.
  // Что бы не добавлять лишних if, для обоих состояний просто меняем
  // состояние на STOPPED и выходим.
  instance->state = MOD_DAEMON_STATE_STOPPED;
}

static void mod_daemon_on_ev_timer(FAR mod_daemon_t* instance, FAR eventq_event_t* event)
{
  // Вызов обработчика унаследованных объектов
  if (instance->vmt->on_ev_timer) {
    instance->vmt->on_ev_timer(instance, event);
  }

  // Проверка работы сервиса
  if (instance->state == MOD_DAEMON_STATE_ERROR) {
    int ret;
    if (!timespec_is_passed(&instance->restart_time)) {
      return;
    }
    ret = mod_daemon_start_daemon(instance);
    if (ret < 0) {
      // Очередная попытка не удалась. Переводим таймер вперёд и выходим.
      instance->restart_time  = timespec_plus_ms(&event->time, instance->pause_ms);
      return;
    }
    // сервис запущен.
    instance->state = MOD_DAEMON_STATE_STARTED;
    return;
  }

  if (instance->state == MOD_DAEMON_STATE_STARTED) {
    // Проверка, что сервис всё ещё запущен.
    int ret = mod_daemon_check_daemon(instance);
    if (ret < 0) {
      // Ошибка.
      instance->state = MOD_DAEMON_STATE_ERROR;
      instance->restart_time  = timespec_plus_ms(&event->time, MOD_DAEMON_DEFAULT_RESTART_INTERVAL_MS);
      return;
    }
    // Сервис работает.
    return;
  }
}



static void mod_daemon_on_event(FAR mod_t* module, FAR eventq_event_t* event)
{
  // Обработка всех поддерживаемых событий.
  FAR mod_daemon_t* instance = (FAR mod_daemon_t*)module;
  if (event->id == EV_START) {
    mod_daemon_on_ev_start(instance, event);
    return;
  }

  if (event->id == EV_STOP) {
    mod_daemon_on_ev_stop(instance, event);
    return;
  }

  if (event->id == EV_TIMER) {
    mod_daemon_on_ev_timer(instance, event);
    return;
  }

  // Обработка неподдерживаемых событий производится наследниками.
  if (instance->vmt->on_event) {
    instance->vmt->on_event(instance, event);
  }
}



////////////////////////////////////////////////////////////////////////////
//  Публичные функции

int mod_daemon_create(
  FAR mod_daemon_t*       instance,
  const mod_daemon_vmt_t* vmt,
  uint32_t                pause_ms,
  const char*             name
)
{
  int ret;
  DEBUGASSERT(instance && vmt);

  ret = mod_create(instance, mod_daemon_on_event, NULL);
  if (ret < 0) {
    return ret;
  }

  // Подстановка стандартных значений аргументов
  if (!pause_ms) {
    pause_ms = MOD_DAEMON_DEFAULT_RESTART_INTERVAL_MS;
  }
  if (!name) {
    name = "";
  }

  // сохранение настроек модуля
  instance->vmt         = vmt;
  instance->pause_ms    = pause_ms;
  instance->name        = name;
  instance->state       = MOD_DAEMON_STATE_STOPPED;

  return 0;
}
