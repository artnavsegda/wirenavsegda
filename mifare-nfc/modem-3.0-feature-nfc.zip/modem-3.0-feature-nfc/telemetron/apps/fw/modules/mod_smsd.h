/// \file
/// \brief  Модуль управления сервисом sms сообщений.
/// \author DL <dmitriy@linikov.ru>
///
///

#ifndef TELEMETRON_APPS_FW_MODULES_MOD_SMSD_H_INCLUDED
#define TELEMETRON_APPS_FW_MODULES_MOD_SMSD_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "mod_daemon.h"

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

/// \brief Время в миллисекундах между попытками запустить сервис sms сообщений.
#define MOD_SMSD_RESTART_INTERVAL_MS      30000

////////////////////////////////////////////////////////////////////////////
//  Типы данных

/// \brief  Модуль управления сервисом sms сообщений.
/// \extends mod_t
typedef struct mod_smsd_s {
  mod_daemon_t      base;           ///< Базовый объект для интеграции в обработку событий.

  const char*       eventq_name;    ///< Имя очереди сообщений для исходящих событий.
  const char*       modem_port;     ///< Путь к драйверу порта модема.

} mod_smsd_t;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int mod_smsd_create(FAR mod_smsd_t* smsd, const char* eventq_name, const char* modem_port);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_FW_MODULES_MOD_SMSD_H_INCLUDED
