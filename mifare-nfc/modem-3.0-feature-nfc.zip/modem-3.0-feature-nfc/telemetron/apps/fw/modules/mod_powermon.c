/// \file
/// \brief  Модуль, осуществляющий периодическую проверку напряжения питания.
/// \author DL <dmitriy@linikov.ru>

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "mod_powermon.h"

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <nuttx/sysutils/ival_file.h>
#include <utils/timeout.h>
#include <utils/posix_iohelper.h>
#include <fw/fw_events.h>
#include <fw/fw_config.h>

#include <settings/settings.h>
#include "status_bitfield.h"
#include "dbg.h"


////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


/// \brief Время на разогрев ТА после подключения питания.
#define CFG_WARMUP_DURATION_MS          30000
/// Время рабоыт от батареи (1 час)
#define CFG_TIME_TO_SHUTDOWN_MS         3600000l

/// \brief Максимальное время в сервисном режиме, после которого считаем,
/// что потеряно питание (с соответствующим уведомлением).
/// Стандартно - 10 минут.
#define CFG_MAX_SERVICE_MODE_TIME_MS    600000


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные

static timeout_t                    power_lost_timeout;
static timeout_t                    warm_up_timeout;
static timeout_t                    service_mode_timeout;
static timeout_t                    shutdown_timeout={.start=0};
static int32_t  tcore=0;
static int32_t  vinput=0;



////////////////////////////////////////////////////////////////////////////
//  Приватные функции



static int32_t ReadSupplyMillivolts(void)
{
  int32_t vin_mv;
  int ret = IoctlHelper(
    CONFIG_TELEMETRON_FW_ADC_VIN_PATH,
    IVALIOC_GET,
    (unsigned long)&vin_mv
  );

  if (ret < 0) {
    return 0;
  }
  return vin_mv;
}

static int32_t ReadCoreTemperature(void)
{
  int32_t mcu_temperature;
  int ret = IoctlHelper(
    CONFIG_TELEMETRON_FW_ADC_VIN_PATH,
    IVALIOC_GET,
    (unsigned long)&mcu_temperature
  );

  if (ret < 0) {
    return 0;
  }
  return mcu_temperature;
}


static int powermon_emit_ev_power(mod_powermon_t* powermon, power_state_t newstate)
{
  if (!powermon->output || !eventq_is_opened(powermon->output)) {
    return 0;
  }

  ev_power_t ev;
  ev.state = newstate;
  return eventq_write(powermon->output, EV_POWER, &ev, sizeof(ev_power_t));
}

static int powermon_set_state(mod_powermon_t* powermon, power_state_t newstate)
{
  powermon->state = newstate;

  return powermon_emit_ev_power(powermon, newstate);
}

static power_state_t powermon_check_power(mod_powermon_t* powermon)
{
  uint32_t mV;


  tcore=ReadCoreTemperature();
  vinput=mV=ReadSupplyMillivolts();

  //log_trace("Supply voltage is %u mV.", mV);

  // Для совместимости с существующим кодом.
  StatusChangeFlag(STATUS_LOW_VOLTAGE, mV < 7000);
  StatusChangeFlag(STATUS_OVERVOLTAGE_DETECTED, mV > 43000);

  if (StatusIsOvervoltageDetected()) {
    return POWER__OVERVOLTAGE;
  }

  power_state_t  state = powermon->state;
  if (StatusIsLowVoltage()) {

    if (state == POWER__SERVICE_MODE) {
      // В сервисном режиме остаёмся до возобновления подачи питания,
      // либо до истечения максимального времени пребывания в сервисном режиме.
      if (timeout_is_elapsed(&service_mode_timeout)) {
        return POWER__NOT_POWERED;
      }

      if (StatusIsServiceEventSent()) {
        StatusClearFlag(STATUS_EVENT_SERVICE_MODE_SENT);
        return POWER__VERIFIED_SERVICE_MODE;
      }

      return POWER__SERVICE_MODE;
    }

    if (state == POWER__VERIFIED_SERVICE_MODE) {
      if (timeout_is_elapsed(&service_mode_timeout)) {
        return POWER__NOT_POWERED;
      }

      return POWER__VERIFIED_SERVICE_MODE;
    }

    if (state == POWER__NOT_POWERED) {
      // В режиме без питания остаёмся до возобновления подачи питания.
      return POWER__NOT_POWERED;
    }

    // Переход в сервисный режим и предупреждающий сигнал об открытой двери
    // используется только в режиме обычной прошивки, но не используется
    // в режиме HoReCa.
    if (state == POWER__UNDERVOLTAGE
        && timeout_is_elapsed(&power_lost_timeout)) {
      // Если в режиме без питания прошло больше, чем powermon.door_time_s
      // то необходимо перейти в режим потери питания (и отправить на сервер
      // соответствующее уведомление).
      return POWER__NOT_POWERED;
    }

    // Во всех остальных случаях возвращаем обычный режим без питания.
    return POWER__UNDERVOLTAGE;
  }

  // Если добрались до сюда, то питание включено.
  if (state == POWER__OK
      || (state == POWER__WARMING_UP && timeout_is_elapsed(&warm_up_timeout))) {
    // Вход в состояние POWER_OK только из WARMING_UP
    return POWER__OK;
  }

  // Переходим из любого другого состояния - значит сначала нужно дать
  // время на прогрев аппарата.
  return POWER__WARMING_UP;
}

void powermon_on_ev_timer(mod_powermon_t* powermon, eventq_event_t* event)
{

  ev_timer_t* e = (ev_timer_t*)event->data;
  (void)e;  // Может не использоваться. Оставлена для отладки.

  DEBUGASSERT(event->size >= sizeof(ev_timer_t));

  power_state_t   prev_state = powermon->state;
  power_state_t   new_state = powermon_check_power(powermon);

  if (new_state != prev_state) {
    // состояние питания изменилось.
    powermon_set_state(powermon, new_state);

    switch(new_state) {
    case POWER__UNDEFINED:
      StatusClearFlag(STATUS_POWER_OK);
      StatusClearFlag(STATUS_SUPPRESS_PING);
      //SequencerSetValue(&LedPowerController, LED_COLOR_BLACK);
      //BeepCancell();
      break;

    case POWER__WARMING_UP:
      StatusClearFlag(STATUS_POWER_OK);
      StatusClearFlag(STATUS_SUPPRESS_PING);
      StatusClearFlag(STATUS_IN_SERVICE_MODE);

      //BeepCancell();
      /// \todo Сейчас симулируем POWER_OK состояние, но лучше добавить
      /// отдельную индикацию для данного состояния.
      //SequencerPlay(&LedPowerController, &blink_warm_up_indication);
      log_trace("Warming up.");
      timeout_start(&warm_up_timeout, CFG_WARMUP_DURATION_MS);

      if (prev_state == POWER__NOT_POWERED) {
        // Отправляем событие восстановления питания только если
        // перешли из состояния отключенного питания.
        StatusSetFlag(STATUS_EVENT_POWER_RESTORED);
        // Сбрасываем таймре выключения модема
        shutdown_timeout.start=0;
      }
      break;

    case POWER__OK:
      StatusSetFlag(STATUS_POWER_OK);\
      StatusClearFlag(STATUS_SUPPRESS_PING);
      log_trace("Power is ok.");
      //SequencerSetValue(&LedPowerController, LED_COLOR_GREEN);
      //BeepCancell();
      break;

    case POWER__OVERVOLTAGE:
      log_trace("Overvoltage!");
      StatusClearFlag(STATUS_POWER_OK);
      StatusClearFlag(STATUS_SUPPRESS_PING);
      //SequencerSetValue(&LedPowerController, LED_COLOR_RED);
      //BeepCancell();
      break;
    case POWER__UNDERVOLTAGE:
      log_trace("Undervoltage!");
      StatusClearFlag(STATUS_POWER_OK);
      StatusClearFlag(STATUS_IN_SERVICE_MODE);
      StatusSetFlag(STATUS_SUPPRESS_PING);
      timeout_start(&power_lost_timeout, 1000*powermon->door_time_s);
      //SequencerPlay(&LedPowerController, &blink_undervoltage_indication);
      //BeepSequence(&beep_undervoltage_indication);
      break;
    case POWER__SERVICE_MODE:
      log_trace("ServiceMode!");
      StatusClearFlag(STATUS_POWER_OK);
      StatusSetFlag(STATUS_SUPPRESS_PING);
      StatusSetFlag(STATUS_IN_SERVICE_MODE);
      StatusClearFlag(STATUS_EVENT_SERVICE_MODE_SENT);
      StatusClearFlag(STATUS_SHOULD_DELAY_EVADTS);
      //SequencerPlay(&LedPowerController, &blink_undervoltage_indication);
      //BeepCancell();
      // Если слишком долго находимся в сервисном режиме, то переходим
      // в отключенное состояние.
      timeout_start(&service_mode_timeout, CFG_MAX_SERVICE_MODE_TIME_MS);
      break;
    case POWER__VERIFIED_SERVICE_MODE:
      log_trace("VerifiedServiceMode!");
      StatusClearFlag(STATUS_POWER_OK);
      StatusSetFlag(STATUS_IN_SERVICE_MODE);
      //SequencerPlay(&LedPowerController, &blink_undervoltage_indication);
      //BeepCancell();
      // В данное состояние автомат переходит после того, как в очередь сообщений
      // на сервер было добавлено сообщение о сервисных работах.
      StatusClearFlag(STATUS_SUPPRESS_PING);
      break;
    case POWER__NOT_POWERED:
      log_trace("NotPowered!");
      StatusClearFlag(STATUS_POWER_OK);
      StatusClearFlag(STATUS_SUPPRESS_PING);
      StatusClearFlag(STATUS_IN_SERVICE_MODE);
      StatusClearFlag(STATUS_SHOULD_DELAY_EVADTS);
      //SequencerPlay(&LedPowerController, &blink_undervoltage_indication);
      //BeepSequence(&beep_entered_not_powered_mode);

      StatusSetFlag(STATUS_EVENT_POWER_LOST);
      // Запускаем таймер выключения модема
      timeout_start(&shutdown_timeout,CFG_TIME_TO_SHUTDOWN_MS);
      break;
    }
  }

  // Сремя выключения питаняи пришло!
  if ((shutdown_timeout.start) && (timeout_is_elapsed(&shutdown_timeout)))
    StatusSetFlag(STATUS_TIME_TO_SHUTDOWN);
}


static void powermon_on_ev_buttons(mod_powermon_t* powermon, FAR eventq_event_t* event)
{
  button_event_t* e = (button_event_t*)event->data;
  (void)e;  // Может не использоваться. Оставлена для отладки.

  DEBUGASSERT(event->size >= sizeof(button_event_t));

  if (powermon->state == POWER__UNDERVOLTAGE) {
    // Если в режиме без питания была нажата любая кнопка, то необходимо
    // перейти в сервисный режим.
    powermon_set_state(powermon, POWER__SERVICE_MODE);
  }
}

static void powermon_on_ev_configure(mod_powermon_t* powermon, FAR eventq_event_t* event)
{
  ev_configure_t* e = (ev_configure_t*)event->data;
  DEBUGASSERT(getpid() == e->sender_pid && e->settings);

  powermon->door_time_s = *settings_get_door_time_s(e->settings);
}

static void mod_powermon_on_event(FAR mod_t* module, FAR eventq_event_t* event)
{
  mod_powermon_t* mod_powermon = (mod_powermon_t*)module;
  DEBUGASSERT(mod_powermon);

  if (event->id == EV_TIMER) {
    powermon_on_ev_timer(mod_powermon, event);
    return;
  }

  if (event->id == EV_BTN_RELEASED) {
    powermon_on_ev_buttons(mod_powermon, event);
    return;
  }

  if (event->id == EV_CONFIGURE) {
    powermon_on_ev_configure(mod_powermon, event);
    return;
  }
}

////////////////////////////////////////////////////////////////////////////
//  Публичные функции

int mod_powermon_create(mod_powermon_t* mod_powermon, eventq_t* output)
{
  int ret;

  DEBUGASSERT(mod_powermon && output);

  ret = mod_create(mod_powermon, mod_powermon_on_event, NULL);
  if (ret < 0) {
    return ret;
  }

  mod_powermon->output = output;
  mod_powermon->state  = POWER__UNDEFINED;
  return 0;
}
