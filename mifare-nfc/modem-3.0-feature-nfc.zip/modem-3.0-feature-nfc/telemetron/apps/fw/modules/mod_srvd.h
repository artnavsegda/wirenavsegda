/// \file
/// \brief  Модуль управления сервисом связи с сервером.
/// \author DL <dmitriy@linikov.ru>
///
///

#ifndef TELEMETRON_APPS_FW_MODULES_MOD_SRVD_H_INCLUDED
#define TELEMETRON_APPS_FW_MODULES_MOD_SRVD_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <srvd/srvd.h>
#include "mod_daemon.h"

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

#define MOD_SRVD_RESTART_INTERVAL_MS      30000

////////////////////////////////////////////////////////////////////////////
//  Типы данных

/// \brief  Модуль управления сервисом связи с сервером.
/// \extends mod_daemon_t
typedef struct mod_srvd_s {
  mod_daemon_t        base;             ///< Базовый объект для интеграции в обработку событий.
  srvd_t*             srvd;             ///< Экземпляр модуля srvd (то, что получено из синглтона)

  const char*         srvdq_name;       ///< Имя очереди файлов на сервер
  const char*         eventq_name;      ///< Имя главной очереди событий
  const char*         third_flow_path;  ///< Путь к файлу с "третьим потоком" данных
  const char*         user_agent;       ///< Текст HTTP-поля User-Agent при отправке на сервер
} mod_srvd_t;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int mod_srvd_create(
  FAR mod_srvd_t* mod_srvd,
  const char* eventq_name,
  const char* srvdq_name,
  const char* third_flow_path,
  const char* user_agent
);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_FW_MODULES_MOD_SRVD_H_INCLUDED
