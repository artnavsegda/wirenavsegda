/// \file
/// \brief  Модуль управления сервисом связи с торговым автоматом.
/// \author DL <dmitriy@linikov.ru>
///
///

#ifndef TELEMETRON_APPS_FW_MODULES_MOD_AUDITD_H_INCLUDED
#define TELEMETRON_APPS_FW_MODULES_MOD_AUDITD_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <auditd/auditd.h>
#include "mod_daemon.h"

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

/// \brief Пауза перед перезапуском сервиса auditd
///
/// Поскольку данный сервис один из самых критических,
/// данное время должно быть довольно малым.
#define MOD_AUDITD_RESTART_INTERVAL_MS      1000


////////////////////////////////////////////////////////////////////////////
//  Типы данных

/// \brief  Модуль управления сервисом связи с торговым автоматом.
/// \extends mod_daemon_t
typedef struct mod_auditd_s {
  mod_daemon_t        base;             ///< Базовый объект для интеграции в обработку событий.
  int                 instance_id;      ///< Номер экземпляра (и номер AUX порта, считая от нуля)
  auditd_t*           auditd;           ///< Экземпляр сервиса
  const char*         eventq_name;      ///< Имя очереди сообщений для уведомления о состоянии
} mod_auditd_t;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int mod_auditd_create(
  FAR mod_auditd_t* mod_auditd,
  int               instance_id,
  const char*       eventq_name,
  const char*       port_path,
  const char*       report_path
);

bool mod_auditd_wake(FAR mod_auditd_t* mod_auditd);


const aux_params_t* mod_auditd_get_settings(mod_auditd_t* mod_auditd);
bool mod_auditd_get_autodetect(mod_auditd_t* mod_auditd);


#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_FW_MODULES_MOD_AUDITD_H_INCLUDED
