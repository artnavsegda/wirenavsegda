/// \file
/// \brief  Модуль, создающий таймер и генерирующий события EV_TIMER.
/// \author DL <dmitriy@linikov.ru>
///
/// Не обязательно должен быть модулем, но так обработка событий старт/стоп
/// будет проще.

#ifndef TELEMETRON_APPS_FW_MODULES_MOD_TIMER_H_INCLUDED
#define TELEMETRON_APPS_FW_MODULES_MOD_TIMER_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <time.h>
#include <fw/fw_events.h>
#include "mod.h"

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Типы данных

typedef struct eventq_s eventq_t;

/// \brief  Модуль, создающий таймер и генерирующий события EV_TIMER.
typedef struct mod_timer_s {
  mod_t                     base;             ///< Базовый объект, от которого наследуем обработку событий.
  uint32_t                  period_ms;        ///< Период между событиями таймера в миллисекундах.
  eventq_t*                 eventq;           ///< Очередь, куда отправлять сообщения.
  struct timespec           next_time;        ///< Время очередного запланированного события.
} mod_timer_t;




////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int mod_timer_create(FAR mod_timer_t* timer, uint32_t period_ms, FAR eventq_t* eventq);
int mod_timer_restart(FAR mod_timer_t* timer);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_FW_MODULES_MOD_TIMER_H_INCLUDED
