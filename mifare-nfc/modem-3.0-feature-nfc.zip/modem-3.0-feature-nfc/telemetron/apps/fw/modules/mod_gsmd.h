/// \file
/// \brief  Модуль управления сервисом gsmd
/// \author DL <dmitriy@linikov.ru>


#ifndef TELEMETRON_APPS_FW_MODULES_MOD_GSMD_H_INCLUDED
#define TELEMETRON_APPS_FW_MODULES_MOD_GSMD_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <gsmd/gsmd.h>
#include "mod_daemon.h"

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

#define MOD_SRVD_RESTART_INTERVAL_MS      30000


////////////////////////////////////////////////////////////////////////////
//  Типы данных

/// \brief  Модуль управления сервисом gsmd
/// \extends mod_daemon_t
typedef struct mod_gsmd_s {
  mod_daemon_t        base;             ///< Базовый объект для интеграции в обработку событий.
  gsmd_t*             gsmd;             ///< Экземпляр сервиса

  const char*         eventq_name;      ///< Имя очереди сообщений для уведомления о состоянии
  const char*         gsm_path;         ///< Путь к драйверу gsm модуля
  const char*         tty_path;         ///< Путь к драйверу последовательного порта

} mod_gsmd_t;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int mod_gsmd_create(
  mod_gsmd_t* mod_gsmd,
  const char* eventq_name,
  const char* gsm_path,
  const char* tty_path
);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_FW_MODULES_MOD_GSMD_H_INCLUDED
