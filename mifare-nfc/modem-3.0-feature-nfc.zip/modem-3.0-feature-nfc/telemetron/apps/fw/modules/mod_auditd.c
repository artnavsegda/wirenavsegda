/// \file
/// \brief  Модуль управления сервисом связи с торговым автоматом.
/// \author DL <dmitriy@linikov.ru>
///
///

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "mod_auditd.h"
#include <fw/fw_config.h>
#include <fw/fw_events.h>
#include <settings/settings.h>


#include <assert.h>
#include <debug.h>
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Приватные функции

static int mod_auditd_start_daemon(FAR mod_daemon_t* instance)
{
  FAR mod_auditd_t*     mod_auditd    = (FAR mod_auditd_t*)instance;

  int ret = service_start((service_t*)mod_auditd->auditd);
  return ret;
}

/// \brief Остановка потока, выполняющего сервис auditd
static int mod_auditd_stop_daemon(FAR mod_daemon_t* instance)
{
  FAR mod_auditd_t*     mod_auditd    = (FAR mod_auditd_t*)instance;

  int ret = service_kill((service_t*)mod_auditd->auditd);
  if (ret < 0) {
    return ret;
  }

  ret = service_wait_terminated(
    (service_t*)mod_auditd->auditd,
    CONFIG_TELEMETRON_FW_SERVICE_TERMINATE_TIMEOUT_MS
  );
  return ret;
}

/// \brief  Проверка, что сервис auditd ещё активен
static int mod_auditd_check_daemon(FAR mod_daemon_t* instance)
{
  FAR mod_auditd_t*     mod_auditd    = (FAR mod_auditd_t*)instance;

  if (!service_is_alive((service_t*)mod_auditd->auditd)) {
    return -ESRCH;
  }

  return 0;
}

/// \brief  Обработка события EV_CONFIGURE
static void mod_auditd_on_ev_configure(FAR mod_auditd_t* mod_auditd, FAR eventq_event_t* event)
{
  int             ret;
  ev_configure_t* e = (ev_configure_t*)event->data;
  DEBUGASSERT(getpid() == e->sender_pid && e->settings);


  // Обновление настроек.
  // Если изменены параметры, используемые сервисом, то перезапуск сервиса.
  const aux_params_t* aux_params    = settings_get_aux(e->settings, mod_auditd->instance_id);
  const onoff_t*      evadts_search = settings_get_evadts_search(e->settings);
  if (!aux_params) {
    return;
  }

  ret = auditd_setup(
    mod_auditd->auditd,
    aux_params,
    evadts_search && *evadts_search != VALUE_OFF
  );

  if (ret < 0) {
    fw_error("Can't set auditd settings. ret=%d (%s)\n", ret, strerror(-ret));
    return;
  }
}

/// \brief Обработка всех событий, не обрабатываемых модулем mod_daemon
static void mod_auditd_on_event(FAR mod_daemon_t* instance, FAR eventq_event_t* event)
{
  FAR mod_auditd_t* mod_auditd = (FAR mod_auditd_t*)instance;
  if (event && event->id == EV_CONFIGURE) {
    mod_auditd_on_ev_configure(mod_auditd, event);
    return;
  }
}

////////////////////////////////////////////////////////////////////////////
//  Публичные функции

int mod_auditd_create(
  FAR mod_auditd_t* mod_auditd,
  int               instance_id,
  const char*       eventq_name,
  const char*       port_path,
  const char*       report_path
)
{

  // Таблица методов для mod_daemon, определяемых объектом mod_auditd.
  static const mod_daemon_vmt_t   MOD_AUDITD_VMT = {
    .start_daemon   = mod_auditd_start_daemon,
    .stop_daemon    = mod_auditd_stop_daemon,
    .check_daemon   = mod_auditd_check_daemon,
    .on_ev_start    = NULL,
    .on_ev_stop     = NULL,
    .on_ev_timer    = NULL,
    .on_event       = mod_auditd_on_event,
  };


  int ret;
  DEBUGASSERT(mod_auditd && eventq_name);
  DEBUGASSERT(instance_id >= 0 && instance_id < 3);

  ret = mod_daemon_create(
    (mod_daemon_t*)mod_auditd,
    &MOD_AUDITD_VMT,
    MOD_AUDITD_RESTART_INTERVAL_MS,
    "mod_auditd"
  );
  if (ret < 0) {
    return ret;
  }

  mod_auditd->instance_id = instance_id;
  mod_auditd->eventq_name = eventq_name;

  ret = auditd_create(
    &mod_auditd->auditd,
    instance_id,
    port_path,
    report_path,
    eventq_name
  );
  if (ret < 0) {
    return ret;
  }
  return 0;
}

bool mod_auditd_wake(FAR mod_auditd_t* mod_auditd)
{
  const aux_params_t* cfg         = auditd_get_settings(mod_auditd->auditd);
  bool                autodetect  = auditd_get_autodetect(mod_auditd->auditd);
  aux_type_t          protocol    = cfg->type;
  aux_interface_t     interface   = cfg->interface;

  if (!auditd_is_enabled(mod_auditd->auditd)) {
    fw_info("AUX%d is not enabled for audit\n", mod_auditd->instance_id+1);
    return false;
  }

  if (mod_auditd->instance_id == 3 /*&& console_enabled*/) {
    fw_info("AUX%d is used for console. Audit disabld.\n", mod_auditd->instance_id+1);
    return false;
  }

  fw_info("AUX%d started audit\n", mod_auditd->instance_id+1);
  return auditd_wake(mod_auditd->auditd) >= 0;
}


const aux_params_t* mod_auditd_get_settings(mod_auditd_t* mod_auditd)
{
  DEBUGASSERT(mod_auditd && mod_auditd->auditd);
  return auditd_get_settings(mod_auditd->auditd);
}

bool mod_auditd_get_autodetect(mod_auditd_t* mod_auditd)
{
  DEBUGASSERT(mod_auditd && mod_auditd->auditd);
  return auditd_get_autodetect(mod_auditd->auditd);
}
