/// \file
/// \brief  Модуль управления сервисом gsmd
/// \author DL <dmitriy@linikov.ru>

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "mod_gsmd.h"
#include <fw/fw_config.h>
#include <fw/fw_events.h>
#include <settings/settings.h>

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Приватные функции
/// \brief Запуск потока, выполняющего сервис gsmd
static int mod_gsmd_start_daemon(FAR mod_daemon_t* instance)
{
  FAR mod_gsmd_t*     mod_gsmd    = (FAR mod_gsmd_t*)instance;

  int ret = service_start((service_t*)mod_gsmd->gsmd);
  return ret;
}

/// \brief Остановка потока, выполняющего сервис gsmd
static int mod_gsmd_stop_daemon(FAR mod_daemon_t* instance)
{
  FAR mod_gsmd_t*     mod_gsmd    = (FAR mod_gsmd_t*)instance;

  int ret = service_kill((service_t*)mod_gsmd->gsmd);
  if (ret < 0) {
    return ret;
  }

  ret = service_wait_terminated(
    (service_t*)mod_gsmd->gsmd,
    CONFIG_TELEMETRON_FW_SERVICE_TERMINATE_TIMEOUT_MS
  );
  return ret;
}

/// \brief  Проверка, что сервис gsmd ещё активен
static int mod_gsmd_check_daemon(FAR mod_daemon_t* instance)
{
  FAR mod_gsmd_t*     mod_gsmd    = (FAR mod_gsmd_t*)instance;

  if (!service_is_alive((service_t*)mod_gsmd->gsmd)) {
    return -ESRCH;
  }

  return 0;
}

/// \brief  Обработка события EV_CONFIGURE
static void mod_gsmd_on_ev_configure(FAR mod_gsmd_t* mod_gsmd, FAR eventq_event_t* event)
{
  ev_configure_t* e = (ev_configure_t*)event->data;
  DEBUGASSERT(getpid() == e->sender_pid && e->settings);

    // Обновление настроек.
  // Если изменены параметры, используемые сервисом, то перезапуск сервиса.
  int   ret;

  gsmd_settings_t settings;

  settings.eventq_name      = mod_gsmd->eventq_name;
  settings.gsm_path         = mod_gsmd->gsm_path;
  settings.tty_path         = mod_gsmd->tty_path;
  settings.ppp_override_apn = true;

  settings.ppp_apn          = settings_get_apn_name(e->settings);
  settings.ppp_user         = settings_get_apn_user(e->settings);
  settings.ppp_pwd          = settings_get_apn_pwd(e->settings);

  ret = gsmd_setup(mod_gsmd->gsmd, &settings);
  if (ret < 0) {
    fw_error("Can't set gsmd settings. ret=%d (%s)\n", ret, strerror(-ret));
    return;
  }
}

/// \brief Обработка всех событий, не обрабатываемых модулем mod_daemon
static void mod_gsmd_on_event(FAR mod_daemon_t* instance, FAR eventq_event_t* event)
{
  FAR mod_gsmd_t* mod_gsmd = (FAR mod_gsmd_t*)instance;
  if (event && event->id == EV_CONFIGURE) {
    mod_gsmd_on_ev_configure(mod_gsmd, event);
    return;
  }
}



////////////////////////////////////////////////////////////////////////////
//  Публичные функции

int mod_gsmd_create(
  mod_gsmd_t* mod_gsmd,
  const char* eventq_name,
  const char* gsm_path,
  const char* tty_path
)
{
  // Таблица методов для mod_daemon, определяемых объектом mod_gsmd.
  static const mod_daemon_vmt_t   MOD_SRVD_VMT = {
    .start_daemon   = mod_gsmd_start_daemon,
    .stop_daemon    = mod_gsmd_stop_daemon,
    .check_daemon   = mod_gsmd_check_daemon,
    .on_ev_start    = NULL,
    .on_ev_stop     = NULL,
    .on_ev_timer    = NULL,
    .on_event       = mod_gsmd_on_event,
  };

  int ret;
  DEBUGASSERT(mod_gsmd);

  // Конструктор базового объекта mod_daemon, выполняющего конечный автомат
  // запуска, остановки и перезапуска какого-либо сервиса.
  ret = mod_daemon_create(
    (mod_daemon_t*)mod_gsmd,
    &MOD_SRVD_VMT,
    MOD_SRVD_RESTART_INTERVAL_MS,
    "mod_gsmd"
  );
  if (ret < 0) {
    return ret;
  }


  // Получаем синглтон-экземпляр сервиса gsmd и сохраняем
  // для удобства дальнейшего использования.
  mod_gsmd->gsmd = gsmd_get_instance();

  // Настройки сервиса gsmd, не изменяющиеся в процессе работы
  mod_gsmd->eventq_name = eventq_name;
  mod_gsmd->gsm_path    = gsm_path;
  mod_gsmd->tty_path    = tty_path;

  // Остальные настройки будут установлены в обработчике события EV_CONFIGURE,
  // поскольку гарантируется, что EV_CONFIGURE обязательно отправляется до EV_START
  return 0;
}
