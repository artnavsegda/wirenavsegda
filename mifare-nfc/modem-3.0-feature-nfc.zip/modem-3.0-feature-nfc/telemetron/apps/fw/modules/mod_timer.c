/// \file
/// \brief  Модуль, создающий таймер и генерирующий события EV_TIMER.
/// \author DL <dmitriy@linikov.ru>

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "mod_timer.h"

#include <assert.h>
#include <debug.h>
#include <utils/time_utils.h>
#include <fw/fw_events.h>

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Приватные функции


static void mod_timer_on_event(FAR mod_t* module, eventq_event_t* event)
{
  FAR mod_timer_t*  timer = (FAR mod_timer_t*)module;

  if (event->id == EV_START) {
    timer->next_time = timespec_after_ms(timer->period_ms);
    return;
  }
  if (event->id == EV_STOP) {
    timespec_clear(&timer->next_time);
    return;
  }
}

static void mod_timer_on_idle(FAR mod_t* module)
{
  int               ret;
  ev_timer_t        event;
  FAR mod_timer_t*  timer = (FAR mod_timer_t*)module;

  if (!timespec_is_set(&timer->next_time)) {
    // Время очередного события не установлено - таймер остановлен.
    return;
  }

  // Запрос текущего времени
  ret = clock_gettime(CLOCK_REALTIME, &event.now);
  if (ret < 0) {
    return;
  }

  // Пришло ли время очередного события
  if (timespec_compare(&event.now, &timer->next_time) < 0) {
    // event.now < timer->next_time,
    // значит время очередного события еще не пришло.
    return;
  }

  // Планируем время следующего события
  timespec_add_ms(&timer->next_time, timer->period_ms);
  if (timespec_compare(&timer->next_time, &event.now) < 0) {
    // время следующего события оказалось в прошлом.
    // Обнаружили пропуск события.
    // Запланируем следующее событие от текущего момента.
    timer->next_time = event.now;
    timespec_add_ms(&timer->next_time, timer->period_ms);
  }

  // И отправляем в очередь событие.
  eventq_write(timer->eventq, EV_TIMER, &event, sizeof(event));
}

////////////////////////////////////////////////////////////////////////////
//  Публичные функции

int mod_timer_create(FAR mod_timer_t* timer, uint32_t period_ms, FAR eventq_t* eventq)
{
  int ret;
  DEBUGASSERT(timer && period_ms);
  if ((ret = mod_create(timer, mod_timer_on_event, mod_timer_on_idle)) < 0) {
    return ret;
  }
  timer->period_ms  = period_ms;
  timer->eventq     = eventq;
  timespec_clear(&timer->next_time);
  return 0;
}

int mod_timer_restart(FAR mod_timer_t* timer)
{
  DEBUGASSERT(timer);
  if (!timespec_is_set(&timer->next_time)) {
    // Время очередного события не установлено - таймер остановлен.
    return 0;
  }

  timer->next_time = timespec_after_ms(timer->period_ms);
  return 0;
}
