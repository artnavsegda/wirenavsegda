/// \file
/// \brief  Модуль управления сервисом связи с сервером.
/// \author DL <dmitriy@linikov.ru>
///
///

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "mod_srvd.h"
#include <srvd/srvd.h>
#include <fw/fw_events.h>
#include <fw/fw_config.h>

#include <assert.h>
#include <debug.h>
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <semaphore.h>
#include <unistd.h>

#include <settings/settings.h>

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора

#define BOARD_NAME    CONFIG_ARCH_BOARD_CUSTOM_NAME

////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Приватные функции

/// \brief Запуск потока, выполняющего сервис srvd
static int mod_srvd_start_daemon(FAR mod_daemon_t* instance)
{
  FAR mod_srvd_t*     mod_srvd    = (FAR mod_srvd_t*)instance;

  int ret = service_start((service_t*)mod_srvd->srvd);
  return ret;
}

/// \brief Остановка потока, выполняющего сервис srvd
static int mod_srvd_stop_daemon(FAR mod_daemon_t* instance)
{
  FAR mod_srvd_t*     mod_srvd    = (FAR mod_srvd_t*)instance;

  int ret = service_kill((service_t*)mod_srvd->srvd);
  if (ret < 0) {
    return ret;
  }

  ret = service_wait_terminated(
    (service_t*)mod_srvd->srvd,
    CONFIG_TELEMETRON_FW_SERVICE_TERMINATE_TIMEOUT_MS
  );
  return ret;
}

/// \brief  Проверка, что сервис srvd ещё активен
static int mod_srvd_check_daemon(FAR mod_daemon_t* instance)
{
  FAR mod_srvd_t*     mod_srvd    = (FAR mod_srvd_t*)instance;

  if (!service_is_alive((service_t*)mod_srvd->srvd)) {
    return -ESRCH;
  }

  return 0;
}

/// \brief  Обработка события EV_CONFIGURE
static void mod_srvd_on_ev_configure(FAR mod_srvd_t* mod_srvd, FAR eventq_event_t* event)
{
  ev_configure_t* e = (ev_configure_t*)event->data;
  DEBUGASSERT(getpid() == e->sender_pid && e->settings);


  // Обновление настроек.
  // Если изменены параметры, используемые сервисом, то перезапуск сервиса.
  int   ret;

  srvd_settings_t settings;

  settings.in_queue_name    = mod_srvd->srvdq_name;
  settings.out_queue_name   = mod_srvd->eventq_name;
  settings.third_flow_path  = mod_srvd->third_flow_path;
  settings.server_name      = settings_get_server_address(e->settings);
  settings.server_port      = settings_get_server_port(e->settings);
  settings.server_path      = settings_get_server_path(e->settings);
  settings.user_agent       = BOARD_NAME;
  settings.t_ping_ms        = settings_get_server_ping_interval_s(e->settings) * 60000;


  ret = srvd_setup(mod_srvd->srvd, &settings);
  if (ret < 0) {
    fw_error("Can't set srvd settings. ret=%d (%s)\n", ret, strerror(-ret));
    return;
  }
}

/// \brief Обработка всех событий, не обрабатываемых модулем mod_daemon
static void mod_srvd_on_event(FAR mod_daemon_t* instance, FAR eventq_event_t* event)
{
  FAR mod_srvd_t* mod_srvd = (FAR mod_srvd_t*)instance;
  if (event && event->id == EV_CONFIGURE) {
    mod_srvd_on_ev_configure(mod_srvd, event);
    return;
  }
}



////////////////////////////////////////////////////////////////////////////
//  Публичные функции

int mod_srvd_create(
  FAR mod_srvd_t* mod_srvd,
  const char* eventq_name,
  const char* srvdq_name,
  const char* third_flow_path,
  const char* user_agent
)
{
  // Таблица методов для mod_daemon, определяемых объектом mod_srvd.
  static const mod_daemon_vmt_t   MOD_SRVD_VMT = {
    .start_daemon   = mod_srvd_start_daemon,
    .stop_daemon    = mod_srvd_stop_daemon,
    .check_daemon   = mod_srvd_check_daemon,
    .on_ev_start    = NULL,
    .on_ev_stop     = NULL,
    .on_ev_timer    = NULL,
    .on_event       = mod_srvd_on_event,
  };

  int ret;
  DEBUGASSERT(mod_srvd);

  // Конструктор базового объекта mod_daemon, выполняющего конечный автомат
  // запуска, остановки и перезапуска какого-либо сервиса.
  ret = mod_daemon_create(
    (mod_daemon_t*)mod_srvd,
    &MOD_SRVD_VMT,
    MOD_SRVD_RESTART_INTERVAL_MS,
    "mod_srvd"
  );
  if (ret < 0) {
    return ret;
  }


  // Получаем синглтон-экземпляр сервиса srvd и сохраняем
  // для удобства дальнейшего использования.
  mod_srvd->srvd = srvd_get_instance();


  // Настройки сервиса srvd, не изменяющиеся в процессе работы
  mod_srvd->srvdq_name      = srvdq_name;
  mod_srvd->eventq_name     = eventq_name;
  mod_srvd->third_flow_path = third_flow_path;
  mod_srvd->user_agent      = user_agent;


  // Остальные настройки будут установлены в обработчике события EV_CONFIGURE,
  // поскольку гарантируется, что EV_CONFIGURE обязательно отправляется до EV_START
  return 0;
}
