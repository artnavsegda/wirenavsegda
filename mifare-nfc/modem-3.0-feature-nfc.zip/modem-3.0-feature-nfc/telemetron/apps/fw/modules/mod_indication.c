/// \file
/// \brief  Передача сообщений изменения индикации в indication/xxx
/// \author DL <dmitriy@linikov.ru>

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "mod_indication.h"

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <fw/fw_events.h>
#include <srvd/events.h>
#include <gsmd/gsmd_events.h>
#include <vmcd/vmcd_event.h>
#include <auditd/audit_events.h>
#include <settings/settings.h>

#include <indication/indicators.h>


////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы

// =========================================================================
//    Константы индикации состояния GSM модуля и сети

static const Sequence    blink_net_registration = {
  .steps = (const SequencerStep[]) {
        { .value = LED_COLOR_GREEN,   .duration = 200  },
        { .value = LED_COLOR_BLACK,   .duration = 3000 },
      },
  .steps_count = 2,
  .repeat = true
};

static const Sequence    blink_ppp_registration = {
  .steps = (const SequencerStep[]) {
        { .value = LED_COLOR_GREEN,   .duration = 200  },
        { .value = LED_COLOR_BLACK,   .duration = 800  },
      },
  .steps_count = 2,
  .repeat = true
};

static const Sequence    blink_ppp_closing = {
  .steps = (const SequencerStep[]) {
        { .value = LED_COLOR_GREEN,   .duration = 200  },
        { .value = LED_COLOR_YELLOW,  .duration = 200  },
        { .value = LED_COLOR_BLACK,   .duration = 600  },
      },
  .steps_count = 3,
  .repeat = true
};


static const Sequence    blink_gsm_error = {
  .steps = (const SequencerStep[]) {
        { .value = LED_COLOR_YELLOW,  .duration = 200  },
        { .value = LED_COLOR_BLACK,   .duration = 200  },
      },
  .steps_count = 2,
  .repeat = true
};

static const Sequence    blink_sim_error = {
  .steps = (const SequencerStep[]) {
        { .value = LED_COLOR_RED,     .duration = 200  },
        { .value = LED_COLOR_BLACK,   .duration = 200  },
      },
  .steps_count = 2,
  .repeat = true
};

static const Sequence     beep_sim_error = {
  .steps = (const SequencerStep[]) {
        // звуковой сигнал 2 секунды с интервалом в 5 секунд
        { .value = BEEPER_ON,       .duration = 2000 },
        { .value = BEEPER_OFF,      .duration = 500 },
        { .value = BEEPER_ON,       .duration = 2000 },
        { .value = BEEPER_OFF,      .duration = 500 }
      },
  .steps_count = 2,
  .repeat = false
};


// =========================================================================
//    Константы индикации общения с сервером

static const Sequence    blink_connecting_to_server = {
  .steps = (const SequencerStep[]) {
        { .value = LED_COLOR_GREEN, .duration = 1000 },
        { .value = LED_COLOR_BLACK, .duration = 1000 },
      },
  .steps_count = 2,
  .repeat = true
};

static const Sequence    blink_server_data_exchange = {
  .steps = (const SequencerStep[]) {
        // начинаем с чёрного, что бы можно было обнаружить короткую
        // передачу в online режиме
        { .value = LED_COLOR_BLACK, .duration = 200 },
        { .value = LED_COLOR_GREEN, .duration = 200 },
      },
  .steps_count = 2,
  .repeat = true
};

static const Sequence    blink_server_invalid_response = {
  .steps = (const SequencerStep[]) {
        { .value = LED_COLOR_RED,   .duration = 1000 },
        { .value = LED_COLOR_BLACK, .duration = 1000 },
      },
  .steps_count = 2,
  .repeat = true
};


// =========================================================================
//    Константы индикации состояния питания

static const Sequence    blink_undervoltage_indication = {
  .steps = (const SequencerStep[]) {
        { .value = LED_COLOR_BLACK, .duration = 1000 },
        { .value = LED_COLOR_GREEN, .duration = 200  }
      },
  .steps_count = 2,
  .repeat = true
};

static const Sequence    blink_warm_up_indication = {
  .steps = (const SequencerStep[]) {
        { .value = LED_COLOR_GREEN, .duration = 100  },
        { .value = LED_COLOR_BLACK, .duration = 100  }
      },
  .steps_count = 2,
  .repeat = true
};

static const Sequence    beep_undervoltage_indication = {
  .steps = (const SequencerStep[]) {
        { .value = 0, .duration = 1000 },
        { .value = 1, .duration = 200  }
      },
  .steps_count = 2,
  .repeat = true
};



static const Sequence    beep_entered_not_powered_mode = {
  .steps = (const SequencerStep[]) {
        { .value = 1, .duration = 100 },
        { .value = 0, .duration = 100 },
        { .value = 1, .duration = 100 },
        { .value = 0, .duration = 100 },
        { .value = 1, .duration = 100 },
        { .value = 0, .duration = 100 },
        { .value = 1, .duration = 100 },
        { .value = 0, .duration = 100 },
        { .value = 1, .duration = 400 },
        { .value = 0, .duration = 0 },
      },
  .steps_count = 2,
  .repeat = false
};

// =========================================================================
//    константы индикации состояния портов аудита
// Описание мигания светодиода, когда происходит подключение к шине DEX

static const Sequence    blink_evadts_connecting = {
  .steps = (const SequencerStep[]) {
        { .value = LED_COLOR_GREEN, .duration = 1000 },
        { .value = LED_COLOR_BLACK, .duration = 1000 },
      },
  .steps_count = 2,
  .repeat = true
};

// Описание мигания светодиода, когда идёт передача данных по шине DEX
static const Sequence    blink_evadts_data_transfer = {
  .steps = (const SequencerStep[]) {
        { .value = LED_COLOR_GREEN, .duration = 200 },
        { .value = LED_COLOR_BLACK, .duration = 200 },
      },
  .steps_count = 2,
  .repeat = true
};

// Описание мигания светодиода, когда идёт передача данных по шине DEX
static const Sequence    blink_evadts_fast_data_transfer = {
  .steps = (const SequencerStep[]) {
        { .value = LED_COLOR_GREEN, .duration = 100 },
        { .value = LED_COLOR_BLACK, .duration = 100 },
      },
  .steps_count = 2,
  .repeat = true
};

// Описание мигания светодиода, когда происходит подключение к шине DDCMP
static const Sequence    blink_evadts_ddcmp_connecting = {
  .steps = (const SequencerStep[]) {
        { .value = LED_COLOR_YELLOW, .duration = 1000 },
        { .value = LED_COLOR_BLACK, .duration = 1000 },
      },
  .steps_count = 2,
  .repeat = true
};

// Описание мигания светодиода, когда идёт передача данных по шине DDCMP
static const Sequence    blink_evadts_ddcmp_data_transfer = {
  .steps = (const SequencerStep[]) {
        { .value = LED_COLOR_YELLOW, .duration = 200 },
        { .value = LED_COLOR_BLACK, .duration = 200 },
      },
  .steps_count = 2,
  .repeat = true
};



////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Приватные функции

static void on_ev_srvd_state(mod_indication_t* mod_indication, eventq_event_t* event)
{
  DEBUGASSERT(event->size >= sizeof(ev_srvd_state_t));
  ev_srvd_state_t*  e         = (ev_srvd_state_t*)event->data;
  srvd_state_t      new_state = e->state;

  (void)mod_indication; // Не используется

  switch(new_state) {
  case SERVER_STATE_UNDEFINED:
  case SERVER_STATE_INITIAL:
  case SERVER_STATE_DISCONNECTED:
    SequencerSetValue(&LedServerController, LED_COLOR_BLACK);
    break;

  case SERVER_STATE_CONNECTING:
    SequencerPlay(&LedServerController, &blink_connecting_to_server);
    break;

  case SERVER_STATE_DATA_EXCHANGE:
    SequencerPlay(&LedServerController, &blink_server_data_exchange);
    break;

  case SERVER_STATE_ONLINE:
    SequencerSetValue(&LedServerController, LED_COLOR_GREEN);
    break;

  case SERVER_STATE_SERVER_NOT_AVAILABLE:
    SequencerSetValue(&LedServerController, LED_COLOR_RED);
    break;

  case SERVER_STATE_INVALID_SERVER_RESPONSE:
    SequencerPlay(&LedServerController, &blink_server_invalid_response);
    break;
  }

}

static void on_ev_gsmd_state(mod_indication_t* mod_indication, eventq_event_t* event)
{
  DEBUGASSERT(event->size >= sizeof(ev_gsmd_state_t));
  ev_gsmd_state_t*  e         = (ev_gsmd_state_t*)event->data;
  gsmd_state_t      new_state = e->state;

  (void)mod_indication; // Не используется

  switch(new_state) {
  case GSMD_STATE_UNINITED:
  case GSMD_STATE_START_CHANGING_SETTINGS:
    SequencerSetValue(&LedGsmController, LED_COLOR_BLACK);
    BeepCancell();
    break;

  case GSMD_STATE_START_RECOVER_FROM_HARD_ERROR:
    SequencerPlay(&LedGsmController, &blink_sim_error);
    BeepSequence(&beep_sim_error);
    break;

  case GSMD_STATE_START_RECOVER_FROM_SIMCARD_ERROR:
    SequencerSetValue(&LedGsmController, LED_COLOR_RED);
    break;

  case GSMD_STATE_START_RECOVER_FROM_GSM_ERROR:
    SequencerPlay(&LedGsmController, &blink_gsm_error);
    break;

  case GSMD_STATE_START_RECOVER_FROM_GPRS_ERROR:
    SequencerSetValue(&LedGsmController, LED_COLOR_YELLOW);
    break;

  case GSMD_STATE_TURNING_ON:                             // fall-through
  case GSMD_STATE_START_WAITING_NET_REGISTRATION:
    SequencerPlay(&LedGsmController, &blink_net_registration);
    break;

  case GSMD_STATE_PPP_HANDSHAKING:
    SequencerPlay(&LedGsmController, &blink_ppp_registration);
    break;

  case GSMD_STATE_PPP_CLOSING:
    SequencerPlay(&LedGsmController, &blink_ppp_closing);
    break;

  case GSMD_STATE_PPP_ONLINE:
    SequencerSetValue(&LedGsmController, LED_COLOR_GREEN);
    break;

  // Пропуск транзитных состояний.
  case GSMD_START_RECOVERING_FROM_ERROR_WITH_POWERCYCLE:  // fall-through
  case GSMD_STATE_WAITING_FOR_AT_READY:                   // fall-through
  case GSMD_STATE_START_WAITING_SIM_READY:                // fall-through
  case GSMD_STATE_WAITING_NET_REGISTRATION:               // fall-through
  case GSMD_STATE_PPP_INIT:                               // fall-through
  case GSMD_STATE_PPP_CLOSED:                             // fall-through
  case GSMD_STATE_RECOVERING_SLEEP:
    break;
  }
}

static void on_ev_vmcd_bus_change(mod_indication_t* mod_indication, eventq_event_t* event)
{
  vmcd_event_bus_change_t* e = (vmcd_event_bus_change_t*)event->data;
  DEBUGASSERT(event->size >= sizeof(vmcd_event_bus_change_t));

  switch (e->bus_state) {
  case VMCBUS_STATE_UNDEFINED:
    SequencerSetValue(&LedMdbExe1Controller, LED_COLOR_BLACK);
    SequencerSetValue(&LedMdbExe2Controller, LED_COLOR_BLACK);
    break;
  case VMCBUS_STATE_OK:
    SequencerSetValue(&LedMdbExe1Controller, LED_COLOR_GREEN);
    SequencerSetValue(&LedMdbExe2Controller, LED_COLOR_GREEN);
    break;
  case VMCBUS_STATE_ERROR:
    SequencerSetValue(&LedMdbExe1Controller, LED_COLOR_RED);
    SequencerSetValue(&LedMdbExe2Controller, LED_COLOR_RED);
    break;
  default:
    break;
  }
}

static void on_ev_power(mod_indication_t* mod_indication, eventq_event_t* event)
{
  DEBUGASSERT(event->size >= sizeof(ev_power_t));
  ev_power_t*  e = (ev_power_t*)event->data;
  (void)e; // Не используется. Оставлено для отладки

  switch(e->state) {
  case POWER__UNDEFINED:
    SequencerSetValue(&LedPowerController, LED_COLOR_BLACK);
    BeepCancell();
    break;

  case POWER__WARMING_UP:
    BeepCancell();
    SequencerPlay(&LedPowerController, &blink_warm_up_indication);
    break;

  case POWER__OK:
    SequencerSetValue(&LedPowerController, LED_COLOR_GREEN);
    BeepCancell();
    break;

  case POWER__OVERVOLTAGE:
    SequencerSetValue(&LedPowerController, LED_COLOR_RED);
    BeepCancell();
    break;

  case POWER__UNDERVOLTAGE:
    SequencerPlay(&LedPowerController, &blink_undervoltage_indication);
    BeepSequence(&beep_undervoltage_indication);
    break;

  case POWER__SERVICE_MODE:
    SequencerPlay(&LedPowerController, &blink_undervoltage_indication);
    BeepCancell();
    break;

  case POWER__VERIFIED_SERVICE_MODE:
    SequencerPlay(&LedPowerController, &blink_undervoltage_indication);
    BeepCancell();
    break;

  case POWER__NOT_POWERED:
    SequencerPlay(&LedPowerController, &blink_undervoltage_indication);
    BeepSequence(&beep_entered_not_powered_mode);
    break;
  }
}


static void on_ev_audit_state(mod_indication_t* mod_indication, eventq_event_t* event)
{
  DEBUGASSERT(event->size >= sizeof(ev_audit_state_t));
  ev_audit_state_t*  e = (ev_audit_state_t*)event->data;

  Sequencer* sequencer = NULL;
  if (e->instance_id == 0) {
    sequencer = &LedAux1Controller;
  } else if (e->instance_id == 1) {
    sequencer = &LedAux2Controller;
  } else if (e->instance_id == 2) {
    sequencer = &LedAux3Controller;
  } else {
    return;
  }

  switch(e->state) {
  case AUDIT_STATE_UNDEFINED:
  case AUDIT_STATE_IDLE:
    SequencerSetValue(sequencer, LED_COLOR_BLACK);
    break;
  case AUDIT_STATE_CONNECTING:
    SequencerPlay(sequencer, &blink_evadts_connecting);
    break;
  case AUDIT_STATE_DATA_TRANSFER:
    SequencerPlay(sequencer, &blink_evadts_data_transfer);
    break;
  case AUDIT_STATE_FAST_DATA_TRANSFER:
    SequencerPlay(sequencer, &blink_evadts_fast_data_transfer);
    break;
  case AUDIT_STATE_DDCMP_CONNECTING:
    SequencerPlay(sequencer, &blink_evadts_ddcmp_connecting);
    break;
  case AUDIT_STATE_DDCMP_DATA_TRANSFER:
    SequencerPlay(sequencer, &blink_evadts_ddcmp_data_transfer);
    break;
  case AUDIT_STATE_ERROR:
    SequencerSetValue(sequencer, LED_COLOR_RED);
    break;
  }
}


static void on_ev_timer(mod_indication_t* mod_indication, eventq_event_t* event)
{
  DEBUGASSERT(event->size >= sizeof(ev_timer_t));
  ev_timer_t*  e = (ev_timer_t*)event->data;

  (void)e;              // Не используется
  (void)mod_indication; // Не используется
}

static void on_ev_configure(mod_indication_t* mod_indication, eventq_event_t* event)
{
  ev_configure_t* e = (ev_configure_t*)event->data;
  DEBUGASSERT(getpid() == e->sender_pid && e->settings);

  BeepSetEnabled(*settings_get_beep(e->settings) == VALUE_ON);
}

static void mod_indication_on_event(mod_t* module, eventq_event_t* event)
{
  mod_indication_t* mod_indication = (mod_indication_t*)module;
  DEBUGASSERT(mod_indication);

  if (event->id == EV_SRVD_STATE) {
    on_ev_srvd_state(mod_indication, event);
    return;
  }

  if (event->id == EV_GSMD_STATE) {
    on_ev_gsmd_state(mod_indication, event);
    return;
  }

  if (event->id == VMCD_EV_BUS_CHANGE) {
    on_ev_vmcd_bus_change(mod_indication, event);
    return;
  }

  if (event->id == EV_AUDIT_STATE) {
    on_ev_audit_state(mod_indication, event);
    return;
  }

  if (event->id == EV_POWER) {
    on_ev_power(mod_indication, event);
    return;
  }

  if (event->id == EV_TIMER) {
    on_ev_timer(mod_indication, event);
    return;
  }

  if (event->id == EV_CONFIGURE) {
    on_ev_configure(mod_indication, event);
    return;
  }
}


////////////////////////////////////////////////////////////////////////////
//  Публичные функции

int mod_indication_create(mod_indication_t* mod_indication)
{
  int ret;
  DEBUGASSERT(mod_indication);
  ret = mod_create(mod_indication, mod_indication_on_event, NULL);
  if (ret < 0) {
    return ret;
  }

  return 0;
}
