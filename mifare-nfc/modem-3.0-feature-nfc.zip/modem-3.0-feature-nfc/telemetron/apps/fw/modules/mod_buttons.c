/// \file
/// \brief  Опрос кнопок и генерация их событий.
/// \author DL <dmitriy@linikov.ru>


////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "mod_buttons.h"

#include <debug.h>
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <fw/fw_config.h>
#include <status_bitfield.h>
#include <indication/indicators.h>


////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Приватные функции
static int mod_buttons_emit_event(FAR mod_buttons_t* buttons, int event_id, size_t button_id)
{
  eventq_event_t event;
  FAR button_event_t* button_event = EVENTQ_CREATE_EVENT(&event, event_id, button_event_t);
  button_event->button_id = button_id;

  return eventq_write_ex(buttons->output, &event);
}

static void mod_buttons_on_ev_start(FAR mod_buttons_t* buttons, FAR eventq_event_t* event)
{
  if (buttons->fd >= 0) {
    return; // Модуль уже работает.
  }

  int ret = open(CONFIG_TELEMETRON_FW_BTN_PATH, O_RDONLY | O_BINARY);
  if (ret < 0) {
    buttons->fd = -1;
    fw_warn(
      "Can't open '%s', ret=%d (%s)\n",
      CONFIG_TELEMETRON_FW_BTN_PATH,
      errno,
      strerror(errno)
    );
    return;
  }

  buttons->fd = ret;
  // Заполнение начальных значений
  ret = mod_buttons_update_no_event(buttons);
}

static void mod_buttons_on_ev_stop(FAR mod_buttons_t* buttons, FAR eventq_event_t* event)
{
  if (buttons->fd >= 0) {
    close(buttons->fd);
    buttons->fd = -1;
  }
}


static void mod_buttons_on_event(FAR mod_t* module, FAR eventq_event_t* event)
{
  FAR mod_buttons_t* buttons = (FAR mod_buttons_t*)module;
  DEBUGASSERT(buttons && event);

  if (event->id == EV_START) {
    mod_buttons_on_ev_start(buttons, event);
  } else if (event->id == EV_STOP) {
    mod_buttons_on_ev_stop(buttons, event);
  }
}

static void mod_buttons_on_idle(FAR mod_t* module)
{
  FAR mod_buttons_t* buttons = (FAR mod_buttons_t*)module;
  mod_buttons_update(buttons);
}

////////////////////////////////////////////////////////////////////////////
//  Публичные функции

int mod_buttons_update_no_event(FAR mod_buttons_t* buttons)
{
  DEBUGASSERT(buttons);
  if (buttons->fd < 0) {
    return -EBADFD;
  }
  return read(buttons->fd, &buttons->buttonset, sizeof(buttons->buttonset));
}

int mod_buttons_create(FAR mod_buttons_t* buttons, FAR eventq_t* output)
{
  int ret;

  DEBUGASSERT(buttons && output);
  ret = mod_create(buttons, mod_buttons_on_event, mod_buttons_on_idle);
  if (ret < 0) {
    return ret;
  }
  buttons->fd = -1;
  buttons->output = output;

  return ret;
}


/// \brief Читает драйвер кнопок и создаёт события для каждого изменения.
int mod_buttons_update(FAR mod_buttons_t* buttons)
{
  int               ret;
  btn_buttonset_t   currentset;
  btn_buttonset_t   changeset;

  DEBUGASSERT(buttons);

  ret = read(buttons->fd, &currentset, sizeof(currentset));
  if (ret < 0) {
    return ret;
  }

  changeset = buttons->buttonset ^ currentset;
  buttons->buttonset = currentset;

  for ( size_t n=0;
        changeset && n < sizeof(changeset)*8;
        ++n, changeset >>= 1, currentset >>= 1
  ) {
    if (!(changeset & 1)) {
      continue;
    }

    if (currentset & 1) {
      BeepOnce(300);
      if (n < 3) {
        StatusSetFlag(STATUS_BTN1_PRESSED << n);
      }
      // Не используем, т.к. нет использующего кода.
      // mod_buttons_emit_event(buttons, EV_BTN_PRESSED);
    } else {
      if (n < 3) {
        StatusClearFlag(STATUS_BTN1_PRESSED << n);
      }
      mod_buttons_emit_event(buttons, EV_BTN_RELEASED, n);
    }
  } // for
  return 0;
}
