/// \file
/// \brief  Базовый класс для модуля управления каким-либо сервисом
/// \author DL <dmitriy@linikov.ru>


#ifndef TELEMETRON_APPS_FW_MODULES_MOD_DAEMON_BASE_H_INCLUDED
#define TELEMETRON_APPS_FW_MODULES_MOD_DAEMON_BASE_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "mod.h"


////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

/// \brief Стандартное время в миллисекундах между попытками запустить.
///
/// Данное значение используется, если при старте модуля в
/// функцию mod_daemon_create() был передан 0 в качестве параметра pause_ms.
#define MOD_DAEMON_DEFAULT_RESTART_INTERVAL_MS      30000

////////////////////////////////////////////////////////////////////////////
//  Типы данных

/// \brief Состояние конечного автомата модуля управления сервисом.
typedef enum {
  MOD_DAEMON_STATE_STOPPED = 0,
  MOD_DAEMON_STATE_STARTED,
  MOD_DAEMON_STATE_ERROR,
} mod_daemon_state_t;

typedef struct mod_daemon_s   mod_daemon_t;

typedef struct mod_daemon_vmt_s {
  /// \brief  Запускает сервис, которым управляет данный модуль.
  /// \return 0 в случае успеха или отрицательный код ошибки (-errno).
  int   (*start_daemon) (FAR mod_daemon_t* instance);

  /// \brief  Останавливает сервис, которым управляет данный модуль.
  /// \return 0 в случае успеха или отрицательный код ошибки (-errno).
  int   (*stop_daemon)  (FAR mod_daemon_t* instance);

  /// \brief  Проверяет, что сервис всё ещё работает.
  /// \return 0 Если сервис работает или `-ESRCH` (или другой код ошибки) если сервис не работает.
  int   (*check_daemon) (FAR mod_daemon_t* instance);

  /// \brief  Дополнительный обработчик события EV_START
  ///
  /// Этот обработчик может быть NULL. Его следует устанавливать,
  /// если наследующему объекту так же нужна обработка события EV_START.
  ///
  /// Данный обработчик вызывается перед обработчиком базового объекта.
  void  (*on_ev_start)  (FAR mod_daemon_t* instance, FAR eventq_event_t* event);

  /// \brief  Дополнительный обработчик события EV_STOP
  ///
  /// Этот обработчик может быть NULL. Его следует устанавливать,
  /// если наследующему объекту так же нужна обработка события EV_STOP.
  ///
  /// Данный обработчик вызывается перед обработчиком базового объекта.
  void  (*on_ev_stop)   (FAR mod_daemon_t* instance, FAR eventq_event_t* event);

  /// \brief  Дополнительный обработчик события EV_TIMER
  ///
  /// Этот обработчик может быть NULL. Его следует устанавливать,
  /// если наследующему объекту так же нужна обработка события EV_TIMER.
  ///
  /// Данный обработчик вызывается перед обработчиком базового объекта.
  void  (*on_ev_timer)  (FAR mod_daemon_t* instance, FAR eventq_event_t* event);

  /// \brief  Дополнительный обработчик всех событий, не поддерживаемых базовым объектом.
  ///
  /// Этот обработчик может быть NULL. Его следует устанавливать,
  /// если наследующему объекту так же нужна обработка других событий.
  ///
  /// Данный обработчик вызывается только если базовый объект не поддерживает
  /// обработку события \p event.
  void  (*on_event)     (FAR mod_daemon_t* instance, FAR eventq_event_t* event);
} mod_daemon_vmt_t;

/// \brief Базовый класс для модуля управления каким-либо сервисом.
/// \extends mod_t
struct mod_daemon_s {
  mod_t                   base;         ///< Базовый объект для интеграции в обработку событий.

  // настройки
  const mod_daemon_vmt_t* vmt;          ///< Виртуальные методы модуля управления сервисами.
  uint32_t                pause_ms;     ///< Время в миллисекундах между попытками запустить сервис.
  const char*             name;         ///< Имя модуля (для отладки)

  // Состояние
  mod_daemon_state_t      state;        ///< Состояние конечного автомата
  struct timespec         restart_time; ///< Время очередной попытки запустить сервис
};

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int mod_daemon_create(FAR mod_daemon_t* instance, const mod_daemon_vmt_t* vmt, uint32_t pause_ms, const char* name);

#ifdef __cplusplus
} // extern "C"
#endif

////////////////////////////////////////////////////////////////////////////
//  inline функции

static inline mod_daemon_state_t mod_daemon_state(FAR mod_daemon_t* instance)
{
  return instance->state;
}


#endif // TELEMETRON_APPS_FW_MODULES_MOD_DAEMON_BASE_H_INCLUDED
