/// \file
/// \brief  Опрос драйвера концевых датчиков дверей.
/// \author DL <dmitriy@linikov.ru>
///
/// Реализовано в виде модуля.

#ifndef TELEMETRON_APPS_FW_FW_DOORS_H_INCLUDED
#define TELEMETRON_APPS_FW_FW_DOORS_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <nuttx/input/buttons.h>

#include <eventq/eventq.h>
#include <fw/fw_events.h>
#include "mod.h"


////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Типы данных

/// \brief Модуль поддержки концевых датчиков дверей
/// \extends mod_t
struct mod_doors_s {
  mod_t             base;       ///< Базовый объект для интеграции в обработку событий.

  int               fd;         ///< Файловый дескриптор драйвера датчиков дверей
  FAR eventq_t*     output;     ///< Указатель на очередь для отправки сообщений
  btn_buttonset_t   activelows; ///< Битмаска датчиков активным низким уровнем
  btn_buttonset_t   enableds;   ///< Битмаска разрешённых датчиков
  btn_buttonset_t   doorset;    ///< Последний прочитанный семпл датчиков дверей

};
typedef struct mod_doors_s   mod_doors_t;


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int mod_doors_create(FAR mod_doors_t* doors, FAR eventq_t* output);
int mod_doors_update(FAR mod_doors_t* doors);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_FW_FW_DOORS_H_INCLUDED
