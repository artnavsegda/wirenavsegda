/// \file
/// \brief  Модуль, осуществляющий периодическую проверку напряжения питания.
/// \author DL <dmitriy@linikov.ru>


#ifndef TELEMETRON_APPS_FW_MODULES_MOD_POWERMON_H_INCLUDED
#define TELEMETRON_APPS_FW_MODULES_MOD_POWERMON_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "mod.h"
#include <eventq/eventq.h>
#include <fw/power_state.h>


////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Типы данных

/// \brief  Модуль, осуществляющий периодическую проверку напряжения питания.
/// \extends mod_t
typedef struct mod_powermon_s {
  mod_t           base;       ///< Базовый объект для интеграции в обработку событий.
  eventq_t*       output;     ///< Указатель на очередь для отправки сообщений

  power_state_t   state;
  uint16_t        door_time_s;
} mod_powermon_t;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int mod_powermon_create(mod_powermon_t* mod_powermon, eventq_t* output);

#ifdef __cplusplus
} // extern "C"
#endif

static inline power_state_t mod_powermon_state(mod_powermon_t* mod_powermon)
{
  return mod_powermon->state;
}
#endif // TELEMETRON_APPS_FW_MODULES_MOD_POWERMON_H_INCLUDED
