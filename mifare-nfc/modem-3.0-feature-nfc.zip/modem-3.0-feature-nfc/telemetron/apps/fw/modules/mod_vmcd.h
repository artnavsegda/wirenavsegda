/// \file
/// \brief  Модуль управления сервисом связи с торговым автоматом.
/// \author DL <dmitriy@linikov.ru>
///
///

#ifndef TELEMETRON_APPS_FW_MODULES_MOD_VMCD_H_INCLUDED
#define TELEMETRON_APPS_FW_MODULES_MOD_VMCD_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <vmcd/vmcd.h>
#include "mod_daemon.h"

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

/// \brief Пауза перед перезапуском сервиса vmcd
///
/// Поскольку данный сервис один из самых критических,
/// данное время должно быть довольно малым.
#define MOD_VMCD_RESTART_INTERVAL_MS      1000


////////////////////////////////////////////////////////////////////////////
//  Типы данных

/// \brief  Модуль управления сервисом связи с торговым автоматом.
/// \extends mod_daemon_t
typedef struct mod_vmcd_s {
  mod_daemon_t        base;             ///< Базовый объект для интеграции в обработку событий.
  vmcd_t*             vmcd;             ///< Экземпляр сервиса
  const char*         eventq_name;      ///< Имя очереди сообщений для уведомления о состоянии
} mod_vmcd_t;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int mod_vmcd_create(FAR mod_vmcd_t* vmcd, const char* eventq_name);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_FW_MODULES_MOD_VMCD_H_INCLUDED
