/// \file
/// \brief  Описание одиночного модуля для основного ПО.
/// \author DL <dmitriy@linikov.ru>

#ifndef TELEMETRON_APPS_FW_FWMODULE_H_INCLUDED
#define TELEMETRON_APPS_FW_FWMODULE_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <queue.h>
#include <eventq/eventq.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

/// \brief Оболочка над for, которая проходит весь односвязный список list.
/// \param varname    Имя переменной, которое следует использовать для хранения
///                   указателя на каждый прочитанный модуль
/// \param list       Указатель (`mod_list_t*`) на список модулей.
#define MOD_LIST_FOREACH(varname, list) \
  for (FAR mod_t* varname = (FAR mod_t*)sq_peek(list); \
      varname != NULL; \
      varname = sq_next(varname))



////////////////////////////////////////////////////////////////////////////
//  Типы данных

/// \brief Базовый объект для модуля основного ПО.
typedef struct mod_s  mod_t;

/// \brief Базовый объект для модуля основного ПО.
struct mod_s {
  /// \brief Для интеграции в односвязный список. Обязательно 1й элемент.
  FAR mod_t*    flink;

  /// \brief Функция, вызываемая для обработки события
  void (*on_event)(FAR mod_t* module, FAR eventq_event_t* event);
  void (*on_idle)(FAR mod_t* module);
};

/// \brief Односвязный список модулей.
typedef sq_queue_t    mod_list_t;



////////////////////////////////////////////////////////////////////////////
//  inline функции

/// \brief  Конструктор для базового "класса" модуля.
/// \note   Первый параметр функции объявлен `void*` вместо `mod_t*`,
///         что бы не приходилось приводить типы для унаследованных объектов.
static inline int mod_create(
  FAR void* module,
  void (*on_event)(FAR mod_t* module, FAR eventq_event_t* event),
  void (*on_idle)(FAR mod_t* module)
)
{
  FAR mod_t* mod = (FAR mod_t*)module;

  mod->flink    = NULL;
  mod->on_event = on_event;
  mod->on_idle  = on_idle;
  return 0;
}

/// \brief  Осуществляет обработку одного события \p event модулем \p module.
static inline void mod_on_event(FAR void* module, FAR eventq_event_t* event)
{
  FAR mod_t* mod = (FAR mod_t*)module;
  if (mod->on_event) {
    mod->on_event(mod, event);
  }
}

/// \brief Осуществляет периодическую обработку во время простоя и перед
/// ожиданием событий из очереди.
static inline void mod_on_idle(FAR void* module)
{
  FAR mod_t* mod = (FAR mod_t*)module;
  if (mod->on_idle) {
    mod->on_idle(mod);
  }
}

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_FW_FWMODULE_H_INCLUDED
