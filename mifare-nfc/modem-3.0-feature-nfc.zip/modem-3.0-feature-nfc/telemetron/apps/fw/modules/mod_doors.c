/// \file
/// \brief  Опрос драйвера концевых датчиков дверей.
/// \author DL <dmitriy@linikov.ru>
///
/// Реализовано в виде модуля, поскольку должен мониторить изменения
/// настроек.

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "mod_doors.h"
#include <fw/fw_config.h>

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Приватные функции

static int mod_doors_emit_event(FAR mod_doors_t* doors, int event_id, size_t door_id)
{
  eventq_event_t      event;
  FAR door_event_t*   door_event = EVENTQ_CREATE_EVENT(&event, event_id, door_event_t);

  door_event->door_id = door_id;

  return eventq_write_ex(doors->output, &event);
}

int mod_doors_update_no_event(FAR mod_doors_t* doors)
{
  int               ret;
  btn_buttonset_t   current;
  DEBUGASSERT(doors);
  if (doors->fd < 0) {
    return -EBADFD;
  }
  ret = read(doors->fd, &current, sizeof(doors->doorset));
  if (ret < 0) {
    return ret;
  }

  current ^= doors->activelows; // приведение всех датчиков к активному высокому
  current &= doors->enableds;   // Используем только разрешённые датчики.

  doors->doorset = current;
  return 0;
}

static void mod_doors_on_ev_start(FAR mod_doors_t* doors, FAR eventq_event_t* event)
{
  if (doors->fd >= 0) {
    return; // Уже запущен
  }

  int ret = open(CONFIG_TELEMETRON_FW_DOORS_PATH, O_RDONLY | O_BINARY);
  if (ret < 0) {
    fw_warn(
      "Can't open '%s', ret=%d (%s)\n",
      CONFIG_TELEMETRON_FW_DOORS_PATH,
      errno,
      strerror(errno)
    );
    return;
  }

  doors->fd = ret;

  // Заполнение начальных значений
  doors->activelows = 0;
  doors->enableds = ~0;
  ret = mod_doors_update_no_event(doors);

}

static void mod_doors_on_ev_stop(FAR mod_doors_t* doors, FAR eventq_event_t* event)
{
  if (doors && doors->fd >= 0) {
    close(doors->fd);
    doors->fd = -1;
  }
}

static void mod_doors_on_event(FAR mod_t* module, FAR eventq_event_t* event)
{
  FAR mod_doors_t* doors = (FAR mod_doors_t*)module;
  if (event->id == EV_START) {
    mod_doors_on_ev_start(doors, event);
  } else if (event->id == EV_STOP) {
    mod_doors_on_ev_stop(doors, event);
  }
}

static void mod_doors_on_idle(FAR mod_t* module)
{
  FAR mod_doors_t* doors = (FAR mod_doors_t*)module;
  mod_doors_update(doors);
}



////////////////////////////////////////////////////////////////////////////
//  Публичные функции

int mod_doors_create(FAR mod_doors_t* doors, FAR eventq_t* output)
{
  int ret;

  DEBUGASSERT(doors && output);

  doors->fd = -1;

  ret = mod_create(doors, mod_doors_on_event, mod_doors_on_idle);
  if (ret < 0) {
    return ret;
  }

  return ret;
}


int mod_doors_update(FAR mod_doors_t* doors)
{
  int               ret;
  btn_buttonset_t   prevset;
  btn_buttonset_t   currentset;
  btn_buttonset_t   changeset;

  DEBUGASSERT(doors);

  prevset = doors->doorset;
  ret = mod_doors_update_no_event(doors);
  if (ret < 0) {
    return ret;
  }
  currentset = doors->doorset;

  changeset = prevset ^ currentset;

  for ( size_t n=0;
        changeset && n < sizeof(changeset)*8;
        ++n, changeset >>= 1, currentset >>= 1
  ) {
    if (!(changeset & 1)) {
      continue;
    }

    if (currentset & 1) {
      mod_doors_emit_event(doors, EV_DOOR_ACTIVATED, n);
    } else {
      mod_doors_emit_event(doors, EV_DOOR_DEACTIVATED, n);
    }
  } // for
  return 0;

}
