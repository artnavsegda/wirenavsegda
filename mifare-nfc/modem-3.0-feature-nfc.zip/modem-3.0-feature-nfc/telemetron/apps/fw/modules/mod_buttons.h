/// \file
/// \brief  Модуль опроса кнопок и генерация их событийю
/// \author DL <dmitriy@linikov.ru>


#ifndef TELEMETRON_APPS_FW_mod_buttons_H_INCLUDED
#define TELEMETRON_APPS_FW_mod_buttons_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <nuttx/input/buttons.h>

#include <eventq/eventq.h>
#include <fw/fw_events.h>
#include "mod.h"

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Типы данных

/// \brief Описатель модуля опроса кнопок.
struct mod_buttons_s {
  mod_t             base;       ///< Базовый объект для интеграции в обработку событий.
  int               fd;         ///< Файловый дескриптор драйвера кнопок
  FAR eventq_t*     output;     ///< Указатель на очередь для отправки сообщений
  btn_buttonset_t   buttonset;  ///< Последний прочитанный семпл кнопок
};
typedef struct mod_buttons_s    mod_buttons_t;


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int mod_buttons_create(FAR mod_buttons_t* buttons, FAR eventq_t* output);
int mod_buttons_update_no_event(FAR mod_buttons_t* buttons);
int mod_buttons_update(FAR mod_buttons_t* buttons);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_FW_mod_buttons_H_INCLUDED
