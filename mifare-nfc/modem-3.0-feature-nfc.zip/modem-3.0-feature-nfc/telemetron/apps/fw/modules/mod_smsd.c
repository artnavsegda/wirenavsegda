/// \file
/// \brief  Модуль управления сервисом sms сообщений.
/// \author DL <dmitriy@linikov.ru>
///
///

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "mod_smsd.h"
#include <smsd/smsd.h>
#include <fw/fw_config.h>
#include <fw/fw_events.h>
#include <utils/time_utils.h>

#include <assert.h>
#include <debug.h>
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Приватные функции

static int mod_smsd_start_daemon(FAR mod_daemon_t* instance)
{
  static const char*  dummy   = "";
  FAR mod_smsd_t*     smsd    = (FAR mod_smsd_t*)instance;
  const char*         argv[]  = {dummy, smsd->eventq_name, smsd->modem_port, NULL};

  int ret = smsd_start(3, argv);
  return ret;
}

static int mod_smsd_stop_daemon(FAR mod_daemon_t* instance)
{
  //FAR mod_smsd_t*     smsd    = (FAR mod_smsd_t*)instance;
  const char*         argv[]  = {NULL};

  int ret = smsd_stop(0, argv);
  return ret;
}

static int mod_smsd_check_daemon(FAR mod_daemon_t* instance)
{
  //FAR mod_smsd_t*     smsd    = (FAR mod_smsd_t*)instance;
  int pid = smsd_get_pid();
  if (pid < 0) {
    return -ESRCH;
  }
  return 0;
}


////////////////////////////////////////////////////////////////////////////
//  Публичные функции

int mod_smsd_create(FAR mod_smsd_t* smsd, const char* eventq_name, const char* modem_port)
{
  static const mod_daemon_vmt_t   MOD_SMSD_VMT = {
    .start_daemon   = mod_smsd_start_daemon,
    .stop_daemon    = mod_smsd_stop_daemon,
    .check_daemon   = mod_smsd_check_daemon,
    .on_ev_start    = NULL,
    .on_ev_stop     = NULL,
    .on_ev_timer    = NULL,
    .on_event       = NULL,
  };

  int ret;
  DEBUGASSERT(smsd);

  ret = mod_daemon_create(
    (mod_daemon_t*)smsd,
    &MOD_SMSD_VMT,
    MOD_SMSD_RESTART_INTERVAL_MS,
    "smsd"
  );
  if (ret < 0) {
    return ret;
  }

  smsd->eventq_name = eventq_name;
  smsd->modem_port  = modem_port;
  return 0;
}
