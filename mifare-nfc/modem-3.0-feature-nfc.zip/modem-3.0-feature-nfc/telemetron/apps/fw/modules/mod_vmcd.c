/// \file
/// \brief  Модуль управления сервисом связи с торговым автоматом.
/// \author DL <dmitriy@linikov.ru>
///
///

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "mod_vmcd.h"
#include <fw/fw_config.h>
#include <fw/fw_events.h>
#include <settings/settings.h>


#include <assert.h>
#include <debug.h>
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Приватные функции

static int mod_vmcd_start_daemon(FAR mod_daemon_t* instance)
{
  FAR mod_vmcd_t*     mod_vmcd    = (FAR mod_vmcd_t*)instance;

  int ret = service_start((service_t*)mod_vmcd->vmcd);
  return ret;
}

/// \brief Остановка потока, выполняющего сервис vmcd
static int mod_vmcd_stop_daemon(FAR mod_daemon_t* instance)
{
  FAR mod_vmcd_t*     mod_vmcd    = (FAR mod_vmcd_t*)instance;

  int ret = service_kill((service_t*)mod_vmcd->vmcd);
  if (ret < 0) {
    return ret;
  }

  ret = service_wait_terminated(
    (service_t*)mod_vmcd->vmcd,
    CONFIG_TELEMETRON_FW_SERVICE_TERMINATE_TIMEOUT_MS
  );
  return ret;
}

/// \brief  Проверка, что сервис vmcd ещё активен
static int mod_vmcd_check_daemon(FAR mod_daemon_t* instance)
{
  FAR mod_vmcd_t*     mod_vmcd    = (FAR mod_vmcd_t*)instance;

  if (!service_is_alive((service_t*)mod_vmcd->vmcd)) {
    return -ESRCH;
  }

  return 0;
}

/// \brief  Обработка события EV_CONFIGURE
static void mod_vmcd_on_ev_configure(FAR mod_vmcd_t* mod_vmcd, FAR eventq_event_t* event)
{
  ev_configure_t* e = (ev_configure_t*)event->data;
  DEBUGASSERT(getpid() == e->sender_pid && e->settings);

  const mdbexe_params_t* params = settings_get_mdbexe(e->settings);
  // Обновление настроек.
  // Если изменены параметры, используемые сервисом, то перезапуск сервиса.
  int   ret;

  int bus_id = params->bus == MDBEXE_BUS_EXE ? VMCBUS_ID_EXE : VMCBUS_ID_MDB;
  if (params->bus_autodetect == VALUE_OFF) {
    // Отрицательное значение означает, что автообнаружение отключено
    bus_id = -bus_id;
  }

  ret = vmcd_setup(
    mod_vmcd->vmcd,
    bus_id,
    params->error_timeout_ms
  );

  if (ret < 0) {
    fw_error("Can't set vmcd settings. ret=%d (%s)\n", ret, strerror(-ret));
    return;
  }
}

/// \brief Обработка всех событий, не обрабатываемых модулем mod_daemon
static void mod_vmcd_on_event(FAR mod_daemon_t* instance, FAR eventq_event_t* event)
{
  FAR mod_vmcd_t* mod_vmcd = (FAR mod_vmcd_t*)instance;
  if (event && event->id == EV_CONFIGURE) {
    mod_vmcd_on_ev_configure(mod_vmcd, event);
    return;
  }
}

////////////////////////////////////////////////////////////////////////////
//  Публичные функции

int mod_vmcd_create(FAR mod_vmcd_t* mod_vmcd, const char* eventq_name)
{
  // Таблица методов для mod_daemon, определяемых объектом mod_vmcd.
  static const mod_daemon_vmt_t   MOD_VMCD_VMT = {
    .start_daemon   = mod_vmcd_start_daemon,
    .stop_daemon    = mod_vmcd_stop_daemon,
    .check_daemon   = mod_vmcd_check_daemon,
    .on_ev_start    = NULL,
    .on_ev_stop     = NULL,
    .on_ev_timer    = NULL,
    .on_event       = mod_vmcd_on_event,
  };


  int ret;
  DEBUGASSERT(mod_vmcd && eventq_name);

  ret = mod_daemon_create(
    (mod_daemon_t*)mod_vmcd,
    &MOD_VMCD_VMT,
    MOD_VMCD_RESTART_INTERVAL_MS,
    "mod_vmcd"
  );
  if (ret < 0) {
    return ret;
  }

  mod_vmcd->eventq_name = eventq_name;
  ret = vmcd_create(
    &mod_vmcd->vmcd,
    0,
    CONFIG_TELEMETRON_FW_MDBMASTER_PATH,
    CONFIG_TELEMETRON_FW_MDBSLAVE_PATH,
    eventq_name,
    CONFIG_TELEMETRON_FW_VMCD_RAWLOG_SIZE
  );
  if (ret < 0) {
    return ret;
  }
  return 0;
}
