/// \file
/// \brief  Передача сообщений изменения индикации в indication/xxx
/// \author DL <dmitriy@linikov.ru>


#ifndef TELEMETRON_APPS_FW_MODULES_MOD_INDICATION_H_INCLUDED
#define TELEMETRON_APPS_FW_MODULES_MOD_INDICATION_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <eventq/eventq.h>
#include "mod.h"

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Типы данных

/// \brief Модуль обнаружения событий, влияющих на индикацию.
/// \extends mod_t
typedef struct mod_indication_s {
  mod_t             base;       ///< Базовый объект для интеграции в обработку событий.
} mod_indication_t;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int mod_indication_create(mod_indication_t* mod_indication);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_FW_MODULES_MOD_INDICATION_H_INCLUDED
