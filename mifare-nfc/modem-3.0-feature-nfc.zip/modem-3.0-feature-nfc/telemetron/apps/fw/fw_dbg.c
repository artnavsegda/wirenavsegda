/// \file
/// \brief  Отладочные функции приложения fw
/// \author DL <dmitriy.linikov@gmail.com>
/// \see fw/dbg.h

#include <stdarg.h>
#include <stdio.h>
#include <sys/random.h>
#include <utils/system_utils.h>
#include <sysutils/crc.h>
#include "dbg.h"

#define DBG_SAFE                2034

volatile uint32_t back_software_position;
volatile uint32_t back_software_halt_position;
volatile uint32_t back_software_work_time;
volatile uint32_t back_timeline_id;
volatile uint32_t software_position __attribute__((section (".user_software_position")));
volatile uint32_t software_work_time __attribute__((section (".user_software_position")));
volatile struct{uint32_t id; uint32_t time; uint32_t packet_number; uint16_t crc;} timeline_id __attribute__((section (".user_software_position")));
//volatile uint8_t array_software_position[2] __attribute__((section (".user_software_position")));

static uint8_t  soft_time=0;

SW_State Set_Software_Position(SW_State state)
{
    SW_State ret=software_position;
    software_position=state;
    return ret;
}

void SetSoftTime(void)
{
    soft_time++;
    if (soft_time>=10)
    {
        soft_time=0;
        software_work_time++;
        timeline_id.time++;
    }
}

uint32_t GetSetSoftTime(systime_t time)
{
    uint32_t ret=software_work_time;
    time/=1000;
    software_work_time=time;
    return(ret);
}

uint32_t GetSoftTime(void)
{
    return(software_work_time);
}

uint32_t GetTimelineIdTime(void)
{
    return(timeline_id.time);
}

uint32_t GetTimelineId(void)
{
    if (crc16_calc_block(DBG_SAFE,(const void *)(&timeline_id.id),sizeof(timeline_id.id))!=timeline_id.crc)
    {
        // Новый Timeline ID
        getrandom((void*)&timeline_id.id, sizeof(timeline_id.id));

        timeline_id.id=rand();
        timeline_id.packet_number=0;
        timeline_id.time=0;
        timeline_id.crc=crc16_calc_block(DBG_SAFE,(const void *)(&timeline_id.id),sizeof(timeline_id.id));
    }
    return(timeline_id.id);
}

// Выдает (с измененеим) номер нового пакета сквозной нумерации
uint32_t GetPacketNumber(void)
{
    return(timeline_id.packet_number++);
}
