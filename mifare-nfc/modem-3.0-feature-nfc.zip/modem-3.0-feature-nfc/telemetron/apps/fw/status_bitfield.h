/// \file
/// \brief Определение битового поля status, его полей и функций для
/// работы с ним
/// \author DL <dmitriy.linikov@gmail.com>

#ifndef STATUS_BITFIELD_H_INCLUDED
#define STATUS_BITFIELD_H_INCLUDED

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

extern volatile uint32_t status;

enum Status {
  STATUS_LED_BLINKER_ON             = (1u << 0),  // 1

  STATUS_LOW_VOLTAGE                = (1u << 1),  // 2

  /// \brief Временная настройка для временного подавления очередного пинга.
  STATUS_SUPPRESS_PING              = (1u << 2),  // 4

  /// \brief Устанавливается в момент начала общения по протоколу DDCMP
  STATUS_GETTING_DDCMP_OR_DEX       = (1u << 4),  // 16

  /// \brief Какая-то хрень. Пока не могу понять смысла.
  /// Данный флаг выставляется, когда переменная minutes становится больше 2000.
  STATUS_MINUTES_OVERFLOW           = (1u << 6),  // 64

  /// \brief Нажата кнопка 1
  STATUS_BTN1_PRESSED               = (1u << 7),  // 128

  /// \brief Нажата кнопка 2
  STATUS_BTN2_PRESSED               = (1u << 8),  // 256

  /// \brief Нажата кнопка 3
  STATUS_BTN3_PRESSED               = (1u << 9),  // 512

  /// \brief Получено новое sms сообщение
  STATUS_HAVE_UNREAD_SMS            = (1u << 10), // 1024

  /// \brief Есть неотправленный MDB отчёт.
  STATUS_HAVE_MDB_REPORT            = (1u << 11), // 2048

  /// \brief Не вышло время ожидания пакета EXE.
  STATUS_EXE_PACKET_OK              = (1u << 12), // 4096

  /// \brief За период таймера TIM6 произошло изменение состояния питания.
  STATUS_LOW_VOLTAGE_CHANGED        = (1u << 13), // 8192

  /// \brief Значение флага \see STATUS_LOW_VOLTAGE в момент предыдущей
  /// его проверки в обработчике прерываний таймера TIM6 (100ms).
  STATUS_PREV_LOW_VOLTAGE           = (1u << 14), // 16384

  /// \brief Подошло время очередного события из планировщика (Выхода на связь?)
  STATUS_SCHEDULE_TIME_COME         = (1u << 15), // 32768

  /// \brief Есть неотправленный EXE отчёт.
  /// \todo Данный флаг нигде не устанавливается.
  STATUS_EVENT_EXE_VEND             = (1u << 16), // 65535

  /// \brief Не знаю. Аналогичен \see STATUS_PREV_LOW_VOLTAGE, но используется
  /// каким-то образом при учёте времени открытия двери аппарата.
  STATUS_PREV_LOW_VOLTAGE_DOOR      = (1u << 17), // 131072

  /// \brief Был зафиксирован удар по аппарату.
  STATUS_PUNCH_DETECTED             = (1u << 18), // 262144

  /// \brief Перенапряжение на входе.
  STATUS_OVERVOLTAGE_DETECTED       = (1u << 19),

  /// \brief Было обнаружено пропадание питания
  STATUS_EVENT_POWER_LOST           = (1u << 20),

  /// \brief Было обнаружено восстановление питания
  STATUS_EVENT_POWER_RESTORED       = (1u << 21),

  /// \brief Получена команда перезагрузить устройство.
  STATUS_RESET_SCHEDULED            = (1u << 22),

  /// \brief Прошло больше, чем T_WARMUP с момента подачи питания на аппарат
  /// и питание всё ещё включено.
  STATUS_POWER_OK                   = (1u << 23),

  /// \brief Обнаружена продажа по шине MDB
  STATUS_EVENT_MDB_VEND             = (1u << 24),

  /// \brief Модем находится в сервисном режиме.
  STATUS_IN_SERVICE_MODE            = (1u << 25),

  /// \brief Событие для PowerMonitor, говорящее, что пакет с уведомлением о сервисных работах
  /// был отправлен на сервер.
  STATUS_EVENT_SERVICE_MODE_SENT    = (1u << 26),

  /// \brief Признак того, что попытка снять отчёт в сервисном режиме не удалась и
  /// следует повторно снять отчёт после того, как будет восстановлено питание.
  STATUS_SHOULD_DELAY_EVADTS        = (1u << 27),

  /// \brief Признак наличия изменения состояния шины. Требуется срочное информирование об этом
  STATUS_HAVE_MDBEXE_CHANGE         = (1u << 28),

  /// \brief Признак окончания времени рабоыт от батареи
  STATUS_TIME_TO_SHUTDOWN           = (1u << 29),

  /// \brief Признак необходимости выключить питание
  STATUS_SHOULD_SHUTDOWN            = (1u << 30),
};

static inline bool StatusIsAnyFlagSet(uint32_t flags_mask)
{
  return !!(status & flags_mask);
}

static inline bool StatusIsAllFlagsSet(uint32_t flags_mask)
{
  return (flags_mask == (status & flags_mask));
}

static inline bool StatusIsFlagSet(uint32_t flag) {
  return !!(status & flag);
}

static inline bool StatusIsLedBlinkerOn(void) {
  return StatusIsFlagSet(STATUS_LED_BLINKER_ON);
}

static inline bool StatusIsLowVoltage(void) {
  return StatusIsFlagSet(STATUS_LOW_VOLTAGE);
}

static inline bool StatusIsSuppressPingSet(void) {
  return StatusIsFlagSet(STATUS_SUPPRESS_PING);
}

//static inline bool StatusIsSendingToServer(void) {
//  return StatusIsFlagSet(STATUS_SENDING_TO_SERVER);
//}

static inline bool StatusIsGettingDdcmpOrDex(void) {
  return StatusIsFlagSet(STATUS_GETTING_DDCMP_OR_DEX);
}

static inline bool StatusIsMinutesOverflow(void) {
  return StatusIsFlagSet(STATUS_MINUTES_OVERFLOW);
}

static inline bool StatusIsBtn1Pressed(void) {
  return StatusIsFlagSet(STATUS_BTN1_PRESSED);
}

static inline bool StatusIsBtn2Pressed(void) {
  return StatusIsFlagSet(STATUS_BTN2_PRESSED);
}

static inline bool StatusIsBtn3Pressed(void) {
  return StatusIsFlagSet(STATUS_BTN3_PRESSED);
}

static inline bool StatusHaveUnreadSms(void) {
  return StatusIsFlagSet(STATUS_HAVE_UNREAD_SMS);
}

static inline bool StatusHaveMdbReport(void) {
  return StatusIsFlagSet(STATUS_HAVE_MDB_REPORT);
}

static inline bool StatusHaveMdbExeChange(void) {
  return StatusIsFlagSet(STATUS_HAVE_MDBEXE_CHANGE);
}

static inline bool StatusIsExePacketOk(void) {
  return StatusIsFlagSet(STATUS_EXE_PACKET_OK);
}

static inline bool StatusIsLowVoltageChanged(void) {
  return StatusIsFlagSet(STATUS_LOW_VOLTAGE_CHANGED);
}

static inline bool StatusIsPrevLowVoltage(void) {
  return StatusIsFlagSet(STATUS_PREV_LOW_VOLTAGE);
}

static inline bool StatusIsScheduledTimeCome(void) {
  return StatusIsFlagSet(STATUS_SCHEDULE_TIME_COME);
}

static inline bool StatusHaveEventExeVend(void) {
  return StatusIsFlagSet(STATUS_EVENT_EXE_VEND);
}

static inline bool StatusIsPrevLowVoltageDoor(void) {
  return StatusIsFlagSet(STATUS_PREV_LOW_VOLTAGE_DOOR);
}

static inline bool StatusIsPunchDetected(void) {
  return StatusIsFlagSet(STATUS_PUNCH_DETECTED);
}

static inline bool StatusIsOvervoltageDetected(void) {
  return StatusIsFlagSet(STATUS_OVERVOLTAGE_DETECTED);
}

static inline bool StatusHasEventPowerLost(void) {
  return StatusIsFlagSet(STATUS_EVENT_POWER_LOST);
}

static inline bool StatusHasEventPowerRestored(void) {
  return StatusIsFlagSet(STATUS_EVENT_POWER_RESTORED);
}

static inline bool StatusIsResetScheduled(void) {
  return StatusIsFlagSet(STATUS_RESET_SCHEDULED);
}

static inline bool StatusIsPowerOk(void) {
  return StatusIsFlagSet(STATUS_POWER_OK);
}

static inline bool StatusHasEventMdbVend(void) {
  return StatusIsFlagSet(STATUS_EVENT_MDB_VEND);
}

static inline bool StatusIsInServiceMode(void) {
  return StatusIsFlagSet(STATUS_IN_SERVICE_MODE);
}

static inline bool StatusIsServiceEventSent(void) {
  return StatusIsFlagSet(STATUS_EVENT_SERVICE_MODE_SENT);
}

static inline bool StatusShouldDelayEvadts(void) {
  return StatusIsFlagSet(STATUS_SHOULD_DELAY_EVADTS);
}

// ============= Запись в переменную status ===================================

static inline void StatusSetFlag(uint32_t flag) {
  status |= flag;
}

static inline void StatusClearFlag(uint32_t flag) {
  status &= ~flag;
}

static inline void StatusChangeFlag(uint32_t flag, bool set) {
  if (set) {
    StatusSetFlag(flag);
  } else {
    StatusClearFlag(flag);
  }
}

// Процедура проверки флагов высоких приоритетов
bool IsHighPriority(void);


/// Таблица приоритетов приложений
typedef enum {
    HIGH_INTERRUPT,
    PRIORITY_LEVEL_0,
    PRIORITY_LEVEL_1,
    PRIORITY_LEVEL_2,
    PRIORITY_LEVEL_3,
    PRIORITY_LEVEL_4,
    PRIORITY_LEVEL_6,
    PRIORITY_LEVEL_7,
    PRIORITY_LEVEL_8,
    PRIORITY_LEVEL_9,
    PRIORITY_LEVEL_10,

/// Всегда последнее объявление
    PRIORITY_LEVEL_MIN
}priority_t;

/// Процедура определения высокоприеритетного события по отношению к месту вызова (кcurrent_priority)
bool NeedBreakeHighPriority(priority_t * level);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // STATUS_BITFIELD_H_INCLUDED
