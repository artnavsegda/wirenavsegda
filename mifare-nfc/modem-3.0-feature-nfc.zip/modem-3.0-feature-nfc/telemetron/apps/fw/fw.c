/// \file
/// \brief  Основной модуль ПО модема.
/// \author DL <dmitriy@linikov.ru>
///


////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <nuttx/config.h>
#include <nuttx/version.h>

#include "fw.h"

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>


#include <auditd/audit_events.h>
#include <srvd/events.h>
#include <smsd/events.h>
#include <utils/time_utils.h>

#include <sender.h>


#include <nuttx/telemetron/board_ioctl.h>


#include "indication/indicators.h"


////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора

#define CHECK(action)                                           \
        do {                                                    \
          int __ret = (action);                                 \
          if (__ret < 0) {                                      \
            fw_error("ERROR: \"%s\" fail, ret=%d (%s)\n",       \
              #action, __ret, strerror(-__ret)                  \
            );                                                  \
          }                                                     \
        } while(0)

////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные

static fw_t             g_fw_instance;
static fw_t* volatile   g_fw = NULL;



////////////////////////////////////////////////////////////////////////////
//  Приватные функции

/// \brief  Добавляет модуль в список модулей.
/// \note   Параметр \p module объявлен как void* что бы не приводить типы.
///         Однако контроль, что неподходящие типы не будут переданы в данную
///         функцию, остаётся задачей программиста.
static void fw_modules_add(FAR fw_t* fw, FAR void* module)
{
  DEBUGASSERT(fw && module);
  sq_addlast((sq_entry_t*)module, &fw->modules);
}

#if 0   // Пока что не используется. Убрано, что бы компилятор не жаловался
/// \brief  Удаляет модуль \p module из списка модулей.
/// \note   Параметр \p module объявлен как void* что бы не приводить типы.
///         Однако контроль, что неподходящие типы не будут переданы в данную
///         функцию, остаётся задачей программиста.
static void fw_modules_rem(FAR fw_t* fw, FAR void* module)
{
  DEBUGASSERT(fw && module);
  sq_rem((sq_entry_t*)module, &fw->modules);
}
#endif

static void fw_modules_on_event(FAR fw_t* fw, FAR eventq_event_t* event)
{
  MOD_LIST_FOREACH(module, &fw->modules) {
    mod_on_event(module, event);
  }
}

static void fw_modules_on_idle(FAR fw_t* fw)
{
  MOD_LIST_FOREACH(module, &fw->modules) {
    mod_on_idle(module);
  }
}

int fw_start_audit_report(fw_t* fw, const char* reason)
{
  if (!fw->started) {
    fw_warn("WARN: Can't get report: not started.\n");
    return -ESRCH;
  }

  if (fw->report_reading) {
    fw_warn("WARN: Can't get report: already reading.\n");
    return -EALREADY;
  }

  // Начинаем запрос отчёта.
  fw_info("Starting audit, reason=\"%s\"\n", reason);
  fw->report_reading = 0;
  fw->report_reading |= (!!mod_auditd_wake(&fw->auditd[0])) << 0;
  fw->report_reading |= (!!mod_auditd_wake(&fw->auditd[1])) << 1;
  fw->report_reading |= (!!mod_auditd_wake(&fw->auditd[2])) << 2;

  if (!fw->report_reading) {
    fw_warn("WARN: No audit source is enabled\n");
    return -ENODEV;
  }

  fw->reports_timeout = timespec_after_ms(CONFIG_TELEMETRON_FW_AUDIT_TIMEOUT_MS);
  fw->reports_reason  = reason;
  return 0;
}


static void fw_on_ev_btn_released(FAR fw_t* fw, FAR eventq_event_t* event)
{
  button_event_t* e = (button_event_t*)event->data;
  (void)e; // Не используется

  power_state_t power_state = mod_powermon_state(&fw->powermon);
  if (fw->report_reading) {
    fw->report_buttons |= (1 << e->button_id);
    return;
  }

  fw->report_first_btn = fw->report_buttons = 1 << e->button_id;
  if (power_state == POWER__OK) {
    fw_start_audit_report(fw, "button");
  } else {
    sender_send_event_btn(&fw->sender);
    fw->is_audit_pending = true;        // Отложенная обработка запроса аудита
  }
  return;
}

static void fw_on_ev_start(FAR fw_t* fw, FAR eventq_event_t* event)
{
  ev_start_t* e = (ev_start_t*)event->data;
  fw->started = true;
  sender_send_reset(
    &fw->sender,
    e->csr_value,
    e->reset_reason,
    &fw->settings
  );
}

static void fw_on_ev_audit_report(FAR fw_t* fw, FAR eventq_event_t* event)
{
  ev_audit_report_t* ev = (ev_audit_report_t*)event->data;
  bool expected = (fw->report_reading & (1 << ev->instance_id)) != 0;
  const char* reason = expected ? fw->reports_reason : "auto_request-bus";

  sender_send_audit(&fw->sender, reason, ev);

  // Сбрс флага, что ждём отчёт от данного порта.
  fw->report_reading &= ~(1 << ev->instance_id);
}

static void fw_check_audit_report_timeout(FAR fw_t* fw, FAR eventq_event_t* event)
{
  if (!fw->report_reading) {
    return;
  }

  if (!timespec_is_passed(&fw->reports_timeout)) {
    return;
  }

  fw_error("Audit timeout. Services mask=%08X\n", fw->report_reading);
  size_t i=0;
  while (fw->report_reading && i < sizeof(fw->auditd)/sizeof(*fw->auditd)) {
    if ((fw->report_reading & 1) != 0) {
      const aux_params_t* settings = mod_auditd_get_settings(&fw->auditd[i]);
      // Симулируем отчёт с ошибкой, если аудит не был снят
      ev_audit_report_t   e;
      e.instance_id = i;
      e.error_code  = (uint32_t)(-ETIMEDOUT);
      e.protocol    = settings->type;
      e.interface   = settings->interface;
      e.saeco_fix   = settings->ddcmp_params.ddcmp_saeco_fix;
      e.report_size = 0;
      e.path[0]     = '\0';

      sender_send_audit(&fw->sender,fw->reports_reason, &e);
    }

    i += 1;
    fw->report_reading >>= 1;
  } // while...

  fw->reports_reason = NULL;
  fw->report_reading = 0;
}

static void fw_on_ev_smsd_message(FAR fw_t* fw, FAR eventq_event_t* event)
{

}

static void fw_on_ev_vmcd_vend(FAR fw_t* fw, FAR eventq_event_t* event)
{
  vmcd_event_sale_t* e = (vmcd_event_sale_t*)event->data;

  sender_send_vend_report(&fw->sender, e, "", false, 1000);

  if (!fw->is_power_ok) {
    return;
  }
  if (*settings_get_request_evadts_after_mdb_change(&fw->settings) != VALUE_ON) {
    return;
  }
  fw_start_audit_report(fw, "auto_request-vend");
}

static void fw_on_ev_vmcd_state(FAR fw_t* fw, FAR eventq_event_t* event)
{
  vmcd_event_bus_change_t* e = (vmcd_event_bus_change_t*)event->data;

  // Отрабатываем только переходы между ошибка->работа и между рабочими шинами.
  bool need_event = false;
  if (e->bus_state == VMCBUS_STATE_ERROR && fw->vmc_bus != -1) {
    need_event = true;
    fw->vmc_bus = -1;
  } else if (e->bus_state != VMCBUS_STATE_ERROR && fw->vmc_bus != e->bus_id) {
    need_event = true;
    fw->vmc_bus = e->bus_id;
  }

  if (!need_event) {
    // Ничего существенного не произошло
    return;
  }

  sender_send_bus_state(
    &fw->sender,
    e->bus_id == VMCBUS_ID_EXE ? "exe" : "mdb",
    e->bus_state != VMCBUS_STATE_ERROR
  );

  if (!fw->is_power_ok) {
    return;
  }
  if (*settings_get_request_evadts_after_mdb_change(&fw->settings) != VALUE_ON) {
    return;
  }
  fw_start_audit_report(fw, "auto_request-bus");
}

static void fw_on_ev_power(FAR fw_t* fw, FAR eventq_event_t* event)
{
  ev_power_t* e = (ev_power_t*)event->data;

  if (e->state == POWER__OK && fw->is_audit_pending) {
    // Запуск отложенного снятия отчёта аудита
    fw_start_audit_report(fw, "button");
    fw->is_audit_pending = false;
  }
}

static void fw_on_ev_reboot(FAR fw_t* fw, FAR eventq_event_t* event)
{
  fw_info("Rebooting firmware\n");
  boardctl(BOARDIOC_RESET, 0);
}

/// \brief обработка всех событий приложения.
static int fw_on_event(FAR fw_t* fw, FAR eventq_event_t* event)
{
  fw_trace("EV: id=%d, size=%d, ts=%d.%03d\n",
    event->id, event->size, event->time.tv_sec, event->time.tv_nsec / 1000000
  );

  fw_modules_on_event(fw, event);

  switch (event->id) {
  case EV_TIMER:
    fw_check_audit_report_timeout(fw, event);
    fw_check_srvd_transaction_timeout(fw, event);
    break;

  case EV_BTN_RELEASED:
    fw_on_ev_btn_released(fw, event);
    break;

  case EV_START:
    fw_on_ev_start(fw, event);
    break;

  case EV_AUDIT_REPORT:
    fw_on_ev_audit_report(fw, event);
    break;

  case EV_SRVD_TRANSACTION_START:
    fw_on_ev_srvd_transaction_start(fw, event);
    break;

  case EV_SRVD_COMMAND:
    fw_on_ev_srvd_command(fw, event);
    break;

  case EV_SRVD_TRANSACTION_END:
    fw_on_ev_srvd_transaction_end(fw, event);
    break;

  case EV_SMSD_MESSAGE:
    fw_on_ev_smsd_message(fw, event);
    break;

  case VMCD_EV_BUS_CHANGE:
    fw_on_ev_vmcd_state(fw, event);
    break;

  case VMCD_EV_VEND:
    fw_on_ev_vmcd_vend(fw, event);
    break;

  case EV_POWER:
    fw_on_ev_power(fw, event);
    break;

  case EV_REBOOT:
    fw_on_ev_reboot(fw, event);
    break;

  default:
    break;
  }

  return 0;
}

int fw_on_idle(FAR fw_t* fw)
{
  fw_modules_on_idle(fw);
  return 0;
}

/// \brief Первоначальная загрузка настроек и отправка сообщения EV_CONFIGURE
/// минуя очередь сообщений
static int fw_startup_configure(fw_t* fw)
{
  if (settings_load_apn_params(&fw->settings) < 0) {
    settings_default_apn_params(&fw->settings);
    fw_info("Loaded default settings for APN\n");
  }

  if (settings_load_fw_params(&fw->settings) < 0) {
    settings_default_fw_params(&fw->settings);
    fw_info("Loaded default FW settings\n");
  }



  ev_configure_t* e   = EVENTQ_CREATE_EVENT(&fw->event, EV_CONFIGURE, ev_configure_t);
  e->sender_pid       = getpid();
  e->settings         = &fw->settings;

  return fw_on_event(fw, &fw->event);
}

/// \brief Отправка сообщения EV_START минуя очередь сообщений.
static int fw_send_ev_start(fw_t* fw)
{
  ev_start_t* e   = EVENTQ_CREATE_EVENT(&fw->event, EV_START, ev_start_t);
  e->csr_value    = boardctl_get_boot_status(NULL);
  e->reset_reason = boardctl_get_boot_reason();

  return fw_on_event(fw, &fw->event);
}

/// \brief Отправка сообщения E_STOP
static int fw_send_ev_stop(fw_t* fw)
{
  eventq_init_event(&fw->event, EV_STOP);
  return fw_on_event(fw, &fw->event);
}

static int fw_process_events(FAR fw_t* fw)
{
  int ret;
  for (size_t i=0; i < 10; ++i) { // Читаем до 10 событий за 1 вызов
    ret = fw_evq_read_timeout(fw, 0);
    if (ret < 0) {
      return ret;
    }
    ret = fw_on_event(fw, &fw->event);
  }
  return 0;
}


static int fw_thread_main(void* arg)
{
  fw_info(
    "\r\n\r\n"
    "==============================================================================\r\n"
    "Telemetron Modem started.\r\n"
    "HW version \"%s\" \r\n"
    "FW version \"%s\" \r\n"
    "           from %s.\r\n"
    "Build on %s, target is \"%s\"\r\n"
    "------------------------------------------------------------------------------\r\n",
    CONFIG_ARCH_BOARD_CUSTOM_NAME,
    VERSINFO_VERSION_STRING,
    VERSINFO_VERSION_TIMESTAMP,
    VERSINFO_BUILD_TIMESTAMP,
    VERSINFO_BUILD_TARGET
  );

#define FW_POLL_DURATION_MS       100
#define FW_WD_LOOP_TIMEOUT_MS     10000
#define FW_WD_STARTUP_TIMEOUT_MS  30000
  int   ret;
  fw_t* fw = (fw_t*)arg;
  DEBUGASSERT(fw);

  fw_wdog_restart(fw, FW_WD_STARTUP_TIMEOUT_MS);

  IndicatorsStart();


  // При старте принудительно обрабатываем события EV_CONFIGURE и EV_START
  // не используя очередь (т.к. в очереди уже могут быть другие события)
  fw_startup_configure(fw);
  fw_send_ev_start(fw);

  // Подготовка поллинга событий из очереди и драйверов кнопок и сенсоров дверей.
  struct pollfd pfds[3] = {
    { .fd       = fw_evq_get_pollfd(fw), .events   = POLLIN, .revents  = 0 },
    { .fd       = fw->buttons.fd,        .events   = POLLIN, .revents  = 0 },
    { .fd       = fw->doors.fd,          .events   = POLLIN, .revents  = 0 },
  };


  // Основной цикл обработки сообщений
  while (!service_should_stop((service_t*)fw)){
    // Долгие ожидания в основном цикле недопустимы.
    fw_wdog_restart(fw, FW_WD_LOOP_TIMEOUT_MS);

    // Обработка модулей в режиме простоя и перед ожиданием событий.
    fw_on_idle(fw);

    // Ожидание событий.
    // Причем обрабатываем только события очереди, а события кнопок и дверей
    // будут обработаны в fw_on_idle, который окажется вызванным сразу, как
    // обнаружится изменение их состояния.
    pfds[0].revents = pfds[1].revents = pfds[2].revents = 0;
    ret = poll(pfds, sizeof(pfds)/sizeof(*pfds), FW_POLL_DURATION_MS);
    if (ret <= 0) {
      continue;
    }

    // Чтение событий из очереди
    if ((pfds[0].revents & POLLIN)) {
      fw_process_events(fw);
    }
  } // for (;;)


  // Отправка сообщения EV_STOP минуя очередь
  fw_send_ev_stop(fw);

  IndicatorsStop();

  // отключение сторожевого таймера при выходе
  fw_wdog_cancel(fw);
  return 0;
}

static int fw_create(FAR fw_t* fw)
{
  CHECK(service_create((service_t*)fw, "FW", CONFIG_TELEMETRON_FW_PRIORITY, CONFIG_TELEMETRON_FW_STACKSIZE, fw_thread_main, fw));

  CHECK(settings_create(&fw->settings));

  // Создание модулей
  CHECK(fw_evq_create(fw));
  CHECK(serverq_create());

  CHECK(mod_timer_create(&fw->timer, CONFIG_TELEMETRON_FW_TIMER_MEDIUM_MS, &fw->eventq));
  CHECK(mod_buttons_create(&fw->buttons, &fw->eventq));
  CHECK(mod_doors_create(&fw->doors, &fw->eventq));
  CHECK(
    mod_auditd_create(
      &fw->auditd[0],
      0,
      CONFIG_TELEMETRON_FW_EVENTQ_NAME,
      CONFIG_TELEMETRON_FW_AUX1_PATH,
      CONFIG_TELEMETRON_FW_AUDIT1_REPORT_PATH
    )
  );
  CHECK(
    mod_auditd_create(
      &fw->auditd[1],
      1,
      CONFIG_TELEMETRON_FW_EVENTQ_NAME,
      CONFIG_TELEMETRON_FW_AUX2_PATH,
      CONFIG_TELEMETRON_FW_AUDIT2_REPORT_PATH
    )
  );
  CHECK(
    mod_auditd_create(
      &fw->auditd[2],
      2,
      CONFIG_TELEMETRON_FW_EVENTQ_NAME,
      CONFIG_TELEMETRON_FW_AUX3_PATH,
      CONFIG_TELEMETRON_FW_AUDIT3_REPORT_PATH
    )
  );
  CHECK(
    mod_gsmd_create(
      &fw->gsmd,
      CONFIG_TELEMETRON_FW_EVENTQ_NAME,
      CONFIG_TELEMETRON_FW_GSM_DRIVER_PATH,
      CONFIG_TELEMETRON_FW_TTY_PPP_PATH
    )
  );
  CHECK(
    mod_srvd_create(
      &fw->srvd,
      CONFIG_TELEMETRON_FW_EVENTQ_NAME,
      CONFIG_TELEMETRON_FW_SRVD_QUEUE_NAME,
      CONFIG_TELEMETRON_FW_FLOW3_FILE_PATH,
      CONFIG_ARCH_BOARD_CUSTOM_NAME
    )
  );
  CHECK(mod_smsd_create(&fw->smsd, CONFIG_TELEMETRON_FW_EVENTQ_NAME, CONFIG_TELEMETRON_FW_TTY_SMS_PATH));
  CHECK(mod_vmcd_create(&fw->vmcd, CONFIG_TELEMETRON_FW_EVENTQ_NAME));
  CHECK(mod_powermon_create(&fw->powermon, &fw->eventq));
  CHECK(mod_indication_create(&fw->indication));

  CHECK(sender_create(&fw->sender, fw));

  // Добавление созданных модулей в список.
  fw_modules_add(fw, &fw->timer);
  fw_modules_add(fw, &fw->buttons);
  fw_modules_add(fw, &fw->doors);
  fw_modules_add(fw, &fw->powermon);
  fw_modules_add(fw, &fw->indication);
  fw_modules_add(fw, &fw->auditd[0]);
  fw_modules_add(fw, &fw->auditd[1]);
  fw_modules_add(fw, &fw->auditd[2]);
  fw_modules_add(fw, &fw->gsmd);
  fw_modules_add(fw, &fw->srvd);
  fw_modules_add(fw, &fw->smsd);
  fw_modules_add(fw, &fw->vmcd);

  return 0;
}




////////////////////////////////////////////////////////////////////////////
//  Публичные функции

fw_t* fw_find_instance(void)
{
  fw_t* fw = NULL;
  sched_lock();
    fw = g_fw;
  sched_unlock();
  return fw;
}

int fw_create_instance(FAR fw_t** dst)
{
  fw_t* fw = NULL;
  if (!dst) {
    return -EINVAL;
  }

  sched_lock();
    if (!g_fw) {
      fw = g_fw = &g_fw_instance;
    }
  sched_unlock();

  if (!fw) {
    return -EADDRINUSE;
  }

  int ret = fw_create(fw);
  if (ret < 0) {
    g_fw = NULL;
    return ret;
  }

  *dst = fw;
  return 0;
}
