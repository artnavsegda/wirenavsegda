/// \file
/// \brief  Функции работы с файловой очередью сообщений на сервер.
/// \author DL <dmitriy@linikov.ru>


////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "serverq.h"
#include "fw.h"

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <sys/stat.h>
#include <sys/types.h>

#include <utils/posix_iohelper.h>




////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Приватные функции


////////////////////////////////////////////////////////////////////////////
//  Публичные функции

/// \brief Создаёт очередь сообщений, отправляемых на сервер.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int serverq_create(void)
{
  int ret;
  fq_settings_t   settings;
  const char*     dirs[SERVERQ_PRIORITIES];

  settings.priority_count = SERVERQ_PRIORITIES;
  settings.flags          = 0;
  settings.max_files_per_priority[SERVERQ_PRIO_LOW]   = 0; // Без ограничения
  settings.max_files_per_priority[SERVERQ_PRIO_HIGH]  = 4; // Не больше 4 файлов с высоким приоритетом

  dirs[SERVERQ_PRIO_LOW]  = CONFIG_TELEMETRON_FW_SRVD_LOWPRIO_DIR;
  dirs[SERVERQ_PRIO_HIGH] = NULL;

  if (dirs[SERVERQ_PRIO_LOW] != NULL) {
    ret = mkdir(CONFIG_TELEMETRON_FW_SRVD_LOWPRIO_DIR, DEFFILEMODE);
    if (ret < 0) {
      if (errno != EEXIST) {
        fw_error(
          "Can't create \"%s\" dir, ret=%d (%s)\n",
          dirs[SERVERQ_PRIO_LOW],
          errno,
          strerror(errno)
        );
        return -errno;
      }
    }
  }

  ret = fq_create_ex(CONFIG_TELEMETRON_FW_SRVD_QUEUE_NAME, &settings, dirs);
  if (ret < 0 && ret != -EEXIST) {
    fw_error(
      "Can't create server queue \"%s\", ret=%d (%s)\n",
      CONFIG_TELEMETRON_FW_SRVD_QUEUE_NAME,
      ret,
      strerror(-ret)
    );
  }
  return 0;
}


/// \brief  Получает монопольный доступ к директории с очередью файлов.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int serverq_lock(void)
{
  int ret = fq_lock(CONFIG_TELEMETRON_FW_SRVD_QUEUE_NAME);
  if (ret < 0) {
    fw_trace("fq_lock fail, ret=%d (%s)\n", ret, strerror(-ret));
  }
  return ret;
}

/// \brief  Получает монопольный доступ к директории с очередью файлов, ожидая
///         не более \p timeout_ms миллисекунд.
/// \param  timeout_ms    Максимальная продолжительность ожидания в миллисекундах.
///                       Если отрицательное число, то бесконечное ожидание.
///                       Если ноль, то выполняется без блокировки.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int serverq_lock_timeout(int32_t timeout_ms)
{
  int ret = fq_lock_timeout(CONFIG_TELEMETRON_FW_SRVD_QUEUE_NAME, timeout_ms);
  return ret;
}

/// \brief  Завершает монопольный доступ к директории с очередью файлов.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int serverq_unlock(void)
{
  int ret = fq_unlock(CONFIG_TELEMETRON_FW_SRVD_QUEUE_NAME);
  if (ret < 0) {
    fw_trace("fq_unlock fail, ret=%d (%s)\n", ret, strerror(-ret));
  }
  return ret;
}

/// \brief  Создаёт новое сообщение с приоритетом \p priority в файловой очереди
/// \param  priority      Приоритет сообщения
/// \param  created_id    Указатель на переменную, в которую будет записан
///                       полный идентификатор созданного файла.
///                       Если данный параметр NULL, то узнать идентификатор
///                       можно (до снятия блокировки и записи другого сообщения)
///                       либо прочитав файл lastid, либо вызвав функцию
///                       \see fq_read_lastid.
/// \return В случае успеха возвращает файловый дескриптор (fd) созданного файла.
///         Иначе, возвращает отрицательный код ошибки.
int serverq_push_new(serverq_prio_t priority, fq_id_t* created_id)
{
  int ret = fq_push_new(CONFIG_TELEMETRON_FW_SRVD_QUEUE_NAME, priority, created_id);
  if (ret < 0) {
    fw_trace("fq_push_new fail, ret=%d (%s)\n", ret, strerror(-ret));
  }
  return ret;
}

/// \brief  Создаёт новое сообщение с полным идентификатором \p msg_id.
///         Если такое сообщение уже есть в очереди, то заменяет его.
/// \param  msg_id        Полный идентификатор сообщения, не 0 и не 0xFFFFFFFF.
/// \return В случае успеха возвращает файловый дескриптор (fd) созданного файла.
///         Иначе, возвращает отрицательный код ошибки.
int serverq_push_or_replace_id(fq_id_t msg_id)
{
  int ret = fq_push_or_replace_id(CONFIG_TELEMETRON_FW_SRVD_QUEUE_NAME, msg_id);
  if (ret < 0) {
    fw_trace("fq_push_or_replace_id fail, ret=%d (%s)\n", ret, strerror(-ret));
  }
  return ret;
}

/// \brief  Добавляет в очередь с приоритетом \p priority существующий файл.
/// \param  priority      Приоритет сообщения
/// \param  existing      Строка, содержащая имя существующего файла.
/// \param  created_id    Указатель на переменную, в которую будет записан
///                       полный идентификатор созданного файла.
///                       Если данный параметр NULL, то узнать идентификатор
///                       можно (до снятия блокировки и записи другого сообщения)
///                       либо прочитав файл lastid, либо вызвав функцию
///                       \see fq_read_lastid.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int serverq_push_existing(serverq_prio_t priority, const char* existing, fq_id_t* created_id)
{
  int ret = fq_push_existing(CONFIG_TELEMETRON_FW_SRVD_QUEUE_NAME, priority, existing, created_id);
  if (ret < 0) {
    fw_trace("fq_push_existing fail, ret=%d (%s)\n", ret, strerror(-ret));
  }
  return ret;
}


/// \brief  Удаляет из очереди файл с полным идентификатором \p msg_id.
/// \param  msg_id        Полный идентификатор сообщения, не 0 и не 0xFFFFFFFF.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int serverq_unlink(fq_id_t msg_id)
{
  int ret = fq_unlink(CONFIG_TELEMETRON_FW_SRVD_QUEUE_NAME, msg_id);
  if (ret < 0) {
    fw_trace("fq_unlink fail, ret=%d (%s)\n", ret, strerror(-ret));
  }
  return ret;
}
