/// \file
/// \brief  Основной модуль ПО для проекта Modem-3.0
/// \author DL <dmitriy@linikov.ru>
///
/// Вся программа разбита нa отдельные, по большей части независимые, модули.
/// По сути, модули - это обработчики и, возможно, генераторы событий.
/// Все модули регистрируются в списке fw->modules и при обработке каждого
/// события каждый из модулей так же вызывается.
///
/// Для большинства модулей основными событиями являются:
///
///   * EV_START
///     Первое сообщение, запуск программы.
///
///     Вложенные данные отсутствуют.
///
///   * EV_CONFIGURE
///     Уведомление, что изменились настройки. Данное сообщение обязательно
///     отправляется после EV_START, так что загружать настройки
///     внутри обработчиков EV_START не нужно. Далее при каждом изменении
///     настроек в очередь отправляется событие EV_CONFIGURE.
///
///     Вложенные данные отсутствуют.
///
///   * EV_POWER
///     Уведомления об изменении режима питания, о переходе в сон.
///     Ещё не уверен о полном usecase использования данного события.
///
/// Подробнее про события: \ref fw_events


////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <nuttx/config.h>

#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <dbg.h>
#include "fw.h"

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора

////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций



////////////////////////////////////////////////////////////////////////////
//  Приватные функции

static int fw_print_usage(int ret, const char* msg)
{
  if (msg) {
    fprintf(stderr, "%s\n\n", msg);
  }

  fprintf(stderr,
    "Usage:\n"
    "  fw start     Starts the main firmware module\n"
    "  fw stop      Stops the main firmware module\n\n"
  );
  return ret;
}


static int fw_daemon_start(void)
{
  int             ret;
  FAR fw_t*       fw = fw_find_instance();

  if (!fw) {
    ret = fw_create_instance(&fw);
    if (ret < 0) {
      fprintf(stderr, "ERROR: Can't create FW, err=%d (%s)\n", ret, strerror(-ret));
      return ret;
    }
  }

  if (!fw) {
    fprintf(stderr, "ERROR: no FW instance\n");
    return -ENOTRECOVERABLE;
  }

  if (fw_is_started(fw)) {
    fprintf(stderr, "ERROR: FW already started\n");
    return -EADDRINUSE;
  }

  ret = fw_start(fw);
  if (ret < 0) {
    fprintf(stderr, "ERROR: Can't start FW, err=%d (%s)\n", ret, strerror(-ret));
    return ret;
  }

  printf("FW started\n");
  return 0;
}

static int fw_daemon_stop(void)
{
  int             ret;
  FAR fw_t*       fw;

  fw = fw_find_instance();
  if (!fw) {
    fprintf(stderr, "ERROR: FW is not created\n");
    return -ESRCH;
  }

  ret = fw_kill_and_wait(fw, 120000);
  if (ret < 0) {
    fprintf(stderr, "ERROR: Can't stop FW, err=%d (%s)\n", ret, strerror(-ret));
    return ret;
  }
  printf("FW stopped\n");
  return 0;
}

////////////////////////////////////////////////////////////////////////////
//  fw_main

#ifdef CONFIG_BUILD_KERNEL
int main(int argc, FAR char *argv[])
#else
int fw_main(int argc, char *argv[])
#endif
{

  if (argc < 2) {
    return fw_print_usage(-1, "ERROR: Not enough arguments");
  }

  if (strcmp(argv[1], "start") == 0) {
    return fw_daemon_start();
  }

  if (strcmp(argv[1], "stop") == 0) {
    return fw_daemon_stop();
  }

  return fw_print_usage(-1, "ERROR: Invalid argument");
}
