/// \file
/// \author DL <dmitriy.linikov@gmail.com>
/// \see status_bitfield.h

#define CFG_FILE_LOG_LEVEL LOG_LEVEL_OFF

#include "status_bitfield.h"

#include "dbg.h"

volatile uint32_t status=0;

bool NeedBreakeHighPriority(priority_t * level)
{
  (void)level;
  return false;
}
