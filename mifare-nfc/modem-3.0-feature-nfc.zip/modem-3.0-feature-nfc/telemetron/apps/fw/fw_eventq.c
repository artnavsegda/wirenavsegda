/// \file
/// \brief  Функции для работы с очередью сообщений из основного приложения.
/// \author DL <dmitriy@linikov.ru>


////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <utils/system_utils.h>
#include <eventq/eventq.h>

#include "fw.h"

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Приватные функции


////////////////////////////////////////////////////////////////////////////
//  Публичные функции

/// \brief Открывает существующую очередь сообщений или создаёт новую.
int fw_evq_create(FAR fw_t* fw)
{
  DEBUGASSERT(fw);
  return eventq_open(
    &fw->eventq,
    CONFIG_TELEMETRON_FW_EVENTQ_NAME,
    O_RDWR | O_CREAT
  );
}

/// \brief Закрывает ранее открытую очередь сообщений.
int fw_evq_close(FAR fw_t* fw)
{
  DEBUGASSERT(fw);
  return eventq_close(&fw->eventq);
}



/// \brief  Ожидает наличия и читает из очереди одно сообщение, сохраняя его в fw->event.
/// \param  timeout_ms  Время ожидания в ms:
///           * Если > 0,   то это время ожидания прихода сообщения
///           * Если == 0,  то данная функция эквивалентна `eventq_read`
///           * Если == -1, то данная функция ожидает события (или ошибки) бесконечно.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
/// \retval -EINVAL Попытка прочесть неоткрытую очередь.
/// \retval -EAGAIN В очереди нет сообщений.
/// \retval -EBADE  Читающая сторона записала меньше, чем размер одного сообщения.
///                 Для восстановления желательно пересоздать очередь.
int fw_evq_read_timeout(FAR fw_t* fw, int timeout_ms)
{
  DEBUGASSERT(fw);
  return eventq_read_timeout(&fw->eventq, &fw->event, timeout_ms);
}


int fw_evq_write(FAR fw_t* fw, int event, const void* data, size_t size)
{
  DEBUGASSERT(fw);
  DEBUGASSERT((size && data) || !size);
  return eventq_write(&fw->eventq, event, data, size);
}

/// \brief  Отправляет в очередь fw->eventq событие \p event.
/// \param  event Указатель на событие, которое необходимо отправить.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
/// \retval -EAGAIN Нет места в очереди.
/// \retval -EBADE  Читающая сторона прочитала меньше, чем размер события
///                 Для восстановления желательно пересоздать очередь.
/// \note   Данная функция не блокируется, если нет места в очереди, то
///         данная функция вернёт -EAGAIN. Что бы дождаться места в очереди
///         необходимо выполнить `eventq_pollwr` или соответствующий `poll`
int fw_evq_write_ex(FAR fw_t* fw, FAR const eventq_event_t* event)
{
  DEBUGASSERT(fw);
  return eventq_write_ex(&fw->eventq, event);
}

/// \brief Возвращает номер файла, который можно передать в `poll()`
int fw_evq_get_pollfd(FAR fw_t* fw)
{
  DEBUGASSERT(fw);
  return eventq_pollfd(&fw->eventq);
}
