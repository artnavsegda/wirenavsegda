/// \file
/// \author DL <dmitriy.linikov@gmail.com>
/// \see device_state.h

#include <ctype.h>
#include <string.h>
#include <settings.h>
#include <ccan/array_size/array_size.h>
#include "dbg.h"
//#include "gsm_sim900.h"

#include "device_state.h"
#include "utils/string_utils.h"

//bool            imei_is_set = false;
//char            imei[IMEI_LENGTH+1];

bool            key_is_set = false;
uint32_t        key_imei[8];

UnpackedTime    g_time;
uint16_t        current_minute_of_day = 5000;

bool            iccid_is_set = false;
char            iccid[ICCID_LENGTH+1];

char            imsi[IMSI_LENGTH+1]="";

char            sim_module[MAX_LENGTH_SIM_NAME+1]="not set";
char            sw_version_module[MAX_LENGTH_GSM_SW_VERSION+1]="not set";

/// \brief Принудительно запрашивает у GSM модуля номер IMEI,
/// сохраняет его в глобальную переменную \see imei, а так же сохраняет его в
/// качестве ключа шифрования в глобальную переменную \see key_imei.
void DevStateForceUpdateKey(void)
{
  const char* imei = SettingsGetImei();
  dbg_assert(NULL != imei, "Attempt to calculate key when IMEI is not known.");

  if (imei) {
    key_imei[0] = (imei[0]<<24) + (imei[1]<<16)  + (imei[2]<<8)  + imei[3];
    key_imei[1] = (imei[4]<<24) + (imei[5]<<16)  + (imei[6]<<8)  + imei[7];
    key_imei[2] = (imei[8]<<24) + (imei[9]<<16)  + (imei[10]<<8) + imei[11];
    key_imei[3] = (imei[12]<<24)+ (imei[13]<<16) + (imei[14]<<8) + imei[0];
    key_imei[4] = (imei[1]<<24) + (imei[2]<<16)  + (imei[3]<<8)  + imei[4];
    key_imei[5] = (imei[5]<<24) + (imei[6]<<16)  + (imei[7]<<8)  + imei[8];
    key_imei[6] = (imei[9]<<24) + (imei[10]<<16) + (imei[11]<<8) + imei[12];
    key_imei[7] = (imei[13]<<24)+ (imei[14]<<16) + (imei[13]<<8) + imei[14];
    key_is_set = true;
  }
}

/// \brief Возвращает номер IMEI устройства. Если этот номер ещё не запрошен,
/// то запрашивает. Номер всегда содержит \see IMEI_LENGTH символов
/// и заканчивается на нуль-символ.
//char* DevStateGetImei(void)
//{
//  //if (!imei_is_set) {
//  //  ForceRequestImei();
//  //}
//  return imei;
//}

/// \brief Возвращает 8 байт ключа шифрования, полученных на основе IMEI.
uint32_t* DevStateGetPrivateKey(void)
{
  if (!key_is_set) {
    DevStateForceUpdateKey();
  }
  return key_imei;
}

/// \brief Записывает в часы реального времени GSM модуля время, хранящееся в
/// глобальной переменной g_time.
void DevStateSetTimeToModem() // ref
{
/// \todo DL: Переделать DevStateSetTimeToModem на использование gsmd с параметрами
//  sim900_set_time(&g_time);
}

/// \brief Запрашивает текущее время у GSM модуля и записывает его
/// в глобальную переменную \see g_time.
bool DevStateUpdateTime(void)
{
/// \todo DL: Переделать DevStateUpdateTime на использование gsmd с параметрами
//  return sim900_get_time(&g_time);
  return false;
}

/// \brief Разбирает строку времени и сохраняет полученные значения в
/// глобальную переменную \see g_time.
bool DevStateParseAndSetTime(const char* time_str)
{
  return TimeParseServerFormat(&g_time, time_str);
}


/// \brief Возвращает указатель на структуру \see UnpackedTime, хранящую
/// текущее время.
const UnpackedTime* DevStateGetTime(void)
{
  return &g_time;
}

/// \brief Запрашивает из GSM модуля номер установленной SIM карты.
/// \note Если запрос ICCID заканчивается ошибкой, то устанавливает
bool DevStateForceRequestIccid(void)
{
  /// \todo DL: Добавить в DevStateForceRequestIccid получение ICCID через gsmd.
  return false;
#if 0
  int16_t count=3;
  iccid_is_set = false;
  while (count>=0)
  {
    count--;
    if (count<0)
        break;

    char* result = NULL;

    if (sim900_get_ccid(&result) && result != NULL) {
        // Проверим ICCID на валидность (длина не более ICCID_LENGTH, 19 цифр, если 20 символ цифра, то его тоже передаем иначе выкидываем
        int32_t len=strlen(result);
        if (len>=ICCID_LENGTH-1)
        {
            if (len>=ICCID_LENGTH)
            {
                len=ICCID_LENGTH;
                if (!isdigit((uint8_t)result[len-1]))
                    len--;
                // Заглушка для Мегафоновских симок (у них нет CRC)
                if ((uint8_t)result[len-1]=='F')
                    len--;
                result[len]='\0';
            }
            if (SettingsStrIsValid(result,len))
            {
                strncpy_ex(iccid, result, ARRAY_SIZE(iccid)-1);
                iccid_is_set = true;
                break;
            }
        }
    }
  }
  return iccid_is_set;
#endif
}

/// \brief Возвращает номер текущей SIM карты. Данный номер всегда содержит
/// 19 или 20 символов.
const char* DevStateGetIccid(void)
{
  if (!iccid_is_set) {
    strncpy_ex(iccid, "00000000000000000000", ARRAY_SIZE(iccid)-1);
    //             1234567890123456789 - 20 нулей.
  }
  return iccid;
}

/// \brief Запрашивает из GSM модуля версию программного обеспечения.
bool DevStateForceRequestModuleSwVersion(void)
{
  int16_t count=3;
  bool ok=false;
  while (count>=0)
  {
    count--;
    /// \todo DL: Добавить в DevStateForceRequestModuleSwVersion получение версии FW gsm модуля через gsmd
    //ok = sim900_get_swversion(sw_version_module,ARRAY_SIZE(sw_version_module)-1);
    if (ok) break;
    else strncpy_ex(sw_version_module,"UNKNOW",ARRAY_SIZE(sw_version_module)-1);
  }
  return(ok);
}

/// \brief Возвращает версию программного обеспечения модуля.
const char* DevStateGetModuleSwVersion(void)
{
  return sw_version_module;
}


/// \brief Запрашивает из GSM модуля тип SIM модуля.
bool DevStateForceRequestSimInfo(void)
{
  /// \todo DL: Добавить в DevStateForceRequestSimInfo запрос типа GSM модуля через gsmd
  return true;
#if 0
  int16_t count=3;
  bool ok=false;
  while (count>=0)
  {
    count--;
    Sim900ModuleInfo result;

    result = sim900_get_siminfo(sim_module,ARRAY_SIZE(sim_module)-1);
    if ((result==SIM_MODULE_SIM800) ||
        (result==SIM_MODULE_SIM900))
    {
        ok=true;
        break;
    }
    else
    {
        strncpy_ex(sim_module,"UNKNOW",ARRAY_SIZE(sim_module)-1);
    }
  }
  return(ok);
#endif
}

/// \brief Возвращает название текущего сим модуля.
const char* DevStateGetSimInfo(void)
{
  return sim_module;
}


/// \brief Запрашивает из GSM модуля номер установленной SIM карты.
/// \note Если запрос IMSI заканчивается ошибкой, то устанавливает
/// номер 0000000000000000000.
bool DevStateForceRequestImsi(void)
{
  int16_t count=3;
  while (count>=0)
  {
    count--;
    if (count<0)
        break;

    char* result = NULL;

    /// \todo DL: Добавить в DevStateForceRequestImsi запрос IMSI через gsmd
    if (0) {
    ///if (sim900_get_imsi(&result) && result != NULL) {
        // Проверим IMSI на валидность (длина не более IMSI_LENGTH)
        int32_t len=strlen(result);
        if ((len>=4))
        {
            if (len>IMSI_LENGTH)
            {
                len=IMSI_LENGTH;
                result[len]=0;
            }
            else
            {
                result[len]=0;
                len--;
            }
            if (SettingsStrIsValid(result,len))
            {
                strncpy_ex(imsi, result, ARRAY_SIZE(imsi)-1);
                return true;
            }
            else
                strncpy_ex(imsi, "000000000000000", ARRAY_SIZE(imsi)-1);
        }
    }
  }
  return false;
}

/// \brief Возвращает номер текущей SIM карты. Данный номер всегда содержит
const char* DevStateGetImsi(void)
{
  return imsi;
}


/// Проверка по IMSI тип карты (по сути определяем тип APN для карты)
bool DevStateIsUsim(char* imsi_to_check)
{
// валидный диапазон beeline для m2m (надо бы сделать хранение этого диапазона в коде для разных операторов)
// диапазон билайн 0280000000-0282999999
#define MIN_IMSI_DIG_VALID  (280000000)
#define MAX_IMSI_DIG_VALID  (282999999)
    char temp[IMSI_LENGTH]="";
    if (imsi_to_check)
    {
        int32_t len=strlen(imsi_to_check);
        if (len<=IMSI_LENGTH)
        {
            // в шестой позиции различия у Билайна: 0 -sim, 2 USIM
            if (len>=6)
            {
                strncpy_ex(temp,&imsi_to_check[5],IMSI_LENGTH);
                len=strlen(temp);
                if (SettingsStrIsValid(temp,len))
                {
                    uint64_t imsi_dig=atoi(temp);
                    if ((imsi_dig>=MIN_IMSI_DIG_VALID) && (imsi_dig<=MAX_IMSI_DIG_VALID))
                        // первичный apn
                        return false;
                    else
                        // вторичный apn2
                        return true;
                }
                else
                {
                    log_info(">>>>> DevStateIsUsim() fail imsi. =0x%s",temp);
                }
            }
        }
    }
    return false;
}
