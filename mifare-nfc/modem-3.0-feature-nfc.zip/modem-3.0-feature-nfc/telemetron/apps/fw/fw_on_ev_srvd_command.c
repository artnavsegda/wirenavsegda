/// \file
/// \brief  Обработка событий команд сервера объектом fw_t
/// \author DL <dmitriy@linikov.ru>


////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "fw.h"

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <srvd/events.h>
#include <utils/time_utils.h>
#include <utils/string_utils.h>
#include <utils/request_tokenizer.h>
#include <ccan/array_size/array_size.h>
#include <telemetron/bootloader_support.h>


////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных

typedef enum request_type_e {
  REQUEST_GENERIC = 0,
  REQUEST_SETTINGS
} request_type_t;

/// \brief Тип функции, которая обрабатывает отдельные параметры в запросе
/// от сервера.
/// \param fw       указатель на экземпляр основного модуля (контроллера)
/// \param request  указатель на структуру, содержащую имя и значение параметра
/// \param state    указатель на структуру, хранящую внутреннее состояние
///                 обработки текущего запроса.
typedef int (*process_request_fxn_t)(fw_t* fw, RequestEntity* request);

/// \brief Структура, описывающая обработчик какого-либо параметра в запросе
/// от сервера.
typedef struct request_processor_s {
  /// \brief Имя параметра (то, что в значении параметра стоИт перед знаком '=')
  const char*             name;

  /// \brief Функция, которая обрабатывает параметры с именем name.
  process_request_fxn_t   process_fxn;

  /// \brief Если true, то данный параметр запроса требует ответа с настройками.
  ///
  /// Соответственно, есл process_fxn вернёт отрицательное значение,
  /// то в ответе с настройками будет указана наличие ошибки
  request_type_t          type;
} request_processor_t;


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций



////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Приватные функции

/// \brief Устанавливает или сбрасывает одиночный бит в переменной server_status
/// в зависимости от значения запроса ('1' или '0').
static int ProcessSetSettingsOnoffValue(
  fw_t* fw,
  RequestEntity* request,
  int (*setter)(settings_t*, const onoff_t*)
)
{
  if (!request->value) {
    return -EINVAL;
  }

  onoff_t value = request->value[0] == '1' ? VALUE_ON : VALUE_OFF;
  return setter(&fw->settings, &value);
}

static int ProcessSetSettingsOnoffValueN(
  fw_t* fw,
  RequestEntity* request,
  int n,
  int (*setter)(settings_t*, int, const onoff_t*)
)
{
  if (!request->value) {
    return -EINVAL;
  }

  onoff_t value = request->value[0] == '1' ? VALUE_ON : VALUE_OFF;
  return setter(&fw->settings, n, &value);
}

static int ProcessSetSettingsStringValue(
  fw_t* fw,
  RequestEntity* request,
  int (*setter)(settings_t*, const char* )
)
{
  if (!request->value) {
    return -EINVAL;
  }

  return setter(&fw->settings, request->value);
}

static int ProcessSetSettingsU16Value(
  fw_t* fw,
  RequestEntity* request,
  int (*setter)(settings_t*, uint16_t)
)
{
  if (!request->value) {
    return -EINVAL;
  }

  unsigned long value = strtoul(request->value, NULL, 0);
  if (value > 65535) {
    return -ERANGE;
  }

  return setter(&fw->settings, (uint16_t)value);
}

static int ProcessSetSettingsPU16Value(
  fw_t* fw,
  RequestEntity* request,
  int (*setter)(settings_t*, const uint16_t*)
)
{
  if (!request->value) {
    return -EINVAL;
  }

  unsigned long value = strtoul(request->value, NULL, 0);
  if (value > 65535) {
    return -ERANGE;
  }

  uint16_t u16_value = value;

  return setter(&fw->settings, &u16_value);
}

static int ProcessSetSettingsPU32Value(
  fw_t* fw,
  RequestEntity* request,
  int (*setter)(settings_t*, const uint32_t*)
)
{
  if (!request->value) {
    return -EINVAL;
  }

  uint32_t value = (uint32_t)strtoul(request->value, NULL, 0);

  return setter(&fw->settings, &value);
}

static int ProcessGetRequest(fw_t* fw, RequestEntity* request)
{
  fw_info("Have Get(%s) request.\n", request->value);

  if (strcmp(request->value, "evadts") == 0) {
    return fw_start_audit_report(fw,  "server-evadts");
  }

  if (strcmp(request->value, "evadts_sniff") == 0) {
    fw_warn("WARN: `get=evadts_snif` not supported yet\n");
    return -ENOSYS;
  }

  if (strcmp(request->value, "report") == 0) {
    return fw_start_audit_report(fw,  "server-report");
  }

  if (strcmp(request->value, "gsm") == 0) {
    fw_warn("WARN: `get=gsm` not supported yet\n");
    return -ENOSYS;
  }

  if (strcmp(request->value, "config") == 0) {
    return sender_send_response_settings(&fw->sender, "server-config", &fw->settings);
  }

  fw_warn("Unknown parameter [%s]\n", request->value);
  return -EBADRQC;
}

static int ProcessSetTimeRequest(fw_t* fw, RequestEntity* request)
{
  int year, month, day, hour, minute, second;
  int ret;

  if (!request->value) {
    return -EINVAL;
  }
  if (!fw->srvd_have_roundrtip_duration) {
    // Устанавливаем время только если есть информация о длительности запроса
    return -ENOMSG;
  }

  ret = sscanf(request->value, "%d-%d-%d %d:%d:%d", &year, &month, &day, &hour, &minute, &second);
  if (ret != 6) {
    return -EILSEQ;
  }

  if (  year < 2018
    ||  month   < 1 || month > 12
    ||  day     < 1 || day > 31
    ||  hour    < 0 || hour > 31
    ||  minute  < 0 || minute > 60
    ||  second  < 0 || second > 60
  ) {
    return -EILSEQ;
  }

  struct tm    tm;
  tm.tm_year = year - 1900;
  tm.tm_mon  = month - 1;
  tm.tm_mday = day;
  tm.tm_hour = hour;
  tm.tm_min  = minute;
  tm.tm_sec  = second;

  time_t server_time = mktime(&tm);

  long roundtrip_ms = fw->srvd_roundtrip_duration.tv_sec * 1000
                    + fw->srvd_roundtrip_duration.tv_nsec / 1000000;

  if (roundtrip_ms > 30000) {
    // Слишком долгий запрос. Невозможно определить время.
    return -ETIME;
  }

  // Оценим серверное время в момент получения ответа.
  server_time += (roundtrip_ms / 2) / 1000;

  // Если серверное время сильно отличается от локального, то переводим часы
  long delta_seconds = server_time - fw->srvd_response_timestamp.tv_sec;
  if (labs(delta_seconds) < 5) {
    return 0; // Не ошибка.
  }

  struct timespec   now = timespec_now();
  now.tv_sec += delta_seconds;
  ret = clock_settime(CLOCK_REALTIME, &now);
  if (ret < 0) {
    ret = -errno;
    fw_error("Can't set time, ret=%d (%s)\n", ret, strerror(-ret));
  }

  fw_info("TIME: clock adjusted by %d seconds\n", delta_seconds);

  // Перезапуск таймера, что бы он не зависал, если время сильно изменилось.
  mod_timer_restart(&fw->timer);
  return ret;
}



static int ProcessSetServerRequest(fw_t* fw, RequestEntity* request)
{
  return ProcessSetSettingsStringValue(fw, request, settings_set_server_address);
}

/// \brief Устанавливает порт сервера.
static int ProcessSetPortRequest(fw_t* fw, RequestEntity* request)
{
  int port;
  if (!request->value) {
    return -EINVAL;
  }
  port = atoi(request->value);
  if (port <= 0 || port > 65535) {
    fw->srvd_settings_error = 1;
    return -EILSEQ;
  }

  return settings_set_server_port(&fw->settings, (uint16_t)port);
}

/// \brief Устанавливает путь к сервису обработки данных на сервере.
static int ProcessSetPathRequest(fw_t* fw, RequestEntity* request)
{
  return ProcessSetSettingsStringValue(fw, request, settings_set_server_path);
}

/// \brief Включает или отключает динамик в зависимости от значения в запросе.
static int ProcessSetBeepEnabledRequest(fw_t* fw, RequestEntity* request)
{
  return ProcessSetSettingsOnoffValue(fw, request, settings_set_beep);
}

/// \brief Включает или отключает sms в зависимости от значения в запросе.
static int ProcessSetSmsEnabledRequest(fw_t* fw, RequestEntity* request)
{
  return ProcessSetSettingsOnoffValue(fw, request, settings_set_sms);
}

/// \brief Включает или отключает шифрование в зависимости от значения в запросе.
static int ProcessSetEncryptionEnabledRequest(fw_t* fw, RequestEntity* request)
{
  return ProcessSetSettingsOnoffValue(fw, request, settings_set_encrypt);
}

/// \brief Включает или отключает (отправку отчётов о каждой покупке???)
/// в зависимости от значения в запросе.
static int ProcessSetSendVendEnabledRequest(fw_t* fw, RequestEntity* request)
{
  return ProcessSetSettingsOnoffValue(fw, request, settings_set_send_vend);
}


/// \brief Устанавливает график (отправки отчётов???).
static int ProcessSetScheduleRequest(fw_t* fw, RequestEntity* request)
{
  if (!request->value) {
    return -EINVAL;
  }

  sched_params_t  sched_params;

  // Очистка календаря
  memset(sched_params.schedule, 0xFF, sizeof(sched_params.schedule));

  // Формат календаря чч:мм,чч:мм,чч:мм
  // Заполняем календарь, если есть значение.
  size_t schedule_index = 0;
  char* colon = request->value;
  while (NULL != (colon = strchr(colon + 1, ':'))) {
    // Найден очередной разделитель между часами и минутами.
    // Проверяем формат
    if (  colon < request->value + 2        // есть место для чч;
        || !isdigit((uint8_t)colon[-1])     // чч - число;
        || !isdigit((uint8_t)colon[-2])     //
        || !isdigit((uint8_t)colon[1])      // мм - число;
        || !isdigit((uint8_t)colon[2])      //
        || (colon[3] != ','                 // после мм - находится
            && colon[3] != '\0'             // допустимый разделитель.
            && colon[3] != '&') ) {
      // Недопустимый формат. Ищем следующее двоеточие.
      continue;
    }

    // Подходящий формат текста.
    int hour = atoi(colon - 2);
    int minute = atoi(colon + 1);
    int minute_of_day = hour*60 + minute;
    sched_params.schedule[schedule_index++] = minute_of_day;

    if (schedule_index == ARRAY_SIZE(sched_params.schedule)) {
      // В календаре закончилось место.
      break;
    }
  }

  // Пометка последней записи, что она последняя
  sched_params.schedule[--schedule_index] |= SCHEDULE_LAST_ENTRY;
  return settings_set_schedule(&fw->settings, &sched_params);
}


/// \brief Включает или отключает отправку с каждым ping-сообщением информации
/// о силе GSM сигнала.
static int ProcessSetSendCsqEnabledRequest(fw_t* fw, RequestEntity* request)
{
  return ProcessSetSettingsOnoffValue(fw, request, settings_set_send_csq);
}

/// \brief Включает или отключает отправку с каждым ping сообщением информации
/// о ближайших к устройству GSM сотах.
static int ProcessSetSendLocationEnabled(fw_t* fw, RequestEntity* request)
{
  return ProcessSetSettingsOnoffValue(fw, request, settings_set_cell_locate);
}

/// \brief Устанавливает новое значение для APN.
static int ProcessSetApnRequest(fw_t* fw, RequestEntity* request)
{
  return ProcessSetSettingsStringValue(fw, request, settings_set_apn_name);
}

/// \brief Устанавливает новое значение логина для доступа к GPRS интернету.
static int ProcessSetGprsLogin(fw_t* fw, RequestEntity* request)
{
  return ProcessSetSettingsStringValue(fw, request, settings_set_apn_user);
}

/// \brief Устанавливает новое значение пароля для доступа к GPRS интернету.
static int ProcessSetGprsPassword(fw_t* fw, RequestEntity* request)
{
  return ProcessSetSettingsStringValue(fw, request, settings_set_apn_pwd);
}

/// \brief Обрабатывает запрос установки используемого типа шины данных.
static int ProcessSetBusRequest(fw_t* fw, RequestEntity* request)
{
  mdbexe_bus_t bus;
  fw->srvd_settings_confirm_pending  = 1;
  if (mdbexe_bus_parse(request->value, &bus) < 0) {
    fw->srvd_settings_error = 1;
    return -EILSEQ;
  }

  return settings_set_mdbexe_bus(&fw->settings, &bus);
}

/// \brief Обрабатывает запрос установки нового значения таймаута.
/// (может, интервала между пингами????).
static int ProcessSetTimeoutRequest(fw_t* fw, RequestEntity* request)
{
  return ProcessSetSettingsU16Value(fw, request, settings_set_server_ping_interval_s);
}

/// \brief Обрабатывает запрос установки времени (в секундах) до установления ошибки по шине MDB/EXE.
static int ProcessSetDelayRequest(fw_t* fw, RequestEntity* request)
{
  return ProcessSetSettingsPU32Value(fw, request, settings_set_mdbexe_error_timeout_ms);
}

/// \brief Обрабатывает запрос установки нового значения таймаута сигнализации
/// (может максимального времени открытия двери??)
static int ProcessSetAlarmTimeoutRequest(fw_t* fw, RequestEntity* request)
{
  return ProcessSetSettingsPU16Value(fw, request, settings_set_door_time_s);
}

static int ProcessSetEvadtsInterfaceN(fw_t* fw, RequestEntity* request, size_t port_n)
{
  aux_interface_t interface;
  int ret = aux_interface_parse(request->value, &interface);
  if (ret < 0) {
    return ret;
  }

  return settings_set_aux_interface(&fw->settings, port_n, &interface);
}

static int ProcessSetEvadtsInterfaceA(fw_t* fw, RequestEntity* request)
{
  return ProcessSetEvadtsInterfaceN(fw, request, AUX1);
}

static int ProcessSetEvadtsInterfaceB(fw_t* fw, RequestEntity* request)
{
  return ProcessSetEvadtsInterfaceN(fw, request, AUX2);
}

static int ProcessSetEvadtsInterfaceC(fw_t* fw, RequestEntity* request)
{
  return ProcessSetEvadtsInterfaceN(fw, request, AUX3);
}



static int ProcessSetEvadtsTypeN(fw_t* fw, RequestEntity* request, size_t port_n)
{
  aux_type_t type;
  int ret = aux_type_parse(request->value, &type);
  if (ret < 0) {
    return ret;
  }

  return settings_set_aux_type(&fw->settings, port_n, &type);
}

static int ProcessSetEvadtsTypeA(fw_t* fw, RequestEntity* request)
{
  return ProcessSetEvadtsTypeN(fw, request, AUX1);
}

static int ProcessSetEvadtsTypeB(fw_t* fw, RequestEntity* request)
{
  return ProcessSetEvadtsTypeN(fw, request, AUX2);
}

static int ProcessSetEvadtsTypeC(fw_t* fw, RequestEntity* request)
{
  return ProcessSetEvadtsTypeN(fw, request, AUX3);
}

static int ProcessSetEvadtsCfgPortN(fw_t* fw, RequestEntity* request, int n)
{
  if (!request->value) {
    return -EINVAL;
  }

  int     ret;
# define MAX_EVADTS_CFG_TOKENS   5
  char*   tokens[MAX_EVADTS_CFG_TOKENS];


  uint8_t n_tokens = SplitString(
    tokens, MAX_EVADTS_CFG_TOKENS, request->value, ",", SPLITSTRING_KEEP_EMPTY
  );

  // Посчитаем количество параметров (количество запятых)
  // Если оно за пределами уставноленного, то ошибка
  if (n_tokens != 5) {
    return -EILSEQ;
  }

  // Локальная копия параметров для редактирования
  aux_params_t auxN = *settings_get_aux(&fw->settings, n);

  // Здесь допустим возможность наличия пустых параметров. Такие не трогаем.


  // 0 = DDCMP Mode
  if (!IsWhiteOrEmptyString(tokens[0])) {
    ret = ddcmp_mode_parse(tokens[0], &auxN.ddcmp_params.ddcmp_mode);
    if (ret < 0) {
      return ret;
    }
  }

  // 1 = DDCMP Ext
  if (!IsWhiteOrEmptyString(tokens[1])) {
    ret = ddcmp_extspeed_parse(tokens[1], &auxN.ddcmp_params.ddcmp_extended);
    if (ret < 0) {
      return ret;
    }
  }

  // 2 = DDCMP Audit Mode
  if (!IsWhiteOrEmptyString(tokens[2])) {
    ret = ddcmp_auditmode_parse(tokens[2], &auxN.ddcmp_params.ddcmp_auditmode);
    if (ret < 0) {
      return ret;
    }
  }

  // 3 = DDCMP Fix Baud
  if (!IsWhiteOrEmptyString(tokens[3])) {
    ret = ddcmp_fix_baud_parse(tokens[3], &auxN.ddcmp_params.ddcmp_fix_baud);
    if (ret < 0) {
      return ret;
    }
  }

  // 4 = Idle Port State
  // DL: Не понимаю, почему это добавили в параметры DDCMP
  if (!IsWhiteOrEmptyString(tokens[4])) {
    ret = aux_idlestate_parse(tokens[4], &auxN.idlestate);
    if (ret < 0) {
      return ret;
    }
  }

  return settings_set_aux(&fw->settings, n, &auxN);
}

static int ProcessSetEvadtsCfgPortA(fw_t* fw, RequestEntity* request)
{
  return ProcessSetEvadtsCfgPortN(fw, request, AUX1);
}

static int ProcessSetEvadtsCfgPortB(fw_t* fw, RequestEntity* request)
{
  return ProcessSetEvadtsCfgPortN(fw, request, AUX2);
}

static int ProcessSetEvadtsCfgPortC(fw_t* fw, RequestEntity* request)
{
  return ProcessSetEvadtsCfgPortN(fw, request, AUX3);
}


static int ProcessSetEvadtsDdcmpSaecoFixPortN(fw_t* fw, RequestEntity* request, int n)
{
  ddcmp_saeco_fix_t   ddcmp_saeco_fix;
  int ret = ddcmp_saeco_fix_parse(request->value, &ddcmp_saeco_fix);
  if (ret < 0) {
    return ret;
  }

  // Локальная копия для редактирования
  aux_params_t  auxN = *settings_get_aux(&fw->settings, n);
  auxN.ddcmp_params.ddcmp_saeco_fix = ddcmp_saeco_fix;
  return settings_set_aux(&fw->settings, n, &auxN);
}

static int ProcessSetEvadtsDdcmpSaecoFixPortA(fw_t* fw, RequestEntity* request)
{
  return ProcessSetEvadtsDdcmpSaecoFixPortN(fw, request, AUX1);
}

static int ProcessSetEvadtsDdcmpSaecoFixPortB(fw_t* fw, RequestEntity* request)
{
  return ProcessSetEvadtsDdcmpSaecoFixPortN(fw, request, AUX2);
}

static int ProcessSetEvadtsDdcmpSaecoFixPortC(fw_t* fw, RequestEntity* request)
{
  return ProcessSetEvadtsDdcmpSaecoFixPortN(fw, request, AUX3);
}



static int ProcessSetEVADTSSearch(fw_t* fw, RequestEntity* request)
{
  return ProcessSetSettingsOnoffValue(fw, request, settings_set_evadts_search);
}

static int ProcessSetAutoRequestEvadts(fw_t* fw, RequestEntity* request)
{
  return ProcessSetSettingsOnoffValue(fw, request, settings_set_request_evadts_after_mdb_change);
}

static int ProcessSetDebugPort(fw_t* fw, RequestEntity* request)
{
  onoff_t is_debug;
  int ret = onoff_parse(request->value, &is_debug);
  if (ret < 0) {
    return ret;
  }

  // локальная копия параметров порта AUX3 - для изменения настроек
  aux_params_t aux3 = *settings_get_aux(&fw->settings, AUX3);


  if (is_debug == VALUE_ON && aux3.type != AUX_TYPE_CONSOLE) {
    // Если порт ещё не был настроен в режим консоли
    aux3.type       = AUX_TYPE_CONSOLE;
    aux3.interface  = AUX_INTERFACE_TTL;
    aux3.idlestate  = AUX_IDLESTATE_ONE;
    return settings_set_aux(&fw->settings, AUX3, &aux3);
  }

  if (is_debug == VALUE_OFF && aux3.type == AUX_TYPE_CONSOLE) {
    // Если порт перестаёт быть консолью и ещё не был переведён в другой режим
    // командами set-evadts-...
    aux3.type       = AUX_TYPE_OFF;
    aux3.interface  = AUX_INTERFACE_TTL;
    aux3.idlestate  = AUX_IDLESTATE_ONE;
    return settings_set_aux(&fw->settings, AUX3, &aux3);
  }

  return 0;
}

static int ProcessSetBusAutodetect(fw_t* fw, RequestEntity* request)
{
  return ProcessSetSettingsOnoffValue(fw, request, settings_set_mdbexe_bus_autodetect);
}

static int ProcessSetMDBEXELog(fw_t* fw, RequestEntity* request)
{
  return ProcessSetSettingsOnoffValue(fw, request, settings_set_mdbexe_MDB_EXE_log);
}

static int ProcessSetExternalSensors(fw_t* fw, RequestEntity* request)
{
  return ProcessSetSettingsOnoffValue(fw, request, settings_set_sensors_on);
}

static int ProcessSetExternalSensor(fw_t* fw, RequestEntity* request)
{
  int ret;
  int last_error = 0;
  if (!request->value) {
    return -EINVAL;
  }

#define MAX_SETSENSOR_TOKENS    MAX_SENSORS*3
  char* tokens[MAX_SETSENSOR_TOKENS];
  size_t n_tokens = SplitStringEx(
    tokens,
    MAX_SETSENSOR_TOKENS,
    request->value,
    ",",
    SPLITSTRING_KEEP_EMPTY,
    SPLITSTRING_OVERFLOW_IGNORE
  );

  if (!n_tokens) {
    return -EINVAL;
  }

  for (size_t i=0; i < n_tokens; i += 3) {
    int             id;
    sensor_params_t sensor;
    char**          sensor_tokens = &tokens[i];
    char*           endptr;

    // Проверки токенов
    if (i + 3 > MAX_SETSENSOR_TOKENS) {
      // в буффере tokens недостаточно места для хранения очередных 3 параметров
      // Завершаем разбор
      last_error = -ENOBUFS;
      break;
    }

    if (i + 3 > n_tokens) {
      // Недостаточно токенов для полного описания настроек одного сенсора
      last_error = -EILSEQ;
      break;
    }

    // Разбор значений
    id = strtol(sensor_tokens[0], &endptr, 10);
    if (endptr == sensor_tokens[0]) {
      // Не удалось разобрать номер сенсора. Пропускаем эту тройку параметров
      last_error = -EINVAL;
      continue;
    }

    ret = onoff_parse(sensor_tokens[1], &sensor.on);
    if (ret < 0) {
      // Ошибка разбора параметра. Пропускаем всю тройку параметров
      last_error = ret;
      continue;
    }

    ret = sensor_type_parse(sensor_tokens[2], &sensor.type);
    if (ret < 0) {
      // Ошибка разбора параметра. Пропускаем всю тройку параметров.
      last_error = ret;
      continue;
    }

    // Сохранение настроек
    ret = settings_set_sensor(&fw->settings, id, &sensor);
    if (ret < 0) {
      last_error = ret;
      continue;
    }
  }

  return last_error;
}


static int SaveCfgRequestForDelayedProcessing(fw_t* fw, RequestEntity* request)
{
  fw->srvd_server_requested_settings = 1;
  return 0;
}

static int ProcessSetDefaultSettingsRequest(fw_t* fw, RequestEntity* request)
{
  if (!request->value || strcmp(request->value, "1") != 0) {
    return -EINVAL;
  }

  return settings_default_fw_params(&fw->settings);
}


/// \brief Обрабатывает запрос смены прошивки устройства.
static int ProcessUpdateFirmwareRequest(fw_t* fw, RequestEntity* request)
{
  fw_info("Have request to update firmware.\n");
  char * ptr_value =(char *)request->value;
  if (!ptr_value) {
    fw_error("Error pointer value.\n");
    return -EINVAL;
  }

  if ((!StartsWith(ptr_value, "firmware")) && (!StartsWith(ptr_value, "firmware_boot"))){
    fw_error("Unknown request.\n");
    return -EINVAL;
  }

  struct Cfg_Firmware* firmware_name_ptr=NULL;
  struct Cfg_Firmware firmware_name={.len_file=0xFFFF,.len_path=0xFFFF,.firmware_file="",.firmware_path=""};

  uint8_t i;
  i=0;
  while ((ptr_value) && (*ptr_value))
  {
      char* str_value = strchr(ptr_value, ',');
      if (str_value)
      {
          *str_value = '\0';
          str_value++;
      }
      else
      {
          if (!i)
            // Нет информации об имени прошивки
            break;
      }
      switch (i)
      {
        // Имя прошивки
        case 1 :
            firmware_name.len_file=sizeof(firmware_name.firmware_file);
            if (strlen(ptr_value)<sizeof(firmware_name.firmware_file))
                firmware_name.len_file=strlen(ptr_value);
            strncpy_ex(firmware_name.firmware_file,ptr_value,sizeof(firmware_name.firmware_file));
            firmware_name_ptr=&firmware_name;
            firmware_name.len_path=0;
            fw_trace("Special firmware file name=%s\n",firmware_name.firmware_file);
            break;
        // Путь к прошивке
        case 2 :
            firmware_name.len_path=sizeof(firmware_name.firmware_path);
            if (strlen(ptr_value)<sizeof(firmware_name.firmware_path))
                firmware_name.len_path=strlen(ptr_value);
            strncpy_ex(firmware_name.firmware_path,ptr_value,sizeof(firmware_name.firmware_path));
            fw_trace("Special firmware path=%s\n",firmware_name.firmware_path);
            break;
        // Большее число передаваемых параметров
        default:
            break;
      }
      i++;
      ptr_value=str_value;
  }
  if (firmware_name_ptr)
    fw_trace("Special firmware params: name=[%s], path=[%s]\n",firmware_name.firmware_file,firmware_name.firmware_path);
    /// \todo DL: Восстановить загрузку прошивки по ftp
//#ifdef CFG_FW_TCPIP
//  #include "firmware_update.h"
//  if (firmware)
//  {
//    uint32_t err=FirmwareUpdate_ftp_open(firmware_name_ptr);
//    if (err)
//    {
//        log_error("Firmware FTP %X", err);
//        bootloader_request_update(firmware_name_ptr);
//    }
//  }
//  else
//#endif // CFG_FW_TCPIP
  // Сообщаем о требовании обновить прошивку
  int ret = bootloader_request_update(firmware_name_ptr);
  if (ret < 0) {
    return ret;
  }

  ret = fw_evq_write(fw, EV_REBOOT, NULL, 0);
  if (ret < 0) {
    fw_error("Can't send reset event, ret=%d (%s)\n", ret, strerror(-ret));
    return ret;
  }
  return 0;
}

static int ProcessSetHWFirmwareFile(fw_t* fw, RequestEntity* request)
{
  int             ret;
  bootldr_data_t  save;

  const char * ptr_value =(char *)request->value;
  if (!ptr_value) {
    return -EINVAL;
  }

  if (strlen(ptr_value) >= sizeof(save.firmware_name)
  ||  !strlen(ptr_value)) {
    // Данные должны быть заданы
    return -EINVAL;
  }

  ret = bootloader_get_state(&save);
  if (ret) {
    fw_warn("There was no bootloader data. Creating.\n");
  } else {
    fw_dump("Read boot data", &save, sizeof(save));
  }


  // Копируем имя файла
  strncpy_ex(
    save.firmware_name.firmware_file,
    ptr_value,
    sizeof(save.firmware_name.firmware_file)
  );

  fw_info("new firmware filename [%s]\n", save.firmware_name.firmware_file);
  return bootloader_set_state(&save);
}


/// \brief Вызывает обработчик для отдельного параметра (например, server=foobar).
static void ProcessModemControlParameter(fw_t* fw, RequestEntity* request)
{
  static const request_processor_t REQUEST_PROCESSORS[] = {
    {"get",                         &ProcessGetRequest,                   REQUEST_GENERIC},
    {"time",                        &ProcessSetTimeRequest,               REQUEST_GENERIC },
    {"set_server",                  &ProcessSetServerRequest,             REQUEST_SETTINGS },
    {"set_port",                    &ProcessSetPortRequest,               REQUEST_SETTINGS },
    {"set_path",                    &ProcessSetPathRequest,               REQUEST_SETTINGS },
    {"set_sound",                   &ProcessSetBeepEnabledRequest,        REQUEST_SETTINGS },
    {"set_sms",                     &ProcessSetSmsEnabledRequest,         REQUEST_SETTINGS },
    {"set_encrypt",                 &ProcessSetEncryptionEnabledRequest,  REQUEST_SETTINGS },
    {"set_quality",                 &ProcessSetSendCsqEnabledRequest,     REQUEST_SETTINGS },
    {"set_location",                &ProcessSetSendLocationEnabled,       REQUEST_SETTINGS },
    {"set_send_vend",               &ProcessSetSendVendEnabledRequest,    REQUEST_SETTINGS },
    {"set_schedule",                &ProcessSetScheduleRequest,           REQUEST_GENERIC },
    {"set_apn",                     &ProcessSetApnRequest,                REQUEST_SETTINGS },
    {"set_apn_login",               &ProcessSetGprsLogin,                 REQUEST_SETTINGS },
    {"set_apn_pass",                &ProcessSetGprsPassword,              REQUEST_SETTINGS },
    {"set_bus",                     &ProcessSetBusRequest,                REQUEST_SETTINGS },
    {"set_timeout",                 &ProcessSetTimeoutRequest,            REQUEST_SETTINGS },
    {"set_delay",                   &ProcessSetDelayRequest,              REQUEST_SETTINGS },
    {"set_alarm_timeout",           &ProcessSetAlarmTimeoutRequest,       REQUEST_SETTINGS },
    {"set_evadts_port_a",           &ProcessSetEvadtsInterfaceA,          REQUEST_SETTINGS },
    {"set_evadts_port_b",           &ProcessSetEvadtsInterfaceB,          REQUEST_SETTINGS },
    {"set_type_evadts_port_a",      &ProcessSetEvadtsTypeA,               REQUEST_SETTINGS },
    {"set_type_evadts_port_b",      &ProcessSetEvadtsTypeB,               REQUEST_SETTINGS },
    {"set_cfg_evadts_port_a",       &ProcessSetEvadtsCfgPortA,            REQUEST_SETTINGS },
    {"set_cfg_evadts_port_b",       &ProcessSetEvadtsCfgPortB,            REQUEST_SETTINGS },
    {"set_evadts_port_a_saeco_fix", &ProcessSetEvadtsDdcmpSaecoFixPortA,  REQUEST_SETTINGS },
    {"set_evadts_port_b_saeco_fix", &ProcessSetEvadtsDdcmpSaecoFixPortB,  REQUEST_SETTINGS },
    {"set_evadts_search",           &ProcessSetEVADTSSearch,              REQUEST_SETTINGS },
    {"set_auto_request_evadts",     &ProcessSetAutoRequestEvadts,         REQUEST_SETTINGS },
    {"set_debug_port",              &ProcessSetDebugPort,                 REQUEST_SETTINGS },
    {"set_bus_autodetect",          &ProcessSetBusAutodetect,             REQUEST_SETTINGS },
    {"set_mdb_exe_log",             &ProcessSetMDBEXELog,                 REQUEST_SETTINGS },
    {"set_external_sensors",        &ProcessSetExternalSensors,           REQUEST_SETTINGS },
    {"set_external_sensor_config[]",&ProcessSetExternalSensor,            REQUEST_SETTINGS },
    // {"set_sms_raw_data",            &ProcessSetSmsRaw,                    REQUEST_SETTINGS },
    // {"set_shake",                   &ProcessSetPunchDetectorEnabled,      REQUEST_SETTINGS },
    // {"set_punch_settings[]=",       &ProcessSetPunchSettings,             REQUEST_SETTINGS },
    // {"set_punch_raw=",              &ProcessSetPunchRaw,                  REQUEST_SETTINGS },
    // {"set_printer_tcp_port",        &ProcessSetPrinterTcpPortRequest,     REQUEST_SETTINGS },
    // {"set_printer_pass",            &ProcessSetPrinterPswRequest,         REQUEST_SETTINGS },
    // {"set_printer_OFD[]",           &ProcessSetPrinterOFDRequest,         REQUEST_SETTINGS },
    {"update",                      &ProcessUpdateFirmwareRequest,        REQUEST_SETTINGS },
    // {"eraseflash",                  &ProcessEraseFlashRequest,            REQUEST_SETTINGS },
    {"config",                      &SaveCfgRequestForDelayedProcessing, REQUEST_GENERIC },
    // {"status",                      &IgnoreRequest,                       REQUEST_GENERIC }, // не используется.
    {"defset",                      &ProcessSetDefaultSettingsRequest,    REQUEST_SETTINGS },
    // {"reset",                       &ProcessResetRequest,                 REQUEST_SETTINGS },
    // {"set_product_db[]",            &ProcessSetDB,                        REQUEST_SETTINGS },
    {"set_hw_firmware_file",        &ProcessSetHWFirmwareFile,            REQUEST_SETTINGS },
  };

  fw_trace("[SRVCMD] Processing parameter [%s] with value [%s]\n",
            request->name, request->value);
  for (size_t i=0; i < ARRAY_SIZE(REQUEST_PROCESSORS); ++i) {
    if (   strcmp(request->name, REQUEST_PROCESSORS[i].name) == 0
        && REQUEST_PROCESSORS[i].process_fxn != NULL
    ) {
      // найден обработчик для параметра request. Вызываем его.
      int ret = REQUEST_PROCESSORS[i].process_fxn(fw, request);
      if (REQUEST_PROCESSORS[i].type == REQUEST_SETTINGS) {
        fw->srvd_settings_confirm_pending  = 1;
        if (ret < 0) {
          fw->srvd_settings_error = 1;
        }
      }
      return;
    }
  }
  fw_warn("[SRVCMD] Unknown request \"%s\".\n", request->name);
}


static void fw_on_srvd_transaction_ended(fw_t* fw)
{
  if (!fw->srvd_transaction_in_progress) {
    return;
  }

  fw_info("[SRVCMD] Transaction ended\n");
  bool settings_changed = false;
  if (fw->srvd_apn_params_version != settings_get_apn_params_version(&fw->settings)) {
    // Изменились настройки APN
    settings_changed = true;
    settings_save_apn_params(&fw->settings);
  }

  if (fw->srvd_fw_params_version != settings_get_fw_params_version(&fw->settings)) {
    // Изменились основные настройки.
    settings_changed = true;
    settings_save_fw_params(&fw->settings);
  }

  if (settings_changed) {
    // Если изменились настройки, то уведомляем все модули об этом
    ev_configure_t* e   = EVENTQ_CREATE_EVENT(&fw->event, EV_CONFIGURE, ev_configure_t);
    e->sender_pid       = getpid();
    e->settings         = &fw->settings;
    fw_evq_write_ex(fw, &fw->event);
  }

  if (fw->srvd_settings_confirm_pending) {
    // Если требуется отправить ответ о настройках обратно на сервер, то делаем это.
    fw_info("[SRVCMD] Sending settings response\n");
    // отправка header&set=[ok|error]
    sender_send_set_settings_confirmation(&fw->sender, !fw->srvd_settings_error);
  }

  if (fw->srvd_server_requested_settings
      || (fw->srvd_settings_confirm_pending && !fw->srvd_settings_error)
  ) {
    // Отправка всех настроек
    fw_info("[SRVCMD] Server requested config. Sending\n");
    sender_send_response_settings(&fw->sender, "server-set_ok", &fw->settings);
  }

  fw->srvd_transaction_in_progress = false;
}

static void fw_on_srvd_transaction_started(fw_t* fw)
{
  if (fw->srvd_transaction_in_progress) {
    // Есть незавершенная транзакция (возможно потеряли уведомление)
    // Завершаем её
    fw_warn("[SRVCMD] Terminated old transaction before starting new\n");
    fw_on_srvd_transaction_ended(fw);
  }

  fw->srvd_transaction_in_progress    = true;
  fw->srvd_settings_confirm_pending  = false;
  fw->srvd_fw_params_version          = settings_get_fw_params_version(&fw->settings);
  fw->srvd_apn_params_version         = settings_get_apn_params_version(&fw->settings);
  fw->srvd_transaction_timeout =
    timespec_after_ms(CONFIG_TELEMETRON_FW_SRVD_TRANSACTION_TIMEOUT_MS);

  if (fw->srvd_have_roundrtip_duration) {
    fw_info("[SRVCMD] Transaction started. Roundtrip=%d.%09ld\n",
      fw->srvd_roundtrip_duration.tv_sec, fw->srvd_roundtrip_duration.tv_nsec
    );
  } else {
    fw_info("[SRVCMD] Transaction started\n");
  }
}



////////////////////////////////////////////////////////////////////////////
//  Публичные функции

void fw_on_ev_srvd_transaction_start(FAR fw_t* fw, FAR eventq_event_t* event)
{
  // Начата обработка пакета от сервера
  ev_srvd_transaction_start_t* e = (ev_srvd_transaction_start_t*)event->data;
  (void)e; // Не используется. оставлено для отладки

  // Вычислние коррекции времени на основе времени на отправку-получение ответа
  // Это нужно для более точной установки локальных часов по времени сервера
  fw->srvd_roundtrip_duration = timespec_diff(&e->ts_response_start, &e->ts_connected);
  fw->srvd_response_timestamp = e->ts_response_start;
  fw->srvd_have_roundrtip_duration = true;
  fw_on_srvd_transaction_started(fw);
}

void fw_on_ev_srvd_transaction_end(FAR fw_t* fw, FAR eventq_event_t* event)
{
  // Завершена обработка пакета от сервера
  ev_srvd_transaction_end_t* e = (ev_srvd_transaction_end_t*)event->data;
  (void)e; // Не используется. оставлено для отладки

  fw_on_srvd_transaction_ended(fw);
}

void fw_check_srvd_transaction_timeout(FAR fw_t* fw, FAR eventq_event_t* event)
{
  // Вызывается из события таймера, проверяет, что не случилось "зависшей"
  // обработки пакета от сервера (например, если оказалась переполнена очередь
  // сообщений и srvd не смог отправить в неё событие EV_SRVD_TRANSACTION_END)
  if (!fw->srvd_transaction_in_progress) {
    return;
  }

  if (timespec_is_passed(&fw->srvd_transaction_timeout)) {
    // Прошло время выделенное на обработку команд одного запроса от сервера.
    fw_warn("[SRVCMD] Transaction timeout\n");
    fw_on_srvd_transaction_ended(fw);
  }
}

void fw_on_ev_srvd_command(FAR fw_t* fw, FAR eventq_event_t* event)
{
  // Обработка отдельной команды из пакета от сервера
  ev_srvd_command_t* e = (ev_srvd_command_t*)event->data;

  if (!fw->srvd_transaction_in_progress) {
    // Если получили команду от сервера, но транзакция не была начата,
    // то начинаем новую транзакцию. Скорее всего, была потеря события,
    // или из-за слишком долгой обработки команд сервера транзакция была
    // завершена ранее.
    // При этом нет информации о длительности запроса.
    fw_info("[SRVCMD] Got cmd without transaction.\n");
    fw->srvd_have_roundrtip_duration = false;
    fw_on_srvd_transaction_started(fw);
  }


  fw_info("[SRVCMD]%s\n", e->text);
  RequestEntity cmd;
  size_t        split_result = SplitRequest(&cmd, 1, e->text);

  if (!split_result) {
    return;
  }

  ProcessModemControlParameter(fw, &cmd);
}
