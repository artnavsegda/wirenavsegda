/// \file
/// \brief  Определения, требуемые для отладки old_fw (сильно связанные с исходным кодом old_fw)
/// \author DL <dmitriy.linikov@gmail.com>

#ifndef OLD_FW_DBG_H_INCLUDED
#define OLD_FW_DBG_H_INCLUDED

#include <stdint.h>
#include <utils/dbg.h>
#include <utils/systime.h>

// список точек входа
typedef enum SW_State_Position {
    SW_MAIN_START                           =   0x80000055,
    SW_MAIN_START_1                         =   0x80000056,
    SW_MAIN_START_2                         =   0x80000057,
    SW_MAIN_START_3                         =   0x80000058,
    SW_MAIN_START_4                         =   0x80000059,
    SW_MAIN_START_5                         =   0x8000005A,
    SW_MAIN_LOOP                            =   0x800000AA,
    SW_MAIN_LOOP_1                          =   0x800000AB,
    SW_MAIN_LOOP_2                          =   0x800000AC,
    SW_MAIN_LOOP_3                          =   0x800000AD,
    SW_MAIN_LOOP_4                          =   0x800000AE,
    SW_MAIN_SHORT_LOOP                      =   0x80000022,
    SW_MAIN_SHORT_LOOP_1                    =   0x80000023,
    SW_MAIN_SHORT_LOOP_2                    =   0x80000024,
    SW_MAIN_SHORT_LOOP_3                    =   0x80000025,
    SW_MAIN_SHORT_LOOP_4                    =   0x80000026,
    SW_MAIN_SHORT_LOOP_5                    =   0x80000027,
    SW_MAIN_SHORT_LOOP_6                    =   0x80000028,
    SW_MAIN_SHORT_LOOP_7                    =   0x80000029,
    SW_MAIN_SHORT_LOOP_8                    =   0x8000002A,
    SW_MAIN_SHORT_LOOP_9                    =   0x8000002B,
    SW_MAIN_SHORT_LOOP_10                   =   0x8000002C,
    SW_MAIN_SHORT_LOOP_11                   =   0x8000002D,
    SW_MAIN_SHORT_LOOP_12                   =   0x8000002E,
    SW_MAIN_SHORT_LOOP_13                   =   0x8000002F,
    SW_MAIN_SHORT_LOOP_14                   =   0x80000030,
    SW_MAIN_SHORT_LOOP_15                   =   0x80000031,
    SW_MAIN_SHORT_LOOP_16                   =   0x80000032,
    SW_MAIN_SHORT_LOOP_17                   =   0x80000033,
    SW_MAIN_SHORT_LOOP_18                   =   0x80000034,
    SW_MAIN_SHORT_LOOP_19                   =   0x80000035,
    Halt_UartDeinit                         =   0xF0000000,
    Halt_UartInit,                          // автоматически = Halt_UartDeinit+1,
    Halt_Assert_Failed,                     // автоматически = Halt_UartInit+1,
    Halt_SMS_Reset,                         // автоматически = Halt_Assert_Failed+1,
    Halt_SaveReportToFLASH,                 // автоматически = Halt_SMS_Reset+1,
    Halt_SendReportsFromFLASH,              // автоматически = Halt_SaveReportToFLASH+1,
    Halt_Softdog_OnServerResponse,          // автоматически = Halt_SendReportsFromFLASH+1,
    Halt_Softdog_OnReturnedToMainLoop,      // автоматически = Halt_Softdog_OnServerResponse+1,
    Halt_Watchdog_Main,                     // автоматически = Halt_Softdog_OnReturnedToMainLoop+1,
    Halt_Watchdog_Server,                   // автоматически = Halt_Watchdog_Main+1,
    Halt__exit,                             // автоматически = Halt_Watchdog_Server+1,
    Halt_Tests_Main,                        // автоматически = Halt__exit+1,
    Halt_Tests_Main_GPRS,                   // автоматически = Halt_Tests_Main+1,
    Halt_EnterLowPowerMode,                 // автоматически = Halt_Tests_Main_GPRS+1,
    Halt_Jump_To_Boot,                      // автоматически = Halt_EnterLowPowerMode+1,
    Not_Halt_Normal_Work,                   // автоматически = Halt_Jump_To_Boot+1,
    Halt_Shutdown,                          // автоматически = Not_Halt_Normal_Work+1,
    Halt_Softdog_OnServerResponse_Wait,     // автоматически = Halt_Shutdown+1
} SW_State;


#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

extern volatile uint32_t back_software_position;
extern volatile uint32_t back_software_halt_position;
extern volatile uint32_t back_software_work_time;
extern volatile uint32_t back_timeline_id;

//extern UartDriver* volatile   dbg_port;

SW_State Set_Software_Position(SW_State state);
uint32_t GetSetSoftTime(systime_t time);
uint32_t GetSoftTime(void);
uint32_t GetTimelineIdTime(void);
void SetSoftTime(void);
// Выдает новый или старый идентификатор временного континиума модема
uint32_t GetTimelineId(void);
// Выдает (с измененеим) номер нового пакета сквозной нумерации
uint32_t GetPacketNumber(void);


#ifdef __cplusplus
} // extern "C" {...
#endif // __cplusplus

#endif // OLD_FW_DBG_H_INCLUDED
