/// \file
/// \brief  Описание внутреннего состояния основного модуля прошивки.
/// \author DL <dmitriy@linikov.ru>
///
///

#ifndef TELEMETRON_APPS_FW_FW_H_INCLUDED
#define TELEMETRON_APPS_FW_FW_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <nuttx/input/buttons.h>
#include <eventq/eventq.h>
#include <utils/service.h>
#include <settings/settings.h>

#include <fw/fw_config.h>
#include "fw_eventq.h"
#include "serverq.h"
#include "sender.h"

#include "modules/mod.h"
#include "modules/mod_auditd.h"
#include "modules/mod_buttons.h"
#include "modules/mod_doors.h"
#include "modules/mod_gsmd.h"
#include "modules/mod_smsd.h"
#include "modules/mod_srvd.h"
#include "modules/mod_timer.h"
#include "modules/mod_vmcd.h"
#include "modules/mod_powermon.h"
#include "modules/mod_indication.h"




////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Типы данных

typedef struct fw_s {
  service_t                 base;         ///< Наследуемся от service_t

  settings_t                settings;     ///< Менеджер настроек.
  eventq_t                  eventq;       ///< Очередь событий
  eventq_event_t            event;        ///< Последнее полученное из очереди событие
  mod_buttons_t             buttons;      ///< Обработка нажатий на кнопки
  mod_doors_t               doors;        ///< Обработка концевых датчиков дверей
  mod_auditd_t              auditd[3];    ///< Управление сервисами снятия отчётов аудита с портов AUX1...AUX3
  mod_gsmd_t                gsmd;         ///< Управление сервисом PPP связи через GSM модуль.
  mod_srvd_t                srvd;         ///< Управление сервисом связи с сервером.
  mod_smsd_t                smsd;         ///< Управление сервисом приёма sms сообщений.
  mod_vmcd_t                vmcd;         ///< Управление сервисом связи с торговым автоматом.
  mod_timer_t               timer;        ///< Периодические события таймера.
  mod_powermon_t            powermon;     ///< Проверка напряжения питания
  mod_indication_t          indication;   ///< Обнаружение событий индикации

  mod_list_t                modules;      ///< 1-связный список модулей обработки событий.

  uint32_t                  report_reading;   ///< Была нажата кнопка. Ждём отчёт. Тут битмаска портов, участвующих
  uint32_t                  report_first_btn; ///< Кнопка, которая была нажата первой
  uint32_t                  report_buttons;   ///< Перечень кнопок, нажатых, пока ждём отчёт.
  struct timespec           reports_timeout;  ///< Максимальное время ожидания отчета.
  const char*               reports_reason;   ///< Причина снятия отчёта

  struct timespec           srvd_transaction_timeout; ///< Таймаут транзакции сервера.
  struct timespec           srvd_response_timestamp;  ///< Точное время получения первого байта ответа
  struct timespec           srvd_roundtrip_duration;  ///< длительность HTTP запроса до получения первых данных
  sender_t                  sender;

  uint32_t                  srvd_fw_params_version;   ///< Версия настроек в момент начала обработки транзакции
  uint32_t                  srvd_apn_params_version;  ///< Версия настроек APN в момент начала обработки транзакции

  int                       vmc_bus;      ///< Текущее состояние шины
  // флаги состояния
  bool                      started:1;
  bool                      is_power_ok:1;
  bool                      is_audit_pending:1;
  bool                      srvd_transaction_in_progress:1;
  bool                      srvd_settings_confirm_pending:1;
  bool                      srvd_settings_error:1;
  bool                      srvd_server_requested_settings:1;
  bool                      srvd_have_roundrtip_duration:1;   ///< Текущая транзакция имеен информацию о длительности запроса

} fw_t;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

fw_t* fw_find_instance(void);
int fw_create_instance(FAR fw_t** dst);
int fw_start_audit_report(fw_t* fw, const char* reason);
// Данные функции находятся в файле fw_on_ev_srvd_command.c
void fw_on_ev_srvd_transaction_start(FAR fw_t* fw, FAR eventq_event_t* event);
void fw_on_ev_srvd_transaction_end(FAR fw_t* fw, FAR eventq_event_t* event);
void fw_check_srvd_transaction_timeout(FAR fw_t* fw, FAR eventq_event_t* event);
void fw_on_ev_srvd_command(FAR fw_t* fw, FAR eventq_event_t* event);

#ifdef __cplusplus
} // extern "C"
#endif

////////////////////////////////////////////////////////////////////////////
//  Определение inline функций

static inline int fw_start(fw_t* fw)
{
  return service_start((service_t*)fw);
}

static inline int fw_kill(fw_t* fw)
{
  return service_kill((service_t*)fw);
}

static inline int fw_wait_terminated(fw_t* fw, int timeout_ms)
{
  return service_wait_terminated((service_t*)fw, timeout_ms);
}

static inline int fw_kill_and_wait(fw_t* fw, int timeout_ms)
{
  return service_kill_and_wait((service_t*)fw, timeout_ms);
}

static inline bool fw_is_started(fw_t* fw)
{
  return service_is_started((service_t*)fw);
}

static inline bool fw_is_alive(fw_t* fw)
{
  return service_is_alive((service_t*)fw);
}

static inline int fw_lock(fw_t* fw)
{
  return service_lock((service_t*)fw);
}

static inline void fw_force_lock(fw_t* fw)
{
  return service_force_lock((service_t*)fw);
}

static inline int fw_lock_timeout(fw_t* fw, int timeout_ms)
{
  return service_lock_timeout((service_t*)fw, timeout_ms);
}

static inline int fw_unlock(fw_t* fw)
{
  return service_unlock((service_t*)fw);
}

static inline bool fw_should_stop(fw_t* fw)
{
  return service_should_stop((service_t*)fw);
}

static inline int fw_wdog_restart(fw_t* fw, uint32_t timeout_ms)
{
  return service_wdog_restart((service_t*)fw, timeout_ms);
}

static inline int fw_wdog_cancel(fw_t* fw)
{
  return service_wdog_cancel((service_t*)fw);
}


#endif // TELEMETRON_APPS_FW_FW_H_INCLUDED
