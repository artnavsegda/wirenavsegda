/// \file
/// \brief  Работа с очередью сообщений на сервер
/// \author DL <dmitriy@linikov.ru>

#ifndef TELEMETRON_APPS_FW_FW_SERVERQ_H_INCLUDED
#define TELEMETRON_APPS_FW_FW_SERVERQ_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <filequeue/filequeue.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Типы данных

#define SERVERQ_PRIORITIES      2

typedef enum serverq_prio_s {
  SERVERQ_PRIO_LOW  = 0,
  SERVERQ_PRIO_HIGH = 1
} serverq_prio_t;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

int serverq_create(void);
int serverq_lock(void);
int serverq_lock_timeout(int32_t timeout_ms);
int serverq_unlock(void);
int serverq_push_new(serverq_prio_t priority, fq_id_t* created_id);
int serverq_push_or_replace_id(fq_id_t msg_id);
int serverq_push_existing(serverq_prio_t priority, const char* existing, fq_id_t* created_id);
int serverq_unlink(fq_id_t msg_id);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // TELEMETRON_APPS_FW_FW_SERVERQ_H_INCLUDED
