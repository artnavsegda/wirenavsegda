/// \file
/// \author DL <dmitriy.linikov@gmail.com>
/// \see version.h

#include "version.h"

#define FW_VERSION              "3.27"

static const char version[] = FW_VERSION;

const char* VersionGet(void)
{
  return version;
}
