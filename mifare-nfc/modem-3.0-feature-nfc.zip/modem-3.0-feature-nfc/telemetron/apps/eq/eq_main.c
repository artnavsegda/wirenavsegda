/// \file
/// \brief  Утилита работы с очередью сообщений
/// \author DL <dmitriy@linikov.ru>

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <nuttx/config.h>

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <syslog.h>
#include <string.h>
#include <unistd.h>

#include <eventq/eventq.h>

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных
typedef struct name2fxn_s {
  const char*     name;
  int             (*fxn)(int argc, char* argv[]);
} name2fxn_t;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций
static int eq_create(int argc, char* argv[]);
static int eq_state(int argc, char* argv[]);
static int eq_read(int argc, char* argv[]);
static int eq_write(int argc, char* argv[]);
static int eq_dump(int argc, char* argv[]);

////////////////////////////////////////////////////////////////////////////
//  Константы
static const name2fxn_t SUPPORTED_FUNCTIONS[] = {
  { .name = "--create", .fxn = eq_create },
  { .name = "--state",  .fxn = eq_state },
  { .name = "--read",   .fxn = eq_read },
  { .name = "--write",  .fxn = eq_write },
  { .name = "--dump",   .fxn = eq_dump },
};

////////////////////////////////////////////////////////////////////////////
//  Приватные функции

static int eq_print_usage(void)
{
  const char* text =
    "\n"
    "eq - Tool for controlling event queues, supported by lib_eventq\n"
    "Usage:\n"
    "   eq --create /queue_name        - Creates new queue\n"
    "   eq --state /queue_name         - prints info about free/used space\n"
    "   eq --read /queue_name          - reads one message from queue\n"
    "   eq --dump /queue_name          - reads forever and prints to syslog\n"
    "   eq --write /queue_name <msgid> \"some text message\" - writes msg\n"
    "\n"
    "Note, that `/queue_name` is not a path. It is the name of the queue.\n"
    "This name should begin with '/'.\n"
    "\n\n";
  printf(text);
  return -1;
}


static int eq_create(int argc, char* argv[])
{
  if (argc < 2) {
    return eq_print_usage();
  }
  const char* queue_name  = argv[1];
  eventq_t    queue;
  int         ret = eventq_open(&queue, queue_name, O_RDWR | O_CREAT);
  if (ret < 0) {
    fprintf(stderr, "ERROR: Can't open '%s', err=%d (%s)\n",
      queue_name, ret, strerror(-ret)
    );
    return ret;
  }

  printf("Queue '%s' is ready\n", queue_name);

  eventq_close(&queue);
  return ret;
}

static int eq_state(int argc, char* argv[])
{
  if (argc < 2) {
    return eq_print_usage();
  }
  const char* queue_name  = argv[1];
  eventq_t    queue;
  int         ret = eventq_open(&queue, queue_name, O_RDONLY);
  if (ret < 0) {
    fprintf(stderr, "ERROR: Can't open '%s', err=%d (%s)\n", ret, strerror(-ret));
    return ret;
  }

  int capacity      = eventq_get_capacity(&queue);
  int unread_count  = eventq_get_unread_count(&queue);
  int free_count    = eventq_get_free_count(&queue);

  if (capacity >= 0 && unread_count >= 0 && free_count >= 0) {
    printf("unread: %3d, free: %3d, total: %3d\n",
      unread_count, free_count, capacity
    );
    ret = 0;
  } else {
    fprintf(stderr, "ERROR: Can't get stats.\n");
    ret = -1;
  }

  eventq_close(&queue);
  return ret;
}

static void eq_dump_event(const eventq_event_t* event, bool to_stdout)
{
  struct tm   t;
  char        datetime[24];
  localtime_r(&event->time.tv_sec, &t);
  strftime(datetime, sizeof(datetime), "%Y-%m-%d,%H:%M:%S", &t);

  if (to_stdout) {
    printf("event: { id: %d, size:%u, time: %s.%03d, data: \"",
      event->id, event->size, datetime, event->time.tv_nsec/1000000
    );
    for (size_t i=0; i < event->size; ++i) {
      fputc(event->data[i], stdout);
    }
    printf("\" }\n");
  } else {
    _info("event: { id: %d, size:%u, time: %s.%03d }\n",
      event->id, event->size, datetime, event->time.tv_nsec/1000000
    );
    infodumpbuffer("event.data", event->data, event->size);
  }

}

static int eq_read(int argc, char* argv[])
{
  if (argc < 2) {
    return eq_print_usage();
  }
  const char*     queue_name  = argv[1];
  eventq_t        queue;
  eventq_event_t  event;
  int             ret = eventq_open(&queue, queue_name, O_RDONLY);
  if (ret < 0) {
    fprintf(stderr, "ERROR: Can't open '%s', err=%d (%s)\n", ret, strerror(-ret));
    return ret;
  }

  ret = eventq_read(&queue, &event);
  if (ret == -EAGAIN) {
    printf("Empty\n");
    ret = 0;
    goto cleanup;
  }

  if (ret < 0) {
    fprintf(stderr, "ERROR: Read failed, err=%d (%s)\n", ret, strerror(-ret));
    goto cleanup;
  }

  eq_dump_event(&event, true);
  ret = 0;

cleanup:
  eventq_close(&queue);
  return ret;
}



static int eq_write(int argc, char* argv[])
{
  if (argc < 4) {
    return eq_print_usage();
  }
  const char*     queue_name  = argv[1];
  int             msg_id = atoi(argv[2]);
  const char*     msg_text = argv[3];
  size_t          msg_size = strlen(msg_text)+1;

  eventq_t        queue;
  int             ret = eventq_open(&queue, queue_name, O_WRONLY);
  if (ret < 0) {
    fprintf(stderr, "ERROR: Can't open '%s', err=%d (%s)\n", ret, strerror(-ret));
    return ret;
  }


  ret = eventq_write(&queue, msg_id, msg_text, msg_size);
  if (ret == -EAGAIN) {
    fprintf(stderr, "ERROR: Queue is full\n");
    ret = -1;
    goto cleanup;
  }

  if (ret < 0) {
    fprintf(stderr, "ERROR: Read failed, err=%d (%s)\n", ret, strerror(-ret));
    goto cleanup;
  }

  printf("Write Ok.\n");
  ret = 0;

cleanup:
  eventq_close(&queue);
  return ret;
}


static int eq_dump(int argc, char* argv[])
{
  if (argc < 2) {
    return eq_print_usage();
  }
  const char*     queue_name  = argv[1];
  eventq_t        queue;
  eventq_event_t  event;
  int             ret = eventq_open(&queue, queue_name, O_RDONLY);
  if (ret < 0) {
    fprintf(stderr, "ERROR: Can't open '%s', err=%d (%s)\n", ret, strerror(-ret));
    return ret;
  }

  printf("Started dumping queue '%s'...\n", queue_name);

  while (ret >= 0) {
    ret = eventq_read_timeout(&queue, &event, -1);
    if (ret >= 0) {
      eq_dump_event(&event, false);
    }
  }

  printf("Ended dumping queue '%s'.\n\n", queue_name);

  eventq_close(&queue);
  return ret;
}



////////////////////////////////////////////////////////////////////////////
//  eq_main

#ifdef CONFIG_BUILD_KERNEL
int main(int argc, FAR char *argv[])
#else
int eq_main(int argc, char *argv[])
#endif
{
  if (argc < 2) {
    return eq_print_usage();
  }

  for (size_t i=0; i < sizeof(SUPPORTED_FUNCTIONS)/sizeof(*SUPPORTED_FUNCTIONS); ++i) {
    const name2fxn_t* entry = &SUPPORTED_FUNCTIONS[i];
    if (strcmp(entry->name, argv[1]) == 0 && entry->fxn) {
      return entry->fxn(argc-1, &argv[1]);
    }
  }

  printf("ERROR: Unknown argument '%s'\n", argv[1]);
  return 0;
}
