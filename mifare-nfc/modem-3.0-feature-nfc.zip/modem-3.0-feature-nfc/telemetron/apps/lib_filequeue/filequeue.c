/// \file
/// \brief  Файл, содержащий реализацию модуля filequeue - очереди сообщений,
///         построенной на основе файловой системы.
/// \author DL <dmitriy@linikov.ru>

/****************************************************************************
 * Included Files
 ****************************************************************************/

#include <filequeue/filequeue.h>

#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include <fcntl.h>
#include <semaphore.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/statfs.h>
#include <dirent.h>
#include <unistd.h>

#include <sysutils/crc.h>
#include <utils/dbg.h>
#include <utils/posix_iohelper.h>
#include <utils/time_utils.h>
#include <utils/array_repeat_initializer.h>


/****************************************************************************
 * Pre-processor Definitions
 ****************************************************************************/

#if !defined(CONFIG_LIB_FILEQUEUE_MAX_FILENAME) || defined(__DOXYGEN__)
/// \brief Максимальная длина имени файла, используемая модулем filequeue
///
/// Предполагается, что файловая очередь использует хранилище в /var.
/// Тогда пример имени файла:
///   /var/some_queue/F/F012345
///            1         2         3
///   12345678901234567890123456789012
///
/// Если примем максимальный размер имени файла равным 31 символу,
/// то на имя самой директории останется до 16 символов.
///
/// При необходимости, данный параметр можно добавить в Kconfig,
/// но для текущих задач это не нужно.
# define  CONFIG_LIB_FILEQUEUE_MAX_FILENAME  31
#endif // CONFIG_LIB_FILEQUEUE_MAX_FILENAME



#if !defined(CONFIG_LIB_FILEQUEUE_BASE_DIR) || defined(__DOXYGEN__)
/// \brief Директория, где хранятся все очереди сообщений данного типа.
///
/// \warning Предполагается, что это всегда будет директория /var, или
/// любая другая, смонтированная в оперативной памяти, длина пути к которой
/// не превышает 4 символов. В противном случае нужно будет пересмотреть
/// значение константы \ref CONFIG_LIB_FILEQUEUE_MAX_FILENAME и, возможно, других.
# define CONFIG_LIB_FILEQUEUE_BASE_DIR      "/var"
#endif // CONFIG_LIB_FILEQUEUE_BASE_DIR


#ifndef OK
# define OK 0
#endif


/// \brief Размер буффера для хранения имени любого файла из очереди.
#define FQ_PATH_BUFFER_SIZE             (CONFIG_LIB_FILEQUEUE_MAX_FILENAME+1)


#define FQ_FILE_SETTINGS                "cfg"
#define FQ_FILE_LASTID                  "lastid"
#define FQ_SEM_LOCK                     ""
#define FQ_SEM_COUNTER                  "_cnt"

#ifndef OK
# define OK 0
#endif


/// \brief Буффер под имя файла, обёрнутый в структуру
///
/// Это нужно для укорочения записи и для уменьшения вероятности ошибок
/// работы со строковыми буфферами.
typedef struct fq_path_s {
  char    value[FQ_PATH_BUFFER_SIZE];
} fq_path_t;


/// \brief  Тип функции, вызываемой функцией fq_walk для каждого найденного файла
/// \note   Порядок файлов не гарантирован. Гарантируется лишь то, что
///         файлы с высоким приоритетом будут обработаны раньше, чем файлы
///         с низким приоритетом. Однако очерёдность файлов с одинаковым
///         приоритетом не гарантируется.
///
/// Если данная функция вернёт отличное от нуля значение, то проход завершится.
typedef int (*fq_walk_fxn_t)(uintptr_t arg, fq_id_t msg_id);


/// \brief Константа пустой строки для модуля filequeue.
///
/// Нужно для того, что бы можно было сравнивать указатели, а не значения.
static const char FQ_EMPTY_STRING[1] = { '\x00' };



/// \brief Стандартные настройки
static const fq_settings_t  FQ_DEFAULTS = {
  .priority_count         = CONFIG_LIB_FILEQUEUE_DEF_PRIORITY_COUNT,
  .flags                  = 0,
  .max_files_per_priority = ARRAY_REPEAT_INITIALIZER(
                              CONFIG_LIB_FILEQUEUE_MAX_PRIORITY_COUNT,
                              CONFIG_LIB_FILEQUEUE_DEF_FILES_PER_PRIORITY
                            ),
  .crc                    = 0 // не вычисляем, нужен только в файле.
};

/****************************************************************************
* Private Functions
****************************************************************************/
static int fq_msgid_priority(fq_id_t msg_id)
{
  return (msg_id  & 0x0F000000) >> 24;
}

static int fq_msgid_sequence(fq_id_t msg_id)
{
  return msg_id & 0x00FFFFFF;
}

static int fq_msgid_fullid(fq_id_t msg_id)
{
  // Возможно, в дальнейшем в fq_id_t могут оказаться ещё и какие-либо
  // флаги.
  return msg_id & 0x0FFFFFFF;
}

static fq_id_t fq_msgid_create(int priority, int sequence)
{
  return  ((priority & 0x0F) << 24)
        | (sequence & 0x00FFFFFFFF);
}


static void fq_error_filename(const char* err_text, const char* file_name, int err_code)
{
  fq_debug("PID%d %s '%s', err=%d (%s)\n", getpid(), err_text, file_name, err_code, strerror(err_code));
}



/// \brief Формирует полный путь директории с очередью сообщений.
static fq_path_t fq_dir_path(const char* queue_name)
{
  fq_path_t path;
  int path_length
    = snprintf(path.value, sizeof(path.value),
        "%s%s", CONFIG_LIB_FILEQUEUE_BASE_DIR, queue_name
      );
  dbg_assert(path_length < sizeof(path.value), "FQ: path overflow");
  return path;
}



/// \brief Формирует имя управляющего файла (например, `/var/queue1/lastid`)
static fq_path_t fq_control_path(const char* queue_name, const char* file_name)
{
  fq_path_t path;
  int path_length
    = snprintf(path.value, sizeof(path.value),
        "%s%s/%s", CONFIG_LIB_FILEQUEUE_BASE_DIR, queue_name, file_name
      );


  dbg_assert(path_length < sizeof(path.value), "FQ: path overflow");
  return path;
}



/// \brief  Полный путь директории с приоритетом \p priority, через ссылки.
/// \note   Это основной способ доступа к файлам.
static fq_path_t fq_data_dir_path(const char* queue_name, int priority)
{
  // Создаёт имя вида `/имяочереди_X`,
  // где X - шестнадцатеричное значение приоритета
  //
  // т.е. доступ к директориям с файлами реализуется через ссылки в
  // корневой директории. Ссылки находятся в корневой директории, а не
  // внутри папки с очередью из-за того, что NuttX позволяет создавать ссылки
  // только в корневой директории.
  fq_path_t path;
  int path_length
    = snprintf(path.value, sizeof(path.value),
        "%s_%1X", queue_name, priority
      );
  dbg_assert(path_length < sizeof(path.value), "FQ: path overflow");
  return path;
}



/// \brief  Полный путь директории с приоритетом \p priority, внутри папки очереди.
/// \note   Данная функция используется при создании и удалении очереди.
static fq_path_t fq_data_dir_raw_path(const char* queue_name, int priority)
{
  fq_path_t path;
  int path_length
    = snprintf(path.value, sizeof(path.value),
        "%s%s/%1X", CONFIG_LIB_FILEQUEUE_BASE_DIR, queue_name, priority
      );
  dbg_assert(path_length < sizeof(path.value), "FQ: path overflow");
  return path;
}


/// \brief Формирует имя файла данных (например, `/var/queue1/F/F123456`).
static fq_path_t fq_data_file_path(const char* queue_name, fq_id_t msg_id)
{
  // Создаёт имя вида `/имяочереди_X/123456`,
  // где X      - шестнадцатеричное значение приоритета,
  //     123456 - шестнадцатеричное число, порядковый номер файла.
  //
  // т.о. доступ к директориям с файлами реализуется через ссылки в
  // корневой директории. Ссылки находятся в корневой директории, а не
  // внутри папки с очередью из-за того, что NuttX позволяет создавать ссылки
  // только в корневой директории.

  fq_path_t path;
  int path_length
    = snprintf( path.value, sizeof(path.value),
        "%s_%1X/%07X",
        queue_name,
        fq_msgid_priority(msg_id),
        fq_msgid_fullid(msg_id)
      );
  dbg_assert(path_length < sizeof(path.value), "FQ: path overflow");
  return path;
}



/// \brief Формирует имя семафора
static fq_path_t fq_sem_path(const char *queue_name, const char *sem_suffix)
{
  fq_path_t path;
  int path_length
    = snprintf(path.value, sizeof(path.value),
        "%s%s", queue_name, sem_suffix
      );
  dbg_assert(path_length < sizeof(path.value), "FQ: path overflow");
  return path;
}



/// \brief Читает содержимое управляющего файла в буффер.
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \param  name          Имя управляющего файла
/// \param  dst           Указатель на буффер
/// \param  size          Сколько байт следует проичтать.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
static int fq_read_control_file(
  const char* queue_name, const char* name, void* dst, size_t size
)
{
  dbg_assert(queue_name != NULL, "FQ: queue name NULL");
  dbg_assert(name != NULL, "FQ: ctl name NULL");
  dbg_assert(dst && size, "FQ: rd ctl: no buffer");

  fq_path_t path = fq_control_path(queue_name, name);
  if (!ReadHelper(path.value, dst, size)) {
    fq_error_filename("Can't read from", path.value, errno);
    return -errno;
  }
  return OK;
}



static int fq_write_control_file(
  const char* queue_name, const char* name, const void* src, size_t size
)
{
  dbg_assert(queue_name != NULL, "FQ: queue name NULL");
  dbg_assert(name != NULL, "FQ: ctl name NULL");
  dbg_assert(src && size, "FQ: rd ctl: no buffer");

  fq_path_t path = fq_control_path(queue_name, name);
  if (!WriteHelper(path.value, src, size)) {
    fq_error_filename("Can't write to", path.value, errno);
    return -errno;
  }
  return OK;
}



/// \brief  Возвращает полный id последнего добавленного в очередь файла.
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \return В случае успеха возвращает полный id последнего добавленного
/// в очередь файла, или отрицательный код ошибки.
fq_id_t fq_read_lastid(const char* queue_name)
{
  int32_t   lastid  = 0;
  int       ret     = fq_read_control_file(queue_name, FQ_FILE_LASTID, &lastid, sizeof(lastid));

  if (ret != OK) {
    return ret;
  }
  return lastid;
}



/// \brief  Сохраняет полный id последнего добавленного в очередь файла.
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \param  msg_id        Полный id последнего добавленного в очередь файла.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int fq_write_lastid(const char* queue_name, fq_id_t lastid)
{
  return fq_write_control_file(queue_name, FQ_FILE_LASTID, &lastid, sizeof(lastid));
}



/// \brief  Читает настройки очереди сообщений.
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \param  dst           Указатель на переменную, в которую следует поместить
///                       прочитанные настройки
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int fq_read_settings(const char* queue_name, fq_settings_t* dst)
{
  int ret = fq_read_control_file(queue_name, FQ_FILE_SETTINGS, dst, sizeof(*dst));
  if (ret != OK) {
    return ret;
  }
  uint16_t crc = crc16_calc_block(0, dst, offsetof(fq_settings_t, crc));
  if (crc != dst->crc) {
    return -EILSEQ;
  }
  return OK;
}



/// \brief Вычисляет CRC и записывает настройки очереди сообщений.
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \param  src           Указатель на переменную с настройками.
///                       В данной переменной будет обновлена контрольная сумма,
///                       и затем значение будет записано в файл.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int fq_write_settings(const char* queue_name, fq_settings_t* src)
{
  src->crc = crc16_calc_block(0, src, offsetof(fq_settings_t, crc));
  return fq_write_control_file(queue_name, FQ_FILE_SETTINGS, src, sizeof(*src));
}



/// \brief Записывает в path путь к файлу и его имя name.
/// \return Указатель на начало непосредственно имени файла в буффере
static char* mk_path_get_name(char* path, size_t size, const char* dir_path, const char* name)
{
  size_t dir_path_len = strlen(dir_path);

  dbg_assert(dir_path_len + 1 < size, "path buffer overflow");

  // Копируем путь в буффер
  memcpy(path, dir_path, dir_path_len);
  // Удостоверяемся, что путь заканчивается на '/'
  if (path[dir_path_len-1] != '/') {
    // Если не так, то добавляем и передвигаем указатель на начало имени файла.
    path[dir_path_len]   = '/';
    ++dir_path_len;
  }

  path[dir_path_len] = '\0';

  if (name) {
    size_t name_len = strlen(name);
    dbg_assert(dir_path_len + name_len < size, "path buffer overflow");

    // Копируем имя вместе с его завершающим нулём
    memcpy(&path[dir_path_len], name, name_len + 1);
  }

  return &path[dir_path_len];
}


static int fq_walk_dir(const char* dir_path, fq_walk_fxn_t callback, uintptr_t arg)
{
  fq_trace("Walk('%s')\n", dir_path);
  int     ret = OK;
  DIR*    dir = opendir(dir_path);
  if (!dir) {
    ret = -errno;
    if (errno == ENOENT) {
      // Отсутствует директория приоритета с файлами.
      // Это подозрительно, но, обычно, не является ошибкой.
      return OK;
    }

    fq_error_filename("Can't open dir", dir_path, errno);
    return ret;
  }

  fq_path_t path;
  char*     name = mk_path_get_name(path.value, sizeof(path.value), dir_path, NULL);
  char*     endname = path.value + sizeof(path.value);

  struct dirent* entry;
  while((entry = readdir(dir)) != NULL) {
    size_t name_len = strlen(entry->d_name);
    if (name + name_len >= endname) {
      // Будет переполнение буффера пути файла.
      // пропуск такого файла.
      fq_debug("Walk:Too long filename '%s/%s'\n", dir_path, entry->d_name);
      continue;
    }

    // Копируем имя вместе с завершающим нулём.
    memcpy(name, entry->d_name, name_len+1);

    // читаем информацию о файле/директории/и т.д.
    struct stat   info;
    if (stat(path.value, &info) < 0) {
      fq_debug("Can't get file stat for '%s', err=%d (%s)\n", path, errno, strerror(errno));
      // С этим файлом не получилось, переходим к следующему
      continue;
    }

    struct tm     timeinfo;
    localtime_r(&info.st_mtime, &timeinfo);

    char          timestamp[20];
    strftime(timestamp, sizeof(timestamp), "%Y-%m-%d,%H:%M:%S", &timeinfo);

    fq_trace("Walk:Found '%s': st_mode=%08X st_size=%d st_blksize=%d st_blocks=%d st_mtime=%s\n",
              name, info.st_mode, info.st_size, info.st_blksize, info.st_blocks, timestamp);


    // Разбор и валидация имени файла
    if (name_len != 7) {
      fq_trace("Walk:bad filename '%s'\n", name);
      continue;
    }

    bool name_ok = true;
    for (int i=0; i < 7 && name_ok; ++i) {
      if (!isxdigit(name[i])) {
        name_ok = false;
      }
    }

    if (!name_ok) {
      fq_trace("Walk:bad filename '%s'\n", name);
      continue;
    }


    if (!callback) {
      // Если callback не задан, то ограничимся ранее выведенной в лог информацией о файле
      // и перейдём к следующему
      continue;
    }

    fq_id_t msg_id = (fq_id_t)strtol(name, NULL, 16);
    ret = callback(arg, msg_id);
    if (ret != OK) {
      // Успешное завершение функции.
      goto cleanup;
    }
  }


cleanup:
  if (dir) {
    closedir(dir);
  }
  return ret;
}


/// \brief Перебирает имена всех файлов в очереди и для каждого вызывает callback
int fq_walk(const char* queue_name, fq_walk_fxn_t callback, uintptr_t arg)
{
  int             ret;
  fq_settings_t   settings;

  ret = fq_read_settings(queue_name, &settings);
  if (ret != OK) {
    return ret;
  }

  for (int priority = 0; priority < settings.priority_count; ++priority)
  {
    fq_path_t path = fq_data_dir_path(queue_name, priority);
    ret = fq_walk_dir(path.value, callback, arg);
    if (ret != OK) {
      // Произошла ошибка или закончен поиск.
      return ret;
    }
  }

  // Не было раннего завершения работы функции. Завершилось без ошибок.
  return OK;
}



typedef struct walker_make_room_state_s {
  // Входные параметры
  const fq_settings_t*  settings;   ///< Настройки очереди
  fq_id_t               new_id;     ///< id добавляемого сообщения

  // Состояние поиска
  fq_id_t               found_id;   ///< id самого старого файла в очереди
  size_t                msg_count;  ///< Количество файлов в директории
} walker_make_room_state_t;

static int walker_make_room(uintptr_t arg, fq_id_t msg_id)
{
  walker_make_room_state_t* state = (walker_make_room_state_t*)arg;

  // Для каждого обработанного файла увеличиваем счётчик сообщений
  state->msg_count += 1;

  // Если нашли файл с тем же id, что и добавляемый файл,
  // то заканчиваем поиск.
  if (msg_id == state->new_id) {
    state->found_id = msg_id;
    // Возвращаем ненулевое число, что бы завершить поиск.
    return msg_id;
  }

  // В остальных случаях ищем файл с минимальным id, т.е. самый старый

  // Если обрабатываем первый файл, то принимаем его в качестве опорного,
  // с которого начнётся сравнение.
  if (state->found_id <= 0) {
    state->found_id = msg_id;
    return OK;
  }

  // Ищем файл с минимальным номером.
  // Поскольку проверяем только одну директорию приоритета,
  // то можно сравнивать сырые значения msg_id между собой,
  // т.к. они имеют один и тот же приоритет.
  if (msg_id < state->found_id) {
    state->found_id = msg_id;
    return OK;
  }

  return OK;
}

/// \brief  Проверяет количество файлов в целевой директории и очищает место под новый файл и увеличивает семафор.
/// \note   Если файл с идентификатором \p new_id уже есть, то именно он и будет удалён.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int fq_make_room(const char* queue_name, const fq_settings_t* settings, fq_id_t new_id)
{
  // Сканирование директории с соответствующим для new_id приоритетом.
  walker_make_room_state_t state = {
    .settings = settings,
    .new_id   = new_id,
    .found_id = -1
  };

  fq_path_t path = fq_data_dir_path(queue_name, fq_msgid_priority(new_id));
  int ret = fq_walk_dir(path.value, walker_make_room, (uintptr_t)&state);
  if (ret < 0) {
    fq_error_filename("Can't walk dir", path.value, -ret);
    return ret;
  }

  // Если в директории найден файл с тем же id, что и добавляемый,
  // то удаляем добавляемый файл и не изменяем счётчик, т.к. общее количество
  // файлов останится прежним.
  if (state.found_id == new_id) {
    path = fq_data_file_path(queue_name, new_id);
    ret = unlink(path.value);
    if (ret < 0) {
      fq_error_filename("Can't unlink", path.value, -ret);
    }
    return ret;
  }

  int priority = fq_msgid_priority(new_id);

  // Если для данного приоритета нет ограничения по количеству файлов
  // или ещё не достигнуто это ограничение, то место для нового файла есть.
  // Просто увеличиваем счётчик сообщений и выходим.
  if (!settings->max_files_per_priority[priority]
      || state.msg_count < settings->max_files_per_priority[priority]
  ) {
    ret = fq_counter_increment(queue_name);
    return ret;
  }

  // Если для данного приоритета установлено ограничение по количеству файлов,
  // и достигнут предел, то удаляем самый старый файл и не изменяем счётчик,
  // т.к. в результате общее количество файлов останется прежним.
  path = fq_data_file_path(queue_name, state.found_id);
  ret = unlink(path.value);
  if (ret < 0) {
    fq_error_filename("Can't unlink", path.value, -ret);
    return ret;
  }

  return OK;
}



/// \brief  Создаёт идентификатор для нового сообщения с приоритетом \p priority.
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \param  priority      Приоритет нового сообщения.
/// \param  dst           Опциональный указатель на переменную, в которую следует
///                       сохранить созданный идентификатор в случае успешного
///                       выполнения данной функции. При ошибке данная переменная
///                       остаётся без изменений.
/// \return неотрицательный идентификатор сообщения или отрицательный код ошибки.
fq_id_t fq_allocate_msgid(const char* queue_name, int priority, fq_id_t* dst)
{
  fq_id_t   msg_id = fq_read_lastid(queue_name);
  if (msg_id < 0) {
    return msg_id;
  }

  msg_id = fq_msgid_create(priority, fq_msgid_sequence(msg_id) + 1);

  if (dst) {
    *dst = msg_id;
  }

  return msg_id;
}

/****************************************************************************
 * Public Functions
 ****************************************************************************/

/// \brief  Создаёт очередь сообщений в директории \p queue_name.
///
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \param  settings      Настройки очереди сообщений.
///                       Если NULL, то используются стандартные настройки.
///
/// Если директория не существует, то она будет создана. Так же в директории
/// будут созданы счётчик сообщений, мьютекс (или семафор) для блокировки
/// доступа к директории и файл с настройками.
///
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int fq_create(const char* queue_name, const fq_settings_t* settings)
{
  return fq_create_ex(queue_name, settings, NULL);
}



/// \brief структура, хранящая состояние прохода по очереди при её создании.
typedef struct walker_create_state_s {
  const fq_settings_t*  settings;   ///< Настройки очереди
  sem_t*                sem;        ///< Семафор, считающий сообщения
  size_t                count;      ///< Количество найденных сообщений
  fq_id_t               min_id;     ///< id сообщения с минимальным seq номером
  fq_id_t               max_id;     ///< id сообщения с максимальным seq номером
  int                   min_seq;    ///< Минимальное значение seq номера
  int                   max_seq;    ///< Максимальное значение seq номера
} walker_create_state_t;

/// \brief Обработчик каждого найденного при создании очереди файла.
static int walker_create(uintptr_t arg, fq_id_t msg_id)
{
  walker_create_state_t* state = (walker_create_state_t*)arg;

  int msg_sequence = fq_msgid_sequence(msg_id);

  if (msg_sequence < state->min_seq) {
    state->min_seq = msg_sequence;
    state->min_id  = msg_id;
  }

  if (msg_sequence > state->max_seq) {
    state->max_seq = msg_sequence;
    state->max_id  = msg_id;
  }

  ++state->count;
  int ret = sem_post(state->sem);
  if (ret < 0) {
    ret = -errno;
    fq_trace("Can't post counter sem, err=%d (%s)\n", errno, strerror(errno));
    // Если не удалось увеличить семафор хоть однажды,
    // то следует прекратить работу, т.к. инициализация очереди не удалась.
    return ret;
  }

  return OK;
}

/// \brief  Создаёт очередь сообщений в директории \p queue_name.
///
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \param  settings      Настройки очереди сообщений.
///                       Если NULL, то используются стандартные настройки.
/// \param  dir_links     Массив c-строк с путями к хранилищам сообщений
///                       с соответствующими номерами приоритетов.
///                       Если для соответствующего приоритета путь
///                       к хранилищу не задан (NULL), то для хранения
///                       сообщений будет создана поддиректория
///                       в папке с очередью.
///                       Если сам параметр dir_links равен NULL,
///                       то данная функция эквивалентна \see fq_create.
///
/// Данный вариант создания очереди отличается от \see fq_create тем,
/// что в дополнение к основным настройкам, данная функция позволяет
/// создать не сами директории, а символьные ссылки на директории.
/// Это позволяет хранить часть сообщений на другом физическом носителе.
///
/// Например, используя данный подход можно сделать так, что бы
/// сообщения с низким приоритетом хранились во внешней flash памяти,
/// в то время как сама очередь и высокоприоритетные сообщения
/// хранились бы в оперативной памяти (tmpfs).
///
///
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int fq_create_ex(
  const char*           queue_name,
  const fq_settings_t*  settings,
  const char* const     dir_links[]
)
{
  int           ret;
  bool          has_symlinks;
  fq_id_t       msg_id;
  fq_settings_t mutable_settings; // изменяемый буффер, для вычисления crc
  struct stat   s;
  fq_path_t     path;

  // Проверка параметров.
  if (!queue_name) {
    fq_debug("queue_name NULL\n");
    return -EINVAL;
  }

  if (queue_name[0] != '/') {
    fq_debug("bad queue_name '%s'\n", queue_name);
    return -EINVAL;
  }

  if (!settings) {
    // Если настройки не заданы, то используем стандартные
    settings = &FQ_DEFAULTS;
  }

  // Проверяем настройки (даже если стандартные).
  // На текущий момент проверяем только, что заданное количество приоритетов
  // не превышает максимальное.
  if (settings->priority_count > CONFIG_LIB_FILEQUEUE_MAX_PRIORITY_COUNT
  ||  settings->priority_count <= 0
  ) {
    fq_debug("bad cfg.priority_count %d\n", settings->priority_count);
    return -EINVAL;
  }


  // Проверка, что в файловой системе ещё нет такой очереди
  path = fq_dir_path(queue_name);
  if (stat(path.value, &s) == OK) {
    fq_warn("Can't create, '%s' already exist\n", path.value);
    return -EEXIST;
  }

  // Создание директории очереди.
  ret = mkdir(path.value, DEFFILEMODE);
  if (ret < 0) {
    ret = -errno;
    fq_error_filename("Can't create dir", path.value, errno);
    return ret;
  }

  // Создание директорий для каждого из приоритетов в папке с очередью
  // и ссылок на них в корневой файловой системе.
  // Это необходимо, что бы обойти ограничение NuttX, разрешающее создавать
  // файловые ссылки только в корневой директории.
  for (int priority=0; priority < settings->priority_count; ++priority) {
    fq_path_t   internal_dir;
    const char* link_target;

    path          = fq_data_dir_path(queue_name, priority);
    if (!dir_links || !dir_links[priority]) {
      // Если для текущего приоритета не задано внешнего хранилища,
      // то для него необходимо создать папку внутри директории с очередью.
      internal_dir  = fq_data_dir_raw_path(queue_name, priority);
      link_target = internal_dir.value;
      ret = mkdir(link_target, DEFFILEMODE);
      if (ret < 0) {
        ret = -errno;
        fq_error_filename("Can't create dir", link_target, errno);
        goto cleanup_with_dirs;
      }
    } else {
      link_target = dir_links[priority];
      has_symlinks = true;
    }

    // Создаем ссылки на директории приоритетов с файлами.
    ret = link(link_target, path.value);
    if (ret < 0) {
      ret = -errno;
      fq_error_filename("Can't create link", path.value, errno);
      goto cleanup_with_dirs;
    }
  } // for (int priority ...)

  // Создание семафоров:
  //    - семафор блокировки директории, изначально заблокированный
  ret = NamedSemCreate(queue_name, 0, false);
  if (ret < 0) {
    goto cleanup_with_dirs;
  }

  //    - семафор, считающий сообщения в очереди.
  path = fq_sem_path(queue_name, FQ_SEM_COUNTER);
  ret = NamedSemCreate(path.value, 0, false);
  if (ret < 0) {
    goto cleanup_with_sems;
  }

  // Создание файла с настройками
  mutable_settings = *settings;
  ret = fq_write_settings(queue_name, &mutable_settings);
  if (ret < 0) {
    goto cleanup_with_sems;
  }

  // Создание файла с идентификатором последнего добавленного сообщения
  // При создании данный файл содержит 0
  msg_id = 0;
  ret = fq_write_lastid(queue_name, msg_id);
  if (ret < 0) {
    goto cleanup_with_ctl_files;
  }

  // Если в очереди есть подключаемые внешние директории, то в момент
  // создания необходимо подсчитать количество имеющихся файлов и найти
  // последний добавленный msg_id.
  if (has_symlinks) {
    path = fq_sem_path(queue_name, FQ_SEM_COUNTER);
    sem_t* sem = sem_open(path.value, 0);
    if (!sem) {
      ret = -errno;
      goto cleanup_with_ctl_files;
    }

    walker_create_state_t state = {
      .settings = settings,
      .sem      = sem,
      .count    = 0,
      .min_id   = -1,       // -1 = недопустимый id, т.е. id ещё не найден
      .max_id   = -1,       // -1 = недопустимый id, т.е. id ещё не найден
      .min_seq  = INT_MAX,  // нач. значение поиска min - больше любого seq номера
      .max_seq  = INT_MIN   // нач. значение поиска max - меньше любого seq номера
    };

    // Проход по всей очереди: поиск min/max значений, подсчёт файлов
    ret = fq_walk(queue_name, walker_create, (uintptr_t)&state);

    // Закроем семафор перед обработкой ошибок fq_walk, что бы не пришлось
    // это делать дважды: в обработчике ошибок и в нормальном потоке.
    sem_close(sem);

    // Обработка ошибок поиска: если ошибка, то очередь неработоспособна
    if (ret < 0) {
      fq_error_filename("Can't walk queue", queue_name, -ret);
      goto cleanup_with_ctl_files;
    }

    fq_debug("Create: Found %d msg. min_id=%08X, max_id=%08X\n",
      state.count, state.min_id, state.max_id
    );

    if (state.max_id > 0) {
      // Если найден хоть один файл, то сохраняем max_id в служебный файл lastid
      ret = fq_write_lastid(queue_name, state.max_id);
      if (ret < 0) {
        goto cleanup_with_ctl_files;
      }
    }
  } // if (has_symlinks) ...

  // Если добрались до сюда, то разблокируем директорию и выходим.
  ret = fq_unlock(queue_name);
  if (ret != OK) {
    goto cleanup_with_ctl_files;
  }

  fq_debug("Created '%s'\n", queue_name);

  return OK;

  // Далее идёт подчистка после ошибок
  // ------------------------------------

cleanup_with_ctl_files:   // В момент ошибки уже были созданы управляющие файлы
  path = fq_control_path(queue_name, FQ_FILE_LASTID);
  if (unlink(path.value) != OK) {
    fq_error_filename("Can't unlink", path.value, errno);
  }

  path = fq_control_path(queue_name, FQ_FILE_SETTINGS);
  if (unlink(path.value) != OK) {
    fq_error_filename("Can't unlink", path.value, errno);
  }

cleanup_with_sems:        // В момент ошибки уже были созданы семафоры
  path = fq_sem_path(queue_name, FQ_SEM_COUNTER);
  if (sem_unlink(path.value) != OK) {
    fq_error_filename("Can't unlink sem", path.value, errno);
  }

  if (sem_unlink(queue_name) != OK) {
    fq_error_filename("Can't unlink sem", queue_name, errno);
  }

cleanup_with_dirs:        // В момент ошибки уже были созданы директории
  // Удаление директорий приоритетов и ссылок на них
  for (int priority = 0; priority < settings->priority_count; ++priority) {
    // Удаляем сперва ссылку
    path = fq_data_dir_path(queue_name, priority);
    if (unlink(path.value) != OK) {
      fq_error_filename("Can't unlink", path.value, errno);
    }

    // А затем и саму директорию.
    path = fq_data_dir_raw_path(queue_name, priority);
    if (rmdir(path.value) != OK) {
      fq_error_filename("Can't unlink", path.value, errno);
    }
  }

  // Удаление директории очереди.
  path = fq_dir_path(queue_name);
  if (rmdir(path.value) != OK) {
    fq_error_filename("Can't unlink", path.value, errno);
  }

  // Возвращаем код ошибки.
  return ret;
}



/// \brief  Получает монопольный доступ к директории с очередью файлов.
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int fq_lock(const char* queue_name)
{
  return NamedSemWaitTimeout(queue_name, -1);
}



/// \brief  Получает монопольный доступ к директории с очередью файлов, ожидая
///         не более \p timeout_ms миллисекунд.
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \param  timeout_ms    Максимальная продолжительность ожидания в миллисекундах.
///                       Если отрицательное число, то бесконечное ожидание.
///                       Если ноль, то выполняется без блокировки.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int fq_lock_timeout(const char* queue_name, int32_t timeout_ms)
{
  return NamedSemWaitTimeout(queue_name, timeout_ms);
}



/// \brief  Завершает монопольный доступ к директории с очередью файлов.
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int fq_unlock(const char* queue_name)
{
  dbg_assert(queue_name != NULL, "FQ: queue name NULL");

  int     result  = 0;
  sem_t*  sem     = sem_open(queue_name, 0);

  if (!sem) {
    result = -errno;
    fq_error_filename("Can't open lock", queue_name, errno);
    goto cleanup;
  }

  if (sem_post(sem) != OK) {
    result = -errno;
    fq_error_filename("Can't post lock", queue_name, errno);
    goto cleanup;
  }

cleanup:
  if (sem) {
    sem_close(sem);
  }
  return result;
}



/// \brief  Дожидается (используя семафор) добавления сообщения в очередь.
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \param  timeout_ms    Максимальная продолжительность ожидания в миллисекундах.
///                       Если отрицательное число, то бесконечное ожидание.
///                       Если ноль, то выполняется без блокировки.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int fq_counter_wait_timeout(const char* queue_name, int32_t timeout_ms)
{
  fq_path_t path = fq_sem_path(queue_name, FQ_SEM_COUNTER);
  return NamedSemWaitTimeout(path.value, timeout_ms);
}



/// \brief  Увеличивает на единицу значение счётчика сообщений.
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int fq_counter_increment(const char* queue_name)
{
  fq_path_t path = fq_sem_path(queue_name, FQ_SEM_COUNTER);
  return NamedSemPost(path.value);
}



/// \brief  Читает текущее значение счётчика сообщений.
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \param  value         Указатель на переменну, в которую следует
///                       записать результат. Не NULL!
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int fq_counter_read(const char* queue_name, int* value)
{
  fq_path_t path = fq_sem_path(queue_name, FQ_SEM_COUNTER);
  return NamedSemGetValue(path.value, value);
}



/// \brief  Создаёт новое сообщение с приоритетом \p priority в файловой очереди
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \param  priority      Приоритет сообщения
/// \param  created_id    Указатель на переменную, в которую будет записан
///                       полный идентификатор созданного файла.
///                       Если данный параметр NULL, то узнать идентификатор
///                       можно (до снятия блокировки и записи другого сообщения)
///                       либо прочитав файл lastid, либо вызвав функцию
///                       \see fq_read_lastid.
/// \return В случае успеха возвращает файловый дескриптор (fd) созданного файла.
///         Иначе, возвращает отрицательный код ошибки.
int fq_push_new(const char* queue_name, int priority, fq_id_t* created_id)
{
  fq_id_t msg_id = fq_allocate_msgid(queue_name, priority, created_id);
  if (msg_id < 0) {
    return (int)msg_id;
  }

  return fq_push_or_replace_id(queue_name, msg_id);
}


/// \brief Проверяет \p msg_id на валидность и выделяет место в очереди для
/// вновь создаваемого в очереди сообщения.
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \param  msg_id        Полный идентификатор сообщения, не 0 и не 0xFFFFFFFF.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int fq_validate_and_make_room(const char* queue_name, fq_id_t msg_id)
{
  int ret;
  fq_settings_t settings;

  ret = fq_read_settings(queue_name, &settings);
  if (ret != OK) {
    return ret;
  }

  int priority = fq_msgid_priority(msg_id);
  if (priority >= settings.priority_count) {
    fq_debug("Invalid priority %d for queue '%s'\n", priority, queue_name);
    return -EINVAL;
  }

  // Сохраняем id последнего добавленного файла.
  ret = fq_write_lastid(queue_name, msg_id);
  if (ret != OK) {
    return ret;
  }

  // Очищаем место в очереди под новый файл, если очередь переполнена.
  ret = fq_make_room(queue_name, &settings, msg_id);
  if (ret != OK) {
    return ret;
  }

  return OK;
}

/// \brief  Создаёт новое сообщение с полным идентификатором \p msg_id.
///         Если такое сообщение уже есть в очереди, то заменяет его.
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \param  msg_id        Полный идентификатор сообщения, не 0 и не 0xFFFFFFFF.
/// \return В случае успеха возвращает файловый дескриптор (fd) созданного файла.
///         Иначе, возвращает отрицательный код ошибки.
int fq_push_or_replace_id(const char* queue_name, fq_id_t msg_id)
{
  int           ret;

  // Проверяем и выделяем место в очереди.
  ret = fq_validate_and_make_room(queue_name, msg_id);
  if (ret != OK) {
    return ret;
  }

  // Создаём сам файл.
  fq_path_t     path  = fq_data_file_path(queue_name, msg_id);
  ret = open(path.value, O_WRONLY | O_CREAT | O_TRUNC);
  if (ret < 0) {
    ret = -errno;
    fq_error_filename("Can't create", path.value, errno);
    return ret;
  }


  return ret;
}



/// \brief  Добавляет в очередь с приоритетом \p priority существующий файл.
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \param  priority      Приоритет сообщения
/// \param  existing      Строка, содержащая имя существующего файла.
/// \param  created_id    Указатель на переменную, в которую будет записан
///                       полный идентификатор созданного файла.
///                       Если данный параметр NULL, то узнать идентификатор
///                       можно (до снятия блокировки и записи другого сообщения)
///                       либо прочитав файл lastid, либо вызвав функцию
///                       \see fq_read_lastid.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int fq_push_existing(const char* queue_name, int priority,
                    const char* existing, fq_id_t* created_id)
{
  int     ret;

  // Создаём новый идентификатор сообщения
  fq_id_t msg_id = fq_allocate_msgid(queue_name, priority, created_id);
  if (msg_id < 0) {
    return (int)msg_id;
  }

  // Проверяем и выделяем место в очереди.
  ret = fq_validate_and_make_room(queue_name, msg_id);
  if (ret != OK) {
    return ret;
  }

  fq_path_t path  = fq_data_file_path(queue_name, msg_id);
  ret = rename(existing, path.value);
  if (ret == OK) {
    // если переименование завершилось успешно, то выходим из функции.
    return ret;
  }

  ret = errno;
  if (ret != EXDEV) {
    // Непредвиденная ошибка.
    fq_debug("can't rename '%s' -> '%s', err=%d (%s)\n",
      existing, path.value, ret, strerror(ret)
    );
    return -ret;
  }

  // Ошибка произошла из-за того, что файлы находятся в разных файловых системах
  // Скопируем файл в новое место и удалим его из источника.
  int fd_src = -1;
  int fd_dst = -1;

  fd_src = open(existing, O_RDONLY);
  if (fd_src < 0) {
    ret = -errno;
    fq_error_filename("Can't open src", existing, errno);
    goto cleanup;
  }

  fd_dst = open(path.value, O_WRONLY);
  if (fd_dst < 0) {
    ret = -errno;
    fq_error_filename("Can't open dst", path.value, errno);
    goto cleanup;
  }

  uint8_t buffer[256];

  for (;;) {
    ssize_t size = read(fd_src, buffer, sizeof(buffer));
    if (size < 0) {
      ret = -errno;
      fq_error_filename("Can't read src", existing, errno);
      goto cleanup;
    }

    if (!size) {
      // Достигли конца файла. Завершаем копирование.
      break;
    }

    ssize_t wr_size = write(fd_dst, buffer, size);
    if (wr_size < 0) {
      ret = -errno;
      fq_error_filename("Can't write dst", path.value, errno);
      goto cleanup;
    }

    if (wr_size != size) {
      ret = -ENOSPC;
      fq_error_filename("Can't write dst", path.value, ENOSPC);
      goto cleanup;
    }
  }

  ret = OK;

cleanup:
  if (fd_src >= 0) {
    close(fd_src);
  }
  if (fd_dst >= 0) {
    close(fd_dst);
  }

  // В результате копирования один из файлов нужно удалить:
  //    - в случае успеха - исходный
  //    - в случае ошибки - целевой
  const char* what_to_delete = ret < 0 ? path.value : existing;
  if (unlink(what_to_delete) != OK) {
    ret = -errno;
  }
  return ret;
}



static int walker_find_head(uintptr_t arg, fq_id_t msg_id)
{
  fq_id_t* min_id = (fq_id_t*)arg;

  int priority      = fq_msgid_priority(msg_id);
  int sequence      = fq_msgid_sequence(msg_id);
  int min_priority  = fq_msgid_priority(*min_id);
  int min_sequence  = fq_msgid_sequence(*min_id);

  // Оставим для отладки все параметры и уберём предупреждения компилятора.
  (void)priority;
  (void)sequence;
  (void)min_priority;
  (void)min_sequence;

  if (*min_id < 0) {
    // Обработали первый файл. Сохраняем его id в качестве базового.
    *min_id = msg_id;
    return OK;
  }

  if (priority > min_priority) {
    // Поскольку проход по файлам идёт по директориям приоритета,
    // то сначала будут обработаны все файлы с самым высоким приоритетом,
    // затем - с чуть меньшим, потом - с ещё меньшим и так далее.
    // Поэтому, как только приоритет очередного файла оказался ниже, чем у
    // любого предыдущего, то можно заканчивать проход по директориям.
    // (по факту id с меньшим значением приоритета оказывается более приоритетным)
    return *min_id;
  }

  if (priority < min_priority) {
    // Если уже был найден хоть один файл и вдруг приоритет очередного файла
    // оказался выше, чем у любого из предыдущих, то это сомнительно,
    // т.к. проход по директориям идёт от самых приоритетных к наименее приоритетным.
    fq_warn("Walker: Suspicious file id=%08X (invalid priority)\n", msg_id);
  }

  if (msg_id < *min_id) {
    // Нашли более приоритетный файл.
    *min_id = msg_id;
  }

  return OK;
}

/// \brief  Сканирует очередь и возвращает id очередного файла для чтения из очереди.
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \return В случае успеха возвращает полный id файла, иначе - 0.
fq_id_t fq_find_head(const char* queue_name)
{
  fq_id_t msg_id = -1;
  int     ret = fq_walk(queue_name, walker_find_head, (uintptr_t)&msg_id);
  if (ret < 0) {
    return ret;
  }
  if (msg_id < 0) {
    // файл не найден.
    return -ENOENT;
  }

  return msg_id;
}



/// \brief  Открывает для чтения файл сообщения с идентификатором \p msg_id.
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \param  msg_id        Полный идентификатор сообщения, не 0 и не 0xFFFFFFFF.
/// \return В случае успеха возвращает файловый дескриптор (fd) созданного файла.
///         Иначе, возвращает отрицательный код ошибки.
int fq_read(const char* queue_name, fq_id_t msg_id)
{
  fq_path_t path = fq_data_file_path(queue_name, msg_id);
  int fd = open(path.value, O_RDONLY);
  if (fd < 0) {
    fd = -errno;
    fq_error_filename("Can't open", path.value, errno);
  }
  fq_trace("PID%d open %s as fd=%d\n", getpid(), path.value, fd);
  return fd;
}



/// \brief  Удаляет из очереди файл с полным идентификатором \p msg_id.
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \param  msg_id        Полный идентификатор сообщения, не 0 и не 0xFFFFFFFF.
/// \return 0 в случае успеха, или отрицательный код ошибки (-errno).
int fq_unlink(const char* queue_name, fq_id_t msg_id)
{
  fq_path_t path = fq_data_file_path(queue_name, msg_id);
  int       ret  = unlink(path.value);
  if (ret < 0) {
    ret = -errno;
    fq_error_filename("Can't unlink", path.value, errno);
  }
  return ret;
}



/// \brief  Проверяет наличие в очереди файла с полным идентификатором \p msg_id.
/// \param  queue_name    Имя очереди сообщений в формате "/имя". Не NULL!
/// \param  msg_id        Полный идентификатор сообщения, не 0 и не 0xFFFFFFFF.
/// \return 0 если файл присутствует, или отрицательный код ошибки (-errno).
int fq_has_message(const char* queue_name, fq_id_t msg_id)
{
  struct stat s;
  fq_path_t   path = fq_data_file_path(queue_name, msg_id);
  int         ret = stat(path.value, &s);
  if (ret < 0) {
    ret = -errno;
    return ret;
  }

  return OK;
}
