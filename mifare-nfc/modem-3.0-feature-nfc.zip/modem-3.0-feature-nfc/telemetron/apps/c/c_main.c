/// \file
/// \brief  Управление программными точками останова.
/// \author DL <dmitriy@linikov.ru>

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <nuttx/config.h>

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <utils/dbg.h>

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Приватные функции


////////////////////////////////////////////////////////////////////////////
//  c_main

#ifdef CONFIG_BUILD_KERNEL
int main(int argc, FAR char *argv[])
#else
int c_main(int argc, char *argv[])
#endif
{
#if defined(CFG_STOPPOINTS_ENABLED)
  if (argc == 1) {
    dbg_stoppoint_continue();
    return 0;
  }

  if (argc == 2 && strlen(argv[1]) == 1) {
    int arg = *(argv[1]);
    if (arg == '1') {
      printf("Enabled stoppoints\n");
      dbg_stoppoint_enable(true);
      return 0;
    }

    if (arg == '0') {
      printf("Disabled stoppoints\n");
      dbg_stoppoint_enable(false);
      return 0;
    }

    if (arg == 'b') {
      printf("Entered stoppoint\n");
      dbg_stoppoint("from 'c' program");
      printf("Exited from stoppoint\n");
      return 0;
    }
  } else {
    fprintf(stderr,
      "ERROR: invalid args\n\n"
      "Usage:\n"
      "  c        - continue stopped thread\n"
      "  c 0      - disable stoppoints\n"
      "  c 1      - enable stoppoints\n"
      "  c b      - halt in stoppoint\n\n"
    );
  }
#else
  fprintf(stderr, "ERROR: stoppoints compile-time disabled\n\n");
#endif

  return 1;
}
