/// \file
/// \brief  КраткоеОписание
/// \author DL <dmitriy@linikov.ru>
///
/// ПодробноеОписание

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <nuttx/config.h>
#include <stdio.h>

#include <kkt/paykiosk_pppd.h>

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные

static paykiosk_pppd_t*     g_paykiosk_pppd = NULL;


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Приватные функции

static int start_paykiosk_pppd(int argc, char* argv[])
{
  //          0     1         2          3
  // kkt_pppd start <ttypath> <baudrate> <timeout>

  if (argc < 4) {
    printf("Not enough args\n");
    return -EINVAL;
  }

  const char* ttypath = argv[1];

  // HACK:  Здесь используем тот факт, что в NuttX переменная типа speed_t
  //        хранит битрейт в виде бинарного значения. В общем же случае,
  //        в posix-совместимых ОС следует использовать константы
  //        (например, B9600, B115200 и т.д.)
  //        При портировании данного примера стоит это учитывать.
  int ret = atoi(argv[2]);
  if (ret <= 0) {
    printf("Invalid baudrate\n");
    return -EINVAL;
  }
  speed_t baudrate = (speed_t)ret;

  int timeout = atoi(argv[3]);
  if (timeout <= 0) {
    printf("Invalid timeout\n");
    return -EINVAL;
  }

  if (g_paykiosk_pppd) {
    printf("Already created. Can't change created instance\n");
    return -EALREADY;
  }

  paykiosk_pppd_t* paykiosk_pppd = (paykiosk_pppd_t*)malloc(sizeof(paykiosk_pppd_t));
  if (!paykiosk_pppd) {
    printf("Can't alloc instance\n");
    return -ENOMEM;
  }
  g_paykiosk_pppd = paykiosk_pppd;

  ret = paykiosk_pppd_create(paykiosk_pppd, ttypath, baudrate);
  if (ret < 0) {
    printf("Can't create instance, ret=%d (%s)\n", ret, strerror(-ret));
    g_paykiosk_pppd = NULL;
    free(paykiosk_pppd);
    return ret;
  }

  ret = paykiosk_pppd_connect(paykiosk_pppd, timeout * 1000);
  if (ret < 0) {
    paykiosk_pppd_destroy(paykiosk_pppd);
    g_paykiosk_pppd = NULL;
    free(paykiosk_pppd);
    return ret;
  }

  return 0;
}

static int stop_paykiosk_pppd(int argc, char* argv[])
{
  //         0    1
  // kkt_ppd stop <timeout>

  if (argc < 2) {
    printf("Not enough args\n");
    return -EINVAL;
  }

  int timeout = atoi(argv[1]);
  if (!timeout) {
    printf("Invalid timeout\n");
    return -EINVAL;
  }

  paykiosk_pppd_t* paykiosk_pppd = g_paykiosk_pppd;
  if (!paykiosk_pppd) {
    printf("Not started\n");
    return 0;
  }

  int ret = paykiosk_pppd_disconnect(paykiosk_pppd, timeout * 1000);
  if (ret < 0) {
    printf("Can't stop service, ret=%d (%s)\n", ret, strerror(-ret));
    return ret;
  }

  ret = paykiosk_pppd_destroy(paykiosk_pppd);
  if (ret < 0) {
    printf("Can't destroy, ret=%d (%s)\n", ret, strerror(-ret));
    return ret;
  }

  g_paykiosk_pppd = NULL;
  free(paykiosk_pppd);
  return 0;
}

////////////////////////////////////////////////////////////////////////////
//  kkt_pppd_main

#ifdef CONFIG_BUILD_KERNEL
int main(int argc, FAR char *argv[])
#else
int kkt_pppd_main(int argc, char *argv[])
#endif
{
  if (argc < 2) {
    printf("Not enough args\n");
    return -EINVAL;
  }

  if (strcmp(argv[1], "start") == 0) {
    return start_paykiosk_pppd(--argc, ++argv);
  }

  if (strcmp(argv[1], "stop") == 0) {
    return stop_paykiosk_pppd(--argc, ++argv);
  }

  printf("Unsupported command '%s'\n", argv[1]);
  return -EINVAL;
}
