/// \file
/// \brief  ККТ PayKiosk
/// \note   Данный модуль - адаптация модулей drv_kkm и kkt_paykiosk
///         из ПО для модема 2.7. Их автор Андрей Сыренков.



#include <kkt/paykiosk.h>
#include "paykiosk_internals.h"

#include <errno.h>
#include <string.h>
#include <inttypes.h>

//#include <sysutils/crc.h>

#include <utils/math_utils.h>
#include <utils/string_utils.h>
#include <utils/smartio.h>
#include <utils/smartio_crcxor.h>
#include <utils/dbg.h>

//#include "drv_kkm.h"
//#include "kkt_paykiosk.h"
//#include "printer.h"
// #include "protocol_ofd.h"
//#include "settings.h"


// ====================== Временные параметры протокола PAYKIOSK ========================
// Таймауты по процедурам
#define PAYKIOSK_WAIT_BYTE                      500       // Для скорости передачи данных 4800 = двум длительностям байта По факту оказалось что ждать нужно минимум 500 мС
#define PAYKIOSK_WAIT_ACK_BYTE                  (500)
#define PAYKIOSK_WAIT_TCP_BYTE                  3         // При работе с TCP
#define PAYKIOSK_WAIT_TCP                       5000      // Получение пакета TCP

#define PAYKIOSK_SEND_TIMEOUT_MS                PAYKIOSK_WAIT_BYTE
#define PAYKIOSK_PRINT_TIMEOUT_MS               300000

#define PAYKIOSK_CMD_DEF_TIMEOUT_MS                 15000

/// \brief Проверка, что операция \p op возвратила неотрицательное значение.
///
/// Внимание:  Данный макрос предполагает, что функция, в которой он вызывается,
///            имеет переменную `ret`, которой он присваивает результат операции \p op.
///
/// Внимание:  Если операция op возвратила отрицательное значение, то данный макрос
///            осуществляет `goto cleanup`, поэтому функция, в которой он вызывается
///            обязательно должна иметь метку `cleanup`.
# define CHECK_OK(op)                               \
    do {                                            \
      ret = (op);                                   \
      if (ret < 0) {                                \
        kkt_warn(                                   \
          "\"%s\" fail, err=%d (%s)\n",             \
          #op, ret, paykiosk_strerror(-ret)         \
        );                                          \
        goto cleanup;                               \
      }                                             \
    } while (0)

/// \brief Проверка, что операция \p op возвратила неотрицательное значение.
///
/// Внимание:  Данный макрос предполагает, что функция, в которой он вызывается,
///            имеет переменную `ret`, которой он присваивает результат операции \p op.
///
/// Внимание:  Если операция op возвратила отрицательное значение, то данный макрос
///            осуществляет `goto cleanup`, поэтому функция, в которой он вызывается
///            обязательно должна иметь метку `cleanup`.
# define CHECKMSG_OK(msg, op)                       \
    do {                                            \
      ret = (op);                                   \
      if (ret < 0) {                                \
        kkt_warn(                                   \
          "\"%s\" fail, err=%d (%s)\n",             \
          msg, ret, paykiosk_strerror(-ret)         \
        );                                          \
        goto cleanup;                               \
      }                                             \
    } while (0)


/// \brief Проверка, что операция \p op возвратила неотрицательное значение или `-ETIMEDOUT`.
///
/// Внимание:  Данный макрос предполагает, что функция, в которой он вызывается,
///            имеет переменную `ret`, которой он присваивает результат операции \p op.
///
/// Внимание:  Если операция op возвратила отрицательное значение, то данный макрос
///            осуществляет `goto cleanup`, поэтому функция, в которой он вызывается
///            обязательно должна иметь метку `cleanup`.
# define CHECK_OK_OR_TIMEDOUT(op)                   \
    do {                                            \
      ret = (op);                                   \
      if (ret < 0 && ret != -ETIMEDOUT) {           \
        kkt_warn(                                   \
          "\"%s\" fail, err=%d (%s)\n",             \
          #op, ret, paykiosk_strerror(-ret)         \
        );                                          \
        goto cleanup;                               \
      }                                             \
    } while (0)

/// \brief Проверка, что операция \p op возвратила неотрицательное значение или `-ETIMEDOUT`.
///
/// Внимание:  Данный макрос предполагает, что функция, в которой он вызывается,
///            имеет переменную `ret`, которой он присваивает результат операции \p op.
///
/// Внимание:  Если операция op возвратила отрицательное значение, то данный макрос
///            осуществляет `goto cleanup`, поэтому функция, в которой он вызывается
///            обязательно должна иметь метку `cleanup`.
# define CHECKMSG_OK_OR_TIMEDOUT(msg, op)           \
    do {                                            \
      ret = (op);                                   \
      if (ret < 0 && ret != -ETIMEDOUT) {           \
        kkt_warn(                                   \
          "\"%s\" fail, err=%d (%s)\n",             \
          msg, ret, paykiosk_strerror(-ret)         \
        );                                          \
        goto cleanup;                               \
      }                                             \
    } while (0)


////////////////////////////////////////////////////////////////////////////
//  Предварительные объявления функций

// =========================================================================
//    Приватные функции драйвера paykiosk

static void paykiosk_save_error(paykiosk_t* me, uint16_t cmd, int error);
static int  paykiosk_check_printer(paykiosk_t* me);

// =========================================================================
//    Функции реализации методов интерфейса kktlink
static const kkt_caps_t* paykiosk_get_caps(kkt_t* kkt);
static int paykiosk_destroy(kkt_t* kkt);
static int paykiosk_init(kkt_t* kkt);
static int paykiosk_deinit(kkt_t* kkt);
static const char* paykiosk_bus_name(kkt_t* kkt);
static int paykiosk_status_check(kkt_t* kkt);
static int paykiosk_datetime_get(kkt_t* kkt, struct timespec* dst);
static int paykiosk_order_open(kkt_t* kkt);
static int paykiosk_order_close(kkt_t* kkt, const kkt_pay_t* summ);
static int paykiosk_order_reg(kkt_t* kkt, const kkt_money_t* price, thousandths_t quant, const char* name, uint16_t section);
static int paykiosk_order_cut(kkt_t* kkt);
static int paykiosk_print_string(kkt_t* kkt, const char* str);
static int paykiosk_print_image(kkt_t* kkt, const uint8_t* image, uint16_t x, uint16_t y);
static int paykiosk_ofd_set_server(kkt_t* kkt, const char* server);
static int paykiosk_ofd_set_port(kkt_t* kkt, uint16_t port);
static int paykiosk_fn_check_status(kkt_t* kkt);
static int paykiosk_fn_set_transport(kkt_t* kkt);

////////////////////////////////////////////////////////////////////////////
//  Константы

struct kkmerror_to_string_s {
  uint8_t     error;
  const char* text;
};

static const struct kkmerror_to_string_s  KKM_ERRORS[] = {
  { .error = 0x4F, .text = "KKT:Invalid password" },
  { .error = 0x50, .text = "KKT:Still printing" },
  { .error = 0x58, .text = "KKT:Waiting resume printing" },
};

static const kkt_vmt_t PAYKIOSK_VMT = {
  .get_caps           = paykiosk_get_caps,
  .destroy            = paykiosk_destroy,
  .init               = paykiosk_init,
  .deinit             = paykiosk_deinit,
  .bus_name           = paykiosk_bus_name,
  .status_check       = paykiosk_status_check,
  .datetime_get       = paykiosk_datetime_get,
  .order_open         = paykiosk_order_open,
  .order_close        = paykiosk_order_close,
  .order_reg          = paykiosk_order_reg,
  .order_cut          = paykiosk_order_cut,
  .print_string       = paykiosk_print_string,
  .print_image        = paykiosk_print_image,
  .ofd_set_server     = paykiosk_ofd_set_server,
  .ofd_set_port       = paykiosk_ofd_set_port,
  .fn_check_status    = paykiosk_fn_check_status,
  .fn_set_transport   = paykiosk_fn_set_transport,
};

/// Драйвер ККТ фирмы ШТРИХ М (он же PAY Kiosk)

const char* paykiosk_strerror(int error)
{
  if (PAYKIOSK_IS_KKTERROR(error)) {
    // Наиболее часто встречающиеся ошибки имеют текстовое описание
    // для упрощения отладки.
    for (size_t i=0; i != sizeof(KKM_ERRORS)/sizeof(KKM_ERRORS[0]); ++i) {
      if (KKM_ERRORS[i].error == PAYKIOSK_GET_KKTERROR(error)) {
        return KKM_ERRORS[i].text;
      }
    }
    // Остальные ошибки - просто опишем, что ошибка от ККМ.
    return "KKM error code";
  }

  // Если не ошибка KKM, то обычный errno
  return strerror(error);
}

static int paykiosk_perror(const char* what, int result) {
  kkt_error("%s fail, ret=%d (%s)\n", what, result, paykiosk_strerror(-result));
  return result;
}


static int paykiosk_tx_cmd(
  paykiosk_t* me, paykiosk_cmd_t cmd, const void* data, size_t data_size
)
{
  int     ret;                          // Для CHECK_OK
  size_t  total_length = (              // Длина с учётом заголовка команды
    data_size
    + (PAYKIOSK_CMD_IS_LONG(cmd) ? 2 : 1)
    + (PAYKIOSK_CMD_HAS_PASSWORD(cmd) ? 4 : 0)
  );

  DEBUGASSERT(total_length <= 255); // На поле длины выделен всего один байт.

  kkt_trace(
    "Tx CMD%04X (long=%d, has_password:%d, data_size:%d)\n",
    PAYKIOSK_CMD_GET_NUM(cmd),
    PAYKIOSK_CMD_IS_LONG(cmd),
    PAYKIOSK_CMD_HAS_PASSWORD(cmd),
    (int)data_size
  );
  if (data_size) {
    kkt_dump("Payload", data, data_size);
  }

  CHECK_OK(kktport_putc(me, STX_CHAR));

  // Длина команды, это первый байт, защищённый контрольной суммой
  kktport_clear_crc_tx(me);
  CHECK_OK(kktport_putc(me, (uint8_t)total_length));

  // Заголовок команды: Номер команды (1 или 2 байта в зависимости от команды).
  // Номер команды передаётся в Big-Endian формате.
  if (PAYKIOSK_CMD_IS_LONG(cmd)) {
    CHECK_OK( kktport_putc(me, PAYKIOSK_CMD_GET_MSB(cmd)) );  // старший байт
  }
  CHECK_OK( kktport_putc(me, PAYKIOSK_CMD_GET_LSB(cmd)) );    // младший байт

  // Заголовок команды: Пароль (опционально)
  if ((cmd & PAYKIOSK_CMDF_NO_PASSWORD) == 0) {
    uint32_t password = kkt_params(me)->printer_psw;
    CHECK_OK(kktport_nbwrite(me, &password, 4, 0));
  }

  // Данные команды
  CHECK_OK(kktport_nbwrite(me, data, data_size, 0));

  // Контрольная сумма
  CHECK_OK(kktport_putc(me, me->txcrc.value));

  // Поскольку используется буффер, сброс буффера для отправки команды
  // одной транзакцией канала связи (UART или TCP/IP соединение)
  CHECK_OK(kktport_flush(me));

  // Команда успешно передана
  return 0;

cleanup: // Обработка ошибок CHECK_OK
  kkt_error(
    "Tx CMD%04X fail, ret=%d (%s)\n",
    PAYKIOSK_CMD_GET_NUM(cmd),
    ret,
    paykiosk_strerror(-ret)
  );
  return ret;
}


/// \brief  Получение ответа ККМ с отправкой ACK или NAK при необходимости.
///
/// \retval -ETIMEDOUT  Таймаут получения ответа.
/// \retval -ENOLINK    Таймаут получения STX или некорректный символ.
/// \retval -EILSEQ     Получена некорректная контрольная сумма, нужно отправить NAK
/// \retval `>= 0`      Успешно получен ответ. Нужно отправить ACK
static ssize_t paykiosk_rx_rsp(
  paykiosk_t*           me,
  paykiosk_rspheader_t* header,
  void*                 rsp,
  size_t                max_rsp_size,
  int                   cmd_timeout_ms
)
{
  int         ret;
  int         len;
  uint8_t*    ptr     = (uint8_t*)rsp;
  uint8_t*    endptr  = ptr ? ptr + max_rsp_size : ptr;
  uint8_t     cmd_msb = 0;
  uint8_t     cmd_lsb;
  uint8_t     error_code;

  // Получение ответа ККМ на команду. Может быть очень долгим.
  CHECKMSG_OK_OR_TIMEDOUT("Rx STX", kktport_nbgetc(me, cmd_timeout_ms));
  if (ret == -ETIMEDOUT) {
    // Таймаут получения STX. Требуется отдельная обработка,
    // т.к. по рекомендованной блок-схеме от ШТРИХ, в случае таймаута STX
    // не производится повторного чтения
    kkt_warn("Rx STX timed out\n");
    return -ENOLINK;
  }
  if (ret != STX_CHAR) {
    // Получили не STX. Нет связи. Повторяем ENQ->....
    kkt_warn("Expect STX, got 0x%02X\n", ret);
    return -ENOLINK;
  }

  // Получение заголовка ответа команды, разбирая его "на-лету".
  kktport_clear_crc_rx(me);
  CHECKMSG_OK("Rx LEN", len = kktport_nbgetc(me, me->timeout_getc_ms));
  CHECKMSG_OK("Rx CMD1", kktport_nbgetc(me, me->timeout_getc_ms));
  if (ret == 0xFF) { // двух-байтная команда
    cmd_msb = (uint8_t)ret;
    CHECKMSG_OK("Rx CMD2", kktport_nbgetc(me, me->timeout_getc_ms));
  }
  cmd_lsb = (uint8_t)ret;
  CHECKMSG_OK("Rx ERRCODE", kktport_nbgetc(me, me->timeout_getc_ms));
  error_code = (uint8_t)ret;

  // Убираем байты заголовка из длины.
  // Если 2-байтная команда, то заголовок 3 байта, иначе - 2 байта.
  len -= cmd_msb ? 3 : 2;
  if (len < 0) {
    // Некорректное поле длины
    kkt_warn("Rx LEN=%d - invalid\n", len);
    len = 0;
  }

  if (len > 0 && error_code) {
    // В ответе ненулевой код ошибки и при этом есть данные
    kkt_warn("Rx error_code and payload together\n");
  }

  // Получаем тело ответа
  for (int i=0; i < len; ++i) {
    CHECKMSG_OK("Rx PAYLOAD", kktport_nbgetc(me, me->timeout_getc_ms));
    if (ptr != endptr) {
      *ptr++ = (uint8_t)ret;
    }
  }

  // Получаем и проверяем контрольную сумму.
  CHECKMSG_OK("Rx CHK", kktport_nbgetc(me, me->timeout_getc_ms));

  // Поскольку контрольная сумма - это XOR, то посчитав её при приёме
  // в случае успеха получим ноль.
  if (me->rxcrc.value != 0) {
    kkt_warn("Rx bad CHK. rx:%02X, calc:%02X\n", (uint8_t)ret, me->rxcrc.value ^ (uint8_t)ret);
    CHECKMSG_OK("Tx NAK", kktport_putc_flush(me, NAK_CHAR));
    return -EILSEQ;
  }

  CHECKMSG_OK("Tx ACK", kktport_putc_flush(me, ACK_CHAR));

  // Похоже, что при текущей реализации TCP/IP стека в NuttX (или в Paykiosk - не знаю)
  // часть отправленных пакетов подтверждения теряется (предполагаю, затирается следующим
  // за ним пакетом с очередным запросом). Добавил небольшую паузу что бы у paykiosk
  // было время обработать этот ACK пакет.
  usleep(250000);

  if (header) {
    header->cmd   = (cmd_msb << 8) | cmd_lsb;
    header->error = error_code;
  }
  return len;

cleanup:
  return ret;
}

static void paykiosk_save_error(paykiosk_t* me, uint16_t cmd, int error)
{
  return kkt_save_error(me, cmd, error);
}

static ssize_t paykiosk_cmd(
  paykiosk_t*     me,
  paykiosk_cmd_t  cmd,
  const void*     data,
  size_t          data_size,
  void*           rsp,
  size_t          max_rsp_size,
  int             cmd_timeout_ms
)
{
  // Данная функция реализована в соответствии с рекомендуемой ШТРИХом
  // блоксхемой обмена данными.
  int                   ret;
  unsigned              j = 0;              // Счётчик повторов приёма
  bool                  cmd_sent = false;   // Данные были отправлены
  paykiosk_rspheader_t  header;

  kkt_info("CMD%04X\n", PAYKIOSK_CMD_GET_NUM(cmd));
  for (unsigned iterations=0; iterations < 20; ++iterations) {
    if (j >= 10) {
      kkt_error("Too much rx retries.\n");
      paykiosk_save_error(me, PAYKIOSK_CMD_GET_NUM(cmd), -ENOLINK);
      return -ENOLINK;
    }

    // Посылка ENQ
    kkt_trace("Sending ENQ...\n");

    CHECK_OK(kktport_putc_flush(me, ENQ_CHAR));
    CHECK_OK_OR_TIMEDOUT(kktport_nbgetc(me, me->timeout_getc_ms));
    if (ret == -ETIMEDOUT) {
      // Истёк таймаут ответа
      kkt_warn("ENQ->(N)ACK timeout\n");
      continue;
    }

    if (ret != ACK_CHAR && ret != NAK_CHAR) {
      // Ожидание конца передачи от ФР
      kkt_warn("ENQ->0x%02X - waiting for FR eot\n", ret);
      continue;
    }

    if (ret == NAK_CHAR) {
      // Режим передачи - отправка команды и данных.
      // Считаем, что при передаче таймаутов быть не должно.
      cmd_sent = false;
      for (unsigned i=0; i < 10; ++i) {
        kkt_trace("Tx mode, i=%u\n", i);
        CHECK_OK(paykiosk_tx_cmd(me, cmd, data, data_size));
        CHECK_OK_OR_TIMEDOUT(kktport_nbgetc(me, me->timeout_getc_ms));
        if (ret == -ETIMEDOUT) {
          // Если произошел таймаут передачи, то необходимо снова отправить ENQ.
          break;
        }
        if (ret != ACK_CHAR) {
          // ККМ не подтвердил получение. Ещё один повтор
          // в цикле отправки `for (size_t i=0; i < 10; ++i)`
          continue;
        }

        // ККМ подтвердил получение.
        cmd_sent = true;
        break;
      } // for (unsigned i=0; i < 10; ++i)...

      if (!cmd_sent) {
        // Не удалось отправить команду в ККМ.
        // Уходим на очередную итерацию цикла for (;;)
        continue;
      }
    } // if (ret == NAK_CHAR)

    // Режим приёма
    kkt_trace("Rx mode, j=%u\n", j);

    ret = paykiosk_rx_rsp(me, &header, rsp, max_rsp_size, cmd_timeout_ms);
    if (ret == -ETIMEDOUT || ret == -EILSEQ) {
      ++j;
      continue;
    }
    if (ret < 0) {
      // -ENOLINK или неожиданная ошибка от потока ввода-вывода
      return ret;
    }

    if (header.cmd != PAYKIOSK_CMD_GET_NUM(cmd)) {
      // Получен ответ на какую-то ранее отправленную команду. Игнорируем его.
      kkt_warn("Got response for previous CMD%04X. Discarded\n", header.cmd);
      ++j;
      continue;
    }

    if (header.error) {
      // ККМ вернул ошибку в ответ на отправленную команду.
      kkt_error(
        "CMD%04X: KKT returned error 0x%02X\n",
        PAYKIOSK_CMD_GET_NUM(cmd),
        header.error
      );
      return -PAYKIOSK_KKTERROR(header.error);
    }

    // Получен ответ на команду, ret содержит количество полученных байт.
    kkt_info("CMD%04X: completed, len=%d\n", PAYKIOSK_CMD_GET_NUM(cmd), ret);
    paykiosk_save_error(me, PAYKIOSK_CMD_GET_NUM(cmd), 0);
    return ret;
  } // for (unsigned iterations=0; iterations < 20; ++iterations)...

  kkt_error("CMD%04X: too much iterations.\n", PAYKIOSK_CMD_GET_NUM(cmd));
  ret = -ENOLINK;

cleanup:
  // Обработка ошибок, произошедших в макросе CHECK_OK.
  // переменная ret содержит код ошибки.
  paykiosk_save_error(me, PAYKIOSK_CMD_GET_NUM(cmd), ret);
  return ret;
}

/// \brief Выполнение команды без дополнительных параметров и не требуя ответа
static ssize_t paykiosk_simple_cmd(paykiosk_t* me, paykiosk_cmd_t cmd, int cmd_timeout_ms)
{
  uint8_t dummy;
  return paykiosk_cmd(me, cmd, NULL, 0, &dummy, 1, cmd_timeout_ms);
}



////////////////////////////////////////////////////////////////////////////
//  Реализация команд принтера



// // Массив с наименованием принтера
// char paykiosk_name[16];
//
// // Инициализация структуры параметров аппарата
// static kkt_state_t    me->params={.name=paykiosk_name,
//                                             .OFDserv="",
//                                             .OFDport=0,
//                                             .printer_ip="",
//                                             .doc_mode=0,};
// // Инициализация структуры статуса ФН
// static fn_state_t     paykiosk_fn_status_={.FN_exch_state=0,
//                                             .FN_read_state=0,
//                                             .FN_msgs=0,
//                                             .FN_doc_num=0,
//                                             .FN_doc_dt="",
//                                             .FN_kkt_sn="",
//                                             .FN_kkt_rnm="",
//                                             .FN_sn="",
//                                             .FN_ta_sn="",
//                                             };

/*
kkmtype_to_msgsize_t paykiosk_max_size[]={
    {KKMTYPE_TRIUMF_F,      47},
    {KKMTYPE_FELIKS_RF,     38},
    {KKMTYPE_FELIKS_02K,    38},
    {KKMTYPE_MERKURI_140F,  30},
    {KKMTYPE_TORNADO,       66},
    {KKMTYPE_MERKURI_MS_K,  66},
    {KKMTYPE_FELIKS_RK,     66},
    {KKMTYPE_FELIKS_3CK,    66},
    {KKMTYPE_FPrint_02K,    66},
    {KKMTYPE_FPrint_03K,    66},
    {KKMTYPE_FPrint_88K,    66},
    {KKMTYPE_FPrint_5200K,  66},
    {KKMTYPE_PayVKP_80K,    66},
    {KKMTYPE_PayPPU_700K,   66},
    {KKMTYPE_PayCTS_2000K,  98},
    {KKMTYPE_FPrint_55K,    50},
    {KKMTYPE_FPrint_11PTK,  62},
    {KKMTYPE_FPrint_22K,    46},
    {KKMTYPE_FPrint_77PTK,  57},
};

kkmtype_to_msgsize_t paykiosk_max_str[]={
    {KKMTYPE_TRIUMF_F,      40},
    {KKMTYPE_FELIKS_RF,     20},
    {KKMTYPE_FELIKS_02K,    20},
    {KKMTYPE_MERKURI_140F,  24},
    {KKMTYPE_TORNADO,       48},
    {KKMTYPE_MERKURI_MS_K,  39},
    {KKMTYPE_FELIKS_RK,     38},
    {KKMTYPE_FELIKS_3CK,    38},
    {KKMTYPE_FPrint_02K,    56},
    {KKMTYPE_FPrint_03K,    32},
    {KKMTYPE_FPrint_88K,    56},
    {KKMTYPE_FPrint_5200K,  36},
    {KKMTYPE_PayVKP_80K,    56},
    {KKMTYPE_PayPPU_700K,   56},
    {KKMTYPE_PayCTS_2000K,  72},
    {KKMTYPE_FPrint_55K,    36},
    {KKMTYPE_FPrint_11PTK,  48},
    {KKMTYPE_FPrint_22K,    32},
    {KKMTYPE_FPrint_77PTK,  57},
};

int16_t paykiosk_get_max_msg_size(kkmtype_paykiosk_t type)
{
    uint16_t size=sizeof(paykiosk_max_size)/sizeof(kkmtype_to_msgsize_t);
    for (uint8_t i=0;i<size;i++)
    {
        if (paykiosk_max_size[i].type==type)
            return paykiosk_max_size[i].msg_size;
    }
    return -1;
}

int16_t paykiosk_get_str_size(kkmtype_paykiosk_t type)
{
    uint16_t size=sizeof(paykiosk_max_str)/sizeof(kkmtype_to_msgsize_t);
    for (uint8_t i=0;i<size;i++)
    {
        if (paykiosk_max_str[i].type==type)
            return paykiosk_max_str[i].msg_size;
    }
    return -1;
}
*/

//++++++++++++++++++++++ Простые команды принтера (порт должен быть уже открыт) ++++++++++++++

/// \brief Продолжить печать
static int paykiosk_resume_print(paykiosk_t* me)
{
  ssize_t ret = paykiosk_simple_cmd(me, PAYKIOSK_CMD_B0, PAYKIOSK_CMD_DEF_TIMEOUT_MS);
  if (ret < 0) {
    return paykiosk_perror("CMDB0", ret);
  }
  return 0;
}

/// \brief Анулировать чек (работает только если чек не попал в ФН)
static int paykiosk_abort_print(paykiosk_t* me)
{
  ssize_t ret = paykiosk_simple_cmd(me, PAYKIOSK_CMD_88, PAYKIOSK_CMD_DEF_TIMEOUT_MS);
  if (ret < 0) {
    return paykiosk_perror("CMD88", ret);
  }
  return 0;
}

/// \brief Открытие смены
static int paykiosk_shift_open_cmd(paykiosk_t* me)
{

  ssize_t ret = paykiosk_simple_cmd(me, PAYKIOSK_CMD_E0, PAYKIOSK_CMD_DEF_TIMEOUT_MS);
  if (ret < 0) {
    return paykiosk_perror("CMDE0", ret);
  }
  return 0;
}

/// \brief Закрытие смены
static int paykiosk_shift_close_cmd(paykiosk_t* me)
{
  ssize_t ret = paykiosk_simple_cmd(me, PAYKIOSK_CMD_41, PAYKIOSK_CMD_DEF_TIMEOUT_MS);
  if (ret < 0) {
    return paykiosk_perror("CMD41", ret);
  }

  return 0;
}



// Запись в таблицу
static int paykiosk_write_table(paykiosk_t* me, paykiosk_tables_t table, uint16_t row, uint8_t field, void * value, size_t value_size)
{
  struct __attribute__((packed)) paykiosk_cmd1e_s {
    uint8_t   table;      ///< Номер таблицы
    uint16_t  row;        ///< Номер ряда
    uint8_t   field;      ///< номер поля
    char      value[246]; ///< значение параметра (зависит от модели до 40 или до 246 байт
  };

  int ret;
  uint8_t                   data[256];
  char                      dump[32];
  struct paykiosk_cmd1e_s*  cmd1e = (struct paykiosk_cmd1e_s*)data;

  if (!me || !value) {
    return -EINVAL;
  }

  //PAYKIOSK_CMD_1E;


  memset(cmd1e, 0, sizeof(*cmd1e));

  cmd1e->table=table;    // Заполняем таблицу
  cmd1e->row=row;        // заполняем ряд
  cmd1e->field=field;    // заполняем поле

  // Заполняем значение
  size_t len=min_u32(sizeof(cmd1e->value), value_size);
  if (len < value_size) {
    kkt_error("Input value cut. value_size %d\n", value_size);
  }

  memcpy(cmd1e->value, value, len);
  size_t size = len + offsetof(struct paykiosk_cmd1e_s, value);

  DumpToHexString(dump, sizeof(dump), cmd1e->value, len);
  kkt_trace(
    "WrTable: {table:%u, row:%u, field:%u, len:%u, value:\"%s\" }\n",
    cmd1e->table,
    cmd1e->row,
    cmd1e->field,
    len,
    dump
  );
  ret = paykiosk_cmd(me, PAYKIOSK_CMD_1E, cmd1e, size, data, sizeof(data), PAYKIOSK_CMD_DEF_TIMEOUT_MS);
  if (ret < 0) {
    paykiosk_perror("CMD1E", ret);
    return ret;
  }

  return 0;
}

// Чтение таблицы
static int paykiosk_read_table(paykiosk_t* me, paykiosk_tables_t table, uint16_t row, uint8_t field, void * value, size_t value_size)
{
  struct  __attribute__((packed)) paykiosk_cmd1f_s{
    uint8_t   table;      ///< Номер таблицы
    uint16_t  row;        ///< Номер ряда
    uint8_t   field;      ///< номер поля
  };

  if (!value || !value_size) {
    return -EINVAL;
  }

  ssize_t                 ret;
  char                    dump[32];
  struct paykiosk_cmd1f_s cmd1f = {
    .table = table,    // таблица
    .row   = row,      // ряд
    .field = field,    // поле
  };

  ret = paykiosk_cmd(me, PAYKIOSK_CMD_1F, &cmd1f, sizeof(cmd1f), value, value_size, PAYKIOSK_CMD_DEF_TIMEOUT_MS);
  if (ret < 0) {
    return paykiosk_perror("CMD1F", ret);
  }

  if (ret > value_size) {
    kkt_error("Input value cut. value_size %u, data_size %d\n", (unsigned)value_size, ret);
  }

  int len = ret > value_size ? value_size : ret;
  DumpToHexString(dump, sizeof(dump), value, len);
  kkt_trace(
    "RdTable: {table:%u, row:%u, field:%u, len:%u, value:\"%s\" }\n",
    cmd1f.table,
    cmd1f.row,
    cmd1f.field,
    len,
    dump
  );

  return 0;
}


/// \brief Устанавлиает режим печати чека
///
/// Допустимые значения value
/// 0 - печать чека на ленту всегда
/// 1 - отключает печать следующего документа на ленту (после печати в ФН, автоматически переходит в режим 0)
/// 2 - отключает печать всех документов на чековую ленту
static int paykiosk_printdoc_off(paykiosk_t* me, uint8_t value)
{
  int res;
  if ((value < 0) || (value > 2)) {
    return -EINVAL;
  }

  res=paykiosk_write_table(me, PAYKIOSK_TABLE_17, 1, 7, &value, sizeof(value));
  kkt_info("paykiosk_printdoc_off: result %d\n", res);
  return res;
}

// возвращает текущую установку режима печати чеков
static int paykiosk_get_printdoc(paykiosk_t* me, uint8_t* value)
{
  int res;
  if (!value) {
    return -EINVAL;
  }

  res=paykiosk_read_table(me, PAYKIOSK_TABLE_17, 1, 7, value, sizeof(*value));
  log_info("paykiosk_get_printdoc: result %d, value = %d", res, *value);

  return res;
}

/// Получает из таблиц статус ФН
static int paykiosk_get_FN_status(paykiosk_t* me, fn_state_t* fn_status)
{
  int ret;
  if (!fn_status) {
    return -EINVAL;
  }

  // Читаем статус очереди
  memset(&fn_status->FN_exch_state, 0, sizeof(fn_status->FN_exch_state));
  CHECK_OK(paykiosk_read_table(me, PAYKIOSK_TABLE_20, 1, 1, &fn_status->FN_exch_state, sizeof(fn_status->FN_exch_state)));

  // Читаем readstate
  memset(&fn_status->FN_read_state, 0, sizeof(fn_status->FN_read_state));
  CHECK_OK(paykiosk_read_table(me, PAYKIOSK_TABLE_20, 1, 2, &fn_status->FN_read_state, sizeof(fn_status->FN_read_state)));

  // Читаем количество неотправленных собщений
  memset(&fn_status->FN_msgs, 0, sizeof(fn_status->FN_msgs));
  CHECK_OK(paykiosk_read_table(me, PAYKIOSK_TABLE_20, 1, 3, &fn_status->FN_msgs, sizeof(fn_status->FN_msgs)));

  // Читаем номер неотправленного документа
  memset(&fn_status->FN_doc_num, 0, sizeof(fn_status->FN_doc_num));
  CHECK_OK(paykiosk_read_table(me, PAYKIOSK_TABLE_20, 1, 4, &fn_status->FN_doc_num, sizeof(fn_status->FN_doc_num)));

  // Читаем дату создания первого в очереди документа на отправку
  strncpy_ex(fn_status->FN_doc_dt, "", sizeof(fn_status->FN_doc_dt));
  CHECK_OK(paykiosk_read_table(me, PAYKIOSK_TABLE_20, 1, 5, fn_status->FN_doc_dt, sizeof(fn_status->FN_doc_dt)));

cleanup:
  if (ret < 0) {
    return paykiosk_perror("GetFnStatus", ret);
  }
  return ret;
}


/// \brief Получаем табличные параметры ФН
static int paykiosk_get_FN_params(paykiosk_t* me, kkt_state_t* params, fn_state_t* fn_status)
{
  int ret; // Для CHECK_OK
  if (!fn_status) {
    return -EINVAL;
  }

  // \todo Возможно, здесь следует читать все параметры не смотря на ошибки.

  // Читаем ИНН пользователя из ФН
  strncpy_ex(params->inn, "", sizeof(params->inn));
  CHECK_OK(paykiosk_read_table(me, PAYKIOSK_TABLE_18, 1, 2, params->inn, sizeof(params->inn)));

  // Читаем заводской номер ККТ
  strncpy_ex(fn_status->FN_kkt_sn, "", sizeof(fn_status->FN_kkt_sn));
  CHECK_OK(paykiosk_read_table(me, PAYKIOSK_TABLE_18, 1, 1, fn_status->FN_kkt_sn, sizeof(fn_status->FN_kkt_sn)));

  // Читаем RNM номер ККТ
  strncpy_ex(fn_status->FN_kkt_rnm, "", sizeof(fn_status->FN_kkt_rnm));
  CHECK_OK(paykiosk_read_table(me, PAYKIOSK_TABLE_18, 1, 3, fn_status->FN_kkt_rnm, sizeof(fn_status->FN_kkt_rnm)));

  // Читаем заводской номер ФН
  strncpy_ex(fn_status->FN_sn, "", sizeof(fn_status->FN_sn));
  CHECK_OK(paykiosk_read_table(me, PAYKIOSK_TABLE_18, 1, 4, fn_status->FN_sn, sizeof(fn_status->FN_sn)));

  // Читаем заводской номер ТА
  strncpy_ex(fn_status->FN_ta_sn, "", sizeof(fn_status->FN_ta_sn));
  CHECK_OK(paykiosk_read_table(me, PAYKIOSK_TABLE_24, 1, 1, fn_status->FN_ta_sn, sizeof(fn_status->FN_ta_sn)));

  return 0;

cleanup:
  if (ret < 0) {
    return paykiosk_perror("GetFnParams", ret);
  }
  return ret;
}

// Получить адрес ОФД
static int paykiosk_get_OFDserv(paykiosk_t* me, char * OFDserv, size_t size)
{
  return paykiosk_read_table(me, PAYKIOSK_TABLE_19, 1, 1, OFDserv, size);
}

// Получить порт ОФД
static int paykiosk_get_OFDport(paykiosk_t* me, uint16_t * OFDport)
{
  return paykiosk_read_table(me, PAYKIOSK_TABLE_19, 1, 2, OFDport, sizeof(uint16_t));
}

//
// // Процедура инициализации принтера
// bool paykiosk_init_printer(paykiosk_t* me, int evadts_channel, bool raw_log)
// {
//   log_func();
//   bool ok=false;
//   _kkm_bus_param kkm_bus;
//   const _kkm_bus_param bus[]={{PAYKIOSK, 115200},
//                             {PAYKIOSK_PPP, 115200},
//                             {PAYKIOSK, 4800},
//                             {PAYKIOSK, 9600},
//                             {PAYKIOSK, 19200},
//                             {PAYKIOSK, 38400},
//                             {PAYKIOSK, 57600},
//                             {PAYKIOSK, 2400}};
//   uint16_t count=0;
//   #define MAX_COUNT (sizeof(bus)/sizeof(bus[0]))
//   do{
//     me->kkm_bus.bus_type=bus[count].bus_type;
//     kkm_bus.bus_type=bus[count].bus_type;
//     /// Сделал автопоиск принтера с перебором допустимых скоростей
//     kkm_bus.baudrate=bus[count].baudrate;
//     //me->psw=PAYKIOSK_DEFAULT_PSW;//Change_BL_Endian_UINT32(PAYKIOSK_DEFAULT_PSW);
//     me->psw=atoi(g_settings.printer_psw);//PAYKIOSK_DEFAULT_PSW;//Change_BL_Endian_UINT32(PAYKIOSK_DEFAULT_PSW);
//     //log_debug("printer password [%d]", me->psw);
//     // Инициализируем порт
//     if ((me) && (kkm_init_port(&kkm_bus,evadts_channel,raw_log))) ok=true;
//     // Открываем порт на работу
//     if (ok)
//     {
//         ok=false;
//         if (kkm_open_port())
//         {
//             ok=false;
//             uint8_t data[40];
//             size_t len;
//             paykiosk_hdr_cmd_t* ptr_cmd=(paykiosk_hdr_cmd_t*)data;
//             paykiosk_hdr_rsp_t*  ptr_resp=(paykiosk_hdr_rsp_t*)data;
//             paykiosk_cmdFC_t*      rspFC=(paykiosk_cmdFC_t*)(ptr_resp+1);
//             uint8_t* end=NULL;
//             // У этой команды нет пароля
//             //ptr_cmd->psw=me->psw;
//             // Запрос тип устройства
//             ptr_cmd->cmd=PAYKIOSK_CMD_FC;
//             end=paykiosk_get_data(data,sizeof(ptr_cmd->cmd),sizeof(data),NULL, true, 30000, NULL, NULL);
//             // Закрываем порт
// #ifdef CFG_FW_TCPIP
//             if (me->kkm_bus.bus_type!=PAYKIOSK_PPP)
// #endif
//             kkm_close_port();
//             if ((end) && (ptr_resp->cmd==PAYKIOSK_CMD_FC) && (((end-data)-sizeof(paykiosk_hdr_rsp_t))>=sizeof(paykiosk_cmdFC_t)))
//             {
//                 me->params=&me->params;
//                 me->type=rspFC->type;
//                 switch ((kkmtype_paykiosk_t)me->type)
//                 {
//                     case KKMTYPE_PAYONLINE_01 :
//                         // Копируем название устройства
//                         len=min_u32(sizeof(paykiosk_name),(end-data)-sizeof(paykiosk_hdr_rsp_t)-sizeof(paykiosk_cmdFC_t));
//                         if (me->params.name) strncpy_ex(me->params.name,(char*)(rspFC+1),len);
//                         /// Сброс последней ошибки
//                         me->params.last_error_code=0;
//                         me->params.last_cmd=0;
//                         /// Определяем серийный номер аппарата
// #ifdef CFG_FW_TCPIP
//                         if (me->kkm_bus.bus_type==PAYKIOSK_PPP)
//                             ok=paykiosk_check_printer(me, NULL, DONT_OPENCLOSE_PORT);
//                         else
// #endif
//                         ok=paykiosk_check_printer(me, NULL, OPENCLOSE_PORT);
//                         if (ok) me->status=KKM_INITED;
//                         else me->status=KKM_ERROR;
//                         // Выходим из инициализации
//                         count=MAX_COUNT;
//                         break;
//                     // Другие аппараты пока не поддердживаем
//                     default :
//                         break;
//                 }
//             }
//         }
//     }
//     /// В случае ошибки, порт закрываем.
//     if (!ok)
//     {
//         kkm_deinit_port();
//         me->kkm_bus.bus_type=BUS_UNK;
//         delay_ms(300);
//     }
//   }while ((!ok) && (++count<MAX_COUNT));
//   log_info("Current bus type [%d], status %d", me->kkm_bus.bus_type, me->status);
//   log_func_result(ok);
//   return(ok);
// }
//
// // Процедура деинициализации принтера
// void paykiosk_deinit_printer(paykiosk_t* me)
// {
//     log_func();
//     if ((me) && (me->status!=KKM_NOT_INSTALL) && ((me->kkm_bus.bus_type==PAYKIOSK) || (me->kkm_bus.bus_type==PAYKIOSK_PPP)))
//     {
//         me->params=NULL;
//         me->fn_status=NULL;
//         me->status=KKM_NOT_INSTALL;
//         me->kkm_bus.bus_type=BUS_UNK;
//         kkm_deinit_port();
//     }
// }

// Получение дополнительных параметров от ККТ
int paykiosk_get_additional_params(paykiosk_t* me)
{
  int ret; // Нужен для CHECK_OK

  kkt_state_t*  state     = kkt_state(me);
  fn_state_t*   fn_state  = kkt_fn_state(me);

  // Пытаемся получить параметры ФН
  CHECK_OK(paykiosk_get_FN_params(me, state, fn_state));

  // Пытаемся получить параметры ОФД
  // Читаем имя или IP сервера ОФД
  CHECK_OK(paykiosk_get_OFDserv(me, state->OFDserv, sizeof(state->OFDserv)));

  // Читаем TCP порт сервера ОФД
  CHECK_OK(paykiosk_get_OFDport(me, &state->OFDport));

  // Читаем статус ФН
  CHECK_OK(paykiosk_get_FN_status(me, fn_state));
  kkt_set_has_fn_state(me, true);
  ret = 0;

cleanup:
  if (ret < 0) {
    return paykiosk_perror("GetAddParams", ret);
  }
  return ret;
}

//


/// \brief Подключение к ККТ через сокет поверх PPP-over-Serial
static int paykiosk_connect_pppos(
  paykiosk_t* me, const char* ttypath, speed_t baudrate
)
{
  int                 ret;
  struct sockaddr_in  endpoint;

  DEBUGASSERT(!me->pppd_created);
  ret = paykiosk_pppd_create(&me->pppd, ttypath, baudrate);
  if (ret < 0) {
    goto cleanup_on_error;
  }
  me->pppd_created = true;

  ret = paykiosk_pppd_connect(
    &me->pppd, CONFIG_PAYKIOSK_PPP_CONNECT_TIMEOUT_MS
  );
  if (ret < 0) {
    goto cleanup_on_error;
  }

  endpoint.sin_family = AF_INET;
  endpoint.sin_port   = htons(kkt_params(me)->printer_tcp_port);
  ret = paykiosk_pppd_get_kkt_ip(&me->pppd, &endpoint.sin_addr);
  if (ret < 0) {
    goto cleanup_on_error;
  }

  me->timeout_discard_ms  = PAYKIOSK_WAIT_BYTE;
  me->timeout_getc_ms     = PAYKIOSK_WAIT_TCP;
  me->timeout_enq_ms      = PAYKIOSK_WAIT_TCP;

  ret = kktport_open_socket_sa(
    me, &endpoint, CONFIG_PAYKIOSK_SOCKET_CONNECT_TIMEOUT_MS
  );

  if (ret < 0) {
    kkt_error(
      "Can't connect through PPP over serial '%s', ret=%d (%s)\n",
      ret,
      strerror(-ret)
    );
    goto cleanup_on_error;
  }
  return 0;


cleanup_on_error:
  paykiosk_pppd_destroy(&me->pppd);
  me->pppd_created = false;

  return ret;
}

/// \brief Подключeние к ККТ через последовательный порт
static int paykiosk_connect_serial(
  paykiosk_t* me, const char* ttypath, speed_t baudrate
)
{
  int ret;
  kkt_trace("Opening %s...\n", ttypath);
  me->timeout_discard_ms  = PAYKIOSK_WAIT_BYTE;
  me->timeout_getc_ms     = PAYKIOSK_WAIT_BYTE;
  me->timeout_enq_ms      = PAYKIOSK_WAIT_BYTE;

  ret = kktport_open_file(me, ttypath);
  if (ret < 0) {
    kkt_error(
      "Can't open KKT on port '%s', ret=%d (%s)\n",
      ttypath,
      ret,
      paykiosk_strerror(-ret)
    );
    return ret;
  }

  // Порт открыт.
  // Если используется AUX порт, то требуется настроить его на режим RS232
  // и требуемую скорость.
  aux_settings_t  aux_settings = {
    .protocol   = AUX_PROTOCOL_RS232,
    .direction  = AUX_DIRECTION_NORMAL,
    .extra      = AUX_EXTRA_NONE,
    .inverted   = false
  };
  ret = kktport_set_aux_params(me, &aux_settings);
  if (ret < 0) {
    kkt_warn("set_aux_params fail, ret=%d (%s)\n", ret, paykiosk_strerror(-ret));
    // Не выходим, т.к. используемый порт может не поддерживать расширенные AUX команды
  }

  ret = kktport_set_comm_params(
    me, baudrate, SERIAL_WORDLEN_8_BIT, SERIAL_PARITY_NONE, SERIAL_FLOWCTL_NONE
  );
  if (ret < 0) {
    kkt_error("set_comm_params fail, ret=%d (%s)\n", ret, paykiosk_strerror(-ret));
    goto cleanup_on_error;
  }

cleanup_on_error:
  kktport_close(me);
  return ret;
}

////////////////////////////////////////////////////////////////////////////
//  Реализация высокоуровневых функций интерфейса с принтером

// Процедура инициализации принтера
static int paykiosk_init_printer(
  paykiosk_t*         me,
  paykiosk_conntype_t conntype,
  speed_t             baudrate
)
{
  int ret;
  // битрейт здесь просто кастуем, без преобразования - при необходимости
  // можно посмотреть в исходниках, какой Bxxx константе соответствует
  // выведенное в лог значение.
  kkt_trace(
    "%s(%s,%u)\n",
    __FUNCTION__,
    paykiosk_conntype_to_string(conntype),
    (unsigned)baudrate
  );

  if (!me) {
    return -EINVAL;
  }

  switch (conntype) {
  case PAYKIOSK_CONNTYPE_PPPOS:
    ret = paykiosk_connect_pppos(me, kkt_ttypath(me), baudrate);
    break;
  case PAYKIOSK_CONNTYPE_SERIAL:
    ret = paykiosk_connect_serial(me, kkt_ttypath(me), baudrate);
    break;
  default:
    ret = -EINVAL;
    break;
  }

  if (ret < 0) {
    return ret;
  }
  me->conntype = conntype;

  uint8_t data[40];
  paykiosk_cmdFC_t*      rspFC=(paykiosk_cmdFC_t*)data;

  // Запрос тип устройства
  kkt_trace("Probing paykiosk type...\n");
  ret = paykiosk_cmd(me, PAYKIOSK_CMD_FC, NULL, 0, data, sizeof(data), 30000);
  if (ret < 0) {
    kkt_error("Can't get cmdFC, ret=%d (%s)\n", ret, paykiosk_strerror(-ret));
    goto cleanup_on_error;
  }

  if (ret < sizeof(paykiosk_cmdFC_t)) {
    kkt_error("rspFC too short\n");
    ret = -EILSEQ;
    goto cleanup_on_error;
  }

  kkt_trace(
    "rspFC: { type:%d, subtype:%d, proto_ver:%d.%d, model:%d, lang:%d, name=\"%s\" }\n",
    rspFC->module_type,
    rspFC->module_subtype,
    rspFC->module_ver_protocol,
    rspFC->module_subver_protocol,
    rspFC->type,
    rspFC->lang,
    (char*)(rspFC+1)
  );

  me->type=rspFC->type;
  if (me->type != KKMTYPE_PAYONLINE_01) {
    // Пока что поддерживается только PAYONLINE,
    // В дальнейшем стоит разделить на 2 объекта:
    // протокол обмена и протокол поддержки конкретного ККМ.
    kkt_error("Unsupported device: type=%d\n", rspFC->type);
    ret = -EPROTO;
    goto cleanup_on_error;
  }

  // Копируем название устройства
  kkt_state_t* state = kkt_state(me);
  snprintf(state->name, sizeof(state->name), "%s", rspFC+1);

  /// Сброс последней ошибки
  paykiosk_save_error(me, 0, 0);

  /// Определяем серийный номер аппарата
  ret = paykiosk_check_printer(me);
  if (ret < 0) {
    paykiosk_perror("check_printer", ret);
    goto cleanup_on_error;
  }

  kkt_info("InitPrinter completed\n");
  return 0;

cleanup_on_error:
  kktport_close(me);

  if (conntype == PAYKIOSK_CONNTYPE_PPPOS && me->pppd_created) {
    paykiosk_pppd_destroy(&me->pppd);
    me->pppd_created = false;
  }
  return ret;
} // paykiosk_init_printer


/// \retval 0     Успешно инициализировано
/// \retval 1     ККМ был изменён
/// \retval `< 0` Ошибка
int paykiosk_cmd11_get_dev_state(paykiosk_t* me)
{
  paykiosk_cmd11_t response;

  memset(&response, 0, sizeof(response));

  kkt_trace("Reading dev state...\n");
  int ret = paykiosk_cmd(
    me,
    PAYKIOSK_CMD_11,
    NULL,
    0,
    &response,
    sizeof(response),
    2000
  );

  if (ret < 0) {
    return ret;
  }

  kkt_trace(
    "DevState: {\n"
    " kass_num:%u,\n"
    " fw_vers:\"%c.%c.%u\",\n"
    " fw_date:\"20%02d-%02d-%02d\",\n"
    " room:%u,\n"
    " doc:%u,\n"
    " flags:%#04X,\n"
    " mode:\"%d.%d\",\n"
    " port:%d,\n"
    " clock:\"20%02d-%02d-%02d %02d:%02d:%02d\",\n"
    " serial:%" PRIu32 ",\n"
    " serial_hi:%u,\n"
    " close_num:%u,\n"
    " reregist_cnt:%u,\n"
    " reregist_rest_cnt:%u\n"
    " inn: [%#X,%#X,%#X,%#X,%#X,%#X],\n"
    "}\n",

    response.kass_num,
    ((char*)&response.fw_version)[0],
      ((char*)&response.fw_version)[1],
      response.fw_build,
    response.fw_date.year, response.fw_date.month, response.fw_date.day,
    response.room_num,
    response.doc_num,
    response.kkt_flags,
    response.kkt_mode, response.kkt_submode,
    response.kkt_port,
    response.clock.year, response.clock.month, response.clock.day,
      response.clock.hour, response.clock.min, response.clock.sec,
    response.kkt_serial,
    response.kkt_serial_hi,
    response.close_num,
    response.reregist_count,
    response.reregist_rest_count,
    response.inn[0],response.inn[1],response.inn[2],
      response.inn[3],response.inn[4],response.inn[5]
  );
  // Разбор данных и сохранение в экземпляре объекта

  /// Разбираем response. Возьмем от туда часы и время для синхронизации своих часов
  // Запомнили ИНН
  // size_t len=min_u32(sizeof(me->params.inn), sizeof(response.inn));
  // memcpy(me->params.inn, response.inn, len);
  // Запомнили флаги принтера
  kkt_state_t* state = kkt_state(me);

  state->flags   = response.kkt_flags;
  state->mode    = response.kkt_mode;
  state->submode = response.kkt_submode;
  // Версия ПО принтера
  state->FW_version    = response.fw_version;
  state->FW_build      = response.fw_build;
  state->FW_date.day   = response.fw_date.day;
  state->FW_date.month = response.fw_date.month;
  state->FW_date.year  = response.fw_date.year;
  // Информация о перерегистрациях
  state->rereg      = response.reregist_count;
  state->rereg_rest = response.reregist_rest_count;
  // Дата и время
  state->KKT_date_time.day   = response.clock.day;
  state->KKT_date_time.month = response.clock.month;
  state->KKT_date_time.year  = response.clock.year;
  state->KKT_date_time.hour  = response.clock.hour;
  state->KKT_date_time.min   = response.clock.min;
  state->KKT_date_time.sec   = response.clock.sec;

  ret = 0;
  if (me->status == KKM_INITED
      && (state->sn != response.kkt_serial
          || state->sn_hi != response.kkt_serial_hi)
  ) {
    // Смена ККТ
    ret = 1;
  }

  // Сохранили серийный номер ККТ
  state->sn    = response.kkt_serial;
  state->sn_hi = response.kkt_serial_hi; // если данных меньше, то == 0 из-за memset

  return ret;
}

int paykiosk_update_dev_state(paykiosk_t* me)
{
  int ret = paykiosk_cmd11_get_dev_state(me);
  if (ret < 0) {
    return ret;
  }

  kkt_state_t* state = kkt_state(me);

  // проверяем наличие кассовой ленты.
  if (!(state->flags & PRINTER_OPTIC_PAPER_ON)) {
    // Бумаги нет! Отключаем вывод чеков на печать.
    kkt_set_paperstate(me, KKT_PAPER_ERROR);
    kkt_trace("No paper. Disabling printing...\n");
    ret = paykiosk_printdoc_off(me, PAYKIOSK_PRINTDOC_OFF);
    if (ret < 0) {
      // И не удалось отключить печать.
      paykiosk_perror("Disable printing", ret);
      return -PAYKIOSK_ERR_6B;
    }

    // Бумаги нет, но успешно отключили вывод чеков на печать
    // поэтому только предупреждение.
    kkt_set_paperstate(me, KKT_PAPER_WARNING);

  } else {
    // Бумага есть.

    // Пока не проверили состояние документа, считаем,
    // что состояние бумаги = предупреждение
    kkt_set_paperstate(me, KKT_PAPER_OK);

    // Возобновим печать чеков, если ещё не включена
    CHECK_OK(paykiosk_get_printdoc(me, &state->doc_mode));

    if (state->doc_mode != PAYKIOSK_PRINTDOC_ON_ALWAYS) {
      kkt_trace("Paper ok. Enabling printing...\n");
      CHECK_OK(paykiosk_printdoc_off(me, PAYKIOSK_PRINTDOC_ON_ALWAYS));
    }
  }


  // Определяем режим работы ККТ.
  if (state->mode == PAYKIOSK_KKT_MODE_3) {
    // Смена закончилась. Нужно закрыть ее
    kkt_info("Work shift hours ended. Closing it\n");
    // Отключаем вывод на печать
    if ((state->flags & PRINTER_OPTIC_PAPER_ON)) {
      ret = paykiosk_printdoc_off(me, PAYKIOSK_PRINTDOC_OFF_NEXT_DOC);
    }

    // Закрываем смену
    ret = paykiosk_shift_close_cmd(me);
    if (ret == -PAYKIOSK_ERR_58) {
      // Пытаемся продолжить печать чека (чек уже в ФН и другого выхода нет, надо
      // установить ленту)
      ret = paykiosk_resume_print(me);
    }

    if (ret == -PAYKIOSK_ERR_14) {
      kkt_trace("paykiosk_shift_close_cmd Ignored err 0x14\n");
      ret = 0;
    }
    if (ret < 0) {
      goto cleanup;
    }
  }


  kkt_pay_t dummy_total;
  switch (state->mode) {
  case PAYKIOSK_KKT_MODE_3:
  case PAYKIOSK_KKT_MODE_4: // Предыдущая смена завершена. Необходимо открыть новую.
    kkt_info("Opening new work shift\n");
    // Отключаем вывод на печать
    if ((state->flags & PRINTER_OPTIC_PAPER_ON)) {
      ret = paykiosk_printdoc_off(me, PAYKIOSK_PRINTDOC_OFF_NEXT_DOC);
    }
    // Открываем смену
    ret = paykiosk_shift_open_cmd(me);
    if (ret == -PAYKIOSK_ERR_58) {
      // Пытаемся продолжить печать чека (чек уже в ФН и другого выхода нет, надо
      // установить ленту)
      ret = paykiosk_resume_print(me);
    }

    if (ret == PAYKIOSK_OK) {
      state->mode = PAYKIOSK_KKT_MODE_2;
    } else if (ret == -PAYKIOSK_ERR_14) {
      log_error("paykiosk_shift_open_cmd: error level = 0x%X", ret);
      ret = PAYKIOSK_OK;
    }
    break;


  case PAYKIOSK_KKT_MODE_8: // Есть открытый документ
    kkt_info("Have unclosed order. Closing...\n");
    dummy_total = (kkt_pay_t) {
      .summ = {
        .value    = PAYKIOSK_MAX_PAY,
        .dot      = 1,
        .currency = CURRENCY_ANY
      },
      .paytype = KKT_PAYTYPE_CASH
    };

    ret = paykiosk_order_close((kkt_t*)me, &dummy_total);
    switch (ret) {
    case -PAYKIOSK_ERR_45:   // Итог больше закрытия
      dummy_total.summ.value = PAYKIOSK_MAX_PAY * 3;
      ret = paykiosk_order_close((kkt_t*)me, &dummy_total);
      break;

    case -PAYKIOSK_ERR_58:   // Требует продолжения печати
      // Пытаемся продолжить печать чека (чек уже в ФН и другого выхода нет, надо
      // установить ленту)
      ret = paykiosk_resume_print(me);

    case -PAYKIOSK_ERR_02:   // Неверное состояние ФН
      // Пытаемся анулировать чек (чек не попал в ФН и можно его отбросить с повтором
      // вывода в ФН без печати)
      ret = paykiosk_abort_print(me);
      break;

    case -PAYKIOSK_ERR_50:   //  Идет печать результатов выполнения предыдущей команды
      ret = PAYKIOSK_OK;
      break;

    case -PAYKIOSK_ERR_14:   // Требуется срочная передача данных в ОФД
      ret = PAYKIOSK_OK;
      break;

    default:
      break;
    }
    break;

  default:
    // Проверим подрежим
    if (state->submode == PAYKIOSK_KKT_SUBMODE_3) {
      /// Пытаемся продолжить печать чека (чек уже в ФН и другого выхода нет, надо
      /// установить ленту)
      ret = paykiosk_resume_print(me);
      /// Пытаемся анулировать чек (чек не попал в ФН и можно его отбросить с повтором
      /// вывода в ФН без печати)
      ret = paykiosk_abort_print(me);
    } else {
      ret = PAYKIOSK_OK;
    }

    if (ret == -PAYKIOSK_ERR_14) {
      ret = PAYKIOSK_OK;
    }
    break;
  }

cleanup:
  return ret;
}

/// \brief Проверка наличия принтера
static int paykiosk_check_printer(paykiosk_t* me)
{
  //log_func();
  int                   ret;

  // Запрос состояния ККТ
  ret = paykiosk_update_dev_state(me);
  if (!PAYKIOSK_IS_KKTERROR(ret)) {
    return ret;
  }

  ///  Запрашиваем дополнительные параметры
  ret = paykiosk_get_additional_params(me);

  // Закрываем работу с портом
  // if (openclose_port)
  //   kkm_close_port();

  return ret;
}





////////////////////////////////////////////////////////////////////////////
//  Реализация методов интерфейса kkt_t

static const kkt_caps_t* paykiosk_get_caps(kkt_t* kkt)
{
  // В данном драйвере все параметры захардкожены.
  static const kkt_caps_t PAYKIOSK_CAPS = {
    .can_print_item             = true, // Может печатать строку с товаром
    .can_print_text             = true, // Может печатать произвольный текст
    .can_print_image            = true, // Может печатать графику
    .can_print_leading_banner   = true, // Допускает печать баннера перед телом чека
    .can_print_trailing_banner  = true, // Допускает печать баннера после тела чека (после закрытия чека)
    .can_cut                    = true, // Может отрезать чек
    .has_fn                     = true, // Имеет фискальный накопитель
    .has_ofd_interface          = true, // Может соединяться с ОФД сервером

    .paper_width_chars          = -1,   // Ширина бумаги в символах, -1 = неизвестно
    .paper_width_dots           = -1,   // Ширина бумаги в точках (при печати графики), -1 = неизвестно
    .line_length                = 40,   // Максимальное количество символов в одной команде печати строки.
  };
  return &PAYKIOSK_CAPS;
}


static int paykiosk_destroy(kkt_t* kkt)
{
  paykiosk_t* me = (paykiosk_t*)kkt;
  kkt_trace("%s\n", __FUNCTION__);
  kktport_set_crc_rx(me, NULL);
  kktport_set_crc_tx(me, NULL);
  kktport_set_txbuf(me, NULL, 0, SMARTIO_BUFOVF_FAIL_ON_WRITE);
  smartio_crcxor_destroy(&me->txcrc);
  smartio_crcxor_destroy(&me->rxcrc);
  return 0;
}


static int paykiosk_init(kkt_t* kkt)
{
  static const struct iface_var_s {
    paykiosk_conntype_t   conntype;
    speed_t               baudrate;
  } VARIANTS[] = {
    { .conntype = PAYKIOSK_CONNTYPE_SERIAL, .baudrate = B115200 },
    { .conntype = PAYKIOSK_CONNTYPE_PPPOS,  .baudrate = B115200 },
    { .conntype = PAYKIOSK_CONNTYPE_SERIAL, .baudrate = B4800 },
    { .conntype = PAYKIOSK_CONNTYPE_SERIAL, .baudrate = B9600 },
    { .conntype = PAYKIOSK_CONNTYPE_SERIAL, .baudrate = B19200 },
    { .conntype = PAYKIOSK_CONNTYPE_SERIAL, .baudrate = B38400 },
    { .conntype = PAYKIOSK_CONNTYPE_SERIAL, .baudrate = B57600 },
    { .conntype = PAYKIOSK_CONNTYPE_SERIAL, .baudrate = B2400 },
  };

  int         ret;
  paykiosk_t* me = (paykiosk_t*)kkt;

  kkt_trace("%s\n", __FUNCTION__);

  for (size_t i=0; i < sizeof(VARIANTS)/sizeof(*VARIANTS); ++i) {
    ret = paykiosk_init_printer(me, VARIANTS[i].conntype, VARIANTS[i].baudrate);
    if (ret >= 0) {
      return 0;
    }
  }

  return -ENODEV;
}

static int paykiosk_deinit(kkt_t* kkt)
{
  int         ret;
  paykiosk_t* me = (paykiosk_t*)kkt;

  kkt_trace("%s\n", __FUNCTION__);

  ret = kktport_close(me);
  if (ret < 0) {
    kkt_warn("Can't close port, ret=%d (%s)\n", ret, strerror(-ret));
  }

  if (me->conntype == PAYKIOSK_CONNTYPE_PPPOS && me->pppd_created) {
    int ret2 = paykiosk_pppd_destroy(&me->pppd);
    if (ret2 < 0) {
      kkt_warn("Can't destroy ppp, ret=%d (%s)\n", ret, strerror(-ret));
    }
    me->pppd_created = false;
  }
  return ret;
}

static const char* paykiosk_bus_name(kkt_t* kkt)
{
  paykiosk_t* me = (paykiosk_t*)kkt;
  return me->conntype == PAYKIOSK_CONNTYPE_PPPOS
         ? "PAYKIOSK_PPP"
         : "PAYKIOSK";
}

static int paykiosk_status_check(kkt_t* kkt)
{
  int                 ret;
  paykiosk_t*         me = (paykiosk_t*)kkt;
  //kkt_state_t        bak_params = me->params;

  ret = paykiosk_check_printer(me);
  if (ret < 0) {
    return ret;
  }

  // В текущей реализации, правила NAT создаются и удаляются динамически.
  // дополнительные действия не требуются. В предыдущей же версии ПО
  // тут было удаление правила NAT если изменился сервер ОФД.
  // При необходимости восстановить этот функционал,
  // см файл printer.c функцию PrinterCheckStatus
  return 0;
}

static int paykiosk_datetime_get(kkt_t* kkt, struct timespec* dst)
{
  if (!kkt || !dst) {
    return -EINVAL;
  }

  // Отдельной команды получения даты/времени нет.
  // Возвращаем время ККТ, полученное при последнем запросе состояния принтера
  paykiosk_t*         me = (paykiosk_t*)kkt;
  kkt_state_t*        p = kkt_state(me);
  struct tm           t;

  // поле year хранит 2 младшие цифры года, а tm_year - количество лет после 1900
  t.tm_year = p->KKT_date_time.year + 2000 - 1900;

  // поле tm_mon хранит количество месяцов после января (т.е. январь=0)
  t.tm_mon  = p->KKT_date_time.month - 1;

  // Остальные поля соответствуют друг другу.
  t.tm_mday = p->KKT_date_time.day;
  t.tm_hour = p->KKT_date_time.hour;
  t.tm_min  = p->KKT_date_time.min;
  t.tm_sec  = p->KKT_date_time.sec;

  dst->tv_sec   = mktime(&t);
  dst->tv_nsec  = 0;
  return 0;
}

static int paykiosk_order_open(kkt_t* kkt)
{
  paykiosk_t*         me = (paykiosk_t*)kkt;

  log_func();
  struct  __attribute__((packed)) _paykiosk_cmd_8d {
    uint8_t doc_type;           // Тип документа
  };

  int                       ret;
  uint8_t                   response[4];
  struct _paykiosk_cmd_8d   cmd_8d = {
    .doc_type = PAYKIOSK_DOCTYPE_INPUT
  };

  ret = paykiosk_cmd(
    me,
    PAYKIOSK_CMD_8D,
    &cmd_8d,
    sizeof(cmd_8d),
    &response,
    sizeof(response),
    PAYKIOSK_CMD_DEF_TIMEOUT_MS
  );

  if (ret >= 0) {
  // Ошибки нет
    return 0;
  }

  paykiosk_perror("CMD8D", ret);

  if (ret == PAYKIOSK_ERR_58) {
    // Завершаем печать
    ret=paykiosk_resume_print(me);
    /// Пытаемся анулировать чек (чек не попал в ФН и можно его отбросить с повтором вывода в ФН без печати)
    ret=paykiosk_abort_print(me);
  }

  usleep(1000000);

  if (ret == PAYKIOSK_ERR_50) {
    // Идет печать документа. Нужно подождать
    usleep(3000000);
  }

  ret = paykiosk_check_printer(me);
  if (ret < 0) {
    return ret;
  }

  // ещё одна попытка
  ret = paykiosk_cmd(
    me,
    PAYKIOSK_CMD_8D,
    &cmd_8d,
    sizeof(cmd_8d),
    &response,
    sizeof(response),
    PAYKIOSK_CMD_DEF_TIMEOUT_MS
  );

  if (ret < 0) {
    return paykiosk_perror("CMD8D", ret);
  }
  return 0;
}

static int paykiosk_order_close(kkt_t* kkt, const kkt_pay_t* total_payment)
{
  // Закрыть чек
  paykiosk_t* me = (paykiosk_t*)kkt;
  uint8_t     data[255];

  struct  __attribute__((packed)) paykiosk_cmd85_s{
    uint32_t summ1;
    uint8_t  summ1_hi;
    uint32_t summ2;
    uint8_t  summ2_hi;
    uint32_t summ3;
    uint8_t  summ3_hi;
    uint32_t summ4;
    uint8_t  summ4_hi;
    int16_t  diskont;        // -9999..9999 0-99.99%
    uint8_t  tax1;
    uint8_t  tax2;
    uint8_t  tax3;
    uint8_t  tax4;
    char     text[40];
  };
  struct paykiosk_cmd85_s* cmd85=(struct paykiosk_cmd85_s*)data;

  if (!total_payment) {
    return -EINVAL;
  }

  // Заполняем поля
  memset(cmd85, 0, sizeof(*cmd85));

  uint64_t  mde = total_payment->summ.value * PAYKIOSK_MDE / total_payment->summ.dot;
  uint32_t  mde_low = (uint32_t)(mde & 0xFFFFFFFF);
  uint8_t   mde_hi  = (uint8_t)((mde >> 32) & 0xFF);

  if (mde > 9999999999ull) {
    kkt_warn("total_payment > 9999999999\n");
  }

  if (total_payment->paytype == KKT_PAYTYPE_CASH || total_payment->paytype == KKT_PAYTYPE_ANY) {
    cmd85->summ1    = mde_low;
    cmd85->summ1_hi = mde_hi;
  } else if (total_payment->paytype == KKT_PAYTYPE_CASHLESS) {
    cmd85->summ2    = mde_low;
    cmd85->summ2_hi = mde_hi;
  } else {
    return -EINVAL;
  }

  // В идеале, ещё проверить тип валюты переменной summ.

  cmd85->tax1=me->nalog;
  cmd85->tax2=me->nalog;
  cmd85->tax3=me->nalog;
  cmd85->tax4=me->nalog;

  ssize_t ret = paykiosk_cmd(me, PAYKIOSK_CMD_85, cmd85, sizeof(*cmd85), data, sizeof(data), PAYKIOSK_CMD_DEF_TIMEOUT_MS);
  if (ret < 0) {
    paykiosk_perror("CMD85", ret);
    if (ret == PAYKIOSK_ERR_58) {
      // Завершаем печать
      ret=paykiosk_resume_print(me);
      /// Пытаемся анулировать чек (чек не попал в ФН и можно его отбросить с повтором вывода в ФН без печати)
      ret=paykiosk_abort_print(me);
    }
    return ret;
  }

  // Ошибки нет
  // Возвращают порядковый номер кассира - 1 байт
  // Сдачу
  // Вебссылку 247 байт


  // По-хорошему, тут стоит дожидаться окончания печати
  return 0;
}

static int paykiosk_order_reg(kkt_t* kkt, const kkt_money_t* price, thousandths_t quant, const char* name, uint16_t section)
{
  // Регистрация продажи в открытый чек
  log_func();

  struct __attribute__((packed)) _paykiosk_cmd_80 {
    uint32_t quant;
    uint8_t  quant_hi;
    uint32_t summ;
    uint8_t  summ_hi;
    uint8_t  section;
    uint8_t  tax1;
    uint8_t  tax2;
    uint8_t  tax3;
    uint8_t  tax4;
    char     text[40];
  };

  int                       ret;
  struct _paykiosk_cmd_80   cmd_80;
  uint8_t                   response[4];
  paykiosk_t*               me = (paykiosk_t*)kkt;

  // Поскольку количество передаётся в функцию в тысячных долях (т.е. для 1.0 quant=1000)
  // то стоимость = цена*количество/1000,
  // после пересчёта из системных денежных единиц в денежные единицы PAYKIOSK получим
  uint64_t  summ = (uint64_t)price->value * quant * PAYKIOSK_MDE  / (price->dot * 1000);

  if ((summ & 0xFFFFFF0000000000) != 0) {
    kkt_error("PAYKIOSK: Summ is more than 40 bits\n");
  }
  /// Формиоруем поля продажи
  // количество товара
  cmd_80.quant    = quant;
  cmd_80.quant_hi = 0;
  // стоимость товара
  cmd_80.summ     = (uint32_t)(summ & 0xFFFFFFFF);
  cmd_80.summ_hi  = (uint8_t)((summ >> 32) & 0x0F);
  // номер отдела
  cmd_80.section  = section;
  // налоги
  cmd_80.tax1     = me->nalog;
  cmd_80.tax2     = me->nalog;
  cmd_80.tax3     = me->nalog;
  cmd_80.tax4     = me->nalog;

  // наименование товара
  if (!name) {
    name = "Продукт";
  }

  ret = snprintf(cmd_80.text, sizeof(cmd_80.text), "%s", name);
  if (ret >= sizeof(cmd_80.text)) {
    kkt_warn("PAYKIOSK: Item name is too large\n");
  }

  ret = paykiosk_cmd(
    me,
    PAYKIOSK_CMD_80,
    &cmd_80,
    sizeof(cmd_80),
    &response,
    sizeof(response),
    PAYKIOSK_CMD_DEF_TIMEOUT_MS
  );
  if (ret < 0) {
    return paykiosk_perror("CMD80", ret);
  }

  // Ошибки нет
  // Возвращают порядковый номер кассира - 1 байт
  return 0;
}


static int paykiosk_order_cut(kkt_t* kkt)
{
  int           ret;
  paykiosk_t*   me        = (paykiosk_t*)kkt;
  uint8_t       cut_type  = 0x01; // 1 = неполная отрезка чека
  uint8_t       oper_num;

  ret = paykiosk_cmd(
    me, PAYKIOSK_CMD_25, &cut_type, 1, &oper_num, 1, PAYKIOSK_CMD_DEF_TIMEOUT_MS
  );
  if (ret < 0) {
    return paykiosk_perror("CMD25", ret);
  }
  return 0;
}

static int paykiosk_print_string(kkt_t* kkt, const char* str)
{
  // Печать произвольной строки (обычным шрифтом)
  struct __attribute__((packed)) _paykiosk_cmd_17 {
    uint8_t doc_type_f;  // Типы документов
    char    text[31];    // строка
  };

  int                       ret;
  paykiosk_t*               me        = (paykiosk_t*)kkt;
  uint8_t                   oper_num;
  struct _paykiosk_cmd_17   cmd_17;

  if (!str) {
    str = "";
  }

  cmd_17.doc_type_f = 0x43;
  snprintf(cmd_17.text, sizeof(cmd_17.text), "%s", str);

  ret = paykiosk_cmd(
    me, PAYKIOSK_CMD_17, &cmd_17, sizeof(cmd_17), &oper_num, 1, PAYKIOSK_CMD_DEF_TIMEOUT_MS
  );
  if (ret < 0) {
    return paykiosk_perror("CMD25", ret);
  }

  return 0;
}

static int paykiosk_print_image(kkt_t* kkt, const uint8_t* image, uint16_t x, uint16_t y)
{
  // Не реализовано
  return -ENOSYS;
}
// ///--------------------------------------------------------------------------------------------
//
//
// // Вывод картинки на чек
// bool paykiosk_print_image(paykiosk_t* me, const uint8_t * image, uint16_t x, uint16_t y)
// {
//     log_func();
//     bool ok=false;
//     if ((image) && (me) && (me->status!=KKM_NOT_INSTALL) && (me->kkm_bus.bus_type==PAYKIOSK) && (x) && (y))
//     {
//         if ((kkmtype_paykiosk_t)me->type==KKMTYPE_PAYONLINE_01)
//         {
//         // Открываем порт
//         kkm_open_port();
//         uint8_t data[100];
//         paykiosk_hdr_cmd_t* ptr_cmd=(paykiosk_hdr_cmd_t*)data;
//         uint8_t* end;
//         size_t size=0;
//         // Отправляем команду на центровку
//         ptr_cmd->psw=me->psw;
// ///        ptr_cmd->cmd=ATOL_CMD_8F;
// ///        data[sizeof(paykiosk_hdr_cmd_t)]=ATOL_CMD_8F;
//         data[sizeof(paykiosk_hdr_cmd_t)+1]=0x1B;
//         data[sizeof(paykiosk_hdr_cmd_t)+2]=0x61;  //
//         data[sizeof(paykiosk_hdr_cmd_t)+3]=0x00;  //
//         size=4;
//         end=paykiosk_get_data(data,sizeof(paykiosk_hdr_cmd_t)+size,sizeof(data),NULL, false, 1000, NULL, NULL);
//         // Включаем режим печати картинки
//         ptr_cmd->psw=me->psw;
// ///        ptr_cmd->cmd=ATOL_CMD_8F;
// ///        data[sizeof(paykiosk_hdr_cmd_t)]=ATOL_CMD_8F;
//         data[sizeof(paykiosk_hdr_cmd_t)+1]=0x1D;
//         data[sizeof(paykiosk_hdr_cmd_t)+2]=0x76;  //
//         data[sizeof(paykiosk_hdr_cmd_t)+3]=0x30;  //
//         data[sizeof(paykiosk_hdr_cmd_t)+4]=0x00;  // режим 0 - нормальный
//         uint16_t xbyte=x%8;
//         if (xbyte) xbyte=x/8+1;
//         else xbyte=x/8;
//         log_trace(" ############### x=%d,  y=%d",xbyte,y);
//         data[sizeof(paykiosk_hdr_cmd_t)+5]=xbyte;  // X
//         data[sizeof(paykiosk_hdr_cmd_t)+6]=0x00;  //
//         data[sizeof(paykiosk_hdr_cmd_t)+7]=y;  // Y
//         data[sizeof(paykiosk_hdr_cmd_t)+8]=0x00;  //
//         size=9;
//         end=paykiosk_get_data(data,sizeof(paykiosk_hdr_cmd_t)+size,sizeof(data),NULL, false, 1000, NULL, NULL);
//         // Выводим картинку
//         uint16_t bytes=xbyte*y;
//         while (bytes)
//         {
//             ptr_cmd->psw=me->psw;
// ///            ptr_cmd->cmd=ATOL_CMD_8F;
// ///            data[sizeof(paykiosk_hdr_cmd_t)]=ATOL_CMD_8F;
//             size=1;
//             uint8_t i=0;
//             if (xbyte>=56) xbyte=56;
//             while ((i<xbyte) && (bytes))
//             {
//                 data[sizeof(paykiosk_hdr_cmd_t)+i+1]=*image++;
//                 i++;
//                 bytes--;
//             }
//             size+=i;
//             //dbg_printhex(data,size+sizeof(paykiosk_hdr_cmd_t));
//             end=paykiosk_get_data(data,sizeof(paykiosk_hdr_cmd_t)+size,sizeof(data),NULL, false, 1000, NULL, NULL);
//         }
//         // Закрываем режим печати
//         //ptr_cmd->psw=me->psw;
//         //ptr_cmd->cmd=ATOL_CMD_8F;
//         //data[sizeof(paykiosk_hdr_cmd_t)]=0x90;
//         //data[sizeof(paykiosk_hdr_cmd_t)+1]=0x01;
//         //size=2;
//         //end=paykiosk_get_data(data,sizeof(paykiosk_hdr_cmd_t)+size,sizeof(data),NULL, false, 0, NULL, NULL);
//         if (end) ok=true;
//             // Закрываем работу с портом
//             kkm_close_port();
//         }
//     }
//     log_func_result(ok);
//     return(ok);
// }
//
// // Распечатка чека по протоколу ATOL
// bool paykiosk_print_string(paykiosk_t* me, char * src)
// {
//     log_func();
//     bool ok=false;
//     if ((src) && (me) && (me->status!=KKM_NOT_INSTALL) && (me->kkm_bus.bus_type==PAYKIOSK))
//     {
//         // Формируем чек на печать и выводим его
//         int16_t max_size=0;///=paykiosk_get_str_size(me->type);
//         size_t size=strlen(src);
//         if (size>max_size) size=max_size;
//         if (max_size>0)
//         {
//             // Открываем порт
//             kkm_open_port();
//             uint8_t data[100];
//             paykiosk_hdr_cmd_t* ptr_cmd=(paykiosk_hdr_cmd_t*)data;
//             uint8_t* end;
//             ptr_cmd->psw=me->psw;
// ///            ptr_cmd->cmd=ATOL_CMD_4C;
//             memcpy(ptr_cmd+1,src,size);
//             end=paykiosk_get_data(data,sizeof(paykiosk_hdr_cmd_t)+size,sizeof(data),NULL, false, 1000, NULL, NULL);
//             if ((end) && ((end-data)>=3))
//             {
//                 if ((data[0]==0x55) &&
//                     (data[1]==0x0) &&
//                     (data[2]==0x0))
//                     ok=true;
//             }
//             // Закрываем работу с портом
//             kkm_close_port();
//         }
//     }
//     log_func_result(ok);
//     return(ok);
// }*/
//


/// \brief Записывает адрес ОФД
static int paykiosk_ofd_set_server(kkt_t* kkt, const char* server)
{
  int           ret;
  paykiosk_t*   me        = (paykiosk_t*)kkt;
  kkt_state_t*  state     = kkt_state(kkt);
  int           len;

  if (!server) {
    server = "";
  }

  len = strlen(server);
  if (len >= sizeof(state->OFDserv)) {
    return -ENOBUFS;
  }

  strcpy(state->OFDserv, server);
  ret = paykiosk_write_table(me, PAYKIOSK_TABLE_19, 1, 1, state->OFDserv, len+1);
  if (ret < 0) {
    return paykiosk_perror("ofd_set_server", ret);
  }

  return 0;
}

/// \brief Записывает порт ОФД
static int paykiosk_ofd_set_port(kkt_t* kkt, uint16_t port)
{
  int           ret;
  paykiosk_t*   me    = (paykiosk_t*)kkt;
  kkt_state_t*  state = kkt_state(kkt);

  state->OFDport = port;
  ret = paykiosk_write_table(me, PAYKIOSK_TABLE_19, 1, 1, &port, sizeof(port));
  if (ret < 0) {
    return paykiosk_perror("ofd_set_server", ret);
  }

  return 0;

}

static int paykiosk_fn_check_status(kkt_t* kkt)
{
  paykiosk_t*   me = (paykiosk_t*)kkt;
  int           ret;
  int           last_error = 0;
  uint8_t       response[30];

  // Запрос состояния ФН (определяем статус ФН)
  ret = paykiosk_cmd(
    me, PAYKIOSK_CMD_FF01, NULL, 0, response, sizeof(response),
    PAYKIOSK_CMD_DEF_TIMEOUT_MS
  );
  if (ret < 0) {
    paykiosk_perror("CMDFF01", ret);
    last_error = ret;
  } else {
    kkt_fnstatus_set(kkt, response, ret);
  }

  // Запрос состояния информационного обмена ФН с ОФД
  ret = paykiosk_cmd(
    me, PAYKIOSK_CMD_FF39, NULL, 0, response, sizeof(response),
    PAYKIOSK_CMD_DEF_TIMEOUT_MS
  );
  if (ret < 0) {
    paykiosk_perror("CMDFF39", ret);
    last_error = ret;
  } else {
    // Вообще-то для унификации, каждый из драйверов должен
    // самостоятельно парсить ответ и сохранять его в поля
    // статуса ОФД в базовом объекте. В идеале, указатель
    // на целевую структуру должен передаваться как аргумент.
    //
    // Пока что оставил как есть, т.к. недостаточно времени.
    kkt_ofdstatus_set(kkt, response, ret);
  }
  return last_error;
}

static int paykiosk_fn_set_transport(kkt_t* kkt)
{
  paykiosk_t*   me = (paykiosk_t*)kkt;
  int           ret;
  uint8_t       response[30];

  // Запрос состояния ФН (определяем статус ФН)
  ret = paykiosk_cmd(
    me, PAYKIOSK_CMD_FF01, NULL, 0, response, sizeof(response),
    PAYKIOSK_CMD_DEF_TIMEOUT_MS
  );
  if (ret < 0) {
    return paykiosk_perror("CMDFF01", ret);
  }
  return 0;
}




////////////////////////////////////////////////////////////////////////////
//  Публичные функции

int paykiosk_create(paykiosk_t* me)
{
  int ret;
  if (!me) {
    return -EINVAL;
  }

  memset(me, 0, sizeof(*me));

  ret = kkt_create(&me->base, &PAYKIOSK_VMT);
  if (ret < 0) {
    return ret;
  }


  smartio_crcxor_create(&me->rxcrc);
  smartio_crcxor_create(&me->txcrc);

  kktport_set_crc_rx(me, (smartio_crc_t*)&me->rxcrc);
  kktport_set_crc_tx(me, (smartio_crc_t*)&me->txcrc);
  ret = kktport_set_txbuf(
    me,
    me->txbuf,
    sizeof(me->txbuf),
    SMARTIO_BUFOVF_FAIL_ON_FLUSH  // Копим исходящие данные для записи по flush
  );

  return 0;
}


const char* paykiosk_conntype_to_string(paykiosk_conntype_t value)
{
  switch (value) {
  case PAYKIOSK_CONNTYPE_SERIAL:  return "serial";
  case PAYKIOSK_CONNTYPE_PPPOS:   return "pppos";
  default:                        return "<invalid>";
  }
}
