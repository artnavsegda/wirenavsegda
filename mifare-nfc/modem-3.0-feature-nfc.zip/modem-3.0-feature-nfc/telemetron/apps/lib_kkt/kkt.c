/// \file
/// \brief  Абстрактный класс для протокола связи с ККМ/ККТ/принтером
/// \author DL <dmitriy@linikov.ru>


////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <kkt/kkt.h>

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <utils/string_utils.h>
#include <productdb/productdb.h>

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Приватные функции


////////////////////////////////////////////////////////////////////////////
//  Публичные функции

/// \brief  Возвращает характеристики драйвера и принтера.
/// \return Указатель на описание характеристик драйвера и принтера.
///         Возвращаемое значение всегда не `NULL`.
const kkt_caps_t* kkt_caps(kkt_t* kkt)
{
  DEBUGASSERT(kkt && kkt->vmt && kkt->vmt->get_caps);

  const kkt_caps_t* result = kkt->vmt->get_caps(kkt);
  DEBUGASSERT(result != NULL);

  return result;
}

int kkt_create(kkt_t* kkt, const kkt_vmt_t* vmt)
{
  int ret;
  DEBUGASSERT(kkt && vmt);

  kkt->vmt = NULL;

  // Заполнение полей и создание вложенных объектов.
  ret = smartio_create(kkt_port(kkt));
  if (ret < 0) {
    return ret;
  }

  // kkt->vmt служит индикатором того, что объект был создан.
  kkt->vmt = vmt;
  kkt->inited = false;
  kkt->has_fn_state = false;

  memset(&kkt->ofd, 0, sizeof(kkt->ofd));
  memset(&kkt->fn, 0, sizeof(kkt->fn));

#if 0
  // на время отладки
  lib_rawsostream(&kkt->logger, 0); // 0=STDOUT_FILENO
  kkt_set_logger(kkt, &kkt->logger.public);
#endif

  return 0;
}

int kkt_destroy(kkt_t* kkt)
{
  int ret;
  DEBUGASSERT(kkt);

  if (kkt->inited) {
    ret = kkt_deinit(kkt);
    if (ret < 0) {
      return ret;
    }
  }

  // Сперва осуществляем уничтожение наследника
  if (kkt->vmt && kkt->vmt->destroy) {
    ret = kkt->vmt->destroy(kkt);
    if (ret < 0) {
      return ret;
    }
  }

  // Удаляем vmt, т.к. наследник уже уничтожен.
  kkt->vmt = NULL;

  // Уничтожаем базовый объект.
  ret = smartio_destroy(kkt_port(kkt));
  if (ret < 0) {
    return ret;
  }

  return 0;
}


int kkt_init(kkt_t* kkt, const char* ttypath, printer_params_t* printer_params)
{
  int ret;
  DEBUGASSERT(kkt && kkt->vmt);
  DEBUGASSERT(!kkt->inited);

  if (!ttypath || !printer_params) {
    return -EINVAL;
  }

  ret = snprintf(kkt->ttypath, sizeof(kkt->ttypath), "%s", ttypath);
  if (ret >= sizeof(kkt->ttypath)) {
    return -ENOBUFS;
  }

  kkt->params = *printer_params;

  if (kkt->vmt->init) {
    // Если драйверу нечего делать в методе init, он может его не предоставлять.
    // Его отсутствие не должно быть причиной ошибки.
    ret = kkt->vmt->init(kkt);
    if (ret < 0) {
      return ret;
    }
  }

  kkt->inited = true;
  return 0;
}

int kkt_deinit(kkt_t* kkt)
{
  int ret;
  DEBUGASSERT(kkt && kkt->vmt);

  if (!kkt->inited) {
    return 0;
  }

  if (kkt->vmt->deinit) {
    // Если драйверу нечего делать в методе init, он может его не предоставлять.
    // Его отсутствие не должно быть причиной ошибки.
    ret = kkt->vmt->deinit(kkt);
    if (ret < 0) {
      return ret;
    }
  }

  return 0;
}

int kkt_status_check(kkt_t* kkt)
{
  DEBUGASSERT(kkt && kkt->vmt);
  if (!kkt->vmt->status_check) {
    return -ENOSYS;
  }
  int ret = kkt->vmt->status_check(kkt);
  if (ret < 0) {
    return ret;
  }

  if (kkt->vmt->datetime_get) {
    struct timespec kkt_time;
    ret = kkt->vmt->datetime_get(kkt, &kkt_time);
    if (ret < 0) {
      // невозможность получить время из ККТ не является критической ошибкой
      // игнорируем её
      return 0;
    }

    /// \todo Здесь следует решить, по каким критериям синхронизировать время с ККТ.
#   warning "Time sync with KKT/KKM/Printer is not implemented"
  }
  return 0;
}

int kkt_datetime_get(kkt_t* kkt, struct timespec* dst)
{
  DEBUGASSERT(kkt && kkt->vmt);
  if (!kkt->vmt->datetime_get) {
    return -ENOSYS;
  }
  return kkt->vmt->datetime_get(kkt, dst);
}

int kkt_order_open(kkt_t* kkt)
{
  DEBUGASSERT(kkt && kkt->vmt);
  if (!kkt->vmt->order_open) {
    return -ENOSYS;
  }
  return kkt->vmt->order_open(kkt);
}

int kkt_order_close(kkt_t* kkt, const kkt_pay_t* total_payment)
{
  DEBUGASSERT(kkt && kkt->vmt);
  if (!kkt->vmt->order_close) {
    return -ENOSYS;
  }
  return kkt->vmt->order_close(kkt, total_payment);
}

int kkt_order_reg(kkt_t* kkt, const kkt_money_t* price, thousandths_t quant, const char* name, uint16_t section)
{
  DEBUGASSERT(kkt && kkt->vmt);
  if (!kkt->vmt->order_reg) {
    return -ENOSYS;
  }
  return kkt->vmt->order_reg(kkt, price, quant, name, section);
}

int kkt_order_cut(kkt_t* kkt)
{
  DEBUGASSERT(kkt && kkt->vmt);
  if (!kkt->vmt->order_cut) {
    return -ENOSYS;
  }
  return kkt->vmt->order_cut(kkt);
}

int kkt_print_string(kkt_t* kkt, const char* str)
{
  DEBUGASSERT(kkt && kkt->vmt);
  if (!kkt->vmt->print_string) {
    return -ENOSYS;
  }
  return kkt->vmt->print_string(kkt, str);
}

int kkt_print_image(kkt_t* kkt, const uint8_t* image, uint16_t x, uint16_t y)
{
  DEBUGASSERT(kkt && kkt->vmt);
  if (!kkt->vmt->print_image) {
    return -ENOSYS;
  }
  return kkt->vmt->print_image(kkt, image, x, y);
}

int kkt_ofd_set_server(kkt_t* kkt, const char* server)
{
  DEBUGASSERT(kkt && kkt->vmt);
  if (!kkt->vmt->ofd_set_server) {
    return -ENOSYS;
  }
  return kkt->vmt->ofd_set_server(kkt, server);
}

int kkt_ofd_set_port(kkt_t* kkt, uint16_t port)
{
  DEBUGASSERT(kkt && kkt->vmt);
  if (!kkt->vmt->ofd_set_port) {
    return -ENOSYS;
  }
  return kkt->vmt->ofd_set_port(kkt, port);
}

int kkt_fn_check_status(kkt_t* kkt)
{
  DEBUGASSERT(kkt && kkt->vmt);
  if (!kkt->vmt->fn_check_status) {
    return -ENOSYS;
  }
  return kkt->vmt->fn_check_status(kkt);
}

int kkt_fn_set_transport(kkt_t* kkt)
{
  DEBUGASSERT(kkt && kkt->vmt);
  if (!kkt->vmt->fn_set_transport) {
    return -ENOSYS;
  }
  return kkt->vmt->fn_set_transport(kkt);
}

int kkt_fn_reset_transport(kkt_t* kkt)
{
  DEBUGASSERT(kkt && kkt->vmt);
  if (!kkt->vmt->fn_reset_transport) {
    return -ENOSYS;
  }
  return kkt->vmt->fn_reset_transport(kkt);
}




void kkt_fnstatus_ofdstatus_clear(kkt_t* kkt)
{
  DEBUGASSERT(kkt);
  // Сброс значнеи явсех статусов с ФН и ОФД
  //void OFD_clear_fn_ofd_status(void)
  memset(&kkt->fn,0,sizeof(kkt->fn));
}

// Формиорвание структуры состояния ФН
void kkt_fnstatus_set(kkt_t* kkt, void* fn_status, size_t size)
{
  //void OFD_set_fn_status(_type_kkm_param* kkm, void * fn_status, size_t size)
  if (!kkt || !fn_status || size < sizeof(_fn_status)) {
    return;
  }

  // Заполняем структуру ФН
  memcpy(
    &kkt->fn.fn_status,
    fn_status,
    sizeof(kkt->fn.fn_status)
  );
}

// Передаем значение структуры состояния информационного обмена ФН с ОФД в процедуру для заполнения статуса ФН ОФД
void kkt_ofdstatus_set(kkt_t* kkt, void* ofd_status, size_t size)
{
  //void OFD_set_fn_ofd_status(_type_kkm_param* kkm, void * fn_ofd_status, size_t size)
  if (!kkt || !ofd_status || size < sizeof(_fn_ofd_status)) {
    return;
  }

  // Заполняем структуру ФН
  memcpy(
    &kkt->fn.fn_ofd_status,
    ofd_status,
    sizeof(kkt->fn.fn_ofd_status)
  );
}


// Производит проверку состояния ОФД сервера
static int kkt_ofd_check_status(kkt_t* kkt)
{
  /// Аглоритм работы по взаимодействию с ФН и ОФД (передача ФД в ОФД и передача даннх из ОФД в ФН)
  // 1. Проверяем окончание очереди в ФН
  // 2. Устанавливаем соединение с ОФД сервером Т-соединение
  // 3. При успешной установке соединения с сервром, пердаем в ФН состояние об установке соединения (Проверяем в ФН текущее значение соединения и при необходимости закрываем его)
  // 4. Запрашиваем данные от ФН и передаем из ФН в ОФД
  // 5. Если данные ФН переданы в ОФД, то сообщаем ФН "Ответ Сервера" и переходим в прием данных от ОФД
  // 6. Если поступили данные от ОФД, то сообщаем ФН о начале приема сообщения от сервера
  // 7. Если сообщение полностью передано в ФН, то сообщаем ФН о завершении приема от ОФД и ждем от ФН подтверждение
  // 8. Если подтверждение записи в ФН получено, то идем п.1. Иначе выходим.
  /// 1. Проверяем статус очереди
  int ret = kkt_fn_check_status(kkt);
  if (ret < 0) {
    return ret;
  }

  if ((!kkt->fn.fn_ofd_status.msg_ofd_count)
      && !(kkt->fn.fn_ofd_status.ofd_status&OFD_INFO_MSGOFD)
  ) {
    // Структуры не заполнены
    return 0;
  }

  /// 2. Устанавливаем соединение с ОФД

  if ((kkt->fn.fn_ofd_status.ofd_status&OFD_INFO_T_SESSION))
  {// Режим соединения установлен. Рвем его на всякий случай (бог его знает когда мы его подняли)
    ret = kkt_fn_reset_transport(kkt);
  }

  /// 3. Записываем в ФН режим соединения
  ret = kkt_fn_set_transport(kkt);
  if (ret < 0) {
    return ret;
  }
  // Режим установился в ФН
  // 4. Запрашиваем документ из ФН
  //OFDGetFD(kkm,)
  return 0;
}

/// Основная процедура взаимодействия с ОФД
// Производит анализ статуса ФН
// Устанавливает соединенеи с ОФД и прописывает этот статус в ФН
// Производит вычитку фискальных данных из ФН ККТ и передает их в ОФД
// Получает пакеты подтверждения из ОФД
void OFD_main(kkt_t* kkt)
{
  DEBUGASSERT(kkt);

  /// Периодичская проверка сведений на стороне ОФД (раз в OFD_RECHECK_PERIOD)
  if ((timeout_is_elapsed(&kkt->ofd.time)) || (!kkt->ofd.time.start))
  {
    //Softdog_OnReturnedToMainLoop();
    kkt_ofd_check_status(kkt);
    timeout_start(&kkt->ofd.time,OFD_RECHECK_PERIOD);
  }
}


const char* PrinterGetSerial(kkt_t* kkt, char* ptr, size_t size)
{
  char sn_string[30];
  char * ret=NULL;
  if (!kkt || !kkt->vmt || !kkt->inited) {
    return NULL;
  }

  if ((kkt->kkt_state.sn_hi==0xFFFF) &&
      (kkt->kkt_state.sn==0xFFFFFFFF))
  {
    ret="SN_not_set";
  }
  else
  {
    snprintf(
      sn_string,
      sizeof(sn_string),
      "%04d%08d",
      kkt->kkt_state.sn_hi,
      kkt->kkt_state.sn
    );
    ret=sn_string;
  }
  kkt_info(
    "KKT SN[%s], sn_hi [0x%X], sn [0x%X]\n",
    ret, kkt->kkt_state.sn_hi, kkt->kkt_state.sn
  );
  if ((ptr) && (size>0)) {strncpy_ex(ptr, ret, size); ret=ptr;}

  return(ret);
}

uint8_t       PrinterGetFNStatus(kkt_t* kkt)
{
  DEBUGASSERT(kkt);

  if (!kkt->has_fn_state) {
    return 0;
  }

  uint8_t ret = kkt->fn_state.FN_exch_state;
  kkt_info("PrinterGetFNStatus: %u\n", ret);

  return ret;
}

uint16_t      PrinterGetFNMessages(kkt_t* kkt)
{
  DEBUGASSERT(kkt);

  if (!kkt->has_fn_state) {
    return 0;
  }

  uint16_t ret = kkt->fn_state.FN_msgs;
  kkt_info("PrinterGetFNMessages: %u\n", ret);

  return ret;
}

const char*   PrinterGetFNFirstDocDataTime(kkt_t* kkt)
{
  DEBUGASSERT(kkt);

  if (!kkt->has_fn_state) {
    return NULL;
  }

  const char* ret = kkt->fn_state.FN_doc_dt;
  kkt_info("PrinterGetFNFirstDocDataTime: %s\n", ret);
  return ret;
}

const char*   PrinterGetFNSerialKKT(kkt_t* kkt)
{
  DEBUGASSERT(kkt);

  if (!kkt->has_fn_state) {
    return NULL;
  }

  const char* ret = kkt->fn_state.FN_kkt_sn;
  kkt_info("PrinterGetFNSerialKKT: %s\n", ret);

  return ret;
}

const char*   PrinterGetFNRnmKKT(kkt_t* kkt)
{
  DEBUGASSERT(kkt);

  if (!kkt->has_fn_state) {
    return NULL;
  }

  const char* ret = kkt->fn_state.FN_kkt_rnm;
  kkt_info("PrinterGetFNRnmKKT: %s\n", ret);

  return ret;
}

const char*   PrinterGetFNSerial(kkt_t* kkt)
{
  DEBUGASSERT(kkt);

  if (!kkt->has_fn_state) {
    return NULL;
  }

  const char* ret = kkt->fn_state.FN_sn;
  kkt_info("PrinterGetFNSerial: %s\n", ret);

  return ret;
}

const char*   PrinterGetTASerial(kkt_t* kkt)
{
  DEBUGASSERT(kkt);

  if (!kkt->has_fn_state) {
    return NULL;
  }

  const char* ret = kkt->fn_state.FN_ta_sn;
  kkt_info("PrinterGetTASerial: %s\n", ret);

  return ret;
}

const char*   PrinterGetOFDserv(kkt_t* kkt)
{
  DEBUGASSERT(kkt);

  const char* ret = kkt->kkt_state.OFDserv;
  kkt_info("PrinterGetOFDserv: %s\n", ret);

  return ret;
}

uint16_t      PrinterGetOFDport(kkt_t* kkt)
{
  DEBUGASSERT(kkt);

  uint16_t ret = kkt->kkt_state.OFDport;
  kkt_info("PrinterGetOFDport: %u\n", ret);
  return ret;
}

uint16_t      PrinterGetFlags(kkt_t* kkt)
{
  DEBUGASSERT(kkt);

  return kkt->kkt_state.flags;
}

uint8_t       PrinterGetMode(kkt_t* kkt)
{
  DEBUGASSERT(kkt);

  return kkt->kkt_state.mode;
}

uint8_t       PrinterGetSubMode(kkt_t* kkt)
{
  DEBUGASSERT(kkt);

  return kkt->kkt_state.submode;
}

uint8_t       PrinterGetReRegist(kkt_t* kkt)
{
  DEBUGASSERT(kkt);

  return kkt->kkt_state.rereg;
}

uint8_t       PrinterGetReRegistRest(kkt_t* kkt)
{
  DEBUGASSERT(kkt);

  return kkt->kkt_state.rereg_rest;
}

const char*   PrinterGetFWVersion(kkt_t* kkt, char * ptr, size_t size)
{
  DEBUGASSERT(kkt);

  char version_string[30];
  char * ret=NULL;
  const kkt_state_t* state = &kkt->kkt_state;
  snprintf(
    version_string,
    sizeof(version_string),
    "%c.%c.%d-%02d/%02d/%02d",
    (state->FW_version&0x00FF),
    (state->FW_version>>8)&0x00FF,
    state->FW_build,
    state->FW_date.day,
    state->FW_date.month,
    state->FW_date.year
  );

  kkt_info(
    "FW KKT[%s], version %X, build %d, day %d, month %d, year %d\n",
    version_string,
    state->FW_version,
    state->FW_build,
    state->FW_date.day,
    state->FW_date.month,
    state->FW_date.year
  );

  if ((ptr) && (size>0)) {
    strncpy_ex(ptr, ret, size);
    ret=ptr;
  }

  return(ret);
}


const char*   PrinterGetINN(kkt_t* kkt, char * ptr, size_t size)
{
  DEBUGASSERT(kkt);

  const char* ret = kkt->kkt_state.inn;
  kkt_info("KKT INN[%s]\n", ret);
  if ((ptr) && (size>0)) {
    strncpy_ex(ptr, ret, size);
    ret=ptr;
  }
  return(ret);
}

uint16_t      PrinterGetLastError(kkt_t* kkt)
{
  DEBUGASSERT(kkt);

  return kkt->kkt_state.last_error_code;
}

uint16_t      PrinterGetLastCmd(kkt_t* kkt)
{
  DEBUGASSERT(kkt);

  return kkt->kkt_state.last_cmd;
}

const char*   PrinterGetName(kkt_t* kkt)
{
  DEBUGASSERT(kkt);

  const char* ret = kkt->kkt_state.name;
  if (!IsWhiteOrEmptyString(ret)) {
    ret = "not_set";
  }
  return ret;
}

uint32_t      PrinterGetBaud(kkt_t* kkt)
{
  DEBUGASSERT(kkt);

  speed_t baudrate;
  if (kktport_get_comm_params(kkt, &baudrate, NULL, NULL, NULL) < 0) {
    return 0;
  }

  return (uint32_t)baudrate;
}

uint8_t       PrinterGetStatus(kkt_t* kkt)
{
  DEBUGASSERT(kkt);

  return kkt->kkt_state.last_error_code < 0
         ? KKT_ERROR
         : KKT_INITED;
}

// int8_t        PrinterGetBusType(kkt_t* kkt)
// {
//   DEBUGASSERT(kkt);


// }

const char*   PrinterGetBusTypeString(kkt_t* kkt)
{
  DEBUGASSERT(kkt && kkt->vmt);

  if (!kkt->vmt->bus_name) {
    return "Unknow";
  }
  return kkt->vmt->bus_name(kkt);
}

const char*   kkt_paperstate_to_string(kkt_paperstate_t value)
{
  switch(value) {
  case KKT_PAPER_OK:      return "paper ok";
  case KKT_PAPER_WARNING: return "paper warning";
  case KKT_PAPER_ERROR:   return "paper error";
  default:                return "<invalid>";
  }
}

const char*   PrinterGetStatusPaper(kkt_t* kkt)
{
  DEBUGASSERT(kkt);
  return kkt_paperstate_to_string(kkt->paperstate);
}

int          PrinterPrintOrder(kkt_t* kkt, uint32_t price, uint16_t dot, uint32_t quant, uint16_t number, bool cash, bool print_banner)
{
  // По всей видимости, все принтеры с фискальным накопителем работают так:
  // открыть заказ -> напечатать товар -> зарегистрировать товар в ФН -> закрыть заказ
  //
  // Тем не менее, что бы интерфейс драйвера был более универсальным,
  // печать информации о товаре ведётся через метод order_reg, который печатает
  // описание на чеке и регистрирует товар в ФН.
  //
  // А методы print_string и print_image следует использовать только для
  // печати рекламной информации (когда чек закрыт).


  int ret;

  DEBUGASSERT(kkt);

  ret = kkt_status_check(kkt);
  if (ret < 0) {
    kkt_warn("PRINT: status_check ret=%d (%s)\n", ret, strerror(-ret));
    return ret;
  }

  const kkt_caps_t* caps = kkt_caps(kkt);


  // Печатаем рекламу, если требуется и принтер позволяет это делать
  if (print_banner
      && caps->can_print_leading_banner
      && kkt_paperstate(kkt) == KKT_PAPER_OK
  ) {
    kkt_trace("PRINT: Printing banner...\n");
    kkt_print_string(kkt, "******************************");
    kkt_print_string(kkt, "*         ТЕЛЕМЕТРОН         *");
    kkt_print_string(kkt, "*  телеметрия для вендинга   *");
    kkt_print_string(kkt, "*     WWW.TELEMETRON.RU      *");
    kkt_print_string(kkt, "*      +7(812)313-29-83      *");
    kkt_print_string(kkt, "*  198188, Санкт-Петербург,  *");
    kkt_print_string(kkt, "*    ул.Возрождения, 20А     *");
    kkt_print_string(kkt, "******************************");
  }

  // Открыть чек
  ret = kkt_order_open(kkt);
  if (ret < 0) {
    kkt_error("PRINT: order_open ret=%d (%s)\n", ret, strerror(-ret));
    return ret;
  }

  char      name[DB_PRODUCT_NAME_LEN];
  uint16_t  section = 1;
  kkt_pay_t item_price = {
    .summ = {
      .value    = price,
      .dot      = dot,
      .currency = CURRENCY_ANY,
    },
    .paytype  = cash ? KKT_PAYTYPE_CASH : KKT_PAYTYPE_CASHLESS
  };

  // База данных продуктов пока работает нестабильно.
  // Поэтому используем строку "Продукт №"
  ret = snprintf(name, sizeof(name), "  Продукт № %d", number);
  if (ret >= sizeof(name)) {
    kkt_warn("PRINT: Product name overflow\n");
  }



  ret = kkt_order_reg(kkt, &item_price.summ, (thousandths_t)quant*1000, name, section);
  if (ret < 0) {
    kkt_error("PRINT: order_reg ret=%d (%s)\n", ret, strerror(-ret));
    // Оригинальное ПО не закрывало заказ после ошибок. Делаем так же.
    return ret;
  }

  ret = kkt_order_close(kkt, &item_price);
  if (ret < 0) {
    kkt_error("PRINT: order_close ret=%d (%s)\n", ret, strerror(-ret));
    return ret;
  }

  if (caps->can_cut) {
    ret = kkt_order_cut(kkt);
    if (ret < 0) {
      kkt_error("PRINT: order_cut ret=%d (%s)\n", ret, strerror(-ret));
    }
  }

  kkt_info("PRINT: Completed\n");
  return 0;
}
