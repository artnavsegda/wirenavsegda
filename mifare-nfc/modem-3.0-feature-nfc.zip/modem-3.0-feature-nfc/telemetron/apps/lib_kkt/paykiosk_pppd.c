/// \file
/// \brief  Реализация сервиса связи с paykiosk через PPP протокол
/// \author DL <dmitriy@linikov.ru>


////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <kkt/paykiosk_pppd.h>

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <sysutils/timeval_utils.h>
#include <utils/string_utils.h>


////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

static ssize_t  paykiosk_ppp_write(void* arg, const void* buf, size_t bufsize);
static ssize_t  paykiosk_ppp_read(void* arg, void* buf, size_t bufsize);
static int      paykiosk_ppp_get_stream_file(void* arg, struct file** fp);
static void     paykiosk_ppp_set_dns(void* arg, uint8_t id, const struct sockaddr* dnsaddr, socklen_t addrlen);
static void     paykiosk_ppp_clr_dns(void* arg);
static void     paykiosk_ppp_on_ifup(void* arg, const struct in_addr* ouraddr, const struct in_addr* gateway, const struct in_addr* mask);
static void     paykiosk_ppp_on_ifdown(void* arg);
static void     paykiosk_ppp_on_link_status(void* arg, libppp_err_t status);
static void     paykiosk_ppp_on_phase(void* arg, libppp_phase_t phase);


////////////////////////////////////////////////////////////////////////////
//  Константы

static const struct libppp_cb_s PAYKIOSK_LIBPPP_CALLBACKS = {
  .write              = paykiosk_ppp_write,
  .read               = paykiosk_ppp_read,
  .get_stream_file    = paykiosk_ppp_get_stream_file,
  .set_dns            = paykiosk_ppp_set_dns,
  .clr_dns            = paykiosk_ppp_clr_dns,
  .on_ifup            = paykiosk_ppp_on_ifup,
  .on_ifdown          = paykiosk_ppp_on_ifdown,
  .on_ppp_link_status = paykiosk_ppp_on_link_status,
  .on_ppp_phase       = paykiosk_ppp_on_phase,
};


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные


////////////////////////////////////////////////////////////////////////////
//  Обработка событий библиотеки libppp

static ssize_t  paykiosk_ppp_write(void* arg, const void* buf, size_t bufsize)
{
  paykiosk_pppd_t*  paykiosk_pppd = (paykiosk_pppd_t*)arg;
  DEBUGASSERT(paykiosk_pppd);

  return smartio_write(&paykiosk_pppd->port, buf, bufsize);
}

static ssize_t  paykiosk_ppp_read(void* arg, void* buf, size_t bufsize)
{
  paykiosk_pppd_t*  paykiosk_pppd = (paykiosk_pppd_t*)arg;
  DEBUGASSERT(paykiosk_pppd);

  return smartio_nbread(&paykiosk_pppd->port, buf, bufsize, 0);
}

static int      paykiosk_ppp_get_stream_file(void* arg, struct file** fp)
{
  paykiosk_pppd_t*  paykiosk_pppd = (paykiosk_pppd_t*)arg;
  DEBUGASSERT(paykiosk_pppd);
  return smartio_get_file(&paykiosk_pppd->port, fp);
}

static void     paykiosk_ppp_set_dns(void* arg, uint8_t id, const struct sockaddr* dnsaddr, socklen_t addrlen)
{
  paykiosk_pppd_t*  paykiosk_pppd = (paykiosk_pppd_t*)arg;
  char    buffer[INET_ADDRSTRLEN];

  DEBUGASSERT(paykiosk_pppd);
  DEBUGASSERT(dnsaddr && dnsaddr->sa_family == AF_INET);

  const struct sockaddr_in* addr = (const struct sockaddr_in*)dnsaddr;

  kkt_trace(
    "KKT provided DNS%d: %s\n",
    id,
    inet_ntop(AF_INET, &addr->sin_addr, buffer, sizeof(buffer))
  );

  // Поскольку paykiosk не предоставляет доступ в сеть, то
  // адрес dns для этого ppp сеанса не используется.
  // Никакой реальной работы здесь не требуется.
}

static void     paykiosk_ppp_clr_dns(void* arg)
{
  // Поскольку paykiosk не предоставляет доступ в сеть, то
  // адрес dns для этого ppp сеанса не используется.
  // Никакой реальной работы здесь не требуется.
}

static void     paykiosk_ppp_on_ifup(void* arg, const struct in_addr* ouraddr, const struct in_addr* gateway, const struct in_addr* mask)
{
  char              buffer[INET_ADDRSTRLEN];
  paykiosk_pppd_t*  paykiosk_pppd = (paykiosk_pppd_t*)arg;
  DEBUGASSERT(paykiosk_pppd);

  kkt_info("Connected\n");
  kkt_info("   outaddr   = %s\n", inet_ntop(AF_INET, ouraddr, buffer, sizeof(buffer)));
  kkt_info("   kktaddr   = %s\n", inet_ntop(AF_INET, gateway, buffer, sizeof(buffer)));
  kkt_info("   netmask   = %s\n", inet_ntop(AF_INET, mask, buffer, sizeof(buffer)));

  // Сохраняем ip адрес ККТ для дальнейшего использования
  paykiosk_pppd->kkt_addr = *gateway;
  paykiosk_pppd->has_kkt_addr = true;
}

static void     paykiosk_ppp_on_ifdown(void* arg)
{
  paykiosk_pppd_t*  paykiosk_pppd = (paykiosk_pppd_t*)arg;
  DEBUGASSERT(paykiosk_pppd);

  // Удаляем IP адрес.
  paykiosk_pppd->has_kkt_addr = false;
  paykiosk_pppd->kkt_addr.s_addr = htonl(INADDR_ANY);
  kkt_info("Disconnected\n");
}

static void     paykiosk_ppp_on_link_status(void* arg, libppp_err_t status)
{
  paykiosk_pppd_t*  paykiosk_pppd = (paykiosk_pppd_t*)arg;
  DEBUGASSERT(paykiosk_pppd);
  paykiosk_pppd->ppp_err = status;
  kkt_info("LinkStatus: %d\n", (int)status);
}

static void     paykiosk_ppp_on_phase(void* arg, libppp_phase_t phase)
{
  // Уведомления о состоянии конечного автомата PPP сессии не используем.
  kkt_info("PPP phase=%d\n", (int)phase);
}


////////////////////////////////////////////////////////////////////////////
//  Приватные функции

/// \brief Прослушивание последовательного порта с поиском строки "CLIENT"
///
/// Если paykiosk отправляет в порт строку "CLIENT", то перед началом работы
/// он ожидает получить в ответ строку "SERVER". Данная функция вызывается
/// перед попыткой соединения с paykiosk и обрабатывает это условие.
static int paykiosk_pppd_check_server_mode(paykiosk_pppd_t* paykiosk_pppd)
{
  paykiosk_pppd->is_server_mode = false;
  // Для поддержки paykiosk в режиме PPP Client
  char            tmp[256];
  size_t          offset      = 0;
  struct timeval  timeout     = timeval_after_ms(CONFIG_PAYKIOSK_PPP_WAIT_FOR_CLIENT_MS);
  const char*     needle      = "CLIENT";
  size_t          needle_len = strlen(needle);

  kkt_trace("%s\n", __FUNCTION__);

  while(!timeval_passed(&timeout)) {

    ssize_t sz = smartio_nbread(
      &paykiosk_pppd->port, &tmp[offset], sizeof(tmp)-offset, 100 /*мс*/
    );

    if (!sz || sz == -ETIMEDOUT) {
      continue;
    }
    if (sz < 0 && sz != -ETIMEDOUT) {
      kkt_warn("Can't readout port, ret=%d (%s)\n", sz, strerror(-sz));
      return sz;
    }

    offset += sz;
    if (offset < needle_len) {
      continue;
    }

    if (MemMem(tmp, offset, "CLIENT", strlen("CLIENT")) == NULL) {
      // Не нашли. Оставляем в буффере последние (needle_len-1) символов
      // - на случай, если в буффере уже есть часть искомого.
      memmove(tmp, &tmp[offset - needle_len + 1], needle_len - 1);
      offset = needle_len - 1;
      continue;
    }

    sz = smartio_write(&paykiosk_pppd->port, "SERVER", strlen("SERVER"));
    if (sz < 0) {
      _warn("Can't send SERVER to kkt, ret=%d (%s)\n", (int)sz, strerror(-sz));
      return sz;
    }

    paykiosk_pppd->is_server_mode = true;
    break;
  } // while()...

  kkt_trace(
    "%s: done. is_server_mode=%d\n", __FUNCTION__, paykiosk_pppd->is_server_mode
  );
  return 0;
}


static int paykiosk_pppd_start_ppp(paykiosk_pppd_t*  paykiosk_pppd)
{
  libppp_set_asyncmap(paykiosk_pppd->ppp, 0x00000000);
  libppp_set_neg_asyncmap(paykiosk_pppd->ppp, true);
  struct in_addr ip;

  libppp_set_auth(paykiosk_pppd->ppp, LIBPPP_AUTHTYPE_NONE, NULL, NULL);
  libppp_set_auth_required(paykiosk_pppd->ppp, false);

  inet_pton(AF_INET, "8.8.8.8", &ip);
  libppp_set_dnsaddr(paykiosk_pppd->ppp, 0, &ip);
  libppp_set_dnsaddr(paykiosk_pppd->ppp, 1, &ip);
  libppp_set_usepeerdns(paykiosk_pppd->ppp, 0);
  libppp_set_forcepeerdns(paykiosk_pppd->ppp, 1);

  // Намеренно не устанавливаю опции libppp_set_passive и libppp_set_silent
  if (paykiosk_pppd->is_server_mode) {
    kkt_info("PPP listening in server rmode\n");
    inet_pton(AF_INET, "192.168.1.168", &ip);
    libppp_set_hisaddr(paykiosk_pppd->ppp, &ip);

    inet_pton(AF_INET, "192.168.1.169", &ip);
    libppp_set_ouraddr(paykiosk_pppd->ppp, &ip);
    return libppp_listen(paykiosk_pppd->ppp);
  }


  kkt_info("PPP connecting in client mode\n");
  return libppp_connect(paykiosk_pppd->ppp, 0);
}

static int paykiosk_pppd_run_session(paykiosk_pppd_t*  paykiosk_pppd)
{
  int             ret;

  // Создание экземпляра библиотеки libppp
  ret = libppp_create(
    paykiosk_pppd,
    &PAYKIOSK_LIBPPP_CALLBACKS,
    "kkt%d",
    false,
    &paykiosk_pppd->ppp
  );
  if (ret < 0) {
    kkt_error("Can't create libppp, ret=%d (%s)\n", ret, strerror(-ret));
    return ret;
  }

  // Настройка модуля PPP
  ret = paykiosk_pppd_start_ppp(paykiosk_pppd);
  if (ret < 0) {
    kkt_error("Can't init libppp, ret=%d (%s)\n", ret, strerror(-ret));
    goto cleanup;
  }

  // Обработка событий PPP
  ret = 0;
  for (;;) {
    if (ret == -EINTR || service_should_stop((service_t*)paykiosk_pppd)) {
      kkt_info("Got terminate PPP request.\n");
      ret = -EINTR;
      break;
    }

    if (libppp_get_phase(paykiosk_pppd->ppp) == LIBPPP_PHASE_DEAD) {
      // Ошибка инициализации или канал был разорван (в т.ч. по нашему запросу)
      ret = -ECONNRESET;
      break;
    }

    ret = libppp_process(paykiosk_pppd->ppp);
    if (ret < 0 && ret != -EINTR) {
      kkt_warn("libppp_process err=%d (%s)\n", ret, strerror(-ret));
      break;
    }
  } // for (;;)...


cleanup:
  // Подчистка состояния ppp
  if (paykiosk_pppd->ppp) {
    if (libppp_get_phase(paykiosk_pppd->ppp) != LIBPPP_PHASE_DEAD) {
      // Закрытие сеанса связи. LwIP PPP требует несколько циклов на это
      // Поэтому приходится ждать завершения работы его конечного автомата.
      libppp_close(paykiosk_pppd->ppp, false);
      do {
        libppp_process(paykiosk_pppd->ppp);
      } while (libppp_get_phase(paykiosk_pppd->ppp) != LIBPPP_PHASE_DEAD);
    }

    libppp_destroy(paykiosk_pppd->ppp);
    paykiosk_pppd->ppp = NULL;
  }

  kkt_info("PPP session terminated, ret=%d (%s)\n", ret, strerror(-ret));
  return ret;
}



////////////////////////////////////////////////////////////////////////////
//  Основная функция сервиса обработки PPP

static int paykiosk_pppd_thread_main(void* arg)
{
  int               ret;
  paykiosk_pppd_t*  paykiosk_pppd = (paykiosk_pppd_t*)arg;
  bool              port_is_aux   = false;
  aux_settings_t    prev_aux_settings;
  aux_settings_t    aux_settings;

  DEBUGASSERT(paykiosk_pppd);
  DEBUGASSERT(!paykiosk_pppd->ppp); // Проверка, что не будет перезаписи

  kkt_info("PPPD thread started\n");

  ret = smartio_create(&paykiosk_pppd->port);
  if (ret < 0) {
    kkt_error("Can't create smartio, ret=%d (%s)\n", ret, strerror(-ret));
    return ret;
  }

  // Открытие порта и настройка его на нужную скорость.
  ret = smartio_open_file(&paykiosk_pppd->port, paykiosk_pppd->ttypath);
  if (ret < 0) {
    kkt_error(
      "Can't open %s, ret=%d (%s)\n",
      paykiosk_pppd->ttypath,
      ret,
      strerror(-ret)
    );
    smartio_destroy(&paykiosk_pppd->port);
    return ret;
  }

  // настройка параметров последовательного порта
  ret = smartio_set_comm_params(
    &paykiosk_pppd->port,
    paykiosk_pppd->baudrate,
    SERIAL_WORDLEN_8_BIT,
    SERIAL_PARITY_NONE,
    SERIAL_FLOWCTL_NONE
  );
  if (ret < 0) {
    kkt_error("Can't set comm params, ret=%d (%s)\n", ret, strerror(-ret));
    goto cleanup;
  }

  ret = smartio_get_aux_params(&paykiosk_pppd->port, &prev_aux_settings);
  port_is_aux = (ret >= 0);

  if (port_is_aux) {
    // Paykiosk использует физику RS-232.
    // Настраиваем AUX порт соответствующим образом
    aux_settings.protocol   = AUX_PROTOCOL_RS232;
    aux_settings.direction  = AUX_DIRECTION_NORMAL;
    aux_settings.extra      = AUX_EXTRA_NONE;
    aux_settings.inverted   = false;
    ret = smartio_set_aux_params(&paykiosk_pppd->port, &aux_settings);
    if (ret < 0) {
      kkt_error("Can't set AUX params, ret=%d (%s)\n", ret, strerror(-ret));
      goto cleanup;
    }
  }

  ret = 0; // Recovery-пауза не нужна при первой итерации
  while (!service_should_stop((service_t*)paykiosk_pppd)) {
    if (ret < 0) {
      ret = usleep(1000*CONFIG_PAYKIOSK_PPP_RECOVERY_PAUSE_MS);
      if (ret < 0 && errno == EINTR) {
        // Получен сигнал остановки сервиса
        break;
      }
    }

    // Ожидание строки "CLIENT" от ККТ перед началом PPP соединения
    ret = paykiosk_pppd_check_server_mode(paykiosk_pppd);
    if (ret < 0) {
      // Если произошла ошибка, то либо проблемы с последовательным портом,
      // либо сервис получил внешний сигнал на завершение.
      break;
    }

    // Работа с PPP от подключения до момента разрыва связи.
    // При выходе из этой функции, экземпляр библиотеки libppp
    // всегда уничтожен
    ret = paykiosk_pppd_run_session(paykiosk_pppd);
    if (ret == -EINTR) {
      // Получен сигнал остановки сервиса
      break;
    }
  } // while (!service_should_stop((service_t*)paykiosk_pppd))

cleanup:
  if (port_is_aux) {
    smartio_set_aux_params(&paykiosk_pppd->port, &prev_aux_settings);
  }

  smartio_close(&paykiosk_pppd->port);
  kkt_info("PPPD thread terminated\n");
  return ret;
}

////////////////////////////////////////////////////////////////////////////
//  Публичные функции


/// \brief  Создаёт экземпляр сервиса связи с paykiosk через PPP протокол.
///
/// \param  paykiosk_pppd     Буффер, в котором следует создать экземпляр
///                           сервиса.
/// \param  ttypath           Путь к драйверу последовательного порта.
/// \param  baudrate          Скорость работы последовательного порта.
/// \return 0 в случае успеха или -errno.
int paykiosk_pppd_create(
  paykiosk_pppd_t*  paykiosk_pppd,
  const char*       ttypath,
  speed_t           baudrate
)
{
  int ret;

  // Проверка аргументов и заполнение полей
  if (!paykiosk_pppd || !ttypath) {
    return -EINVAL;
  }

  memset(paykiosk_pppd, 0, sizeof(*paykiosk_pppd));

  paykiosk_pppd->baudrate = baudrate;
  ret = snprintf(
    paykiosk_pppd->ttypath,
    sizeof(paykiosk_pppd->ttypath),
    "%s",
    ttypath
  );

  if (ret >= sizeof(paykiosk_pppd->ttypath)) {
    return -EINVAL;
  }

  // Создание вложенных объектов

  ret = service_create(
    (service_t*)paykiosk_pppd,
    "paykiosk_pppd",
    CONFIG_LIB_KKT_PPP_DAEMON_PRIORITY,
    CONFIG_LIB_KKT_PPP_DAEMON_STACK_SIZE,
    paykiosk_pppd_thread_main,
    paykiosk_pppd
  );
  if (ret < 0) {
    return ret;
  }

  // Успешно создали экземпляр сервиса.
  return 0;
}

/// \brief  Уничтожает экземпляр сервиса \p paykiosk_pppd
int paykiosk_pppd_destroy(paykiosk_pppd_t* paykiosk_pppd)
{
  int ret;

  if (!paykiosk_pppd) {
    return -EINVAL;
  }
  ret = paykiosk_pppd_disconnect(paykiosk_pppd, CONFIG_PAYKIOSK_PPP_KILL_TIMEOUT_MS);
  if (ret < 0) {
    return ret;
  }

  service_delete((service_t*)paykiosk_pppd);

  return 0;
}


/// \brief  Запускает сервис связи и ждёт подключения к удалённой точке
///
/// \param  paykiosk_pppd     Экземпляр сервиса. Обязательно должен быть
///                           создан вызовом `paykiosk_pppd_create` и
///                           ещё не запущен (через paykiosk_pppd_connect
///                           или service_start).
///
/// \param  timeout_ms        Время ожидания подключения к удалённой
///                           точке в миллисекундах.
///                           Если `< 0`, то максимальное время ожидания
///                           будет неограничено, т.е. продлится до момента
///                           подключения, либо до остановки сервиса,
///                           либо до получения сигнала вызывающим потоком.
///
/// \return 0 в случае успеха или -errno.
///
/// \note Если данная функция возвратит любой код ошибки, то
/// при выходе из неё сервис связи будет принудительно остановлен,
/// в том числе при получении вызывающим потоком внешнего сигнала
/// в процессе ожидания подключения. Из-за этой обработки ошибок
/// (и остановки сервиса в случае ошибок) реальная длительность выполнения
/// данной функции может оказаться больше, чем \p timeout_ms.
int paykiosk_pppd_connect(paykiosk_pppd_t* paykiosk_pppd, int timeout_ms)
{
  int             ret;
  struct timeval  timeout;

  ret = service_start((service_t*)paykiosk_pppd);
  if (ret < 0) {
    return ret;
  }

  if (timeout_ms >= 0) {
    timeout = timeval_after_ms(timeout_ms);
  }

  for (;;) {
    if (timeout_ms >= 0 && timeval_passed(&timeout)) {
      // Истекло время ожидания соединения
      ret = -ETIMEDOUT;
      goto cleanup_on_error;
    }

    ret = usleep(100000); // ждём 100 мс
    if (ret < 0 && errno == EINTR) {
      // Получили сигнал прерывания текущего потока.
      // Останавливаем так же и поток сервиса.
      ret = -EINTR;
      goto cleanup_on_error;
    }

    if (!service_is_started((service_t*)paykiosk_pppd)) {
      // Поток сервиса был остановлен. Больше ждать нечего.
      ret = -EIO;
      goto cleanup_on_error;
    }

    if (paykiosk_pppd->has_kkt_addr) {
      break;
    }
  } // for (;;)

  // Дождались установки PPP подключения с удалённой точкой.
  return 0;

cleanup_on_error:
  paykiosk_pppd_disconnect(paykiosk_pppd, CONFIG_PAYKIOSK_PPP_KILL_TIMEOUT_MS);
  return ret;
}

/// \brief  Отправляет сигнал остановки в сервис связи и ждёт его остановки
///
/// \param  paykiosk_pppd     Экземпляр сервиса
/// \param  timeout_ms        Время ожидания остановки сервиса
/// \return 0 в случае успеха или -errno.
///
/// \note Данная функция эквивалентна вызову service_stop_and_wait
///
/// \note Если данная функция возвращает ошибку, то в общем случае следует
/// считать, что сервис не получил сигнала остановки и продолжает
/// работать. Для проверки действительного состояния сервиса
/// можно воспользоваться функциями service_is_started и service_is_alive
int paykiosk_pppd_disconnect(paykiosk_pppd_t* paykiosk_pppd, int timeout_ms)
{
  int ret = service_kill_and_wait((service_t*)paykiosk_pppd, timeout_ms);
  if (ret == -ESRCH) {
    // Сервис не найден - значит уже остановлен. Это не ошибка.
    return 0;
  }
  if (ret < 0) {
    kkt_error("Can't stop service, ret=%d (%s)\n", ret, strerror(-ret));
  }
  return ret;
}

/// \brief  Возвращает IP адрес ККТ.
///
/// \param  paykiosk_pppd     Экземпляр сервиса
/// \param  addr              Переменная, в которую следует сохранить адрес.
///
/// Если PPP сервис подключен к ККТ, то данная функция записывает в \p addr
/// значение ip адреса ККТ (если \p addr не NULL), и возвращает 0.
///
/// \return 0 в случае успеха или -errno.
/// \retval `0`               Сервис подключен к ККТ
/// \retval `-EINVAL`         \p paykiosk_pppd равен NULL
/// \retval `-ENOTCONN`       Сервис не подключен к ККТ, либо не было выдано адреса.
int paykiosk_pppd_get_kkt_ip(paykiosk_pppd_t* paykiosk_pppd, struct in_addr* addr)
{
  if (!paykiosk_pppd) {
    return -EINVAL;
  }

  if (paykiosk_pppd->has_kkt_addr && addr) {
    *addr = paykiosk_pppd->kkt_addr;
  }

  return paykiosk_pppd->has_kkt_addr
         ? 0
         : -ENOTCONN;
}
