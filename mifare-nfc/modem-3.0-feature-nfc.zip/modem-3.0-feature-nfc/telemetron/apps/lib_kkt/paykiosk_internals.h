/// \file
/// \brief  Внутренние определения для модуля paykiosk
/// \author Andrey Syrenkov <a.syrenkov@telemetron.net>
/// \author DL <dmitriy@linikov.ru>
/// \note   Данный модуль - адаптация модулей drv_kkm и kkt_paykiosk
///         из ПО для модема 2.7. Их автор Андрей Сыренков.

#ifndef TELEMETRON_APPS_LIB_KKT_PAYKIOSK_INTERNALS_H_INCLUDED
#define TELEMETRON_APPS_LIB_KKT_PAYKIOSK_INTERNALS_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <kkt/paykiosk.h>

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

// =========================================================================
//    Флаги, добавляемые к коду команды для описания поведения
//    функции kkt_paykiosk_cmd



// ====================== Константы протокола =========================
#define MAX_ENQ_REP                             5
#define MAX_DAT_REP                             10
#define MAX_DAT_REP_TCP                         4

// ======== Определения сырых символов =============
#define STX_CHAR                                0x02
#define ETX_CHAR                                0x03
#define EOT_CHAR                                0x04
#define ENQ_CHAR                                0x05
#define ACK_CHAR                                0x06
#define DLE_CHAR                                0x10
#define NAK_CHAR                                0x15

// ----------------------------------------------------------------------------------------

#define PAYKIOSK_CMDF_NO_PASSWORD 0x80000000
#define PAYKIOSK_MASK_CMD         0x0000FFFF
#define PAYKIOSK_MASK_FLAGS       0xFFFF0000
#define PAYKIOSK_CMD_GET_NUM(cmdf)        ((cmdf) & PAYKIOSK_MASK_CMD)
#define PAYKIOSK_CMD_GET_FLAGS(cmdf)      ((cmdf) & PAYKIOSK_MASK_FLAGS)
#define PAYKIOSK_CMD_GET_MSB(cmdf)        (((cmdf) >> 8) & 0xFF)
#define PAYKIOSK_CMD_GET_LSB(cmdf)        ((cmdf) & 0xFF)
#define PAYKIOSK_CMD_HAS_PASSWORD(cmdf)   (!((cmdf) & PAYKIOSK_CMDF_NO_PASSWORD))
#define PAYKIOSK_CMD_IS_LONG(cmdf)        (PAYKIOSK_CMD_GET_NUM(cmdf) > 0xFF)


////////////////////////////////////////////////////////////////////////////
//  Типы данных

#define PAYKIOSK_MAKE_CMD(cmd_id, flags)          \
    ( ((uint32_t)(cmd_id) & PAYKIOSK_MASK_CMD)    \
    | ((uint32_t)(flags)  & PAYKIOSK_MASK_FLAGS)  \
    )

/// \brief Список команд ШТРИХ
typedef enum paykiosk_cmd_e {
  // Сами команды
  PAYKIOSK_CMD_01   = PAYKIOSK_MAKE_CMD(0x01, 0),
  PAYKIOSK_CMD_17   = PAYKIOSK_MAKE_CMD(0x17, 0),    // Печать строки стандартным шрифтом
  PAYKIOSK_CMD_1E   = PAYKIOSK_MAKE_CMD(0x1E, 0),    // Запись в таблицу
  PAYKIOSK_CMD_1F   = PAYKIOSK_MAKE_CMD(0x1F, 0),    // Чтение таблицы
  PAYKIOSK_CMD_25   = PAYKIOSK_MAKE_CMD(0x25, 0),    // Отрезка чека
  PAYKIOSK_CMD_3F   = PAYKIOSK_MAKE_CMD(0x3F, 0),
  PAYKIOSK_CMD_41   = PAYKIOSK_MAKE_CMD(0x41, 0),
  PAYKIOSK_CMD_42   = PAYKIOSK_MAKE_CMD(0x42, 0),
  PAYKIOSK_CMD_43   = PAYKIOSK_MAKE_CMD(0x43, 0),
  PAYKIOSK_CMD_44   = PAYKIOSK_MAKE_CMD(0x44, 0),
  PAYKIOSK_CMD_45   = PAYKIOSK_MAKE_CMD(0x45, 0),
  PAYKIOSK_CMD_46   = PAYKIOSK_MAKE_CMD(0x46, 0),
  PAYKIOSK_CMD_47   = PAYKIOSK_MAKE_CMD(0x47, 0),
  PAYKIOSK_CMD_48   = PAYKIOSK_MAKE_CMD(0x48, 0),
  PAYKIOSK_CMD_49   = PAYKIOSK_MAKE_CMD(0x49, 0),
  PAYKIOSK_CMD_4A   = PAYKIOSK_MAKE_CMD(0x4A, 0),    // Закрыть чек
  PAYKIOSK_CMD_4B   = PAYKIOSK_MAKE_CMD(0x4B, 0),
  PAYKIOSK_CMD_4C   = PAYKIOSK_MAKE_CMD(0x4C, 0),    // Печать строки
  PAYKIOSK_CMD_4D   = PAYKIOSK_MAKE_CMD(0x4D, 0),
  PAYKIOSK_CMD_4E   = PAYKIOSK_MAKE_CMD(0x4E, 0),
  PAYKIOSK_CMD_4F   = PAYKIOSK_MAKE_CMD(0x4F, 0),
  PAYKIOSK_CMD_50   = PAYKIOSK_MAKE_CMD(0x50, 0),
  PAYKIOSK_CMD_52   = PAYKIOSK_MAKE_CMD(0x52, 0),
  PAYKIOSK_CMD_54   = PAYKIOSK_MAKE_CMD(0x54, 0),
  PAYKIOSK_CMD_56   = PAYKIOSK_MAKE_CMD(0x56, 0),
  PAYKIOSK_CMD_57   = PAYKIOSK_MAKE_CMD(0x57, 0),
  PAYKIOSK_CMD_58   = PAYKIOSK_MAKE_CMD(0x58, 0),
  PAYKIOSK_CMD_59   = PAYKIOSK_MAKE_CMD(0x59, 0),
  PAYKIOSK_CMD_5A   = PAYKIOSK_MAKE_CMD(0x5A, 0),
  PAYKIOSK_CMD_60   = PAYKIOSK_MAKE_CMD(0x60, 0),
  PAYKIOSK_CMD_61   = PAYKIOSK_MAKE_CMD(0x61, PAYKIOSK_CMDF_NO_PASSWORD),
  PAYKIOSK_CMD_62   = PAYKIOSK_MAKE_CMD(0x62, 0),
  PAYKIOSK_CMD_63   = PAYKIOSK_MAKE_CMD(0x63, 0),
  PAYKIOSK_CMD_64   = PAYKIOSK_MAKE_CMD(0x64, 0),
  PAYKIOSK_CMD_65   = PAYKIOSK_MAKE_CMD(0x65, 0),
  PAYKIOSK_CMD_66   = PAYKIOSK_MAKE_CMD(0x66, 0),
  PAYKIOSK_CMD_67   = PAYKIOSK_MAKE_CMD(0x67, 0),
  PAYKIOSK_CMD_68   = PAYKIOSK_MAKE_CMD(0x68, 0),
  PAYKIOSK_CMD_69   = PAYKIOSK_MAKE_CMD(0x69, 0),
  PAYKIOSK_CMD_6A   = PAYKIOSK_MAKE_CMD(0x6A, 0),
  PAYKIOSK_CMD_6B   = PAYKIOSK_MAKE_CMD(0x6B, PAYKIOSK_CMDF_NO_PASSWORD),
  PAYKIOSK_CMD_6C   = PAYKIOSK_MAKE_CMD(0x6C, 0),
  PAYKIOSK_CMD_6D   = PAYKIOSK_MAKE_CMD(0x6D, 0),
  PAYKIOSK_CMD_6E   = PAYKIOSK_MAKE_CMD(0x6E, 0),
  PAYKIOSK_CMD_71   = PAYKIOSK_MAKE_CMD(0x71, 0),
  PAYKIOSK_CMD_73   = PAYKIOSK_MAKE_CMD(0x73, 0),
  PAYKIOSK_CMD_74   = PAYKIOSK_MAKE_CMD(0x74, 0),
  PAYKIOSK_CMD_75   = PAYKIOSK_MAKE_CMD(0x75, 0),
  PAYKIOSK_CMD_77   = PAYKIOSK_MAKE_CMD(0x77, 0),
  PAYKIOSK_CMD_78   = PAYKIOSK_MAKE_CMD(0x78, 0),
  PAYKIOSK_CMD_80   = PAYKIOSK_MAKE_CMD(0x80, 0),
  PAYKIOSK_CMD_82   = PAYKIOSK_MAKE_CMD(0x82, 0),
  PAYKIOSK_CMD_83   = PAYKIOSK_MAKE_CMD(0x83, 0),
  PAYKIOSK_CMD_84   = PAYKIOSK_MAKE_CMD(0x84, 0),
  PAYKIOSK_CMD_85   = PAYKIOSK_MAKE_CMD(0x85, 0),
  PAYKIOSK_CMD_86   = PAYKIOSK_MAKE_CMD(0x86, 0),
  PAYKIOSK_CMD_87   = PAYKIOSK_MAKE_CMD(0x87, 0),
  PAYKIOSK_CMD_88   = PAYKIOSK_MAKE_CMD(0x88, 0),
  PAYKIOSK_CMD_89   = PAYKIOSK_MAKE_CMD(0x89, 0),
  PAYKIOSK_CMD_8A   = PAYKIOSK_MAKE_CMD(0x8A, 0),
  PAYKIOSK_CMD_8B   = PAYKIOSK_MAKE_CMD(0x8B, 0),
  PAYKIOSK_CMD_8C   = PAYKIOSK_MAKE_CMD(0x8C, 0),
  PAYKIOSK_CMD_8D   = PAYKIOSK_MAKE_CMD(0x8D, 0),
  PAYKIOSK_CMD_8E   = PAYKIOSK_MAKE_CMD(0x8E, 0),
  PAYKIOSK_CMD_8F   = PAYKIOSK_MAKE_CMD(0x8F, 0),
  PAYKIOSK_CMD_E0   = PAYKIOSK_MAKE_CMD(0xE0, 0),
  PAYKIOSK_CMD_B0   = PAYKIOSK_MAKE_CMD(0xB0, 0),    // продолжить печать
  PAYKIOSK_CMD_92   = PAYKIOSK_MAKE_CMD(0x92, 0),    // Открыть чек
  PAYKIOSK_CMD_FC   = PAYKIOSK_MAKE_CMD(0xFC, PAYKIOSK_CMDF_NO_PASSWORD),    // Тип принтера
  PAYKIOSK_CMD_11   = PAYKIOSK_MAKE_CMD(0x11, 0),    // Проверка связи. Дата и время принтера
  PAYKIOSK_CMD_FF01 = PAYKIOSK_MAKE_CMD(0xFF01u, 0),  // Команда проверки статуса ФН
  PAYKIOSK_CMD_FF39 = PAYKIOSK_MAKE_CMD(0xFF39u, 0),  // Команда опроса статуса информационного соединенеия с ОФД
} paykiosk_cmd_t;

// Заголовок ответа на команду
typedef struct {
  paykiosk_cmd_t  cmd;
  uint8_t         error;
} paykiosk_rspheader_t;


// Структура пакета PAYKIOSK (Штрих)
typedef struct {
  uint8_t     cmd;
  uint32_t    psw;
} __attribute__((packed)) paykiosk_hdr_cmd_t;

typedef struct {
  uint8_t     cmd;
  uint8_t     error;
} __attribute__((packed)) paykiosk_hdr_rsp_t;

// Двубайтовая команда
typedef struct {
  uint16_t    cmd;
  uint32_t    psw;
} __attribute__((packed)) paykiosk_hdr_wcmd_t;

typedef struct {
  uint16_t    cmd;
  uint8_t     error;
} __attribute__((packed)) paykiosk_hdr_wrsp_t;

// Сторуктура команды 0xFC
typedef struct{
  uint8_t     module_type;
  uint8_t     module_subtype;
  uint8_t     module_ver_protocol;
  uint8_t     module_subver_protocol;
  uint8_t     type;
  uint8_t     lang;
} __attribute__((packed)) paykiosk_cmdFC_t;

// Структура команды 0x11
typedef struct{
  uint8_t     kass_num;
  uint16_t    fw_version;
  uint16_t    fw_build;
  struct{
    uint8_t day;
    uint8_t month;
    uint8_t year;
  }fw_date;
  uint8_t     room_num;
  uint16_t    doc_num;
  uint16_t    kkt_flags;
  uint8_t     kkt_mode;
  uint8_t     kkt_submode;
  uint8_t     kkt_port;
  uint8_t     reserv1[7];
  struct{
    uint8_t day;
    uint8_t month;
    uint8_t year;
    uint8_t hour;
    uint8_t min;
    uint8_t sec;
  }clock;
  uint8_t     reserv2;
  uint32_t    kkt_serial;
  uint16_t    close_num;
  uint16_t    reserv3;
  uint8_t     reregist_count;
  uint8_t     reregist_rest_count;
  uint8_t     inn[6];
  uint16_t    reserv4;
  uint16_t    kkt_serial_hi;
} __attribute__((packed)) paykiosk_cmd11_t;

// Структура соответствия команды запроса с ответом
typedef struct {
  kkmtype_paykiosk_t type;
  uint16_t msg_size;
}kkmtype_to_msgsize_t;


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
} // extern "C"
#endif




#endif // TELEMETRON_APPS_LIB_KKT_PAYKIOSK_INTERNALS_H_INCLUDED
