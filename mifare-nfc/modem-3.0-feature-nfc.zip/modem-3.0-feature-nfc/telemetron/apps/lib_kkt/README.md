# lib_kkt, Библиотека связи с ккт/ккм/принтером

Здесь необходимо добавить описание данной библиотеки.
Оно будет отображаться в браузере при входе в папку библиотеки в bitbucket.

## Features

## Example

```c

#include <kkt/paykiosk.h>
void main(...)
{
  uint32_t result = paykiosk_foo(void);
  printf("paykiosk_foo = %d\n", result);
}
```

## Limitations

Список известных ограничений.

## Bugs

Багов нет, есть незадокументированные фичи.

## Licensing

## Author

DL <dmitriy@linikov.ru>
