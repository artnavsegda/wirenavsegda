/****************************************************************************
 * telemetron/apps/gsmd/gsmd_main.c
 *
 * GSM modem daemon.
 * Сервис поддержки gsm модема.
 ****************************************************************************/

/****************************************************************************
 * Included Files
 ****************************************************************************/

#include <nuttx/config.h>

#include <debug.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <nuttx/modem/ioctl.h>
#include <nuttx/gsm/modem_ioctl.h>
#include <gsmd/gsmd.h>
#include <utils/posix_iohelper.h>

/****************************************************************************
 * Private state
 ****************************************************************************/

/****************************************************************************
 * Private Functions
 ****************************************************************************/

static void print_usage(void)
{
  fprintf(stderr,
    "Usage:\n"
    "  gsmd start [modem_path [serial_path [apn [user_name [password]]]]]\n"
    "  gsmd stop\n\n"
    "Where:"
    "  modem_path     - path to modem driver.\n\n"
    "  serial_path    - path to modem serial port.\n\n"
    "  apn            - Parameters of GSM access point\n"
    "  username         that shall be used when starting\n"
    "  password         a PPP session. \n"
    "\n"
    "Default values:\n"
    "  modem_path  = \"%s\"\n"
    "  serial_path = \"%s\"\n"
    "  apn         = \"%s\"\n"
    "  username    = \"%s\"\n"
    "  password    = \"%s\"\n"
    "\n",
    CONFIG_TELEMETRON_GSMD_MODEM_PATH,
    CONFIG_TELEMETRON_GSMD_PPP_TTY_PATH,
    CONFIG_TELEMETRON_GSMD_APN_NAME,
    CONFIG_TELEMETRON_GSMD_APN_USER,
    CONFIG_TELEMETRON_GSMD_APN_PWD
  );
}

static int gsmd_daemon_start(int argc, char** argv, int* args_used)
{
  int             ret;
  gsmd_t*         gsmd;
  gsmd_settings_t settings;

  (void)args_used;

  memset(&settings, 0, sizeof(settings));

  settings.eventq_name      = NULL;
  settings.ppp_override_apn = true;
  settings.gsm_path     = argc > 1 ? argv[1] : CONFIG_TELEMETRON_GSMD_MODEM_PATH;
  settings.tty_path     = argc > 2 ? argv[2] : CONFIG_TELEMETRON_GSMD_PPP_TTY_PATH;
  settings.ppp_apn      = argc > 3 ? argv[3] : CONFIG_TELEMETRON_GSMD_APN_NAME;
  settings.ppp_user     = argc > 4 ? argv[4] : CONFIG_TELEMETRON_GSMD_APN_USER;
  settings.ppp_pwd      = argc > 5 ? argv[5] : CONFIG_TELEMETRON_GSMD_APN_PWD;

  gsmd = gsmd_get_instance();

  ret = gsmd_setup(gsmd, &settings);
  if (ret < 0) {
    fprintf(
      stderr, "ERROR: Can't configure gsmd, err=%d (%s)\n\n",
      ret, strerror(-ret)
    );
    return ret;
  }

  if (service_is_alive((service_t*)gsmd)) {
    fprintf(stderr, "WARNING: Already started. Just changed settings\n\n");
    return 0;
  }

  ret = service_start((service_t*)gsmd);
  if (ret < 0) {
    fprintf(stderr, "ERROR: Can't start gsmd daemon, err=%d (%s)\n\n",
      ret, strerror(-ret)
    );
    return ret;
  }

  printf("gsmd daemon started.\n");
  return OK;
}

static int gsmd_daemon_stop(int argc, char** argv, int* args_used)
{
  (void)args_used;
  int         ret;
  gsmd_t*     gsmd = gsmd_get_instance();
  service_t*  service = (service_t*)gsmd;

  if (!service_is_alive(service)) {
    fprintf(stderr, "WARNING: Daemon was not running.\n\n");
    return 0;
  }

  ret = service_kill(service);
  if (ret < 0) {
    fprintf(stderr, "ERROR: Can't send kill signal, err=%d (%s).\n\n",
      ret, strerror(-ret)
    );
    return ret;
  }

  ret = service_wait_terminated(service, 20000);
  if (ret < 0) {
    fprintf(stderr, "ERROR: Signal sent but service still alive, err=%d (%s).\n\n",
      ret, strerror(-ret)
    );
    return ret;
  }

  printf("gsmd daemon terminated.\n");
  return 0;
}

static int gsmd_daemon_status(int argc, char** argv, int* args_used)
{
  (void)args_used;

  gsmd_t*     gsmd = gsmd_get_instance();
  service_t*  service = (service_t*)gsmd;

  if (!service_is_alive(service)) {
    printf("Not started\n");
    return -1;
  }

  gsmd_state_t state = gsmd->state;
  printf("%s\n", gsmd_state_to_string(state));
  return (int)state;
}


static const
  struct name_to_action {
    const char* name;
    int (*fxn)(int argc, char** argv, int* args_used);
  }
  GSMD_ACTIONS[] = {
    { .name = "start",  .fxn = gsmd_daemon_start   },
    { .name = "stop",   .fxn = gsmd_daemon_stop    },
    { .name = "status", .fxn = gsmd_daemon_status  },
    // Терминатор списка.
    { .name = NULL,       .fxn = NULL         }
  };

static const struct name_to_action* find_action_for_arg(const char* arg)
{
  // Ищем обработчик команды, у которого name равен значению параметра arg.
  const struct name_to_action* result = GSMD_ACTIONS;
  while (result && result->name) {
    if (strcmp(arg, result->name) == 0) {
      // Нашли, возвращаем его.
      return result;
    }
    ++result;
  }

  // Не нашли. Возвращаем NULL.
  return NULL;
}


/****************************************************************************
 * gsmd_main
 ****************************************************************************/

#ifdef CONFIG_BUILD_KERNEL
int main(int argc, FAR char *argv[])
#else
int gsmd_main(int argc, char *argv[])
#endif
{
  if (argc == 1) {
    print_usage();
    return -1;
  }

  int arg_n       = 1;
  int last_error  = 0;
  // разбор параметров и выполнение соответствующих команд.
  while (arg_n < argc) {
    const struct name_to_action* action = find_action_for_arg(argv[arg_n]);

    if (!action || !action->fxn) {
      // Обнаружили неизвестный параметр.
      fprintf(stderr, "  Unknown arg #%d=\"%s\"\n", arg_n, argv[arg_n]);

      // Пропускаем его и переходим к проверке следующего
      ++arg_n;
      continue;
    }

    // Считаем, что стандартно действие использует 1 аргумент.
    // Такое действие может не использовать параметр args_used.
    int args_used = 1;
    int ret = action->fxn(argc-arg_n, &argv[arg_n], &args_used);

    if (ret < 0) {
      last_error = ret;
      _err("gsmd %s: err=%d (%s)\n", action->name, -ret, strerror(-ret));
    }

    arg_n += args_used;
  } // while (arg_n < argc) ...

  return last_error;
}
