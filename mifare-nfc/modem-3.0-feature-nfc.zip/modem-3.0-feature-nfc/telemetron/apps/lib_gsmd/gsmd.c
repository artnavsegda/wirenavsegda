/// \file
/// \brief  Сервис поддержания ppp сеанса связи через GSM модуль.
/// \author DL <dmitriy@linikov.ru>

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <gsmd/gsmd.h>

#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <net/if.h>
#include <net/route.h>
#include <nuttx/net/tun.h>
#include <netutils/netlib.h>

#include <nuttx/gsm/modem_ioctl.h>
#include <nuttx/gsm/stdmodem_commands.h>
#include <utils/posix_iohelper.h>
#include <utils/service.h>
#include <utils/string_utils.h>
#include <utils/system_utils.h>
#include <utils/time_utils.h>



////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


#if (CONFIG_LIB_GSMD_BAUDRATE == 9600)
# define GSMD_TERMIOS_BAUDRATE_ID          B9600

#elif (CONFIG_LIB_GSMD_BAUDRATE == 19200)
# define GSMD_TERMIOS_BAUDRATE_ID          B19200

#elif (CONFIG_LIB_GSMD_BAUDRATE == 38400)
# define GSMD_TERMIOS_BAUDRATE_ID          B38400

#elif (CONFIG_LIB_GSMD_BAUDRATE == 57600)
# define GSMD_TERMIOS_BAUDRATE_ID          B57600

#elif (CONFIG_LIB_GSMD_BAUDRATE == 115200)
# define GSMD_TERMIOS_BAUDRATE_ID          B115200

#elif (CONFIG_LIB_GSMD_BAUDRATE == 230400)
# define GSMD_TERMIOS_BAUDRATE_ID          B230400

#elif (CONFIG_LIB_GSMD_BAUDRATE == 460800)
# define GSMD_TERMIOS_BAUDRATE_ID          B460800

#else
# error Unsupported value of CONFIG_LIB_GSMD_BAUDRATE
#endif


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

static ssize_t  gsmd_ppp_write(void* arg, const void* buf, size_t bufsize);
static ssize_t  gsmd_ppp_read(void* arg, void* buf, size_t bufsize);
static int      gsmd_ppp_get_stream_file(void* arg, struct file** fp);
static void     gsmd_ppp_set_dns(void* arg, uint8_t id, const struct sockaddr* dnsaddr, socklen_t addrlen);
static void     gsmd_ppp_clr_dns(void* arg);
static void     gsmd_ppp_on_ifup(void* arg, const struct in_addr* ouraddr, const struct in_addr* gateway, const struct in_addr* mask);
static void     gsmd_ppp_on_ifdown(void* arg);
static void     gsmd_ppp_on_link_status(void* arg, libppp_err_t status);
static void     gsmd_ppp_on_phase(void* arg, libppp_phase_t phase);

static int      gsmd_set_state(gsmd_t* gsmd, gsmd_state_t newstate);

static void gsmd_addroute(
  gsmd_t* gsmd,
  const struct in_addr* target,
  const struct in_addr* netmask,
  const struct in_addr* gateway
);
static void gsmd_delroute(gsmd_t* gsmd);


////////////////////////////////////////////////////////////////////////////
//  Константы

static const struct libppp_cb_s GSMD_LIBPPP_CALLBACKS = {
  .write              = gsmd_ppp_write,
  .read               = gsmd_ppp_read,
  .get_stream_file    = gsmd_ppp_get_stream_file,
  .set_dns            = gsmd_ppp_set_dns,
  .clr_dns            = gsmd_ppp_clr_dns,
  .on_ifup            = gsmd_ppp_on_ifup,
  .on_ifdown          = gsmd_ppp_on_ifdown,
  .on_ppp_link_status = gsmd_ppp_on_link_status,
  .on_ppp_phase       = gsmd_ppp_on_phase,
};

////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные

static gsmd_t             g_gsmd_instance;
static gsmd_t* volatile   g_gsmd = NULL;

////////////////////////////////////////////////////////////////////////////
//  Приватные функции

static ssize_t  gsmd_ppp_write(void* arg, const void* buf, size_t bufsize)
{
  gsmd_t* gsmd = (gsmd_t*)arg;
  DEBUGASSERT(gsmd);

  return atport_write(&gsmd->port, buf, bufsize);
}

static ssize_t  gsmd_ppp_read(void* arg, void* buf, size_t bufsize)
{
  ssize_t ret;
  gsmd_t* gsmd = (gsmd_t*)arg;
  DEBUGASSERT(gsmd);

  ret = atport_nbread(&gsmd->port, buf, bufsize);
  if (ret == -EAGAIN || ret == -ETIMEDOUT) {
    return 0;
  }
  return ret;
}

static int      gsmd_ppp_get_stream_file(void* arg, struct file** fp)
{
  gsmd_t* gsmd = (gsmd_t*)arg;
  DEBUGASSERT(gsmd);
  if (fp) {
    *fp = atport_get_file(&gsmd->port);
  }
  return 0;
}

static void     gsmd_ppp_set_dns(void* arg, uint8_t id, const struct sockaddr* dnsaddr, socklen_t addrlen)
{
  int     ret;
  gsmd_t* gsmd = (gsmd_t*)arg;
  char    buffer[INET_ADDRSTRLEN];
  DEBUGASSERT(gsmd);
  DEBUGASSERT(dnsaddr && dnsaddr->sa_family == AF_INET);

  const struct sockaddr_in* addr = (const struct sockaddr_in*)dnsaddr;

  gsmd_info(
    "DNS%u = %s\n",
    id,
    inet_ntop(AF_INET, &addr->sin_addr, buffer, sizeof(buffer))
  );

  if (id != 0) {
    return;
  }

  ret = netlib_set_ipv4dnsaddr(&addr->sin_addr);
  if (ret < 0) {
    gsmd_warn("Can't set DNS address, ret=%d (%s)\n", ret, strerror(-ret));
  }
}

static void     gsmd_ppp_clr_dns(void* arg)
{
  int     ret;
  gsmd_t* gsmd = (gsmd_t*)arg;
  DEBUGASSERT(gsmd);

  struct in_addr  addr;
  addr.s_addr = htonl(INADDR_ANY);
  ret = netlib_set_ipv4dnsaddr(&addr);
  if (ret < 0) {
    gsmd_warn("Can't clear DNS address, ret=%d (%s)\n", ret, strerror(-ret));
  }
}

static void     gsmd_ppp_on_ifup(void* arg, const struct in_addr* ouraddr, const struct in_addr* gateway, const struct in_addr* mask)
{
  char buffer[INET_ADDRSTRLEN];
  gsmd_t* gsmd = (gsmd_t*)arg;
  DEBUGASSERT(gsmd);


  gsmd_info("Connected\n");
  gsmd_info("   ipaddr    = %s\n", inet_ntop(AF_INET, ouraddr, buffer, sizeof(buffer)));
  gsmd_info("   gateway   = %s\n", inet_ntop(AF_INET, gateway, buffer, sizeof(buffer)));
  gsmd_info("   netmask   = %s\n", inet_ntop(AF_INET, mask, buffer, sizeof(buffer)));

  // Регистрируем стандартный маршрут через PPP интерфейс
  if (gsmd->have_route) {
    gsmd_delroute(gsmd);
  }
  struct in_addr target;
  target.s_addr = htonl(INADDR_ANY); // 0.0.0.0
  gsmd_addroute(gsmd, &target, &target, gateway);
}

static void     gsmd_ppp_on_ifdown(void* arg)
{
  gsmd_t* gsmd = (gsmd_t*)arg;
  DEBUGASSERT(gsmd);
  gsmd_delroute(gsmd);
}

static void     gsmd_ppp_on_link_status(void* arg, libppp_err_t status)
{
  gsmd_t* gsmd = (gsmd_t*)arg;
  DEBUGASSERT(gsmd);

  gsmd->ppp_err = status;
}

static void     gsmd_ppp_on_phase(void* arg, libppp_phase_t phase)
{
  gsmd_t* gsmd = (gsmd_t*)arg;
  DEBUGASSERT(gsmd);
  // Не используем
}








static void gsmd_addroute(
  gsmd_t* gsmd,
  const struct in_addr* target,
  const struct in_addr* netmask,
  const struct in_addr* gateway
)
{
  gsmd->route_target.sin_family   = AF_INET;
  gsmd->route_target.sin_port     = 0;
  gsmd->route_target.sin_addr     = *target;

  gsmd->route_netmask.sin_family  = AF_INET;
  gsmd->route_netmask.sin_port    = 0;
  gsmd->route_netmask.sin_addr    = *netmask;

  gsmd->route_gateway.sin_family  = AF_INET;
  gsmd->route_gateway.sin_port    = 0;
  gsmd->route_gateway.sin_addr    = *gateway;


  int sockfd = socket(AF_INET, NETLIB_SOCK_TYPE, 0);
  if (sockfd < 0) {
    gsmd_error("Can't create socket, ret=%d (%s)\n", errno, strerror(errno));
    return;
  }

  int ret = addroute(
    sockfd,
    (FAR struct sockaddr_storage *)&gsmd->route_target,
    (FAR struct sockaddr_storage *)&gsmd->route_netmask,
    (FAR struct sockaddr_storage *)&gsmd->route_gateway
  );

  if (ret < 0) {
    gsmd_error("Can't add route, ret=%d (%s)\n", errno, strerror(-errno));
  } else {
    gsmd_info("Added route.\n");
    gsmd->have_route = true;
  }

  close(sockfd);
}

static void gsmd_delroute(gsmd_t* gsmd)
{
  if (!gsmd->have_route) {
    return;
  }

  int sockfd = socket(AF_INET, NETLIB_SOCK_TYPE, 0);
  if (sockfd < 0) {
    gsmd_error("Can't create socket, ret=%d (%s)\n", errno, strerror(errno));
    return;
  }

  int ret = delroute(
    sockfd,
    (FAR struct sockaddr_storage *)&gsmd->route_target,
    (FAR struct sockaddr_storage *)&gsmd->route_netmask
  );

  if (ret < 0) {
    gsmd_warn("Can't delete default route, ret=%d (%s)\n", errno, strerror(-errno));
  } else {
    gsmd_info("Deleted route\n");
    gsmd->have_route = false;
  }

  close(sockfd);
}

/// \brief Отправляет в очередь сообщений одно сообщение
static int gsmd_emit_event(gsmd_t* me, int event, const void* data, size_t size)
{
  int ret;
#ifdef CONFIG_LIB_EVENTQ
  if (!eventq_is_opened(&me->output)) {
    // Сервис работает без очереди сообщений от сервера к устройству.
    // Такое допустимо, это не ошибка.
    return OK;
  }


  ret = eventq_waittx(&me->output, CONFIG_LIB_GSMD_T_OUTPUT_QUEUE_WAIT_MS);
  if (ret < 0) {
    gsmd_warn("no space in eventq. event lost.\n");
    return ret;
  }

  ret = eventq_write(&me->output, event, data, size);
  if (ret != OK) {
    gsmd_warn("can't write to eventq. event lost.\n");
    return ret;
  }
#else
  gsmd_trace("EventQ not enabled. Discarded event %d\n", event);
#endif

  return OK;
}

/// \brief Отправляет в очередь сообщений одно сообщение типа EV_GSMD_STATE
int gsmd_emit_ev_gsmd_state(gsmd_t* me, gsmd_state_t state)
{
  ev_gsmd_state_t ev;
  ev.state = state;
  return gsmd_emit_event(me, EV_GSMD_STATE, &ev, sizeof(ev_gsmd_state_t));
}


static int gsmd_set_state(gsmd_t* gsmd, gsmd_state_t newstate)
{
  if (gsmd->state == newstate) {
    return 0;
  }

  gsmd_trace(
    "State %s->%s\n",
    gsmd_state_to_string(gsmd->state),
    gsmd_state_to_string(newstate)
  );
  gsmd->state = newstate;
  return gsmd_emit_ev_gsmd_state(gsmd, newstate);
}

static void gsmd_start_timer(gsmd_t* gsmd, int timeout_ms)
{
  if (timeout_ms < 0) {
    timespec_clear(&gsmd->timer);
    return;
  }

  gsmd->timer = timespec_after_ms(timeout_ms);
}

static bool gsmd_timer_elapsed(gsmd_t* gsmd)
{
  return timespec_is_passed(&gsmd->timer);
}



static void gsmd_cleanup(gsmd_t* gsmd)
{
  // в данной функции не выходим при возникновении ошибки, т.к.
  // нужно подчистить при любом раскладе.
  int ret;
  if (atport_isopen(&gsmd->port)) {
    ret = atport_close(&gsmd->port);
    if (ret < 0) {
      gsmd_warn("Can't close atport, ret=%d (%s)\n", ret, strerror(-ret));
    }
  }

  if (gsmd->gsm >= 0) {
    ret = ioctl(gsmd->gsm, MODEM_IOC_POWEROFF, 0);
    if (ret < 0) {
      gsmd_warn("Can't poweroff modem, ret=%d (%s)\n", ret, strerror(-ret));
    }

    ret = close(gsmd->gsm);
    if (ret < 0) {
      // Это серьёзная ошибка, которая приведёт к утечке файловых дескрипторов
      // но лучшее, что можем сделать - вывести в лог информацию.
      gsmd_error("ERROR: Can't close gsm driver, ret=%d (%s)\n", ret, strerror(-ret));
    }
    gsmd->gsm = -1;
  }
}



static int gsmd_init(gsmd_t* gsmd)
{
  int             ret;
  modem_status_t  status;


  if (    IsWhiteOrEmptyString(gsmd->gsm_path)
      ||  IsWhiteOrEmptyString(gsmd->tty_path)
  ) {
    gsmd_warn("WARN: gsm_path or tty_path not set. Can't start.\n");
    return -EBADFD;
  }

  // Открытие драйвера GSM модуля
  ret = open(gsmd->gsm_path, O_RDWR);
  if (ret < 0) {
    ret = -errno;
    gsmd_trace("Can't open '%s', ret=%d (%s)\n", gsmd->gsm_path, ret, strerror(-ret));
    return ret;
  }
  gsmd->gsm = ret;


  // Проверка, что gsm модуль выключен
  ret = ioctl(gsmd->gsm, MODEM_IOC_GETSTATUS, (uintptr_t)&status);
  if (ret < 0) {
    ret = -errno;
    gsmd_trace("Can't get status, ret=%d (%s)\n", ret, strerror(-ret));
    return ret;
  }

  // Включение или перезапуск gsm модуля
  int cmd = status == MODEM_STATUS_OFF
          ? MODEM_IOC_POWERON
          : MODEM_IOC_RESET;

  ret = ioctl(gsmd->gsm, cmd, 0);
  if (ret < 0) {
    ret = -errno;
    gsmd_trace("Can't turn on modem, ret=%d (%s)\n", ret, strerror(-ret));
    return ret;
  }

  // Модем включен. Открываем порт.
  // Поскольку обычно требуется некоторое время (0.5 - 1 секунды) на старт мультиплексора,
  // то будем открывать порт в цикле с таймаутом.
  struct timespec   timeout = timespec_after_ms(CONFIG_LIB_GSMD_WAIT_AT_READY_MS);
  for (;;) {
    ret = atport_open(&gsmd->port, gsmd->tty_path, GSMD_TERMIOS_BAUDRATE_ID);
    if (ret >= 0) {
      // успешно открыли.
      break;
    }

    gsmd_trace("Can't open modem port '%s', ret=%d (%s)\n",
      gsmd->tty_path, ret, strerror(-ret)
    );

    // Если мультиплексор ещё не запущен, то попытка открыть порт возвращает ENOTCONN.
    if (ret != -ENOTCONN) {
      // Все остальные ошибки возвращаем сразу.
      return ret;
    }

    if (timespec_is_passed(&timeout)) {
      // Истекло время ожидания, а порт так и не открыли.
      return -ENOTCONN;
    }

    // Если ещё есть время, то ждём 100мс.
    ret = usleep(100000);
    if (ret < 0) {
      return ret;
    }
  }

  // модем готов к приёму команд (и при этом SIM карта так же готова).
  return 0;
}

/// \return 0=сеть не готова, 1=сеть готова, или отрицательный код ошибки (-errno)
static int gsmd_check_net(gsmd_t* gsmd)
{
  int ret;
  int netstate;
  int gprsstate;

  (void)gprsstate; // Возможно не используется.

  ret = stdmodem_get_net_state(&gsmd->port, &netstate);
  if (ret == -ETIMEDOUT || ret == -ENOEXEC) {
    // Ошибка выполнения команды. Просто возвращаем, что сеть не готова.
    return 0;
  }

  if (ret < 0) {
    // Прерывание или ошибка порта - возвращаем ошибку.
    return ret;
  }

  if (netstate != STDMODEM_NETSTAT_REGISTERED
      && netstate != STDMODEM_NETSTAT_ROAMING
  ) {
    return 0; // сеть не готова.
  }

  gsmd->roaming = (netstate == STDMODEM_NETSTAT_ROAMING);


#if 0
  ret = stdmodem_get_gprs_state(&gsmd->port, &gprsstate);
  if (ret == -ETIMEDOUT || ret == -ENOEXEC) {
    // Ошибка выполнения команды. Просто возвращаем, что сеть не готова.
    return 0;
  }

  if (ret < 0) {
    // Прерывание или ошибка порта - возвращаем ошибку.
    return ret;
  }

  if (gprsstate != 1) {
    return 0; // сеть не готова.
  }
#endif
  return 1;
}

/// Пытается синхронно завершить сеанс ppp
static void gsmd_ppp_fair_close(gsmd_t* gsmd, bool emergency)
{
  libppp_close(gsmd->ppp, emergency);
  for (size_t i=0; i < 10; ++i) {
    if (libppp_get_phase(gsmd->ppp) == LIBPPP_PHASE_DEAD) {
      goto cleanup_gsm;
    }
    libppp_process(gsmd->ppp);
  }

  // Если добрались до сюда, то emergency = false и
  // слишком долго не получается завершить сеанс связи.
  libppp_close(gsmd->ppp, true);

cleanup_gsm:
  stdmodem_switch_to_cmd_mode(&gsmd->port);
}


static int gsmd_run(gsmd_t* gsmd)
{
  int ret = 0;

  if (gsmd->settings_changed) {
    // Такой код ошибки не встречается при обычной работе,
    // поэтому будем считать, что он всегда означает изменившиеся настройки.
    gsmd->settings_changed = false;
    return -EOWNERDEAD;
  }


  switch (gsmd->state) {
  case GSMD_STATE_UNINITED:
    gsmd_set_state(gsmd, GSMD_STATE_TURNING_ON);
    break;


  case GSMD_STATE_START_RECOVER_FROM_HARD_ERROR:
    // Модем не включается
    gsmd_trace("Recovering from hard error. Turned off the modem.\n");
    gsmd_set_state(gsmd, GSMD_START_RECOVERING_FROM_ERROR_WITH_POWERCYCLE);
    break;


  case GSMD_STATE_START_RECOVER_FROM_SIMCARD_ERROR:
    // Ошибка симкарты
    gsmd_trace("Recovering from simcard error. Turned off the modem.\n");
    gsmd_set_state(gsmd, GSMD_START_RECOVERING_FROM_ERROR_WITH_POWERCYCLE);
    break;


  case GSMD_STATE_START_RECOVER_FROM_GSM_ERROR:
    // слишком долгая регистрация в сети
    gsmd_trace("Recovering from long gsm registration. Turned off the modem.\n");
    gsmd_set_state(gsmd, GSMD_START_RECOVERING_FROM_ERROR_WITH_POWERCYCLE);
    break;


  case GSMD_STATE_START_RECOVER_FROM_GPRS_ERROR:
    // слишком долго нет ip пакетов от GSM сети
    gsmd_trace("Recovering from long gprs inactivity. Turned off the modem.\n");
    gsmd_set_state(gsmd, GSMD_START_RECOVERING_FROM_ERROR_WITH_POWERCYCLE);
    break;


  case GSMD_START_RECOVERING_FROM_ERROR_WITH_POWERCYCLE:
    // Фактическая реализация восстановления после хард-сбоя,
    // заданного состояниями GSMD_STATE_START_RECOVER_FROM_xxx
    //
    // Отключение модема и переход в состояние паузы перед повторным включением
    gsmd_cleanup(gsmd);
    gsmd_start_timer(gsmd, CONFIG_LIB_GSMD_HARD_RECOVERY_MS);
    gsmd_set_state(gsmd, GSMD_STATE_RECOVERING_SLEEP);
    break;

  case GSMD_STATE_START_CHANGING_SETTINGS:
    gsmd_trace("Settings changed. Turned off the modem.\n");
    gsmd_cleanup(gsmd);
    gsmd_start_timer(gsmd, 2000);
    gsmd_set_state(gsmd, GSMD_STATE_RECOVERING_SLEEP);
    break;

  case GSMD_STATE_RECOVERING_SLEEP:
    // Пауза перед повторным включением
    if (!gsmd_timer_elapsed(gsmd)) {
      ret = usleep(CONFIG_LIB_GSMD_IDLE_SLEEP_MS * 1000);
      break;
    }

    gsmd_set_state(gsmd, GSMD_STATE_TURNING_ON);
    break;


  case GSMD_STATE_TURNING_ON:
    // Открытие всех необходимых драйверов и включение модема.
    ret = gsmd_init(gsmd);
    if (ret < 0) {
      gsmd_set_state(gsmd, GSMD_STATE_START_RECOVER_FROM_HARD_ERROR);
      break;
    }
    gsmd_start_timer(gsmd, CONFIG_LIB_GSMD_WAIT_AT_READY_MS);
    gsmd_set_state(gsmd, GSMD_STATE_WAITING_FOR_AT_READY);
    break;


  case GSMD_STATE_WAITING_FOR_AT_READY:
    // Ожидание ответа на первую AT команду. Можно использовать просто AT,
    // но лучше, что бы не использовать бессмысленные команды - сразу ATE1.
    ret = stdmodem_echo_on(&gsmd->port);
    if (ret >= 0) {
      // Успешно получили ответ на команду включения эхо-ответа.
      // Уходим в следующее состояние
      gsmd_set_state(gsmd, GSMD_STATE_START_WAITING_SIM_READY);
      break;
    }

    // Обработка возможных ошибок при выполнении команды.
    // позволяем только таймауты и возвращаемые AT-портом ошибки.
    if (ret != -ETIMEDOUT && ret != ENOEXEC) {
      break;
    }

    // Поскольку остальные ошибки обрабатываются во внешнем цикле,
    // то не передаём эту ошибку на уровень выше.
    ret = 0;

    if (gsmd_timer_elapsed(gsmd)) {
      // Истёк таймер ожидания ответа на первую AT команду.
      // Скорее всего, аппаратные проблемы. Попробуем выключить-включить.
      gsmd_set_state(gsmd, GSMD_STATE_START_RECOVER_FROM_HARD_ERROR);
      break;
    }

    // Таймер не истёк. Ждём.
    ret = usleep(CONFIG_LIB_GSMD_IDLE_SLEEP_MS * 1000);
    break;


  case GSMD_STATE_START_WAITING_SIM_READY:
    // В текущей реализации драйвер модема сам дожидается готовности
    // SIM карты. Поэтому здесь только читаем информацию о симкарте
    // из недр драйвера.
    ret = modem_get_iccid(gsmd->gsm, &gsmd->iccid);
    if (ret < 0) {
      gsmd_trace("Can't get iccid, ret=%d (%s)\n", ret, strerror(-ret));
      break;
    }

    gsmd_set_state(gsmd, GSMD_STATE_START_WAITING_NET_REGISTRATION);
    break;


  case GSMD_STATE_START_WAITING_NET_REGISTRATION:
    // Вход в ожидание готовности сети.
    gsmd_start_timer(gsmd, CONFIG_LIB_GSMD_WAIT_NET_REGISTRATION_MS);
    gsmd_set_state(gsmd, GSMD_STATE_WAITING_NET_REGISTRATION);
    break;


  case GSMD_STATE_WAITING_NET_REGISTRATION:
    // Ожидание готовности сети.
    if (gsmd_timer_elapsed(gsmd)) {
      gsmd_trace("Net not ready.\n");
      gsmd_set_state(gsmd, GSMD_STATE_START_RECOVER_FROM_GSM_ERROR);
      break;
    }

    ret = gsmd_check_net(gsmd);
    if (ret < 0) {
      break;
    }
    if (ret == 0) {
      // без ошибок, но сеть ещё не готова. Ждём.
      usleep(CONFIG_LIB_GSMD_IDLE_SLEEP_MS * 1000);
      break;
    }

    // сеть готова к установке связи.
    gsmd_set_state(gsmd, GSMD_STATE_PPP_INIT);
    break;


  case GSMD_STATE_PPP_INIT:
    libppp_set_asyncmap(gsmd->ppp, 0x00000000);
    libppp_set_neg_asyncmap(gsmd->ppp, true);
    libppp_set_auth(gsmd->ppp, LIBPPP_AUTHTYPE_PAP, gsmd->ppp_user, gsmd->ppp_pwd);
    libppp_set_usepeerdns(gsmd->ppp, 1);

    ret = stdmodem_connect_ip(&gsmd->port, gsmd->ppp_apn);
    if (ret < 0) {
      _warn("Can't dial data. ret=%d (%s)\n", ret, strerror(-ret));
      gsmd_set_state(gsmd, GSMD_STATE_START_RECOVER_FROM_GSM_ERROR);
      break;
    }

    ret = libppp_connect(gsmd->ppp, 0);
    if (ret < 0) {
      gsmd_set_state(gsmd, GSMD_STATE_START_RECOVER_FROM_GSM_ERROR);
      ret = 0;
    }
    gsmd_set_state(gsmd, GSMD_STATE_PPP_HANDSHAKING);
    break;

  case GSMD_STATE_PPP_HANDSHAKING:
    // Состояние PPP_INIT использует тот же таймер,
    // что был создан при входе в WAITING_NET_REGISTRATION.
    if (gsmd_timer_elapsed(gsmd)) {
      gsmd_trace("Can't start PPP session for too long.\n");
      libppp_close(gsmd->ppp, false);
      gsmd_set_state(gsmd, GSMD_STATE_PPP_CLOSING);
      break;
    }

    ret = libppp_process(gsmd->ppp);
    if (ret == -EINTR) {
      // Возвращает только -EINTR ошибку, остальные обрабатываются внутри.
      gsmd_ppp_fair_close(gsmd, false);
      gsmd_set_state(gsmd, GSMD_STATE_PPP_CLOSED);
      break;
    }

    if (libppp_get_phase(gsmd->ppp) == LIBPPP_PHASE_DEAD) {
      gsmd_set_state(gsmd, GSMD_STATE_PPP_CLOSED);
      break;
    }

    if (libppp_get_phase(gsmd->ppp) == LIBPPP_PHASE_RUNNING) {
      gsmd_set_state(gsmd, GSMD_STATE_PPP_ONLINE);
      break;
    }
    break;

  case GSMD_STATE_PPP_ONLINE:
    ret = libppp_process(gsmd->ppp);
    if (ret == -EINTR) {
      // Возвращает только -EINTR ошибку, остальные обрабатываются внутри.
      gsmd_ppp_fair_close(gsmd, false);
      gsmd_set_state(gsmd, GSMD_STATE_PPP_CLOSED);
      break;
    }
    if (libppp_get_phase(gsmd->ppp) != LIBPPP_PHASE_RUNNING) {
      // Утеряна связь.
      gsmd_set_state(gsmd, GSMD_STATE_PPP_CLOSING);
      break;
    }
    break;

  case GSMD_STATE_PPP_CLOSING:
    ret = libppp_process(gsmd->ppp);
    if (ret == -EINTR) {
      // Возвращает только -EINTR ошибку, остальные обрабатываются внутри.
      gsmd_ppp_fair_close(gsmd, false);
      gsmd_set_state(gsmd, GSMD_STATE_PPP_CLOSED);
      break;
    }

    if (libppp_get_phase(gsmd->ppp) == LIBPPP_PHASE_DEAD) {
      gsmd_set_state(gsmd, GSMD_STATE_PPP_CLOSED);
      break;
    }

    // Если PPP сессия восстановилась самостоятельно, то
    // уходим обратно в PPP_ONLINE состояние.
    if (libppp_get_phase(gsmd->ppp) == LIBPPP_PHASE_RUNNING) {
      gsmd_set_state(gsmd, GSMD_STATE_PPP_ONLINE);
      break;
    }
    break;

  case GSMD_STATE_PPP_CLOSED:
    gsmd_info(
      "Last PPP error = %d (%s - %s)\n",
      (int)gsmd->ppp_err,
      libppp_err_to_string(gsmd->ppp_err),
      libppp_err_to_description(gsmd->ppp_err)
    );
    gsmd_set_state(gsmd, GSMD_STATE_WAITING_FOR_AT_READY);
    break;
  };
  return ret;
}

static int gsmd_thread_main(void* arg)
{
  int     ret;
  gsmd_t* gsmd = (gsmd_t*)arg;

#ifdef CONFIG_LIB_EVENTQ
  if (!IsWhiteOrEmptyString(gsmd->eventq_name)) {
    ret = eventq_open(&gsmd->output, gsmd->eventq_name, O_RDONLY);
    if (ret < 0) {
      gsmd_error("Can't open out queue '%s'\n", gsmd->eventq_name);
      // Позволяем работу и без выходной очереди. Поэтому, не выходим из функции.
    }
  }
#endif

  while (!service_should_stop((service_t*)gsmd)) {
    ret = gsmd_run(gsmd);
    if (ret >= 0) {
      // Без ошибок
      continue;
    }


    // Обработка ошибок

    gsmd_trace("Trouble running, ret=%d (%s)\n", ret, strerror(-ret));

    if (ret == -ENOTCONN) {
      // потеряна связь с gsm модулем.
      gsmd_set_state(gsmd, GSMD_STATE_START_RECOVER_FROM_HARD_ERROR);
      continue;
    }

    if (ret == -EINTR) {
      // получен сигнал остановки сервиса.
      break;
    }

    if (ret == -ETIMEDOUT) {
      // игнорируем таймауты, т.к. они могут часто встречаться и не влиять
      // на работоспособность.
      continue;
    }

    if (    gsmd->state == GSMD_STATE_PPP_INIT
        ||  gsmd->state == GSMD_STATE_PPP_HANDSHAKING
        ||  gsmd->state == GSMD_STATE_PPP_ONLINE
        ||  gsmd->state == GSMD_STATE_PPP_CLOSING
    ) {
      // Обработку ошибок при поднятой ppp сессии нужно вести через
      // остановку ppp сессии.
      gsmd_ppp_fair_close(gsmd, true);
    }

    if (ret == -EOWNERDEAD) {
      // изменились настройки
      gsmd_set_state(gsmd, GSMD_STATE_START_CHANGING_SETTINGS);
    } else {
      // неопознанная ошибка. Обработаем через выключение модуля.
      gsmd_set_state(gsmd, GSMD_STATE_START_RECOVER_FROM_HARD_ERROR);
    }

  } // while (!service_should_stop((service_t*)gsmd))...



  // Завершение работы сервиса
  gsmd_info("Service terminated\n");

  if (    gsmd->state == GSMD_STATE_PPP_INIT
      ||  gsmd->state == GSMD_STATE_PPP_HANDSHAKING
      ||  gsmd->state == GSMD_STATE_PPP_ONLINE
      ||  gsmd->state == GSMD_STATE_PPP_CLOSING
  ) {
    gsmd_ppp_fair_close(gsmd, false);
  }

  gsmd_cleanup(gsmd);

#ifdef CONFIG_LIB_EVENTQ
  eventq_close(&gsmd->output);
#endif
  return 0;
}


static int gsmd_create(gsmd_t* gsmd)
{
  int ret;

  DEBUGASSERT(gsmd);

  // Иницализация вложенных объектов
  ret = service_create(
    (service_t*)gsmd,
    "gsmd",
    CONFIG_LIB_GSMD_DAEMON_PRIORITY,
    CONFIG_LIB_GSMD_DAEMON_STACK_SIZE,
    gsmd_thread_main,
    gsmd
  );
  if (ret < 0) {
    return ret;
  }

#ifdef CONFIG_LIB_EVENTQ
  ret = eventq_init(&gsmd->output);
  if (ret < 0) {
    service_delete((service_t*)gsmd);
    return ret;
  }
#endif

  ret = atport_create(&gsmd->port);
  if (ret < 0) {
    service_delete((service_t*)gsmd);
    return ret;
  }

  ret = libppp_create(gsmd, &GSMD_LIBPPP_CALLBACKS, "ppp%d", true, &gsmd->ppp);
  if (ret < 0) {
    service_delete((service_t*)gsmd);
    return ret;
  }


  // Заполнение стандартных значений для остальных полей
  gsmd->gsm   = -1;
  gsmd->state = 0;
  gsmd->ppp_override_apn  = false;

  strcpy(gsmd->gsm_path,    "");
  strcpy(gsmd->tty_path,    "");
  strcpy(gsmd->eventq_name, "");
  strcpy(gsmd->ppp_apn,     "");
  strcpy(gsmd->ppp_user,    "");
  strcpy(gsmd->ppp_pwd,     "");

  // Удаляем стандартный маршрут
  gsmd->route_target.sin_family = AF_INET;
  gsmd->route_target.sin_port   = 0;
  gsmd->route_target.sin_addr.s_addr = htonl(INADDR_ANY);

  gsmd->route_netmask = gsmd->route_target;
  gsmd->route_gateway = gsmd->route_target;

  gsmd->have_route = true; // Обманываем функцию gsmd_delroute
  gsmd_delroute(gsmd);
  gsmd->have_route = false;

  return 0;
}

////////////////////////////////////////////////////////////////////////////
//  Публичные функции

const char* gsmd_state_to_string(gsmd_state_t value)
{
  switch(value) {
  case GSMD_STATE_UNINITED:                               return "UNINITED";
  case GSMD_STATE_START_RECOVER_FROM_HARD_ERROR:          return "START_RECOVER_FROM_HARD_ERROR";
  case GSMD_STATE_START_RECOVER_FROM_SIMCARD_ERROR:       return "START_RECOVER_FROM_SIMCARD_ERROR";
  case GSMD_STATE_START_RECOVER_FROM_GSM_ERROR:           return "START_RECOVER_FROM_GSM_ERROR";
  case GSMD_STATE_START_RECOVER_FROM_GPRS_ERROR:          return "START_RECOVER_FROM_GPRS_ERROR";
  case GSMD_START_RECOVERING_FROM_ERROR_WITH_POWERCYCLE:  return "RECOVERING_FROM_ERROR_WITH_POWERCYCLE";
  case GSMD_STATE_START_CHANGING_SETTINGS:                return "START_CHANGING_SETTINGS";
  case GSMD_STATE_RECOVERING_SLEEP:                       return "RECOVERING_SLEEP";
  case GSMD_STATE_TURNING_ON:                             return "TURNING_ON";
  case GSMD_STATE_WAITING_FOR_AT_READY:                   return "WAITING_FOR_AT_READY";
  case GSMD_STATE_START_WAITING_SIM_READY:                return "START_WAITING_SIM_READY";
  case GSMD_STATE_START_WAITING_NET_REGISTRATION:         return "START_WAITING_NET_REGISTRATION";
  case GSMD_STATE_WAITING_NET_REGISTRATION:               return "WAITING_NET_REGISTRATION";
  case GSMD_STATE_PPP_INIT:                               return "PPP_INIT";
  case GSMD_STATE_PPP_HANDSHAKING:                        return "PPP_HANDSHAKING";
  case GSMD_STATE_PPP_ONLINE:                             return "PPP_ONLINE";
  case GSMD_STATE_PPP_CLOSING:                            return "PPP_CLOSING";
  case GSMD_STATE_PPP_CLOSED:                             return "PPP_CLOSED";
  default:                                                return "<invalid>";
  }
}



/// \brief    Возвращает singleton-экземпляр сервиса gsmd. Если ещё нет, то создаёт.
/// \warning  Если при создании экземпляра сервиса произойдёт ошибка, то
///           данная функция завершит выполнение программы, вызвав
gsmd_t* gsmd_get_instance(void)
{
  int     ret = 0;
  gsmd_t* gsmd;

  sched_lock();
  {
    gsmd = g_gsmd;
    if (!gsmd) {
      gsmd = &g_gsmd_instance;
      ret = gsmd_create(gsmd);
      if (ret < 0) {
        gsmd = NULL;
      }
      g_gsmd = gsmd;
    }
  }
  sched_unlock();

  if (!gsmd) {
    gsmd_error("Can't create instance, ret=%d (%s)\n", ret, strerror(-ret));
    HaltWithReason("Can't create srvd instance", 0, false);
  }
  return gsmd;
}

/// \brief  Устанавливает новое значение строкового параметра.
///
/// \param  dstname   Имя изменяемого параметра - для вывода в лог в случае ошибки
/// \param  dst       Буффер, в который будет записано новое значение
/// \param  dstsize   Размер буффера в байтах.
/// \param  newvalue  Новое значение, которое следует записать в буффер, или NULL.
/// \param  defvalue  Значение, которое следует записать в буффер, если \p newvalue равен NULL.
/// \return true, если значение в буффере \p dst было изменено.
///
/// Данная функция делает следующие вещи:
///   1. Если \p newvalue равен NULL, то заменяет его на стандартное значение \p defvalue
///   2. Если полученное в п.1 значение отличается от \p dst, то копирует до dstsize-1
///      символов в \p dst.
///   3. Возвращает true, если значение \p dst было изменено.
static bool set_param_str(
  const char* dstname,
  char*       dst,
  size_t      dstsize,
  const char* newvalue,
  const char* defvalue
)
{
  DEBUGASSERT(dst && dstsize);
  DEBUGASSERT(defvalue);

  if (!newvalue) {
    newvalue = defvalue;
  }
  if (strncmp(dst, newvalue, dstsize-1) != 0) {
    int n = snprintf(dst, dstsize, "%s", newvalue);
    if (n >= dstsize) {
      gsmd_warn("WARN: Write to %s overflowed.\n", dstname);
      (void)dstname; // что бы компилятор не жаловался на неиспользуемый аргумент.
    }
    return true;
  }
  return false;
}

/// \brief  Настраивает (или перенастраивает) экземпляр сервиса gsmd.
/// \note   Все строки, переданные в данную функцию могут быть удалены
///         сразу после возврата из неё, т.к. вся необходимая информация
///         копируется в экземпляр объекта.
/// \return 0 в случае успеха или отрицательный код ошибки (-errno).
int gsmd_setup(gsmd_t* gsmd, const gsmd_settings_t* settings)
{
  if (!gsmd || !settings) {
    return -EINVAL;
  }

  // Проверка настроек
  if (    IsWhiteOrEmptyString(settings->gsm_path)
      ||  IsWhiteOrEmptyString(settings->tty_path)
  ) {
    return -EINVAL;
  }

  bool changed = false;

  // Все несуществующие настройки заменяем на пустую строку.
  changed |= set_param_str("gsm_path",    gsmd->gsm_path,    sizeof(gsmd->gsm_path),    settings->gsm_path,    "");
  changed |= set_param_str("tty_path",    gsmd->tty_path,    sizeof(gsmd->tty_path),    settings->tty_path,    "");
  changed |= set_param_str("eventq_name", gsmd->eventq_name, sizeof(gsmd->eventq_name), settings->eventq_name, "");
  changed |= set_param_str("ppp_apn",     gsmd->ppp_apn,     sizeof(gsmd->ppp_apn),     settings->ppp_apn,     "");
  changed |= set_param_str("ppp_user",    gsmd->ppp_user,    sizeof(gsmd->ppp_user),    settings->ppp_user,    "");
  changed |= set_param_str("ppp_pwd",     gsmd->ppp_pwd,     sizeof(gsmd->ppp_pwd),     settings->ppp_pwd,     "");

  changed |= (gsmd->ppp_override_apn != settings->ppp_override_apn);
  gsmd->ppp_override_apn = settings->ppp_override_apn;

  if (changed) {
    gsmd->settings_changed = true;
  }

  return 0;
}
