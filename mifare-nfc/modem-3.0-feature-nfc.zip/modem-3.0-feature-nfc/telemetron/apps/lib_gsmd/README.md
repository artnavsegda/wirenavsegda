# lib_gsmd, Библиотека

Здесь необходимо добавить описание данной библиотеки.
Оно будет отображаться в браузере при входе в папку библиотеки в bitbucket.

## Features

## Example

```c

#include <gsmd/gsmd.h>
void main(...)
{
  uint32_t result = gsmd_foo(void);
  printf("gsmd_foo = %d\n", result);
}
```

## Limitations

Список известных ограничений.

## Bugs

Багов нет, есть незадокументированные фичи.

## Licensing

## Author
DL <dmitriy@linikov.ru>

