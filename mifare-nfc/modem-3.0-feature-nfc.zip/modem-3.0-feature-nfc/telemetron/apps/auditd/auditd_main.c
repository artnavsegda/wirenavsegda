/// \file
/// \brief  Запускает сервис Сервис `auditd` (Vending Machine REPorts Daemon).
/// \author DL <dmitriy@linikov.ru>

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <nuttx/config.h>

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <auditd/auditd.h>

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Приватные функции

static int print_usage(int ret_code, const char* message)
{
  if (message) {
    fprintf(stderr, "%s\n\n", message);
  }

  fprintf(
    stderr,
    "Usage:\n"
    "  auditd start <instance_id> <port path> [audit output path]\n"
    "  auditd stop <instance_id>\n"
    "  auditd wake <instance_id>\n"
    "\n"
    "Where\n"
    "  start      starts the instance of auditd\n"
    "  stop       stops the previously started instance of auditd\n"
    "  wake       prints audit data to syslog\n"
    "\n"
  );

  return ret_code;
}

static int auditd_start_daemon(int argc, char *argv[])
{
  int           ret;
  auditd_t*     auditd;
  int           instance_id;
  const char*   port_path;
  const char*   output_path = NULL;

  aux_params_t  settings = {
    .type         = AUX_TYPE_AUDIT_DEX,
    .interface    = AUX_INTERFACE_RS232,
    .idlestate    = AUX_IDLESTATE_ONE,
    .ddcmp_params = {
      .ddcmp_mode       = EVADTS_DDCMP_AUTO,
      .ddcmp_extended   = EVADTS_DDCMP_SPEED_UP_OFF,
      .ddcmp_auditmode  = EVADTS_DDCMP_AUDIT,
      .ddcmp_fix_baud   = EVADTS_DDCMP_FIX_9600,
      .ddcmp_saeco_fix  = EVADTS_DDCMP_FIX_SAECO_OFF,
    }
  };

  if (argc < 3) {
    return print_usage(-1, "Not enough args");
  }

  instance_id = atoi(argv[1]);
  port_path   = argv[2];

  if (argc >= 3) {
    output_path = argv[3];
  }

  ret = auditd_create(&auditd, instance_id, port_path, output_path, NULL);
  if (ret < 0) {
    fprintf(stderr, "Can't create auditd, ret=%d (%s)\n", ret, strerror(-ret));
    return ret;
  }

  ret = auditd_setup(auditd, &settings, false);
  if (ret < 0) {
    fprintf(stderr, "Can't setup auditd, ret=%d (%s)\n", ret, strerror(-ret));
    goto cleanup;
  }

  ret = auditd_start(auditd);
  if (ret < 0) {
    fprintf(stderr, "Can't start auditd service, ret=%d (%s)\n", ret, strerror(-ret));
    goto cleanup;
  }

  printf("auditd#%d started on port %s\n", instance_id, port_path);
  return 0;

cleanup:
  auditd_destroy(auditd);
  return ret;
}

static int auditd_stop_daemon(int argc, char *argv[])
{
  int         ret;
  auditd_t*     auditd;
  int         instance_id;

  if (argc < 2) {
    return print_usage(-1, "Not enough args");
  }

  instance_id = atoi(argv[1]);

  auditd = auditd_find_instance(instance_id);
  if (!auditd) {
    fprintf(stderr, "ERROR: Can't find auditd%d\n", instance_id);
    return -ESRCH;
  }

  ret = auditd_kill_and_wait(auditd, 30000);
  if (ret < 0) {
    fprintf(stderr, "ERROR: Can't terminate, ret=%d (%s)\n", ret, strerror(-ret));
    return ret;
  }

  auditd_destroy(auditd);
  printf("auditd#%d stopped.\n", instance_id);
  return 0;
}

static int auditd_wake_daemon(int argc, char *argv[])
{
  int         ret;
  auditd_t*     auditd;
  int         instance_id;

  if (argc < 2) {
    return print_usage(-1, "Not enough args");
  }

  instance_id = atoi(argv[1]);

  auditd = auditd_find_instance(instance_id);
  if (!auditd) {
    fprintf(stderr, "ERROR: Can't find auditd%d\n", instance_id);
    return -ESRCH;
  }

  ret = auditd_wake(auditd);
  if (ret < 0) {
    fprintf(stderr, "ERROR: Can't wake, ret=%d (%s)\n", ret, strerror(-ret));
    return ret;
  }

  printf("auditd#%d woken up\n", instance_id);
  return 0;
}

////////////////////////////////////////////////////////////////////////////
//  auditd_main

#ifdef CONFIG_BUILD_KERNEL
int main(int argc, FAR char *argv[])
#else
int auditd_main(int argc, char *argv[])
#endif
{
  if (argc < 2) {
    return print_usage(-1, "Not enough arguments");
  }
  if (strcmp(argv[1], "start") == 0) {
    return auditd_start_daemon(argc-1, argv+1);
  }
  if (strcmp(argv[1], "stop") == 0) {
    return auditd_stop_daemon(argc-1, argv+1);
  }
  if (strcmp(argv[1], "wake") == 0) {
    return auditd_wake_daemon(argc-1, argv+1);
  }

  fprintf(stderr, "Invalid argument \"%s\"\n\n", argv[1]);
  return print_usage(-2, NULL);
  return 0;
}
