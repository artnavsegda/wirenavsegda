# auditd, Встроенное приложение для NSH

Запускает сервис `auditd` (vending machine audit daemon).
Подробнее, см. в папке [telemetron/apps/lib_auditd](../lib_auditd/README.md)

## Features

## Example

```sh
auditd start <instance_id> <path to port driver> [output reports file]
```

Запуск экземпляра сервиса с номером `instance_id`, использующего для общения с торговым автоматом последовательный порт `path to port driver`. Если задан путь `output reports file`, то снятые отчёты будут сохраняться в указанный файл (соответственно, если задать `/dev/console`, то снятые отчёты будут выводиться прямо в консоль).

```sh
auditd stop <instance_id>
```

Остановка и удаление экземпляра сервиса с номером `instance_id`.

```sh
auditd wake <instance_id>
```

Команда сервису с номером `instance_id` проснуться и снять отчёт (если это не запрещено в данный момент времени).

`instance_id` начинает счёт с нуля, общее количество доступных экземпляров задаётся через Kconfig в настройках библиотеки lib_auditd (параметр `LIB_AUDITD_MAX_INSTANCES`).

## Limitations

Список известных ограничений.

## Bugs

Багов нет, есть незадокументированные фичи.

## Licensing

## Author

DL <dmitriy@linikov.ru>
