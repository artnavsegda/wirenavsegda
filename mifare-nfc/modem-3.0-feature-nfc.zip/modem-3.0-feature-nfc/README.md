# 1. Программное обеспечение для Telemetron Modem-3.0

**Содержание:**
<!-- TOC -->

- [1. Программное обеспечение для Telemetron Modem-3.0](#1-программное-обеспечение-для-telemetron-modem-30)
  - [1.1. Краткое описание структуры папок](#11-краткое-описание-структуры-папок)
  - [1.2. Подготовка рабочего места](#12-подготовка-рабочего-места)
    - [1.2.1. Подготовка рабочего места в дистрибутивах, основанных на Debian (Ubuntu, Mint, и так далее)](#121-подготовка-рабочего-места-в-дистрибутивах-основанных-на-debian-ubuntu-mint-и-так-далее)
      - [1.2.1.1. Установка необходимых библиотек](#1211-установка-необходимых-библиотек)
      - [1.2.1.2. Установка kconfig-frontends](#1212-установка-kconfig-frontends)
      - [1.2.1.3. Установка toolchain для кросс-компиляции под процессоры ARM](#1213-установка-toolchain-для-кросс-компиляции-под-процессоры-arm)
      - [1.2.1.4. Установка утилиты сборки проектов Ninja Build System](#1214-установка-утилиты-сборки-проектов-ninja-build-system)
      - [1.2.1.5. Установка OpenOCD (Если используется ST-Link)](#1215-установка-openocd-если-используется-st-link)
      - [1.2.1.6. Установка отладчика и утилит от Segger (Если используется J-Link)](#1216-установка-отладчика-и-утилит-от-segger-если-используется-j-link)
      - [1.2.1.7. Установка генератора документации doxygen](#1217-установка-генератора-документации-doxygen)
      - [1.2.1.8. Установка утилиты fixpath](#1218-установка-утилиты-fixpath)
      - [1.2.1.9. Получение из репозитория и настройка исходных кодов](#1219-получение-из-репозитория-и-настройка-исходных-кодов)
      - [1.2.1.10. Установка редактора Visual Studio Code](#12110-установка-редактора-visual-studio-code)
      - [1.2.1.11. Сборка проекта](#12111-сборка-проекта)
      - [1.2.1.12. Сборка документации](#12112-сборка-документации)
      - [1.2.1.13. Сборка модульных тестов](#12113-сборка-модульных-тестов)

<!-- /TOC -->

## 1.1. Краткое описание структуры папок

| Папка                     | Описание |
| ------------------------- | -------- |
| /.vscode                  | Содержит настройки проекта для среды разработки Visual Studio Code (сокращённо vscode) |
| /.vscode/snippets         | Шаблоны кода для автоподстановки в vscode     |
| /nuttx/nuttx              | Исходные коды операционной системы NuttX      |
| /nuttx/apps               | Исходные коды "приложений" и user-space библиотек для NuttX |
| /telemetron               | Все исходники и утилиты Telemetron            |
| /telemetron/apps          | Все наши "Приложения" для NuttX               |
| /telemetron/nuttx-configs | Все BSP для наших плат или написанные нами    |
| /telemetron/nuttx-drivers | Все общие драйверы устройств, написанные нами |
| /telemetron/templates     | Шаблоны для утилит `/add_app.sh`, `/add_lib.sh` и других |
| /tests                    | Модульные тесты (Google Test) для не зависящих от NuttX модулей |

## 1.2. Подготовка рабочего места

Для сборки проекта следует применять компьютер с операционной системой Linux. Сборка в Windows не поддерживается (и не проверялась).

### 1.2.1. Подготовка рабочего места в дистрибутивах, основанных на Debian (Ubuntu, Mint, и так далее)

#### 1.2.1.1. Установка необходимых библиотек

```sh
sudo apt-get install build-essential libncurses-dev libncurses5-dev libncursesw5-dev
sudo apt-get install libz-dev
sudo apt-get install mpc-devel
sudo apt install texinfo
sudo apt-get install libgmp-dev libgmp3-dev libmpfr-dev libmpc-dev
sudo apt-get install gperf libncurses5-dev
sudo apt-get install libmpc3
sudo apt-get install exuberant-ctags
sudo apt-get remove modemmanager

sudo add-apt-repository ppa:george-edison55/cmake-3.x -y
sudo apt-get update
sudo apt-get install python-argparse git-core wget zip \
    python-empy qtcreator cmake build-essential genromfs -y
# simulation tools
# иногда нужно добавить ppa:
# sudo add-apt-repository ppa:openjdk-r/ppa
sudo apt-get install ant protobuf-compiler libeigen3-dev libopencv-dev openjdk-8-jdk openjdk-8-jre clang-3.5 lldb-3.5 -y
sudo apt-get install python-serial openocd \
    flex bison libncurses5-dev autoconf texinfo build-essential \
    libftdi-dev libtool zlib1g-dev \
    python-empy  -y
sudo apt-get remove gcc-arm-none-eabi gdb-arm-none-eabi binutils-arm-none-eabi gcc-arm-embedded
sudo add-apt-repository --remove ppa:team-gcc-arm-embedded/ppa

#install GNU Global
wget http://tamacom.com/global/global-6.5.7.tar.gz
tar zxvf global-6.5.7.tar.tar.gz
cd global-6.5.7.tar
./configure
make
sudo make install
cd ..
```

#### 1.2.1.2. Установка kconfig-frontends

**kconfig-frontends** - Это программа с помощью которой в NuttX задаются все настройки для плат, приложений, библиотек.

Установка:

```sh
mkdir -r ~/build_repos
cd ~/build-repos
git clone git://ymorin.is-a-geek.org/kconfig-frontends
cd kconfig-frontends
autoreconf -fi
./configure
make
sudo make install
```

В операционной системе ubuntu может потребоваться добавить путь /usr/local/lib к списку директорий, из которых загружаются разделяемые библиотеки. Это нужно сделать, если kconfig-mconf жалуется на отсутствие библиотек:

```sh
sudo sh -c 'echo "/usr/local/lib" > /etc/ld.so.conf.d/usr-local-lib.conf'
sudo ldconfig
```

#### 1.2.1.3. Установка toolchain для кросс-компиляции под процессоры ARM

[Описание ручной установки toolchain из проекта PixHawk](https://dev.px4.io/en/setup/dev_env_linux_ubuntu.html) - там можно подсмотреть решение, если что-то не получается.

Установка GCC 5.4:

```sh
pushd .
cd ~
wget https://launchpad.net/gcc-arm-embedded/5.0/5-2016-q2-update/+download/gcc-arm-none-eabi-5_4-2016q2-20160622-linux.tar.bz2
tar -jxf gcc-arm-none-eabi-5_4-2016q2-20160622-linux.tar.bz2
exportline="export PATH=$HOME/gcc-arm-none-eabi-5_4-2016q2/bin:\$PATH"
if grep -Fxq "$exportline" ~/.profile; then echo nothing to do ; else echo $exportline >> ~/.profile; fi
. ~/.profile
popd
```

Для работы intellisense в Visual Studio Code необходимо так же добавить в файл `~/.profile` следующие строки (скорректировав пути при необходимости):

```sh
# Пути к основной папке arm-none-eabi-gcc и к используемым библиотекам
ARM_NONE_EABI_DIR=$HOME/gcc-arm-none-eabi-5_4-2016q2/arm-none-eabi/
ARM_NONE_EABI_LIB_DIR=$HOME/gcc-arm-none-eabi-5_4-2016q2/lib/gcc/arm-none-eabi/5.4.1/
export ARM_NONE_EABI_DIR
export ARM_NONE_EABI_LIB_DIR
```

Это можно сделать скриптом:

```sh
if grep "ARM_NONE_EABI_LIB_DIR" ~/.profile ; then echo "nothing to do" ;
else
echo "ARM_NONE_EABI_DIR=$HOME/gcc-arm-none-eabi-5_4-2016q2/arm-none-eabi/" >> ~/.profile
echo "ARM_NONE_EABI_LIB_DIR=$HOME/gcc-arm-none-eabi-5_4-2016q2/lib/gcc/arm-none-eabi/5.4.1/" >> ~/.profile
echo "export ARM_NONE_EABI_DIR" >> ~/.profile
echo "export ARM_NONE_EABI_LIB_DIR" >> ~/.profile
fi
. ~/.profile
```

#### 1.2.1.4. Установка утилиты сборки проектов Ninja Build System

Если установлен, то nuttx собирается несколько быстрее. Скорее всего, не обязательно к установке.

Стандартно в Ubuntu устанавливается довольно старая версия. Меняем её.

```sh
mkdir -p $HOME/ninja
cd $HOME/ninja
wget https://github.com/martine/ninja/releases/download/v1.6.0/ninja-linux.zip
unzip ninja-linux.zip
rm ninja-linux.zip
exportline="export PATH=$HOME/ninja:\$PATH"
if grep -Fxq "$exportline" ~/.profile; then echo nothing to do ; else echo $exportline >> ~/.profile; fi
. ~/.profile
```

#### 1.2.1.5. Установка OpenOCD (Если используется ST-Link)

Скачать openocd [отсюда](https://sourceforge.net/projects/openocd/files/openocd/0.10.0/openocd-0.10.0.tar.bz2/download)

распаковать куда-нибудь
в распакованной папке openocd выполнить:

```sh
./configure && make
sudo make install
```

#### 1.2.1.6. Установка отладчика и утилит от Segger (Если используется J-Link)

Скачать и установить драйверы для J-Link: [32-бит linux](https://www.segger.com/downloads/jlink/JLink_Linux_V622f_i386.deb) или [64-бит linux](https://www.segger.com/downloads/jlink/JLink_Linux_V622f_x86_64.deb)

Скачать и установить программу-отладчик Ozone: [32-бит linux](https://www.segger.com/downloads/jlink/ozone_2.54.2_i386.deb), или [64-бит linux](https://www.segger.com/downloads/jlink/ozone_2.54.2_x86_64.deb)

Бывает, что в Ubuntu браузер не позволяет открывать пакеты установщика. В таком случае необходимо открыть скачанный пакет через диспетчер файлов.

#### 1.2.1.7. Установка генератора документации doxygen

```sh
sudo apt install doxygen doxygen-gui graphviz dia
sudo apt install wget gksu perl-tk

# Всё, что ниже - опционально - установка texlive для генерации PDF
# texlive занимает около 2.5 ГБ места на диске, поэтому устанавливать при необходимости.
sudo apt install xzdec
wget http://mirror.ctan.org/systems/texlive/tlnet/install-tl-unx.tar.gz
tar -xzf install-tl-unx.tar.gz
cd install-tl-20171007            # Тут может быть другая директория, если будет более свежий инсталлятор.

sudo ./install-tl
# в открывшемся меню выбрать s -> d для выбора компактной установки
# После выбора схемы нажать r для выхода в основное меню
# в главном меню нажать i

# после установки (на 32-битном компьютере пути могут быть другие, но их видно в конце установки):
export PATH=/usr/local/texlive/2017/bin/x86_64-linux:$PATH
export INFOPATH=$INFOPATH:/usr/local/texlive/2017/texmf-dist/doc/info
export MANPATH=$MANPATH:/usr/local/texlive/2017/texmf-dist/doc/man

sudo apt install equivs --no-install-recommends
mkdir -p /tmp/tl-equivs && cd /tmp/tl-equivs
equivs-control texlive-local
wget -O texlive-local http://www.tug.org/texlive/files/debian-equivs-2016-ex.txt

equivs-build texlive-local
sudo dpkg -i texlive-local_2016-2_all.deb
sudo apt install -f

sudo tlmgr option repository ftp://tug.org/historic/systems/texlive/2015/tlnet-final

sudo tlmgr install float xcolor multirow varwidth adjustbox tabu xkeyval collectbox wasysym cyrillic
```

Подробнее, про установку texlive на ubuntu [смотреть здесь](https://tex.stackexchange.com/questions/1092/how-to-install-vanilla-texlive-on-debian-or-ubuntu)

Для генерации документации вызвать из корня проекта

```sh
make doc
```

#### 1.2.1.8. Установка утилиты fixpath

Для того, что бы в VSCode можно было переходить по Ctrl+Click в места ошибок сборки необходимо при сборке преобразовывать относительные пути в абсолютные. Это делает утилита `fixpath` и она прописана в настройки проекта VSCode (т.е. без неё сборка по горячим клавишам работать не будет).

Установка:

```sh
git clone https://github.com/hardlulz/fixpath.git
cd fixpath
./configure
./make
sudo cp ./fixpath /usr/local/bin
```

Использование:

```sh
make -w -другие -параметры 2>&1 | fixpath
```

Обязательно использование 2>&1 для перенаправления stderr в stdout.

#### 1.2.1.9. Получение из репозитория и настройка исходных кодов

Создаём папки, получаем из репозитория, переходим на ветку develop и обновляем связанные репозитории:
В третьей строке вместо src можно выбрать другую папку.

```sh
mkdir -p ~/work/telemetron/modem-3.0
cd ~/work/telemetron/modem-3.0
git clone https://bitbucket.org/hardlulz/modem-3.0.git src
cd src
git checkout develop
git submodule update --init --recursive
```

Следующий шаг - очистка рабочей директории от остатков предыдущих сборок и выбор целевой платы:

```sh
make distclean
make set-brd-nucleo-f207zg
```

Далее, можно отредактироват настройки сборки.

```sh
make menuconfig
```

Запустится приложение, в котором собраны все настройки. Обычно, интересуют выбор приложений, которые войдут в сборку.

Навигация в этом приложении:

- **Клавиши вверх и вниз** - выбор пунктов из списка, клавиши лево и право - выбор кнопок внизу меню.
- **Enter** - нажатие на кнопку внизу меню.

Для сборки портированного из `Modem-2.7` приложения прошивки необходимо выбрать:
> `Application Configuration` -> `Telemetron apps` -> `Telemetron old_fw`.

Это  было актуально на момент завершения первой стадии проекта. Сейчас данное приложение не поддерживается и может даже не собираться.

Для сборки основного приложения необходимо выбрать
> `Application Configuration` -> `Telemetron apps` -> `Telemetron fw`.

Обычно он выбран по-умолчанию для плат telemetron, однако, в процессе портирования и отладки я могу отключать его, например, что бы можно было протестировать драйвера платы, при условии, что fw содержит ошибки и не собирается. Но, в любом случае, для релизных коммитов в репозитории данное приложение обязательно включено.

**Внимание:** Альтернативно, если во время сборки **kconfig-frontends** были доступны библиотеки рабочей среды *gnome*, то так же будет собрана и графическая версия конфигуратора *gconfig*. Его можно вызвать командой:

```sh
make gconfig
```

**Внимание:** Альтернативно, если во время сборки **kconfig-frontends** были доступны библиотеки рабочей среды *kde* и *qt*, то так же будет собрана и графическая версия конфигуратора *qconfig*. Его можно вызвать командой:

```sh
make qconfig
```

#### 1.2.1.10. Установка редактора Visual Studio Code

Для работы с данным проектом в linux наиболее удобным оказался редактор Visual Studio Code.
Актуальную версию можно скачать с сайта [code.visualstudio.com](code.visualstudio.com)
Скачать [актуальную на момент написания версию для 64-бит linux](https://go.microsoft.com/fwlink/?LinkID=760868)

В редакторе необходимы следующие плагины:

- `C/C++` от Microsoft
- `Reloaded C/C++` от Reloaded Extensions
- `Reloaded Themes` от Reloaded Extensions
- `Project Snippets` от Peng Lv

Рекомендую так же поставить плагины:

- `Alignment` от annsk
- `C/C++ Advanced Lint` от Joseph Benden
- `Dash` от Budi Irawan
- `Doxygen Documentation Generator` от Christoph Schlosser
- `Encode Decode` от Mitch Denny
- `hexdump for VSCode` от slevesque
- `Markdown Preview Enhanced` от Yiyi Wang
- `markdownlint` от David Anson
- `Markdown TOC` от AlanWalk
- `Rainbow Brackets` от 2gua
- `Rewrap` от stkb

#### 1.2.1.11. Сборка проекта

Для сборки проекта в папке проекта следует вызвать команду

```sh
make
```

В редакторе VSCode при стандартных настройках сборка проекта должна выполняться по нажатию `Ctrl+Shif+B`.

#### 1.2.1.12. Сборка документации

Сборка документации по исходным кодам (doxygen):

```sh
make doc
```

#### 1.2.1.13. Сборка модульных тестов

Сборка и выполнение модульных тестов из папки `/tests`:

```sh
make test
```
