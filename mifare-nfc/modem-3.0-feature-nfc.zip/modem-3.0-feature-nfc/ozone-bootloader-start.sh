#!/bin/bash
# Запускает ozone, открывает проект, открывает консоль nsh (swo - внутри ozone).


# Absolute path to this script, e.g. /home/user/bin/foo.sh
SCRIPT=$(readlink -f "$0")
# Absolute path this script is in, thus /home/user/bin
SCRIPTPATH=$(dirname "$SCRIPT")
echo "Run from '$SCRIPTPATH'"

cd ${SCRIPTPATH}/bootloader

DATE=$(date +%Y-%m-%d-%H%M%S);
#xterm -fa "Consolas" -fs 8 -geometry 315x25 -leftbar -T "JLink GDB" -e 'JLinkGDBServer -device STM32F101VG -if SWD -speed auto -port 3333 -swoport 4000 -telnetport 4001 -vd' &
#echo ${!} > /var/tmp/jlink.pid

#sleep 0.2

#putty -serial -log ~/putty_logs/$DATE-NSH-telemetron.log -sercfg 115200,8,1,n,N -title 'NSH' /dev/ttyACM0 &
putty -serial -log ~/putty_logs/$DATE-bootloader-telemetron.log -sercfg 921600,8,1,n,N -title 'bootloader' /dev/ttyUSB0 &
echo ${!} > /var/tmp/nsh.pid

#putty -raw -log ~/putty_logs/$DATE-SYSLOG-telemetron.log -P 4001 -title 'SYSLOG' localhost &
Ozone bootloader.jdebug &
echo ${!} > /var/tmp/syslog.pid

