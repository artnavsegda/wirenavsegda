#!/bin/bash

# Создание нового приложения в /telemetron/apps из шаблона.
# Параметры:
# add_app.sh --name <app_name> --id <APP_UPPERCASE_ID> --force
#
# Где 	<app_name> 				- имя приложения (и имя директории по совместительству)
# 		<APP_UPPERCASE_ID>		- идентификатор приложения, используемый как часть создаваемых конфигурационных констант в Kconfig и т.д.
#
# Если есть параметр --force, то при нахождении в папке telemetron/apps/<app_name>, 
# данная папка будет удалена, а на её место будет записано новое приложение из шаблона.

function PrintUsageAndDie {
	# Сделал подсказку двуязычной на случай, если консоль имеет отличную от UTF-8 кодировку
	echo "================================================================================"
	echo ""
	echo "Script to create from template a new application and save it to /telemetron/apps"
	echo "Usage:"
	echo ""
	echo "  ./add_app.sh --name <app_name> --id <APP_UPPERCASE_ID> [--force]"
	echo "  where:"
	echo "    <app_name>         - lowercase name of the app (without spaces)"
	echo "    <APP_UPPERCASE_ID> - ID of the app, used as part of #ifdef/#define"
	echo ""
	echo "If --force is present then existing app with the same name will be deleted."
	echo ""
	echo "--------------------------------------------------------------------------------"
	echo ""
	echo "Скрипт для создания из шаблона нового приложения в папке /telemetron/apps"
	echo "Правила использования:"
	echo ""
	echo "  ./add_app.sh --name <app_name> --id <APP_UPPERCASE_ID> [--force]"
	echo "  где:"
	echo "    <app_name>         - имя создаваемого приложения, желательно в нижнем "
	echo "                         регистре. Оно должно быть таким, что бы в C можно было "
	echo "                         создать переменную с таким именем."
	echo "    <APP_UPPERCASE_ID> - ID создаваемого приложения, в верхнем регистре,"
	echo "                         Этот ID будет использоваться в составе #ifdef/#define "
	echo ""
	echo "Если задан парамер --force, то уже существующее приложение с таким именем"
	echo "будет удалено из папки /telemetron/apps перед созданием нового."
	echo ""
	echo "================================================================================"
	echo ""
	exit $1
}

if [[ $# -eq 0 ]]
then
	PrintUsageAndDie 1
fi

while [[ $# -gt 0 ]]
do
key="$1"


case $key in
    -n|--name)
      APP_NAME="$2"
      shift # past argument
    ;;
    -i|--id)
      APP_ID="$2"
      shift # past argument
    ;;
    -f|--force)
      FORCE=1
    ;;
    *)
      # unknown option
      echo "Unknown option \"$1\""
    ;;
esac
shift # past argument or value
done

ERROR=0

# Проверка правильности имени приложения
if [ -z ${APP_NAME+x} ]
then
	echo "ERROR: App name is not specified"
	ERROR=1

elif [ ${#APP_NAME} -eq 0 ]
then
	echo "ERROR: App name is empty"
	ERROR=1

elif [ ${APP_NAME:0:1} = - ]
then
	echo "ERROR: App name \($APP_NAME\) is invalid"
	ERROR=1

fi


# Проверка правильности идентификатора приложения
if [ -z ${APP_ID+x} ]
then
	echo "ERROR: App ID is not specified"
	ERROR=1

elif [ ${#APP_ID} -eq 0 ]
then
	echo "ERROR: App ID is empty"
	ERROR=1

elif [ ${APP_ID:0:1} = - ]
then
	echo "ERROR: App ID \($APP_ID\) is invalid"
	ERROR=1

fi

# Проверка наличия переменной FORCE и подстановка стандартного значения
if [ -z ${FORCE+x} ]
then
	FORCE=0
fi

if [ $ERROR -ne 0 ]
then
	echo "ERROR: Not all parameters are set. Can't continue"
	PrintUsageAndDie $ERROR
fi


TEMPLATE_FOLDER="telemetron/templates/app_template"
TEMPLATE_MAIN_C="app_template_main.c"
TEMPLATE_KCONFIG="Kconfig"

FOLDER_NAME="telemetron/apps/$APP_NAME"
MAIN_C="${APP_NAME}_main.c"


# Проверка, что директория отсутствует
if [[ -e $FOLDER_NAME && $FORCE -eq 1 ]]
then
	echo "WARNING: The folder '$FOLDER_NAME' already exist. Removed it because --force is specified."
	rm -rf $FOLDER_NAME

elif [[ -e $FOLDER_NAME && $FORCE -eq 0 ]]
then
	echo "ERROR: Can't write to '$FOLDER_NAME' - already exist."
	exit 2
fi


# Копирование шаблона в целевую директорию
cp -R $TEMPLATE_FOLDER/. $FOLDER_NAME

# Переименование основного файла для соответствия с названием приложения
mv $FOLDER_NAME/$TEMPLATE_MAIN_C $FOLDER_NAME/$MAIN_C

# Замена всех вхождений:
#   {APP_ID}        на ID
#   {APP_NAME}      на название приложения.
#   {AUTHOR}        на имя автора, взятое из git
#   {AUTHOR_EMAIL}  на почту автора, взятую из git

AUTHOR=$(git config user.name)
AUTHOR_EMAIL=$(git config user.email)

REPLACE_LIST=""
REPLACE_LIST+="s/{APP_NAME}/${APP_NAME}/g; "
REPLACE_LIST+="s/{APP_ID}/${APP_ID}/g; "
REPLACE_LIST+="s/{AUTHOR}/${AUTHOR}/g; "
REPLACE_LIST+="s/{AUTHOR_EMAIL}/${AUTHOR_EMAIL}/g; "


pushd . > /dev/null
cd $FOLDER_NAME
sed -i -- "${REPLACE_LIST}" *
popd > /dev/null

echo
echo "Done. New application is created in $FOLDER_NAME"
echo "Don't forget to 'make distclean'"
echo

exit 0