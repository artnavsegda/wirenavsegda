#!/bin/bash
# Запускает openocd, открывает консоль nsh и swo syslog
gnome-terminal -e 'minicom --baudrate 115200 --device /dev/ttyACM0'
gnome-terminal -e 'openocd -f ./telemetron-nucleo-f207zg.cfg'
./parse_itm.py