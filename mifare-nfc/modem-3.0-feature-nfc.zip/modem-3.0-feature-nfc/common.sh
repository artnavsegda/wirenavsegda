#!/bin/bash

DIR_NUTTX=nuttx/nuttx
DIR_NUTTX_TOOLS=${DIR_NUTTX}/tools
DIR_RELEASES=releases
FILE_VERSION=${DIR_NUTTX}/.version
