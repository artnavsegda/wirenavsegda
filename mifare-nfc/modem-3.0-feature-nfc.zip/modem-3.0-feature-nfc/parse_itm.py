#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import sys
import errno

from datetime import datetime

FIFOIN  = "/tmp/swo"
FIFOOUT = "/tmp/swo_console"
FILEPATH= "~/putty_logs/"
FILENAME= "{:%Y-%m-%d-%H%M%S}-syslog.log"

SHOULD_DUMP     = False
SHOULD_FLUSH    = False
ADDRESS = 0

class ITMPacket:
    """A class representing single ITM packet (with TPIU formatter turned off)"""
    def __init__(self, header_byte = None):
        self.address = 0
        self.length  = 0
        self.data    = []
        self.valid   = False

        if header_byte is None:
            return
        
        if (header_byte & 0x04) != 0:
            # бит 2 всегда ноль в SWIT пакетах. 
            # Получили 1 - значит либо рассинхрон, либо битый пакет
            return 

        self.length = header_byte & 0x03
        if self.length == 3:
            # биты 0..1 содержат длину пакета, которая может быть только 1, 2 и 4
            # Получили 3 - значит либо рассинхрон, либо битый пакет
            return
        if self.length == 0:
            # Если поле длины равно 0, то это один из служебных пакетов:
            #   Overflow    0b01110000
            #   Timestamp   0bCDDD0000  где D = data (!=000) - время, C = continuation
            # Не используем такие пакеты за ненадобностью
            return

        self.address = (header_byte & 0xF8) >> 3
        self.valid = True
        return

    def Process(self, data_byte):
        """Добавляет в пакет очередной байт. Возвращает true, если пакет завершён."""
        if self.length == len(self.data):
            return True

        self.data.append(data_byte)
        if self.length != len(self.data):
            return False

        return True

    def GetChar(self):
        return chr(self.data[0])

    def GetCharAsByteArray(self):
        return bytearray([self.data[0]])

    def Dump(self):
        print("ITMPacket: addr={0}, length={1}, data={2}, valid={3}"
                .format(self.address, self.length, self.data, self.valid)
             )



def ReadPacket(fifo_in):
    """Читает из fifo_in пакет. 
       Если пакет прочитан успешно, то packet.valid = True.
       Если при чтении был закрыт входной поток, то возвращает None."""

    data = fifo_in.read(1)
    if len(data) == 0:
        print("input closed")
        return None

    packet = ITMPacket(ord(data[0]))

    while packet.valid:
        data = fifo_in.read(1)
        if len(data) == 0:
            print("input closed")
            return None

        if packet.Process(ord(data[0])):
            break

    return packet


def IsSupportedPacket(packet):
    return (    packet is not None 
            and packet.valid 
            and packet.length == 1 
            and len(packet.data) == 1 
            and packet.address == ADDRESS)


def SendPacket(fifo_out, packet):
    value = packet.GetCharAsByteArray()
    if fifo_out is not None:
        fifo_out.write(value)

    sys.stdout.write(value)


def LoopInput(fifo_in, fifo_out):
    while True:
        packet = ReadPacket(fifo_in)
        if packet is None:
            return

        if IsSupportedPacket(packet):
            if SHOULD_DUMP:
                packet.Dump()
            SendPacket(fifo_out, packet)


def DoSingleRun(name_in, name_out):
    print("Opening input {0}".format(name_in))
    with open(name_in, "rb") as fifo_in:
        print("Input opened.")

        if name_out is None:
            LoopInput(fifo_in, None)
            return

        print("Opening output {0}".format(name_out))
        with open(name_out, "wb+") as fifo_out:
            print("Output opened")
            LoopInput(fifo_in, fifo_out)


def Run(name_in, name_out):
    while True:
        DoSingleRun(name_in, name_out)



try:
    os.mkfifo(FIFOIN)
except OSError as oe: 
    if oe.errno != errno.EEXIST:
        raise

# try:
#     os.mkfifo(FIFOOUT)
# except OSError as oe: 
#     if oe.errno != errno.EEXIST:
#         raise


if len(sys.argv) > 1:
    Run(FIFOIN, sys.argv[1])
else:
    rel_path = FILEPATH
    abs_path = os.path.expanduser(rel_path)
    file_name = abs_path + FILENAME.format(datetime.now())

    if not os.path.isdir(abs_path):
        os.mkdir(abs_path)
        print("Created dir ", abs_path)

    Run(FIFOIN, file_name)


# print("Opening input {0}".format(FIFOIN))
# with open(FIFOIN, "rb") as fifo_in:
#     print("Input opened.")
#     print("Opening output {0}".format(FIFOOUT))

#     with open(FIFOOUT, "wb") as fifo_out:
#         print("Output opened")
#         while True:
#             packet = ReadPacket(fifo_in)
#             if packet is None:
#                 break;
#             #packet.Dump()
#             if IsSupportedPacket(packet):
#                 SendPacket(fifo_out, packet)

