#!/bin/bash
# Запускает openocd, открывает консоль nsh и swo syslog

# Подчистка после выхода из gdb
if [ -f /var/tmp/syslog.pid ]; then
  kill -n 9 $(cat /var/tmp/syslog.pid && rm /var/tmp/syslog.pid)
fi

if [ -f /var/tmp/nsh.pid ]; then
  kill -n 9 $(cat /var/tmp/nsh.pid && rm /var/tmp/nsh.pid)
fi

if [ -f /var/tmp/jlink.pid ]; then
  kill -n 9 $(cat /var/tmp/jlink.pid && rm /var/tmp/jlink.pid)
fi
pkill --signal SIGABRT JLinkGDBServer

