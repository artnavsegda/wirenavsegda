#ifndef BOOTLOADER_MAIN_H_INCLUDED
#define BOOTLOADER_MAIN_H_INCLUDED

int bootloader_main();

#endif // BOOTLOADER_MAIN_H_INCLUDED
