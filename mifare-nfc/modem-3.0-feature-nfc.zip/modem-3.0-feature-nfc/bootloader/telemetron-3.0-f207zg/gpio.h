/// @file gpio.h
/// @author DL <dmitriy.linikov@gmail.com>
/// @brief Макросы, функции и типы данных для абстрагирования портов ввода-вывода.

#ifndef GPIO_H_INCLUDED
#define GPIO_H_INCLUDED

#include "stm32f2xx.h"
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

#define GPIO_AF_USART1        ((uint8_t)0x07)  /* USART1 Alternate Function mapping */
#define GPIO_AF_USART3        ((uint8_t)0x07)  /* USART3 Alternate Function mapping */
#define GPIO_AF_I2C3          ((uint8_t)0x04)  /* I2C3 Alternate Function mapping */

#define GPIO_MODER_IN         0
#define GPIO_MODER_OUT        1
#define GPIO_MODER_AF         2
#define GPIO_MODER_ANALOG     3
#define GPIO_OTYPER_PP        0
#define GPIO_OTYPER_OD        1
#define GPIO_PUPDR_NONE       0
#define GPIO_PUPDR_UP         1
#define GPIO_PUPDR_DOWN       2
#define GPIO_OSPEEDR_LOW      0
#define GPIO_OSPEEDR_MEDIUM   1
#define GPIO_OSPEEDR_FAST     2
#define GPIO_OSPEEDR_HIGH     3

#define GPIO_MKMODE(moder,otyper,pupdr,ospeedr) \
    (((moder)   & 0x3) << 0) \
  | (((otyper)  & 0x1) << 2) \
  | (((pupdr)   & 0x3) << 3) \
  | (((ospeedr) & 0x3) << 5)

#define GPIO_GET_MODER(mode)    (((mode) >> 0) & 0x3)
#define GPIO_GET_OTYPER(mode)   (((mode) >> 2) & 0x1)
#define GPIO_GET_PUPDR(mode)    (((mode) >> 3) & 0x3)
#define GPIO_GET_OSPEEDR(mode)  (((mode) >> 5) & 0x3)

/// \brief Структура, связывающая конкретный GPIO порт и номер вывода этого порта
typedef struct GpioChannelTag {
  GPIO_TypeDef* port;
  uint32_t      pin_id;
} GpioChannel;


typedef enum GpioModeTag {
  GPIO_MODE_IN_FLOAT              = GPIO_MKMODE(GPIO_MODER_IN, 0, GPIO_PUPDR_NONE, 0),
  GPIO_MODE_IN_PULLUP             = GPIO_MKMODE(GPIO_MODER_IN, 0, GPIO_PUPDR_UP,   0),
  GPIO_MODE_IN_PULLDOWN           = GPIO_MKMODE(GPIO_MODER_IN, 0, GPIO_PUPDR_DOWN, 0),
  GPIO_MODE_ANALOG                = GPIO_MKMODE(GPIO_MODER_ANALOG, 0, GPIO_PUPDR_NONE, 0),
  GPIO_MODE_OUT_PUSHPULL          = GPIO_MKMODE(GPIO_MODER_OUT, GPIO_OTYPER_PP, GPIO_PUPDR_NONE, GPIO_OSPEEDR_FAST),
  GPIO_MODE_OUT_OPENDRAIN         = GPIO_MKMODE(GPIO_MODER_OUT, GPIO_OTYPER_OD, GPIO_PUPDR_NONE, GPIO_OSPEEDR_FAST),
  GPIO_MODE_OUT_OPENDRAIN_PULLUP  = GPIO_MKMODE(GPIO_MODER_OUT, GPIO_OTYPER_OD, GPIO_PUPDR_UP,   GPIO_OSPEEDR_FAST),
  GPIO_MODE_ALT_PUSHPULL          = GPIO_MKMODE(GPIO_MODER_AF,  GPIO_OTYPER_PP, GPIO_PUPDR_NONE, GPIO_OSPEEDR_FAST),
  GPIO_MODE_ALT_OPENDRAIN         = GPIO_MKMODE(GPIO_MODER_AF,  GPIO_OTYPER_OD, GPIO_PUPDR_NONE, GPIO_OSPEEDR_FAST),
  GPIO_MODE_ALT_OPENDRAIN_PULLUP  = GPIO_MKMODE(GPIO_MODER_AF,  GPIO_OTYPER_OD, GPIO_PUPDR_UP,   GPIO_OSPEEDR_FAST),

  GPIO_MODE_OUT=GPIO_MODE_OUT_PUSHPULL,
  GPIO_MODE_ALT=GPIO_MODE_ALT_PUSHPULL,
} GpioMode;

typedef struct GpioConfigTag {
  GpioMode        mode;     ///< Режим работы
  uint8_t         af;       ///< Номер альтернативной функции для GPIO_MODE_ALT_xxx
} GpioConfig;


#define GPIO_CHANNEL(port, pin_id)    (GpioChannel){(port), (pin_id)}

#define GPIO_CONFIG(mode)             (GpioConfig){ (mode), 0    }
#define GPIO_CONFIG_AF(mode, af)      (GpioConfig){ (mode), (af) }

/// \brief Устанавливает GPIO вывод \p pad в высокое состояние (Vdd).
void GpioSet(const GpioChannel* pad);

/// \brief Устанавливает GPIO вывод \p pad в низкое состояние (GND).
void GpioClear(const GpioChannel* pad);

/// \brief Устанавливает новое значение GPIO вывода \p pad в 1 или 0
/// в соответствии со значением параметра \p new_value.
void GpioWrite(const GpioChannel* pad, bool new_value);

/// \brief Возвращает значение (1 или 0) GPIO входа \p pad.
bool GpioRead(const GpioChannel* pad);

/// \brief Устанавливает новые настройки GPIO каналу \p pad.
void GpioConfigure(const GpioChannel* pad, const GpioConfig* config);

/// \brief Устанавливает новые настройки GPIO каналу, используя отдельные
/// параметры.
/// \param pad            Дескриптор GPIO канала
/// \param mode           Режим работы GPIO канала
/// \param af             Номер альтернативной функции - для режимов GPIO_MODE_ALT_xxx
/// \param initial_value  Значение, которое следует установить после настройки.
///                       (в случае Pull-Up/Pull-Down канала выбирает подтяжку:
///                        0 - к земле, 1 - к напряжению питания).
void GpioConfigArgs(const GpioChannel* pad,
                    GpioMode           mode,
                    uint8_t            af,
                    bool               initial_value);


#ifdef __cplusplus
}
#endif // __cplusplus

#endif // GPIO_H_INCLUDED
