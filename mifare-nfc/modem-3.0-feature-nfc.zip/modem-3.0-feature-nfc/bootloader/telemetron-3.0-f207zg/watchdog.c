/// @file watchdog.c
/// @author DL <dmitriy.linikov@gmail.com>
/// @see watchdog.h

#ifndef CFG_FILE_LOG_LEVEL
#define CFG_FILE_LOG_LEVEL   LOG_LEVEL_INFO
#endif // CFG_FILE_LOG_LEVEL

#if defined(STM8)
# include <stm8s_conf.h>

#elif defined(STM32F10X)
# include <stm32f10x.h>
# include "dbg.h"

#elif defined(STM32F2XX)
# include <stm32f2xx.h>
# include "dbg.h"

#else
# error "Unsupported MCU type"
#endif

#include "watchdog.h"

void watchdog_configure(uint32_t timeout_ms)
{
  uint32_t prescaler, prescaler_register_value, max_timeout_ms, reload_value;
  if (timeout_ms > WATCHDOG_MAX_PERIOD_MS(256)) {
    // Если запрошен период, больший чем максимально возможный, то уменьшаем
    // его до максимально возможного периода сторожевого таймера.
    timeout_ms = WATCHDOG_MAX_PERIOD_MS(256);
  }

  // Вычисляем делитель частоты
   prescaler = 4;
   prescaler_register_value = 0;

  while (WATCHDOG_MAX_PERIOD_MS(prescaler) < timeout_ms && prescaler != 256) {
    ++prescaler_register_value;
    prescaler *= 2;
  }

  // требуемое значение сброса вычисляем из пропорции
  // 0xFFF / max_timeout_ms = X / timeout_ms
  // т.е. X = 0xFFF * timeout_ms / max_timeout_ms
  //
  // граничный случай: X=4095 * 26208 / 26208 = 107321760 / 26208 = 0xFFF
  // умещается в 32 бита.
   max_timeout_ms = WATCHDOG_MAX_PERIOD_MS(prescaler);
   reload_value = timeout_ms * WATCHDOG_MAX_COUNT / max_timeout_ms;

  // Установка настроек сторожевого таймера.
#ifdef STM8
  IWDG->KR = 0xCC;
  IWDG->KR = 0x55;
  IWDG->PR = (uint8_t)prescaler_register_value;
  IWDG->RLR = (uint8_t)reload_value;
#else
  IWDG->KR = 0x5555;
  IWDG->PR = prescaler_register_value;
  IWDG->RLR = reload_value;
#endif // STM8

  watchdog_reset();
}

void watchdog_start(void)
{
#ifdef STM8
  IWDG->KR = 0xCC;
#else
  IWDG->KR = 0xCCCC;
#endif // STM8
}

void watchdog_reset(void)
{
#ifdef STM8
  IWDG->KR = 0xAA;
#else
  //log_func();
  IWDG->KR = 0xAAAA;
#endif // STM8
}
