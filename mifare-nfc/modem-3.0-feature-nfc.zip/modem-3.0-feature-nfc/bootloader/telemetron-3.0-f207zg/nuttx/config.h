/// \file
/// \brief  Заглушка для кода, требующего настройки nuttx
/// \author DL <dmitriy@linikov.ru>


#ifndef BOOTLOADER_FAKE_NUTTX_CONFIG_H_INCLUDED
#define BOOTLOADER_FAKE_NUTTX_CONFIG_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов


////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

#define DEBUGASSERT(cond)   ((void)0)

#define CONFIG_LIB_SRVD_DEFAULT_SERVER_NAME     "my.rc.telemetron.net"
#define CONFIG_LIB_SRVD_DEFAULT_SERVER_PORT     80
#define CONFIG_LIB_SRVD_DEFAULT_SERVER_PATH     "/data/"
#define CONFIG_LIB_SRVD_DEFAULT_T_PING_MS       30000

////////////////////////////////////////////////////////////////////////////
//  Типы данных


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif

#endif // BOOTLOADER_FAKE_NUTTX_CONFIG_H_INCLUDED
