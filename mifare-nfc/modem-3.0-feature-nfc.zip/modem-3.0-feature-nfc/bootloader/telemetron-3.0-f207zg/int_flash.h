/// \file int_flash.h
/// \author DL <dmitriy.linikov@gmail.com>
/// \brief Функции для работы со встроенной флеш памятью микроконтроллера.

#ifndef INT_FLASH_H_INCLUDED
#define INT_FLASH_H_INCLUDED

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

/// \brief Записывает двух-байтное слово \p data во встроенную память
/// по адресу \p address.
void IntFlashWriteWord(uint32_t address, uint16_t data);

/// \brief Записывает 4-х байтное слово \p data во встроенную память
/// по адресу \p address.
void IntFlashWriteDWord(uint32_t address,uint32_t data);

/// \brief Записывает \p size байт из буффера \p data во встроенную память
/// начиная с адреса \p address.
void IntFlashWriteBuffer(uint32_t address, const void* data, uint32_t size);

/// \brief Снимает блокировку от записи во встроенную флеш память.
void IntFlashUnlock(uint32_t address);

/// \brief Стирает страницу встроенной флеш памяти контроллера, содержащую
/// адрес \p address.
void IntFlashErasePage(uint32_t address);

/// \brief Читает из встроенной флеш памяти двойное слово, расположенное
/// по адресу \p address.
uint32_t IntFlashRead(uint32_t address);

/// \brief Защищает память контроллера от чтения.
void IntFlashSecureChip(uint32_t address);


#ifdef __cplusplus
}
#endif // __cplusplus

#endif // INT_FLASH_H_INCLUDED
