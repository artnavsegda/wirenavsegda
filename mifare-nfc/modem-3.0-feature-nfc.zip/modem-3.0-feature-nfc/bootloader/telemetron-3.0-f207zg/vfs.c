/// \file
/// \brief  Реализация виртуальной файловой системы через newlib
/// \author DL <dmitriy@linikov.ru>
///
/// В данном файле я придерживаюсь стиля кодирования с goto прыжками
/// в обработчики ошибок для того, что бы при необходимости можно было
/// довольно быстро добавить синхронизацию доступа к файловой системы
/// (захват мьютекса или семаформа в начале фукнции и его освобождение
/// в обработчике ошибок в конце функции).

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include "vfs.h"

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

////////////////////////////////////////////////////////////////////////////
//  Приватные константы препроцессора

#define FILE_F_OPENED     0x40000000

////////////////////////////////////////////////////////////////////////////
//  Приватные типы данных

/// Запись регистрации файла в системе.
struct file_rec_s {
  const file_ops_t*   vmt;    ///< Таблица методов драйвера/файла
  const char*         path;   ///< Полный путь к файлу
  int                 mode;   ///< Тип файла, для использования в fstat и isatty

  file_t              state;  ///< Изменяемые данные драйвера
};

typedef struct file_rec_s     file_rec_t;



////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


////////////////////////////////////////////////////////////////////////////
//  Константы


////////////////////////////////////////////////////////////////////////////
//  Глобальные переменные

static file_rec_t SYS_FILES[MAX_SYS_FILES];


////////////////////////////////////////////////////////////////////////////
//  Приватные функции

/// \return номер записи в таблице файловых дескрипторов или -EINVAL или -ENOENT
static int vfs_find_path(const char* path)
{
  if (!path) {
    return -EINVAL;
  }

  for (size_t i=0; i != MAX_SYS_FILES; ++i) {
    file_rec_t* file = &SYS_FILES[i];
    if (!file->vmt) {
      continue;
    }
    if (file->path == path || strcmp(file->path, path) == 0) {
      return i;
    }
  }
  return -ENOENT;
}

/// \return номер записи в таблице файловых дескрипторов или -ENFILE
static int vfs_find_free(void)
{
  // Начинаем поиск с 3-й записи, что бы оставить место для
  // STDIN_FILENO, STDOUT_FILENO и STDERR_FILENO
  for (size_t i=3; i != MAX_SYS_FILES; ++i) {
    file_rec_t* file = &SYS_FILES[i];
    if (!file->vmt) {
      return i;
    }
  }
  return -ENFILE;
}

static file_rec_t* vfs_get_file(int fd)
{
  if (fd < 0 || fd >= MAX_SYS_FILES) {
    return NULL;
  }
  return &SYS_FILES[fd];
}

static int vfs_fstat_int(int fd, struct stat* st, bool should_be_open)
{
  int ret;
  if (!st) {
    ret = -EINVAL;
    goto cleanup;
  }

  file_rec_t* file = vfs_get_file(fd);
  if (!file) {
    ret = -EBADF;
    goto cleanup;
  }

  if (should_be_open && !(file->state.flags & FILE_F_OPENED)) {
    // Файл должен быть открыт, но он не открыт
    ret = -EBADF;
    goto cleanup;
  }

  if (!file->vmt || !file->vmt->fstat) {
    ret = -ENOSYS;
    goto cleanup;
  }

  ret = file->vmt->fstat(&file->state, st);
  if (ret < 0) {
    goto cleanup;
  }

  // Пока что поддерживаются только символьные файлы.
  st->st_mode |= S_IFCHR;

cleanup:
  return ret;
}


////////////////////////////////////////////////////////////////////////////
//  Публичные функции

void vfs_init(void)
{
  memset(SYS_FILES, 0, sizeof(SYS_FILES));
}

int vfs_register(const char* path, const file_ops_t* vmt, void* priv, int mode)
{
  // Статическая проверка, что константы соответствуют нашим ожиданиям.
# if !defined(STDIN_FILENO)   || (STDIN_FILENO  != 0) \
  || !defined(STDOUT_FILENO)  || (STDOUT_FILENO != 1) \
  || !defined(STDERR_FILENO)  || (STDERR_FILENO != 2)
#   error "VFS module expects STDIN_FILENO=0, STDOUT_FILENO=1, STDERR_FILENO=2"
# endif

  int ret;
  if (!path || !vmt) {
    return -EINVAL;
  }

  // TODO: Добавить блокировку доступа
  int fd = vfs_find_path(path);
  if (fd >= 0) {
    // Нельзя зарегистрировать, т.к. уже есть в системе.
    ret = -EEXIST;
    goto err_cleanup;
  }

  int fixed_fd = mode & VFS_MODE_STDxxx_MASK;

  if (fixed_fd) {
    fd = fixed_fd == VFS_MODE_STDIN  ? STDIN_FILENO
       : fixed_fd == VFS_MODE_STDOUT ? STDOUT_FILENO
       : fixed_fd == VFS_MODE_STDERR ? STDERR_FILENO
       : -EINVAL;
  } else {
    fd  = vfs_find_free();
  }

  if (fd < 0) {
    // Нет свободных файловых дескрипторов.
    ret = fd;
    goto err_cleanup;
  }

  file_rec_t* file = vfs_get_file(fd);
  if (!file) {
    ret = -EBADF;
    goto err_cleanup;
  }

  if ((file->state.flags & FILE_F_OPENED) == FILE_F_OPENED) {
    // Сюда можем попасть либо из-за гонок потоков,
    // либо при попытке зарегистрировать один из стандартных файлов,
    // если он уже был зарегистрирован.
    ret = -ENFILE;
    goto err_cleanup;
  }

  file->vmt   = vmt;
  file->path  = path;
  file->mode  = mode;
  file->state.priv = priv;

  ret = 0;

err_cleanup:
  return ret;
}

int vfs_open(const char* path, int flags, int mode)
{
  (void)mode;

  int ret;
  if (!path) {
    return -EINVAL;
  }

  // Поиск существующего файла и проверка, что он ещё не открыт
  int fd = vfs_find_path(path);
  if (fd < 0) {
    ret = fd;
    goto cleanup;
  }

  file_rec_t* file = vfs_get_file(fd);
  if (!file) {
    ret = -EBADF;
    goto cleanup;
  }

  if ((file->state.flags & FILE_F_OPENED) == FILE_F_OPENED) {
    // Файл уже был открыт кем-то другим
    ret = -EMFILE;
    goto cleanup;
  }

  if ((flags & O_CREAT) && (flags & O_EXCL)) {
    // Файлы создавать не умеем, но дать ошибку о
    // невозможности создать файл, т.к. уже есть
    // - это всегда пожалуйста.
    ret = -EEXIST;
    goto cleanup;
  }

  // Заполнение стандартных начальных значений полям файла
  // Обрабатываем только часть возможных флагов, остальные
  // должны быть обработаны в драйвере - при необходимости.
  int     accmode = flags & O_ACCMODE;

  if ( accmode == O_RDONLY || accmode == O_RDWR) {
    if ((file->mode & VFS_MODE_READ) != VFS_MODE_READ) {
      // Чтение не поддерживается
      ret = -EACCES;
      goto cleanup;
    }
  }

  if ( accmode == O_WRONLY || accmode == O_RDWR) {
    if ((file->mode & VFS_MODE_WRITE) != VFS_MODE_WRITE) {
      // Запись не поддерживается
      ret = -EROFS;
      goto cleanup;
    }
  }

  // сохраняем флаги перед вызовом функции открытия драйвера.
  file->state.flags     = flags | FILE_F_OPENED;
  file->state.size      = 0;
  file->state.capacity  = -1;
  file->state.pos       = 0;

  // Вызов функции открытия драйвера.
  if (file->vmt && file->vmt->open) {
    ret = file->vmt->open(&file->state);
    if (ret < 0) {
      // Структура файла была выделена, необходимо освободить.
      file->state.flags = 0;
      goto cleanup;
    }
  }

  // Успешно открыли файл
  ret = fd;

cleanup:
  return ret;
}

// close - закрытие файла - возвращаем ошибку
int vfs_close(int fd)
{
  int ret;

  file_rec_t* file = vfs_get_file(fd);
  if (!file) {
    ret = -EBADF;
    goto cleanup;
  }

  if (!(file->state.flags & FILE_F_OPENED)) {
    ret = -EBADF;
    goto cleanup;
  }

  if (file->vmt && file->vmt->close) {
    ret = file->vmt->close(&file->state);
    if (ret < 0) {
      goto cleanup;
    }
  }

  // Успешно закрыт.
  file->state.flags = 0;
  ret = 0;

cleanup:
  return ret;
}

off_t vfs_lseek(int fd, off_t offset, int whence)
{
  int ret;

  file_rec_t* file = vfs_get_file(fd);
  if (!file) {
    ret = -EBADF;
    goto cleanup;
  }

  if (!(file->state.flags & FILE_F_OPENED)) {
    ret = -EBADF;
    goto cleanup;
  }

  if (!(file->mode & VFS_MODE_SEEKABLE)) {
    ret = -ESPIPE;
    goto cleanup;
  }

  // Если файл/драйвер предоставляет функцию перемещения указателя,
  // то используем её,
  if (file->vmt && file->vmt->lseek) {
    ret = file->vmt->lseek(&file->state, offset, whence);
    // Все проверки - внутри lseek драйвера. Выходим.
    goto cleanup;
  }

  // иначе - просто изменяем поле смещения в соответствии с параметрами
  if (whence == SEEK_CUR) {
    // Переход от текущей позиции файла
    offset += file->state.pos;

  } else if (whence == SEEK_END && file->state.size >= 0) {
    // Переход от конца файла, когда размер файла известен
    offset += file->state.size;

  } else if (whence == SEEK_END) {
    // Размер неизвестен, переход относительно конца файла невозможен
    ret = -EINVAL;
    goto cleanup;

  } else if (whence != SEEK_SET) {
    // Поддерживаются только SEEK_SET, SEEK_CUR и SEEK_END.
    ret = -EINVAL;
    goto cleanup;
  }

  // Новая позиция вычислена. Проверяем на допустимость.
  if (offset < 0) {
    // смещение не может оказаться отрицательным
    ret = -EINVAL;
    goto cleanup;
  }

  if (file->state.capacity >= 0 && offset > file->state.capacity) {
    // смещение не может превышать размер устройства (если известен)
    ret = -EINVAL;
    goto cleanup;
  }

  file->state.pos = offset;
  ret = offset;

cleanup:
  return ret;
}

int vfs_write(int fd, const char* ptr, int len)
{
  int ret;
  file_rec_t* file = vfs_get_file(fd);
  if (!file) {
    ret = -EBADF;
    goto cleanup;
  }

  if (!(file->state.flags & FILE_F_OPENED)) {
    ret = -EBADF;
    goto cleanup;
  }

  int     accmode = file->state.flags & O_ACCMODE;
  if ((accmode != O_WRONLY && accmode != O_RDWR) || !file->vmt || !file->vmt->write) {
    // Файл не поддерживает запись
    ret = -EBADF;
    goto cleanup;
  }

  ret = file->vmt->write(&file->state, ptr, len);

cleanup:
  return ret;
}

int vfs_read(int fd, char* ptr, int len)
{
  int ret;
  file_rec_t* file = vfs_get_file(fd);
  if (!file) {
    ret = -EBADF;
    goto cleanup;
  }

  if (!(file->state.flags & FILE_F_OPENED)) {
    ret = -EBADF;
    goto cleanup;
  }

  int     accmode = file->state.flags & O_ACCMODE;
  if ((accmode != O_RDONLY && accmode != O_RDWR) || !file->vmt || !file->vmt->read) {
    // Файл не поддерживает запись
    ret = -EBADF;
    goto cleanup;
  }

  ret = file->vmt->read(&file->state, ptr, len);

cleanup:
  return ret;
}

int vfs_stat(const char* path, struct stat* st)
{
  int ret;
  int fd = vfs_find_path(path);
  if (fd < 0) {
    ret = fd;
    goto cleanup;
  }

  ret = vfs_fstat_int(fd, st, false);

cleanup:
  return ret;
}

int vfs_fstat(int fd, struct stat* st)
{
  return vfs_fstat_int(fd, st, true);
}

/// Проверяет, что файл - открытый терминал
///
/// В отличие от системной функции isatty, данная функция возвращает 1 в случае успеха
/// или отрицательный код ошибки. Если данная функция используется для переопределения
/// системной isatty, то в случае получения отрицательного результата следует сохранить
/// его в errno и вернуть 0 (а не -1, как в случае большинства других системных вызовов)
int vfs_isatty(int fd)
{
  int         ret;
  file_rec_t* file = vfs_get_file(fd);
  if (!file) {
    ret = -EBADF;
    goto cleanup;
  }

  if (!(file->state.flags & FILE_F_OPENED)) {
    ret = -EBADF;
    goto cleanup;
  }

  if (!(file->mode & VFS_MODE_CHAR) || !(file->mode & VFS_MODE_TTY)) {
    ret = -EINVAL;
    goto cleanup;
  }

  ret = 1;
cleanup:
  return ret;
}

int vfs_link(const char* oldpath, const char* newpath)
{
  if (!oldpath || !newpath) {
    return -EINVAL;
  }
  // Пока не поддерживаем ссылки
  return -EPERM;
}

int vfs_unlink(const char* pathname)
{
  if (!pathname) {
    return -EINVAL;
  }
  return -EPERM;
}
