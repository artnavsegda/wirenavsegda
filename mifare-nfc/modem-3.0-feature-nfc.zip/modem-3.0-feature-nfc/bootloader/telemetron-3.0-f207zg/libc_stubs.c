#ifndef CONFIG_LIBC_STUBS_LOG_LEVEL
#define CONFIG_LIBC_STUBS_LOG_LEVEL LOG_LEVEL_DEBUG
#endif

#include <errno.h>
#include <stm32f2xx.h>
#include <core_cmFunc.h>
#include <sys/stat.h>
#include <sys/times.h>
#include <sys/unistd.h>
#include "dbg.h"
#include "vfs.h"
extern uint32_t __get_MSP(void);

// errno
#undef errno
extern int errno;


/*
 Переменные среды - пустой список.
 */
char*  __env[1] = {0};
char** environ  = __env;




int _open(const char* path, int flags, ...)
{
  int ret = vfs_open(path, flags, 0);
  log_trace("vfs_open('%s',%X) ret %d", path, flags, ret);
  if (ret < 0) {
    errno = -ret;
    ret = -1;
  }
  return ret;
}

// close - закрытие файла - возвращаем ошибку
int _close(int fd)
{
  int ret = vfs_close(fd);
  log_trace("vfs_close(%d) ret %d", fd, ret);
  if (ret < 0) {
    errno = -ret;
    ret = -1;
  }
  return ret;
}

/*
 lseek - установить позицию в файле
 */
int _lseek(int file, int ptr, int dir)
{
  (void)file;
  (void)ptr;
  (void)dir;
  return 0;
}


int _write(int fd, char* ptr, int len)
{
  int ret = vfs_write(fd, ptr, len);
  log_trace("vfs_write(%d,@%p,%d) ret %d", fd, ptr, len, ret);
  log_trace_printhex(ptr, len);
  if (ret < 0) {
    errno = -ret;
    ret = -1;
  }
  return ret;
}

int _read(int fd, char* ptr, int len)
{
  int ret = vfs_read(fd, ptr, len);
  log_trace("vfs_read(%d,@%p,%d) ret %d", fd, ptr, len, ret);
  log_trace_printhex(ptr, len);
  if (ret < 0) {
    errno = -ret;
    ret   = -1;
  }
  return ret;
}

/*
 stat - состояние файла по его пути.
 */
int _stat(const char* filepath, struct stat* st)
{
  int ret = vfs_stat(filepath, st);
  log_trace("vfs_stat('%s',@%p) ret %d", filepath, st, ret);
  if (ret < 0) {
    errno = -ret;
    ret   = -1;
  }
  return ret;
}

/*
 fstat - состояние открытого файла
 */
int _fstat(int fd, struct stat* st)
{
  int ret = vfs_fstat(fd, st);
  log_trace("vfs_fstat(%d,@%p) ret %d", fd, st, ret);
  if (ret < 0) {
    errno = -ret;
    ret   = -1;
  }
  return ret;
}

/*
 isatty - является ли файл терминалом.
 */
int _isatty(int fd)
{
  int ret = vfs_isatty(fd);
  log_trace("vfs_isatty(%d) ret %d", fd, ret);
  if (ret < 0) {
    errno = -ret;
    // В отличие от большинства системных вызовов, данный в случае ошибки
    // должен возвращать ноль!
    ret   = 0;
  }
  return ret;
}

/*
 link - устанвить новое имя для существующего файла.
 */
int _link(char* oldpath, char* newpath)
{
  int ret = vfs_link(oldpath, newpath);
  log_trace("vfs_link('%s','%s') ret %d", oldpath, newpath, ret);
  if (ret < 0) {
    errno = -ret;
    ret   = -1;
  }
  return ret;
}

/*
 unlink - удалить имя файла.
 */
int _unlink(char* name)
{
  int ret = vfs_unlink(name);
  log_trace("vfs_unlink('%s') ret %d", name, ret);
  if (ret < 0) {
    errno = -ret;
    ret   = -1;
  }
  return ret;
}



// exit - экстренный выход. В качестве выхода - зацикливаемся.
__attribute__((weak)) void _exit(int status)
{
  (void)status;
  while (1)
    ;
}



/*
 execve - передача управления новому процессу - процессов нет -> возвращаем ошибку.
 */
int _execve(char* name, char** argv, char** env)
{
  (void)name;
  (void)argv;
  (void)env;
  errno = ENOMEM;
  return -1;
}

/*
 fork = создание нового процесса
 */
int _fork()
{
  errno = EAGAIN;
  return -1;
}


/*
 getpid - получить ID текущего процесса
 */

int _getpid()
{
  return 1;
}


/*
 kill - послать сигнал процессу
 */
int _kill(int pid, int sig)
{
  (void)pid;
  (void)sig;
  errno = EINVAL;
  return (-1);
}



/*
 sbrk - увеличить размер области данных, использутся для malloc
 */
caddr_t _sbrk(int incr)
{
  extern char  _ebss;
  static char* heap_end;
  char*        prev_heap_end;

  if (heap_end == 0) {
    heap_end = &_ebss;
  }
  prev_heap_end = heap_end;

  char* stack = (char*)__get_MSP();
  log_trace("_sbrk(%d). Current heap_end=0x%08X, stack=0x%08X", incr, heap_end, stack);
  if (heap_end + incr > stack) {
    _write(STDERR_FILENO, "Heap and stack collision\n", 25);
    errno = ENOMEM;
    return (caddr_t)-1;
    // abort ();
  }

  heap_end += incr;
  return (caddr_t)prev_heap_end;
}


/*
 times - временная информация о процессе (сколько тиков: системных, процессорных и т.д.)
 */

clock_t _times(struct tms* buf)
{
  (void)buf;
  return -1;
}

/*
 wait - ожидания дочерних процессов
 */
int _wait(int* status)
{
  (void)status;
  errno = ECHILD;
  return -1;
}
