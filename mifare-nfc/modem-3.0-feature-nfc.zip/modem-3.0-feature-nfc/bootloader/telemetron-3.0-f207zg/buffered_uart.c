/// @file buffered_uart.c
/// @author DL <dmitriy.linikov@gmail.com>

#include "buffered_uart.h"
#include <string.h>
#include "system_utils.h"
#include <system_stm32f2xx.h>

#if (  BUFFERED_UART_ENABLE_UART1 \
    || BUFFERED_UART_ENABLE_UART2 \
    || BUFFERED_UART_ENABLE_UART3 \
    || BUFFERED_UART_ENABLE_UART4 \
    || BUFFERED_UART_ENABLE_UART5 )
# define BUFFERED_UART_ENABLED     1
#else
# define BUFFERED_UART_ENABLED     0
#endif


// ============================================================================
// Определение настроек и декларация служебных переменных для порта USART1
// ============================================================================
#if BUFFERED_UART_ENABLE_UART1 || defined(__DOXYGEN__)
# if !defined(UART1_TX_BUFFER_SIZE) || defined(__DOXYGEN__)
    /// \brief Размер буффера передачи для последовательного порта U(S)ART1
    ///
    /// При необходимости, данный параметр следует изменить на более подходящее значение в настройках проекта.
    ///
    /// \note Если данный параметр равен нулю, то данный последовательный порт будет
    /// работать в polled режиме передачи без использования буффера.
#ifdef MODEM_VERSION_27
#   define UART1_TX_BUFFER_SIZE   256
#else
#   define UART1_TX_BUFFER_SIZE   32
#endif // MODEM_VERSION_27
# endif

# if !defined(UART1_RX_BUFFER_SIZE) || defined(__DOXYGEN__)
    /// \brief Размер буффера приёма для последовательного порта U(S)ART1
    ///
    /// При необходимости, данный параметр следует изменить на более подходящее значение в настройках проекта.
    ///
    /// \note Если данный параметр равен нулю, то данный последовательный порт будет
    /// работать в polled режиме приёма без использования буффера.
#ifdef MODEM_VERSION_27
#   define  UART1_RX_BUFFER_SIZE  1500
#else
#   define  UART1_RX_BUFFER_SIZE  64
#endif // MODEM_VERSION_27
# endif // UART1_RX_BUFFER_SIZE

# if (UART1_TX_BUFFER_SIZE != 0)
    uint8_t       uart1_tx_buffer[UART1_TX_BUFFER_SIZE];
# else
#   define        uart1_tx_buffer         NULL
# endif

# if (UART1_RX_BUFFER_SIZE != 0)
    uint8_t       uart1_rx_buffer[UART1_RX_BUFFER_SIZE];
# else
#   define        uart1_rx_buffer         NULL
# endif

  UartDriver    SD1;
#endif // BUFFERED_UART_ENABLE_UART1


// ============================================================================
// Определение настроек и декларация служебных переменных для порта USART2
// ============================================================================
#if BUFFERED_UART_ENABLE_UART2 || defined(__DOXYGEN__)
# if !defined(UART2_TX_BUFFER_SIZE) || defined(__DOXYGEN__)
    /// \brief Размер буффера передачи для последовательного порта U(S)ART2
    ///
    /// При необходимости, данный параметр следует изменить на более подходящее значение в настройках проекта.
    ///
    /// \note Если данный параметр равен нулю, то данный последовательный порт будет
    /// работать в polled режиме передачи без использования буффера.
#ifdef MODEM_VERSION_27
#   define UART2_TX_BUFFER_SIZE   256
#else
#   define UART2_TX_BUFFER_SIZE   32
#endif // MODEM_VERSION_27
# endif

# if !defined(UART2_RX_BUFFER_SIZE) || defined(__DOXYGEN__)
    /// \brief Размер буффера приёма для последовательного порта U(S)ART2
    ///
    /// При необходимости, данный параметр следует изменить на более подходящее значение в настройках проекта.
    ///
    /// \note Если данный параметр равен нулю, то данный последовательный порт будет
    /// работать в polled режиме приёма без использования буффера.
#ifdef MODEM_VERSION_27
#   define  UART2_RX_BUFFER_SIZE  256
#else
#   define  UART2_RX_BUFFER_SIZE  64
#endif // MODEM_VERSION_27
# endif

# if (UART2_TX_BUFFER_SIZE != 0)
    uint8_t       uart2_tx_buffer[UART2_TX_BUFFER_SIZE];
# else
#   define        uart2_tx_buffer         NULL
# endif

# if (UART2_RX_BUFFER_SIZE != 0)
    uint8_t       uart2_rx_buffer[UART2_RX_BUFFER_SIZE];
# else
#   define        uart2_rx_buffer         NULL
# endif

  /// \brief Дескриптор последовательного порта U(S)ART2.
  UartDriver    SD2;
#endif // BUFFERED_UART_ENABLE_UART2


// ============================================================================
// Определение настроек и декларация служебных переменных для порта USART3
// ============================================================================
#if BUFFERED_UART_ENABLE_UART3 || defined(__DOXYGEN__)
# if !defined(UART3_TX_BUFFER_SIZE) || defined(__DOXYGEN__)
    /// \brief Размер буффера передачи для последовательного порта U(S)ART3
    ///
    /// При необходимости, данный параметр следует изменить на более подходящее значение в настройках проекта.
    ///
    /// \note Если данный параметр равен нулю, то данный последовательный порт будет
    /// работать в polled режиме передачи без использования буффера.
#ifdef MODEM_VERSION_27
#   define UART3_TX_BUFFER_SIZE   256
#else
#   define UART3_TX_BUFFER_SIZE   32
#endif // MODEM_VERSION_27
# endif

# if !defined(UART3_RX_BUFFER_SIZE) || defined(__DOXYGEN__)
    /// \brief Размер буффера приёма для последовательного порта U(S)ART3
    ///
    /// При необходимости, данный параметр следует изменить на более подходящее значение в настройках проекта.
    ///
    /// \note Если данный параметр равен нулю, то данный последовательный порт будет
    /// работать в polled режиме приёма без использования буффера.
#ifdef MODEM_VERSION_27
#   define  UART3_RX_BUFFER_SIZE  256
#else
#   define  UART3_RX_BUFFER_SIZE  64
#endif // MODEM_VERSION_27
# endif // UART3_RX_BUFFER_SIZE

# if (UART3_TX_BUFFER_SIZE != 0)
    uint8_t       uart3_tx_buffer[UART3_TX_BUFFER_SIZE];
# else
#   define        uart3_tx_buffer         NULL
# endif

# if (UART3_RX_BUFFER_SIZE != 0)
    uint8_t       uart3_rx_buffer[UART3_RX_BUFFER_SIZE];
# else
#   define        uart3_rx_buffer         NULL
# endif

  /// \brief Дескриптор последовательного порта U(S)ART3.
  UartDriver    SD3;
#endif // BUFFERED_UART_ENABLE_UART3


// ============================================================================
// Определение настроек и декларация служебных переменных для порта UART4
// ============================================================================
#if BUFFERED_UART_ENABLE_UART4 || defined(__DOXYGEN__)
# if !defined(UART4_TX_BUFFER_SIZE) || defined(__DOXYGEN__)
    /// \brief Размер буффера передачи для последовательного порта UART4
    ///
    /// При необходимости, данный параметр следует изменить на более подходящее значение в настройках проекта.
    ///
    /// \note Если данный параметр равен нулю, то данный последовательный порт будет
    /// работать в polled режиме передачи без использования буффера.
#ifdef MODEM_VERSION_27
#   define UART4_TX_BUFFER_SIZE   256
#else
#   define UART4_TX_BUFFER_SIZE   128
#endif // MODEM_VERSION_27
# endif

# if !defined(UART4_RX_BUFFER_SIZE) || defined(__DOXYGEN__)
    /// \brief Размер буффера приёма для последовательного порта UART4
    ///
    /// При необходимости, данный параметр следует изменить на более подходящее значение в настройках проекта.
    ///
    /// \note Если данный параметр равен нулю, то данный последовательный порт будет
    /// работать в polled режиме приёма без использования буффера.
#ifdef MODEM_VERSION_27
#   define  UART4_RX_BUFFER_SIZE  1500
#else
#   define  UART4_RX_BUFFER_SIZE  128
#endif // MODEM_VERSION_27
# endif

# if (UART4_TX_BUFFER_SIZE != 0)
    uint8_t       uart4_tx_buffer[UART4_TX_BUFFER_SIZE];
# else
#   define        uart4_tx_buffer         NULL
# endif

# if (UART4_RX_BUFFER_SIZE != 0)
    uint8_t       uart4_rx_buffer[UART4_RX_BUFFER_SIZE];
# else
#   define        uart4_rx_buffer         NULL
# endif

  /// \brief Дескриптор последовательного порта UART4.
  UartDriver    SD4;
#endif // BUFFERED_UART_ENABLE_UART4




// ============================================================================
// Определение настроек и декларация служебных переменных для порта UART5
// ============================================================================
#if BUFFERED_UART_ENABLE_UART5 || defined(__DOXYGEN__)
# if !defined(UART5_TX_BUFFER_SIZE) || defined(__DOXYGEN__)
    /// \brief Размер буффера передачи для последовательного порта UART5
    ///
    /// При необходимости, данный параметр следует изменить на более подходящее значение в настройках проекта.
    ///
    /// \note Если данный параметр равен нулю, то данный последовательный порт будет
    /// работать в polled режиме передачи без использования буффера.
#ifdef MODEM_VERSION_27
#   define UART5_TX_BUFFER_SIZE   256
#else
#   define UART5_TX_BUFFER_SIZE   128
#endif // MODEM_VERSION_27
# endif

# if !defined(UART5_RX_BUFFER_SIZE) || defined(__DOXYGEN__)
    /// \brief Размер буффера приёма для последовательного порта U(S)ART5
    ///
    /// При необходимости, данный параметр следует изменить на более подходящее значение в настройках проекта.
    ///
    /// \note Если данный параметр равен нулю, то данный последовательный порт будет
    /// работать в polled режиме приёма без использования буффера.
#ifdef MODEM_VERSION_27
#   define  UART5_RX_BUFFER_SIZE  1500
#else
#   define  UART5_RX_BUFFER_SIZE  128
#endif // MODEM_VERSION_27
# endif

# if (UART5_TX_BUFFER_SIZE != 0)
    uint8_t       uart5_tx_buffer[UART5_TX_BUFFER_SIZE];
# else
#   define        uart5_tx_buffer         NULL
# endif

# if (UART5_RX_BUFFER_SIZE != 0)
    uint8_t       uart5_rx_buffer[UART5_RX_BUFFER_SIZE];
# else
#   define        uart5_rx_buffer         NULL
# endif

  /// \brief Дескриптор последовательного порта U(S)ART3.
  UartDriver    SD5;
#endif // BUFFERED_UART_ENABLE_UART5


// ============================================================================
// Инициализация драйвера и настройка порта.
// ============================================================================


#if (BUFFERED_UART_ENABLED == 1)
static void UartDriverObjectInit(UartDriver* port, void* tx_buffer, size_t tx_size, void* rx_buffer, size_t rx_size) {
  memset(port, 0, sizeof(*port));
  CircBufferObjectInit(&port->oqueue, tx_buffer, tx_size);
  CircBufferObjectInit(&port->iqueue, rx_buffer, rx_size);
}


static void UartStart(UartDriver* port, uint32_t baudrate, uint32_t cr1, uint32_t cr2, uint32_t cr3)
{
  USART_TypeDef *u = port->port;
  if (port){
  u->CR1 &= ~USART_CR1_UE;
  UartSetBaudrate(port, baudrate);

  u->CR2 = cr2;//USART_CR2_LBDIE;
  u->CR3 = cr3;//USART_CR3_EIE;

  uint32_t cr1_tmp = USART_CR1_UE | cr1;// | USART_CR1_PEIE
  if (port->iqueue.size > 0) {
    // разрешаем приём данных из прерывания только для портов, имеющих буффер.
    cr1_tmp |= USART_CR1_RXNEIE;
  }

  u->SR = 0;
  (void)u->SR;  /* SR reset step 1.*/
  (void)u->DR;  /* SR reset step 2.*/
  u->CR1 = cr1_tmp;
  }
}

static void UartStop(UartDriver* port)
{
  USART_TypeDef *u = port->port;
  u->CR1 = 0;
  u->CR2 = 0;
  u->CR3 = 0;
}


// ============================================================================
// Обработчики прерываний для всех поддерживаемых последовательных портов
// ============================================================================


static void serve_interrupt(UartDriver *sdp) {
  USART_TypeDef *u = sdp->port;
  uint16_t cr1 = u->CR1;
  uint16_t sr = u->SR;  /* SR reset step 1.*/
  uint16_t dr = 0;

  // Корректная вычитка статуса (только когда байт полностью пришел, сбрасываем флажки)
  if (sr & USART_SR_RXNE) dr = u->DR;  /* SR reset step 2.*/
  // Сброс ошибок и Break.
  if (sr & (USART_SR_ORE | USART_SR_NE | USART_SR_FE  | USART_SR_PE |USART_SR_LBD)) {
    //u->SR &= ~(USART_SR_ORE | USART_SR_NE | USART_SR_FE  | USART_SR_PE|USART_SR_LBD);
  }

  // Обнаружение BREAK состояния на шине LIN и сброс этого флага.
  //if (sr & USART_SR_LBD) {
  //  u->SR &= ~USART_SR_LBD;
  //}

  // Обработка приёма данных только для порта, которому разрешен приём данных в прерываниях.
  if ((cr1 & USART_CR1_RXNEIE) && (sr & USART_SR_RXNE)) {
    //__disable_irq();
    CircBufferPush(&sdp->iqueue, (uint8_t)dr);
    //__enable_irq();
  }

  // Обработка передачи данных.
  if ((cr1 & USART_CR1_TXEIE) && (sr & USART_SR_TXE)) {
    int b;
    //__disable_irq();
    b = CircBufferPop(&sdp->oqueue);
    if (b < CIRCBUFFER_OK) {
      // Очередь данных на отправку опустела.
      cr1 = (cr1 & ~USART_CR1_TXEIE) | USART_CR1_TCIE;
      u->CR1 = cr1;
    } else {
      // В очереди есть данные. Отправляем.
      u->DR = b;
      sr &=  ~USART_SR_TC;
    }
    //__enable_irq();
  }

  // Обработка события окончания передачи.
  if (sr & USART_SR_TC) {
    u->CR1 = cr1 & ~USART_CR1_TCIE;
    // Вот этого делать нельзя. К моменту обработки может произойти возведение других флагов, а мы этой операцией их сбросим.
    //u->SR &= ~USART_SR_TC;

    if (sdp->state == UARTSTATE_TX_ACTIVE) {
#ifdef DBG_ACTIVITY_GUARD
      if (dbg_port==sdp)
      DBG_ACTIVITY_GUARD = false;
#endif // DBG_ACTIVITY_GUARD
      sdp->state = UARTSTATE_READY;
    }
  }
}


#if BUFFERED_UART_ENABLE_UART1
void USART1_IRQHandler(void)
{
  serve_interrupt(&SD1);
}
#endif // BUFFERED_UART_ENABLE_UART1

#if BUFFERED_UART_ENABLE_UART2
void USART2_IRQHandler(void)
{
  serve_interrupt(&SD2);
}
#endif // BUFFERED_UART_ENABLE_UART2

#if BUFFERED_UART_ENABLE_UART3
void USART3_IRQHandler(void)
{
  serve_interrupt(&SD3);
}
#endif // BUFFERED_UART_ENABLE_UART3

#if BUFFERED_UART_ENABLE_UART4
void UART4_IRQHandler(void)
{
  serve_interrupt(&SD4);
}
#endif // BUFFERED_UART_ENABLE_UART4

#if BUFFERED_UART_ENABLE_UART5
void UART5_IRQHandler(void)
{
  serve_interrupt(&SD5);
}
#endif // BUFFERED_UART_ENABLE_UART4



// ============================================================================
// Публичные функции драйвера.
// ============================================================================


void BufferedUartDriverInit()
{
#if BUFFERED_UART_ENABLE_UART1
  UartDriverObjectInit(&SD1, uart1_tx_buffer, UART1_TX_BUFFER_SIZE, uart1_rx_buffer, UART1_RX_BUFFER_SIZE);
  SD1.port = USART1;
#endif // BUFFERED_UART_ENABLE_UART1

#if BUFFERED_UART_ENABLE_UART2
  UartDriverObjectInit(&SD2, uart2_tx_buffer, UART2_TX_BUFFER_SIZE, uart2_rx_buffer, UART2_RX_BUFFER_SIZE);
  SD2.port = USART2;
#endif // BUFFERED_UART_ENABLE_UART2

#if BUFFERED_UART_ENABLE_UART3
  UartDriverObjectInit(&SD3, uart3_tx_buffer, UART3_TX_BUFFER_SIZE, uart3_rx_buffer, UART3_RX_BUFFER_SIZE);
  SD3.port = USART3;
#endif // BUFFERED_UART_ENABLE_UART3

#if BUFFERED_UART_ENABLE_UART4
  UartDriverObjectInit(&SD4, uart4_tx_buffer, UART4_TX_BUFFER_SIZE, uart4_rx_buffer, UART4_RX_BUFFER_SIZE);
  SD4.port = UART4;
#endif // BUFFERED_UART_ENABLE_UART4

#if BUFFERED_UART_ENABLE_UART5
  UartDriverObjectInit(&SD5, uart5_tx_buffer, UART5_TX_BUFFER_SIZE, uart5_rx_buffer, UART5_RX_BUFFER_SIZE);
  SD5.port = UART5;
#endif // BUFFERED_UART_ENABLE_UART5
}

#ifdef DBG_ACTIVITY_GUARD
bool UartWaitTxCompleteImmediately(UartDriver* port, systime_t timeout)
{
  timeout_t t;
  timeout_start(&t, timeout);
  do {
    if (port->oqueue.size)
        return false;
    else
    {
        if ((port->port)->SR&USART_SR_TC)
        {
            (port->port)->SR&=~USART_SR_TC;
            return true;
        }
    }
  } while(!timeout_is_elapsed(&t));
  return false;
}
#endif // DBG_ACTIVITY_GUARD

bool UartWaitTxComplete(UartDriver* port, systime_t timeout)
{
  timeout_t t;
  volatile UartState state;
  timeout_start(&t, timeout);
  do {
    if (port->oqueue.size)
    {
        __disable_irq();
        state=port->state;
        __enable_irq();
        if (state!=UARTSTATE_TX_ACTIVE) {
        return true;
        }
        delay_ms(1);
    }
    else
    {
        if ((port->port)->SR&USART_SR_TC)
        {
            (port->port)->SR&=~USART_SR_TC;
            return true;
        }
    }
  } while(!timeout_is_elapsed(&t));
  return false;
}

int32_t UartGetIrq(UartDriver * port)
{
    int32_t ret=-1;
    if (port==NULL) ret=-2;
#if BUFFERED_UART_ENABLE_UART1
    else if (port->port==USART1) ret=USART1_IRQn;
#endif // BUFFERED_UART_ENABLE_UART1
#if BUFFERED_UART_ENABLE_UART2
    else if (port->port==USART2) ret=USART2_IRQn;
#endif // BUFFERED_UART_ENABLE_UART2
#if BUFFERED_UART_ENABLE_UART3
    else if (port->port==USART3) ret=USART3_IRQn;
#endif // BUFFERED_UART_ENABLE_UART3
#if BUFFERED_UART_ENABLE_UART4
    else if (port->port==UART4) ret=UART4_IRQn;
#endif // BUFFERED_UART_ENABLE_UART4
#if BUFFERED_UART_ENABLE_UART5
    else if (port->port==UART5) ret=UART5_IRQn;
#endif // BUFFERED_UART_ENABLE_UART5
    return(ret);
}

void UartDeinit(UartDriver* port)
{
  if (port->state == UARTSTATE_READY || port->state == UARTSTATE_TX_ACTIVE) {
    UartWaitTxComplete(port, TIMEOUT_FOREVER);

    port->state = UARTSTATE_UNINIT;
    UartStop(port);

#if BUFFERED_UART_ENABLE_UART1
    if (port == &SD1) {
      RCC->APB2ENR &= ~RCC_APB2ENR_USART1EN;
      NVIC_DisableIRQ(USART1_IRQn);
      return;
    }
#endif // BUFFERED_UART_ENABLE_UART1

#if BUFFERED_UART_ENABLE_UART2
    if (port == &SD2) {
      RCC->APB1ENR &= ~RCC_APB1ENR_USART2EN;
      NVIC_DisableIRQ(USART2_IRQn);
      return;
    }
#endif // BUFFERED_UART_ENABLE_UART2

#if BUFFERED_UART_ENABLE_UART3
    if (port == &SD3) {
      RCC->APB1ENR &= ~RCC_APB1ENR_USART3EN;
      NVIC_DisableIRQ(USART3_IRQn);
      return;
    }
#endif // BUFFERED_UART_ENABLE_UART3

#if BUFFERED_UART_ENABLE_UART4
    if (port == &SD4) {
      RCC->APB1ENR &= ~RCC_APB1ENR_UART4EN;
      NVIC_DisableIRQ(UART4_IRQn);
      return;
    }
#endif // BUFFERED_UART_ENABLE_UART4

#if BUFFERED_UART_ENABLE_UART5
    if (port == &SD5) {
      RCC->APB1ENR &= ~RCC_APB1ENR_UART5EN;
      NVIC_DisableIRQ(UART5_IRQn);
      return;
    }
#endif // BUFFERED_UART_ENABLE_UART5

    HaltWithReason("Invalid port", Halt_UartDeinit, false);
  }
}

void UartInit(UartDriver* port, uint32_t baudrate, uint32_t cr1, uint32_t cr2, uint32_t cr3, uint32_t priority)
{
  if (port->state == UARTSTATE_UNINIT) {
    bool match = false;

#if BUFFERED_UART_ENABLE_UART1
    if (port == &SD1) {
      RCC->APB2ENR |= RCC_APB2ENR_USART1EN;
      if (priority) NVIC_SetPriority(USART1_IRQn, priority);
      else NVIC_SetPriority(USART1_IRQn, DEX_PORT_PRIORITY);
      NVIC_EnableIRQ(USART1_IRQn);
      match = true;
    }
#endif // BUFFERED_UART_ENABLE_UART1

#if BUFFERED_UART_ENABLE_UART2
    if (port == &SD2) {
      RCC->APB1ENR |= RCC_APB1ENR_USART2EN;
      if (priority) NVIC_SetPriority(USART2_IRQn, priority);
      else NVIC_SetPriority(USART2_IRQn, DEX_PORT_PRIORITY);
      NVIC_EnableIRQ(USART2_IRQn);
      match = true;
    }
#endif // BUFFERED_UART_ENABLE_UART2

#if BUFFERED_UART_ENABLE_UART3
    if (port == &SD3) {
      RCC->APB1ENR |= RCC_APB1ENR_USART3EN;
      if (priority) NVIC_SetPriority(USART3_IRQn, priority);
      else NVIC_SetPriority(USART3_IRQn, DEX_PORT_PRIORITY);
      NVIC_EnableIRQ(USART3_IRQn);
      match = true;
    }
#endif // BUFFERED_UART_ENABLE_UART3

#if BUFFERED_UART_ENABLE_UART4
    if (port == &SD4) {
      RCC->APB1ENR |= RCC_APB1ENR_UART4EN;
      if (priority) NVIC_SetPriority(UART4_IRQn, priority);
      else NVIC_SetPriority(UART4_IRQn, DEX_PORT_PRIORITY);
      NVIC_EnableIRQ(UART4_IRQn);
      match = true;
    }
#endif // BUFFERED_UART_ENABLE_UART4

#if BUFFERED_UART_ENABLE_UART5
    if (port == &SD5) {
      RCC->APB1ENR |= RCC_APB1ENR_UART5EN;
      if (priority) NVIC_SetPriority(UART5_IRQn, priority);
      else NVIC_SetPriority(UART5_IRQn, DEX_PORT_PRIORITY);
      NVIC_EnableIRQ(UART5_IRQn);
      match = true;
    }
#endif // BUFFERED_UART_ENABLE_UART5

    if (!match) {
      HaltWithReason("Invalid port", Halt_UartInit, false);
    }
    UartStart(port, baudrate, cr1, cr2, cr3);
    port->state = UARTSTATE_READY;
  }
}

void UartSetBaudrate(UartDriver* port, uint32_t baudrate)
{
  if ((port) && (baudrate)) {
    USART_TypeDef*  p = port->port;
    // В данном случае считаем, что частота шин APB1/APB2 совпадает с
    // частотой системных часов. Это верно только в текущих настройках проекта.
    uint32_t clock=0;
    if (p == USART1) {
        clock = GET_APB2_CLOCK();
    } else if (p == USART2) {
        clock = GET_APB1_CLOCK();
    } else if (p == USART3) {
        clock = GET_APB1_CLOCK();
    } else if (p == UART4) {
        clock = GET_APB1_CLOCK();
    } else if (p == UART5) {
        clock = GET_APB1_CLOCK();
    } else {
        clock = SystemCoreClock;
    }
    uint32_t  divider = clock / baudrate;
    uint32_t  save_CR1 = p->CR1;
    p->CR1 = 0;//&=~ USART_CR1_UE;
    p->BRR = divider;
    p->CR1 = save_CR1;//|= USART_CR1_UE;
  }
}

void UartClearBufRx(UartDriver* port)
{
    //while (UartGetImmediately(port)!=UARTRESULT_TIMEOUT);
    __disable_irq();
    if (port->iqueue.size) memset(port->iqueue.data,0,port->iqueue.size);
    //if (port->oqueue.size) memset(port->oqueue.data,0,port->oqueue.size);
    port->iqueue.count=0;
    port->iqueue.rd_ptr=port->iqueue.data;
    port->iqueue.wr_ptr=port->iqueue.data;
    //port->oqueue.count=0;
    //port->oqueue.rd_ptr=port->oqueue.data;
    //port->oqueue.wr_ptr=port->oqueue.data;
    __enable_irq();
}

int UartGetImmediately(UartDriver* port)
{
  int result;
    if (port->iqueue.size) {
      __disable_irq();
      result = CircBufferPop(&(port->iqueue));
      __enable_irq();
    } else {
      result = uart_getc_immediate(port->port);
    }
  return result < 0 ? UARTRESULT_TIMEOUT : result;
}

int UartPutImmediately(UartDriver* port, int value)
{
//  uart_putc(port->port, value);
//  return UARTRESULT_OK;

  int result = UARTRESULT_TIMEOUT;
  if (port->oqueue.size) {
    __disable_irq();
    if (CircBufferPush(&(port->oqueue), value) == CIRCBUFFER_OK) {
      // Если в буффер были добавлены данные, то разрешаем прерывания отправки
      (port->port)->CR1 |= USART_CR1_TXEIE;
      if (port->state == UARTSTATE_READY) {
        port->state = UARTSTATE_TX_ACTIVE;
      }
      result = UARTRESULT_OK;
    }
    __enable_irq();
  } else {
    // Если нет буффера, то передача в polled режиме
    if (uart_tx_ready(port->port)) {
      uart_putc(port->port, value);
      result = UARTRESULT_OK;
    }
  } // if (port->oqueue.size) ... else ...
  return result;
}

int UartGetTimeout(UartDriver* port, systime_t timeout)
{
  int         result;
  timeout_t   t;
  if (port==NULL) return (UARTRESULT_TIMEOUT);
  timeout_start(&t, timeout);
  do {
    result = UartGetImmediately(port);
    if (result == UARTRESULT_TIMEOUT) delay_ms(1);
  } while (result == UARTRESULT_TIMEOUT && timeout && !timeout_is_elapsed(&t));
  return result;
}

int UartPutTimeout(UartDriver* port, int value, systime_t timeout)
{
  int         result;
  timeout_t   t;
  if (port==NULL) return (UARTRESULT_TIMEOUT);
  timeout_start(&t, timeout);
  do {
    result = UartPutImmediately(port, value);
  } while(result != UARTRESULT_OK && timeout && !timeout_is_elapsed(&t));
  return result;
}


int UartWriteImmediately(UartDriver* port, const void* value, uint16_t size)
{
//  __disable_irq();
  const uint8_t* data = value;
  uint16_t length = 0;

  while (length < size) {
    int b = UartPutImmediately(port, data[length]);
    if (b < UARTRESULT_OK) {
      break;
    }
    ++length;
  }
//  __enable_irq();
  return length;
}

int UartWriteTimeout(UartDriver* port, const void* value, uint16_t size, systime_t timeout)
{
  timeout_t       t;
  const uint8_t*  data = value;
  uint16_t        length = 0;

  if (!size) {
    return size;
  }

  timeout_start(&t, timeout);

  while (length < size) {
    if (UartPutImmediately(port, data[length]) == UARTRESULT_OK) {
      ++length;
    } else if (!timeout || timeout_is_elapsed(&t)) {
      break;
    }
  }
  return length;
}

int UartReadImmediately(UartDriver* port, void* dst, uint16_t max_size)
{
  uint8_t* data = dst;
  uint16_t length = 0;

  while (length < max_size) {
    int b = UartGetImmediately(port);
    if (b < UARTRESULT_OK) {
      break;
    }

    data[length++] = (uint8_t)b;
  }

  return length;
}

int UartReadTimeout(UartDriver* port, void* dst, uint16_t max_size, systime_t timeout)
{
  timeout_t   t;
  uint8_t*    data = dst;
  uint16_t    length = 0;

  timeout_start(&t, timeout);

  while (length < max_size) {
    int b = UartGetImmediately(port);
    if (b >= UARTRESULT_OK) {
      data[length++] = (uint8_t)b;
    } else if (!timeout || timeout_is_elapsed(&t)) {
      break;
    }
  }

  return length;
}

#endif // BUFFERED_UART_ENABLED == 1
