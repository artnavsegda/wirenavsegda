/// @file buffered_uart.h
/// @author DL <dmitriy.linikov@gmail.com>
/// @brief Модуль работы с UART портом процессора STM32F100 в асинхронно через буфферы.

#ifndef BUFFERED_UART_H_INCLUDED
#define BUFFERED_UART_H_INCLUDED

#include "board.h"
#include "uart.h"
#include "timeout.h"
#include "circular_buffer.h"

#define USART_CR2_STOP1_BITS    (0 << 12)   /**< @brief CR2 1 stop bit value.*/
#define USART_CR2_STOP0P5_BITS  (1 << 12)   /**< @brief CR2 0.5 stop bit value.*/
#define USART_CR2_STOP2_BITS    (2 << 12)   /**< @brief CR2 2 stop bit value.*/
#define USART_CR2_STOP1P5_BITS  (3 << 12)   /**< @brief CR2 1.5 stop bit value.*/


#ifndef BUFFERED_UART_BUFFER_SIZE
/// \brief Размер буффера для приёма и передачи.
#define BUFFERED_UART_BUFFER_SIZE   256
#endif // BUFFERED_UART_BUFFER_SIZE


typedef enum UartStateTag {
  UARTSTATE_UNINIT = 0,
  UARTSTATE_READY = 1,
  UARTSTATE_TX_ACTIVE = 2,
} UartState;

typedef enum UartResultTag {
  UARTRESULT_OK = 0,
  UARTRESULT_TIMEOUT = -1
} UartResult;

typedef struct UartDriverTag {
  USART_TypeDef*          port;
  volatile UartState      state;

  CircBuffer              oqueue;
  CircBuffer              iqueue;
} UartDriver;



#if BUFFERED_UART_ENABLE_UART1  || defined(__DOXYGEN__)
  /// \brief Дескриптор последовательного порта U(S)ART1.
  extern UartDriver    SD1;
#endif // BUFFERED_UART_ENABLE_UART1

#if BUFFERED_UART_ENABLE_UART2  || defined(__DOXYGEN__)
  /// \brief Дескриптор последовательного порта U(S)ART2.
  extern UartDriver    SD2;
#endif // BUFFERED_UART_ENABLE_UART2

#if BUFFERED_UART_ENABLE_UART3  || defined(__DOXYGEN__)
  /// \brief Дескриптор последовательного порта U(S)ART3.
  extern UartDriver    SD3;
#endif // BUFFERED_UART_ENABLE_UART3

#if BUFFERED_UART_ENABLE_UART4  || defined(__DOXYGEN__)
  /// \brief Дескриптор последовательного порта UART4.
  extern UartDriver    SD4;
#endif // BUFFERED_UART_ENABLE_UART4

#if BUFFERED_UART_ENABLE_UART5  || defined(__DOXYGEN__)
  /// \brief Дескриптор последовательного порта U(S)ART3.
  extern UartDriver    SD5;
#endif // BUFFERED_UART_ENABLE_UART5


void BufferedUartDriverInit();

/// \param cr1, cr2, cr3  должны содержать биты, ответственные за настройку длины слова, чётности,
///                       а так же разрешения приёма и передачи. Проверки данных значений не производится!
///                       Кроме того, 9-битный режим поддерживается только с автоматически-генерируемым битом чётности.
void UartInit(UartDriver* port, uint32_t baudrate, uint32_t cr1, uint32_t cr2, uint32_t cr3, uint32_t priority);

/// \brief Меняет скорость работы открытого порта.
void UartSetBaudrate(UartDriver* port, uint32_t baudrate);
void UartDeinit(UartDriver* port);
int32_t UartGetIrq(UartDriver * port);

#ifdef DBG_ACTIVITY_GUARD
bool UartWaitTxCompleteImmediately(UartDriver* port, systime_t timeout);
#endif // DBG_ACTIVITY_GUARD
bool UartWaitTxComplete(UartDriver* port, systime_t timeout);
void UartClearBufRx(UartDriver* port);

int UartWriteImmediately(UartDriver* port, const void* value, uint16_t size);
int UartReadImmediately(UartDriver* port, void* dst, uint16_t max_size);
int UartGetImmediately(UartDriver* port);
int UartPutImmediately(UartDriver* port, int value);
int UartGetTimeout(UartDriver* port, systime_t timeout);
int UartPutTimeout(UartDriver* port, int value, systime_t timeout);
int UartWriteTimeout(UartDriver* port, const void* value, uint16_t size, systime_t timeout);
int UartReadTimeout(UartDriver* port, void* dst, uint16_t max_size, systime_t timeout);


static inline int UartGet(UartDriver* port) {
  return UartGetTimeout(port, TIMEOUT_FOREVER);
}

static inline int UartPut(UartDriver* port, int value) {
  return UartPutTimeout(port, value, TIMEOUT_FOREVER);
}

static inline int UartWrite(UartDriver* port, const void* value, uint16_t size) {
  return UartWriteTimeout(port, value, size, TIMEOUT_FOREVER);
}

static inline int UartRead(UartDriver* port, void* dst, uint16_t max_size) {
  return UartReadTimeout(port, dst, max_size, TIMEOUT_FOREVER);
}

#endif // BUFFERED_UART_H_INCLUDED
