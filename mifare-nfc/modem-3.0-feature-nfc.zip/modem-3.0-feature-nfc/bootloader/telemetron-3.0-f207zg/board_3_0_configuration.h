/// \file board_3_0_configuration.h
/// \brief Определяет заводские настройки платы, хранимые вместе с загрузчиком

#ifndef BOARD_3_0_CONFIGURATION_H_INCLUDED
#define BOARD_3_0_CONFIGURATION_H_INCLUDED

#include <stdint.h>

#define BRD30_SIM_CARD_NONE             0

/// Идентификатор для SIM-карты, в разъеме SIM-карт
#define BRD30_SIM_CARD_EXTERNAL         1

/// Идентификатор для SIM-чипа
#define BRD30_SIM_CARD_INTERNAL         2

#define BRD22_SIM_CARDS_COUNT           2


enum SimPresence {
  BRD30_SIM_CARD_ABSENT = 0,
  BRD30_SIM_CARD_PRESENT = 1
};

typedef struct Board3v0Config {
  /// \brief Флаг наличия конкретной симкарты
  /// \note размер массива на 1 больше, чем реальное количество сим-карт.
  /// Это сделано для того, что бы можно было проверять состояние
  /// карты по её идентификатору (BRD30_SIM_CARD_EXTERNAL,
  /// BRD22_SIM_CARD_INTERNAL, и т.д.), которые начинают отсчёт не с нуля,
  /// а с единицы.
  /// Т.е. нулевой элемент данного массива соответствует BRD30_SIM_CARD_NONE,
  /// который не является сим-картой.
  uint8_t               sim_card_presence[BRD22_SIM_CARDS_COUNT + 1];
} Board3v0Config;


#endif // BOARD_3_0_CONFIGURATION_H_INCLUDED
