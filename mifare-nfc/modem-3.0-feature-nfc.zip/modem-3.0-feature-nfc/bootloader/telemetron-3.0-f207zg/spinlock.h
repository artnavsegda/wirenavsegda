/// \file
/// \brief  Реализация SpinLock для arm cortex m3,
///         работающая без блокировки прерываний.
/// \author DL <dmitriy@linikov.ru>


#ifndef ARM_CORTEX_M3_TOOLS_SPINLOCK_H_INCLUDED
#define ARM_CORTEX_M3_TOOLS_SPINLOCK_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <stdbool.h>
#include <stdint.h>
#include <core_cmInstr.h>
#include <timeout.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

#ifndef CONFIG_SPINLOCK_TRYLOCK_ITERATIONS
#define CONFIG_SPINLOCK_TRYLOCK_ITERATIONS        32
#endif

////////////////////////////////////////////////////////////////////////////
//  Типы данных

typedef struct {
  volatile uint8_t __lock;
} spinlock_t;



////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций


#if 0
Из статьи:
ARM Synchronization Primitives DHT0008A
Copyright © 2009 ARM. All rights reserved.


locked    EQU    1
unlocked  EQU  0
; lock_mutex
; Declare for use from C as extern void lock_mutex(void * mutex);
EXPORT lock_mutex

lock_mutex PROC
    LDR     r1, =locked
1   LDREX   r2,   [r0]
    CMP     r2, r1        ; Test if mutex is locked or unlocked
    BEQ     %f2           ; If locked - wait for it to be released, from 2
    STREXNE r2, r1, [r0]  ; Not locked, attempt to lock it
    CMPNE   r2, #1        ; Check if Store-Exclusive failed
    BEQ     %b1           ; Failed - retry from 1

    ; Lock acquired
    DMB                   ; Required before accessing protected resource
    BX      lr

2   ; Take appropriate action while waiting for mutex to become unlocked
    WAIT_FOR_UPDATE
    B       %b1           ; Retry from 1
    ENDP

; unlock_mutex
; Declare for use from C as extern void unlock_mutex(void * mutex);
EXPORT unlock_mutex
unlock_mutex PROC
    LDR     r1, =unlocked
    DMB                   ; Required before releasing protected resource
    STR     r1, [r0]      ; Unlock mutex
    SIGNAL_UPDATE
    BX      lr
    ENDP
#endif


/**
  \brief   STR Exclusive (8 bit)
  \details Executes a exclusive STR instruction for 8 bit values.
  \param [in]  value  Value to store
  \param [in]    ptr  Pointer to location
  \return          0  Function succeeded
  \return          1  Function failed
 */
__attribute__((always_inline)) static inline uint32_t ___STREXB(uint8_t value, volatile uint8_t *addr)
{
   uint32_t result;

   __ASM volatile ("strexb %0, %2, %1" : "=&r" (result), "=Q" (*addr) : "r" ((uint32_t)value) );
   return(result);
}

/**
  \brief   LDR Exclusive (8 bit)
  \details Executes a exclusive LDR instruction for 8 bit value.
  \param [in]    ptr  Pointer to data
  \return             value of type uint8_t at (*ptr)
 */
__attribute__((always_inline)) static inline uint8_t ___LDREXB(volatile uint8_t *addr)
{
    uint32_t result;

#if (__GNUC__ > 4) || (__GNUC__ == 4 && __GNUC_MINOR__ >= 8)
   __ASM volatile ("ldrexb %0, %1" : "=r" (result) : "Q" (*addr) );
#else
    /* Prior to GCC 4.8, "Q" will be expanded to [rx, #0] which is not
       accepted by assembler. So has to use following less efficient pattern.
    */
   __ASM volatile ("ldrexb %0, [%1]" : "=r" (result) : "r" (addr) : "memory" );
#endif
   return ((uint8_t) result);    /* Add explicit type cast here */
}



/// \brief  Попытка захватить spinlock, без ожидания и блокировки.
/// \return true в случае успеха
static inline bool spinlock_trylock(spinlock_t* spinlock)
{
  if (!spinlock) {
    return false;
  }

  for (unsigned i=CONFIG_SPINLOCK_TRYLOCK_ITERATIONS; i; --i) {
    uint8_t val = ___LDREXB(&spinlock->__lock);
    if (val) {
      // spinlock уже захвачен кем-то другим
      break;
    }
    if (___STREXB(1, &spinlock->__lock) != 0) {
      // Не удалось сохранить изменённое значение.
      // Уходим на ещё одну итерацию.
      continue;
    }

    // Успешно захватили spinlock
    __DMB();
    return true;
  } // for
  return false;
}

static inline bool spinlock_lock_timeout(spinlock_t* spinlock, timeout_t* timeout)
{
  for (;;) {
    if (spinlock_trylock(spinlock)) {
      return true;
    }
    if (timeout_is_elapsed(timeout)) {
      break;
    }
    __WFE();
  }
  return false;
}

static inline bool spinlock_lock(spinlock_t* spinlock, uint32_t waitticks)
{
  timeout_t timeout;
  timeout_start(&timeout, waitticks);
  return spinlock_lock_timeout(spinlock, &timeout);
}

static inline void spinlock_unlock(spinlock_t* spinlock)
{
  __DMB();
  spinlock->__lock = 0;
  __SEV();
}




#endif // ARM_CORTEX_M3_TOOLS_SPINLOCK_H_INCLUDED
