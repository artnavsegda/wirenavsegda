/// @file watchdog.h
/// @author DL <dmitriy.linikov@gmail.com>
/// @brief Функции для работы со сторожевым таймером.

#ifndef WATCHDOG_H_INCLUDED
#define WATCHDOG_H_INCLUDED

#ifndef STM8
#include <stdint.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

/// \brief На вход сторожевого таймера поступают тактовые импульсы от
#ifdef STM8
/// RC генератора LSI, частота STM8 которого - около 128/2=64кГц.
#define WATCHDOG_INPUT_CLOCK    64000
#else
/// RC генератора LSI, частота которого - около 40кГц.
#define WATCHDOG_INPUT_CLOCK    40000
#endif // STM8

#ifdef STM8
/// \brief Сторожевой таймер - 8 битный, максимальное значение 0xFF (255)
#define WATCHDOG_MAX_COUNT      (uint32_t)0xFF
#else
/// \brief Сторожевой таймер - 12 битный, максимальное значение 0xFFF (4095)
#define WATCHDOG_MAX_COUNT      0x0FFF
#endif // STM8

/// \brief Вычисляет максимальную длительность сторожевого таймера при
/// делителе входной частоты prescer
/// Максимальный случай STM8  - 1000*255*256/64000 = 65280000/64000 = 1020 мс.
/// Максимальный случай STM32 - 1000*4095*256/40000 = 1048320000/40000 = 26208 мс.
#define WATCHDOG_MAX_PERIOD_MS(prescaler)                                      \
    (uint32_t)(1000 * WATCHDOG_MAX_COUNT * (prescaler) / WATCHDOG_INPUT_CLOCK)

/// \brief Максимальное значение периода сторожевого таймера STM8  около 1 секунды.
/// \brief Максимальное значение периода сторожевого таймера STM32 около 26 секунд.
#define WATCHDOG_MAX_TIMEOUT_MS   WATCHDOG_MAX_PERIOD_MS(256)


/// \brief Настраивает сторожевой таймер (independent watchdog) на сброс
/// контроллера через \p timeout_ms миллисекунд, но не запускает его.
void watchdog_configure(uint32_t timeout_ms);

/// \brief Запускает сторожевой таймер. Будучи запущенным, его уже не остановить
/// до очередного сброса микроконтроллера.
void watchdog_start(void);

/// \brief Сбрасывает сторожевой таймер обратного отсчёта к настроенному
/// значению что бы предотвратить перезагрузку микроконтроллера.
void watchdog_reset(void);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // WATCHDOG_H_INCLUDED
