/// @file
/// @author DL <dmitriy.linikov@gmail.com>

#include "board_3_0.h"
#include <system_stm32f2xx.h>

#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <ccan/array_size/array_size.h>
#include <timeout.h>
#include <spinlock.h>

#define STM32F2XX_GPIO_IMPLEMENT_PINS
// Реализация всех GPIO выводов.
#include "all_gpio_pins.h"
#undef STM32F2XX_GPIO_IMPLEMENT_PINS

#include "sysutils/crc.h"
#include "dbg.h"
#include "buffered_uart.h"
#include "vfs.h"

#ifdef __GNUC__
#define STATIC_ASSERT(__cond, __msg) _Static_assert(__cond, #__msg)
#else
#define STATIC_ASSERT(__cond, __msg) char static_assertion_##__msg[2*(!!(__cond))-1]
#endif


////////////////////////////////////////////////////////////////////////////
//  Работа с GPIO каналами микроконтроллера
// -------------------------------------------------------------------------

void GpioInit()
{
  RCC_AHB1PeriphClockCmd( 0
                          | RCC_AHB1Periph_GPIOA
                          | RCC_AHB1Periph_GPIOB
                          | RCC_AHB1Periph_GPIOC
                          | RCC_AHB1Periph_GPIOD
                          | RCC_AHB1Periph_GPIOE
                          | RCC_AHB1Periph_GPIOF
                          | RCC_AHB1Periph_GPIOG
                          | RCC_AHB1Periph_GPIOH
                          | RCC_AHB1Periph_GPIOI,

                          ENABLE);
}

void GpioDeinit()
{
  RCC_AHB1PeriphClockCmd( 0
                          | RCC_AHB1Periph_GPIOA
                          | RCC_AHB1Periph_GPIOB
                          | RCC_AHB1Periph_GPIOC
                          | RCC_AHB1Periph_GPIOD
                          | RCC_AHB1Periph_GPIOE
                          | RCC_AHB1Periph_GPIOF
                          | RCC_AHB1Periph_GPIOG
                          | RCC_AHB1Periph_GPIOH
                          | RCC_AHB1Periph_GPIOI,

                          DISABLE);
}




////////////////////////////////////////////////////////////////////////////
//  Реализация пищалки
// -------------------------------------------------------------------------
//      Для загрузчика платы Modem 3.0 не реализовано. Использованы заглушки

void BuzzerInit(void)
{
  GpioConfigArgs(BUZZER, GPIO_MODE_ANALOG, 0, 0);
}

void BuzzerDeinit(void)
{
  GpioConfigArgs(BUZZER, GPIO_MODE_ANALOG, 0, 0);
}

void BoardBuzzerOn(void)
{
  // не реализовано
}

void BoardBuzzerOff(void)
{
  // не реализовано
}




////////////////////////////////////////////////////////////////////////////
//  Реализация светодиодов
// -------------------------------------------------------------------------
//      Для загрузчика платы Modem 3.0 не реализовано. Использованы заглушки

const Led LedPower = {
  .red_channel    = NULL,
  .green_channel  = NULL
};

const Led LedGsm = {
  .red_channel    = NULL,
  .green_channel  = NULL
};

const Led LedServer = {
  .red_channel    = NULL,
  .green_channel  = NULL
};

const Led LedDex = {
  .red_channel    = NULL,
  .green_channel  = NULL
};

const Led LedMdbExe = {
  .red_channel    = NULL,
  .green_channel  = NULL
};

void LedsInit()
{
}

void LedsDeinit()
{
}




////////////////////////////////////////////////////////////////////////////
//  Реализация кнопок
// -------------------------------------------------------------------------
//      Для загрузчика платы Modem 3.0 не реализовано. Использованы заглушки

static bool PushbuttonReadDefault(Pushbutton* button);

#define DEFINE_PUSHBUTTON(gpio_channel_ptr) DEFINE_PUSHBUTTON_EX((gpio_channel_ptr), &PushbuttonReadDefault)

Pushbutton  BtnReset = DEFINE_PUSHBUTTON(BTN0);
Pushbutton  Btn1 = DEFINE_PUSHBUTTON_EX(NULL, NULL);
Pushbutton  Btn2 = DEFINE_PUSHBUTTON_EX(NULL, NULL);
Pushbutton  Btn3 = DEFINE_PUSHBUTTON_EX(NULL, NULL);

static bool PushbuttonReadDefault(Pushbutton* button)
{
  if (!button || !button->channel) {
    return false;
  }
  const GpioChannel* channel = (const GpioChannel*)button->channel;
  return GpioRead(channel);
}

void ButtonsInit()
{
  GpioConfigArgs(BTN0, GPIO_MODE_IN_FLOAT, 0, 1);
  // Кнопки BTN1-BTN3 - не реализованы.
}

void ButtonsDeinit()
{
  // Кнопки в отключенном состоянии ведут себя так же, как и во включенном.
  // Ещё раз вызываем ButtonsInit() на случай, если в процессе работы были
  // отключены подтяжки
  ButtonsInit();
}

////////////////////////////////////////////////////////////////////////////
//  Работа с энергонезависимой памятью RTC микроконтроллера
// -------------------------------------------------------------------------

#define RTC_FLAG_ALL    \
  ( RTC_FLAG_TSOVF    | \
    RTC_FLAG_TAMP1F   | \
    RTC_FLAG_TSF      | \
    RTC_FLAG_WUTF     | \
    RTC_FLAG_ALRBF    | \
    RTC_FLAG_ALRAF    | \
    RTC_FLAG_INITF    | \
    RTC_FLAG_RSF      | \
    RTC_FLAG_INITS    | \
    RTC_FLAG_WUTWF    | \
    RTC_FLAG_ALRBWF   | \
    RTC_FLAG_ALRAWF   )


void InitBackupSram()
{
  /* Enable PWR and BKP clock */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_AHB1Periph_BKPSRAM, ENABLE);

  /* Enable write access to Backup domain */
  PWR_BackupAccessCmd(ENABLE);

  /* Clear Tamper pin Event(TE) pending flag */
  RTC_ClearFlag(RTC_FLAG_ALL);

  /* Check if the Power On Reset flag is set */
  if(RCC_GetFlagStatus(RCC_FLAG_PORRST) != RESET)
  {
    /* Clear reset flags */
    RCC_ClearFlag();
  }
}

uint32_t ReadBackupRegister(unsigned reg)
{
  return RTC_ReadBackupRegister(reg);
}

void     WriteBackupRegister(unsigned reg, uint32_t value)
{
  RTC_WriteBackupRegister(reg, value);
}





////////////////////////////////////////////////////////////////////////////
//  Перевод микроконтроллера в энергосберегающие режимы и перезагрузка
// -------------------------------------------------------------------------

void BoardShutdown(bool reset)
{
  __disable_irq();
  // Сбрасываем флажки событий
  EXTI->PR=0x000FFFFF;
  RTC_ClearFlag(RTC_FLAG_ALL);

  // Просьба программной перезагрузки
  if (reset)
  {
    SCB->AIRCR=0x05FA0004;
  }
  for(;;) {PWR_EnterSTOPMode(PWR_Regulator_ON,PWR_STOPEntry_WFI);}
}

void BoardStandby(void)
{
  while(1) {
    PWR_EnterSTANDBYMode();
  }
}

void WaitForEvent()
{
  // Процессор один - используем ожидание прерываний.
  __WFI();
}




////////////////////////////////////////////////////////////////////////////
//  Реализация АЦП каналов
// -------------------------------------------------------------------------
//      Для загрузчика платы Modem 3.0 не реализовано. Использованы заглушки
//      Что бы реализовать, требуется I2C драйвер для ADC081C02x

uint32_t ReadSupplyMillivolts(void)
{
  return 24000;
}

/// Читает текущее значение температуры в градусах цельсия
int32_t ReadCoreTemperature(void)
{
  return 25;
}


void AdcInit()
{
  // Не реализовано
}

void AdcDeinit()
{
  // Не реализовано
}



////////////////////////////////////////////////////////////////////////////
//  Работа с таймерами
// -------------------------------------------------------------------------

// Проверяет и устанавливает частоту работы таймера
bool Time_set_freq(TIM_TypeDef * TIM, uint32_t apbclock, float freq)
{
  dbg_assert((freq>=(apbclock/4294967295.0)), "ERROR: TIM freq is very low. Change APB freq");
  if (freq<(apbclock/4294967295.0))
  {
  //Частота очень низкая и недопустиимая, требуется перестройка apbclock
    log_error("Freq very low. TIM [0x%X]", TIM);
    return(0);
  }
  if ((apbclock/freq)<(0xFFFFl))
  {// Частота высокая
    TIM->PSC = 0;
    TIM->ARR = (apbclock/freq) - 1;
  }
  else
  {// Частота низкая
    if (((apbclock/1000l)/freq)>0xFFFFul)
    {
        if (((apbclock/10000l)/freq)>0xFFFFul)
        {
            TIM->PSC = ((apbclock/65536.0)/freq) - 1;
            TIM->ARR = 0x10000l-1;
        }
        else
        {
            TIM->PSC = ((apbclock/10000.0)/freq) - 1;
            TIM->ARR = 10000-1;
        }
    }
    else
    {
        TIM->PSC = ((apbclock/1000.0)/freq) - 1;
        TIM->ARR = 1000-1;
    }
  }
  //int32_t freq_u=(int32_t)(freq*100000.0);
  //log_info("TIM[0x%X]-> ARR[0x%X], PSC[0x%X], apbclock %d, freq %d", TIM, TIM->ARR, TIM->PSC, apbclock, freq_u);
  return(1);
}

void TimersInit()
{
  //  Вариант для обычного кварца на 8МГц.
  uint32_t TIMclock=GET_APB1_CLOCK();
  if (TIMclock<=(SystemCoreClock/2)) TIMclock=GET_APB1_CLOCK()*2;
  // 1 раз в 60 секунд
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);
  Time_set_freq(TIM5, TIMclock, TIM5_freq);
  //TIM5->PSC = 32000 - 1;
  //TIM5->ARR = 45000 - 1;
  TIM5->DIER |= TIM_DIER_UIE;
  TIM5->CR1 = TIM_CR1_CEN | TIM_CR1_ARPE;
  NVIC_SetPriority(TIM5_IRQn, MINUTE_TIMER_PRIORITY);

  // 10 Гц
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);
  Time_set_freq(TIM6, TIMclock, TIM6_freq);
  //TIM6->PSC = 999;
  //TIM6->ARR = 2399;
  TIM6->DIER |= TIM_DIER_UIE;
  TIM6->CR1 = TIM_CR1_CEN | TIM_CR1_ARPE;
#if defined(STM32F10X_HD_VL) || defined(STM32F2XX)
  NVIC_SetPriority(TIM6_DAC_IRQn, SERVICE_TIMER_PRIORITY);
  NVIC_EnableIRQ(TIM6_DAC_IRQn);
#else
  NVIC_SetPriority(TIM6_IRQn, SERVICE_TIMER_PRIORITY);
  NVIC_EnableIRQ(TIM6_IRQn);
#endif // #if defined(STM32F10X_HD_VL) || defined(STM32F2XX)


  // 1кГц
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, ENABLE);
  Time_set_freq(TIM7, TIMclock, TIM7_freq);
  //TIM7->PSC = 100 - 1;
  //TIM7->ARR = 240 - 1;
  TIM7->DIER |= TIM_DIER_UIE;
  TIM7->CR1 = TIM_CR1_CEN | TIM_CR1_ARPE;
  NVIC_SetPriority(TIM7_IRQn, SYSTEM_TIMER_PRIORITY);
  NVIC_EnableIRQ(TIM7_IRQn);
}

void TimersDeinit()
{
  NVIC_DisableIRQ(TIM7_IRQn);
  TIM7->CR1 = 0;
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, DISABLE);


#if defined(STM32F10X_HD_VL) || defined(STM32F2XX)
  NVIC_DisableIRQ(TIM6_DAC_IRQn);
#else
  NVIC_DisableIRQ(TIM6_IRQn);
#endif
  TIM6->CR1 = 0;
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, DISABLE);

  NVIC_DisableIRQ(TIM5_IRQn);
  TIM5->CR1 = 0;
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, DISABLE);
}





////////////////////////////////////////////////////////////////////////////
//  Работа с шиной I2C
// -------------------------------------------------------------------------

#ifndef CONFIG_BOARD_I2C_SPEED
#define CONFIG_BOARD_I2C_SPEED    100000
#endif

#define I2C_EVENT_BIT_NAK         0x00000400

static spinlock_t   i2c_lock;

typedef enum {
  I2C_TRANSMIT  = I2C_Direction_Transmitter,
  I2C_RECEIVE   = I2C_Direction_Receiver
} i2c_dir_t;

void BoardI2CInit(void)
{
  I2C_InitTypeDef  config;

  GpioConfigArgs(I2C3_SCL, GPIO_MODE_ALT_OPENDRAIN, I2C3_GPIO_AF, 1);
  GpioConfigArgs(I2C3_SDA, GPIO_MODE_ALT_OPENDRAIN, I2C3_GPIO_AF, 1);

  RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C3, ENABLE);

  config.I2C_Mode                 = I2C_Mode_I2C;
  config.I2C_DutyCycle            = I2C_DutyCycle_2;
  config.I2C_OwnAddress1          = 0x00;
  config.I2C_Ack                  = I2C_Ack_Enable;
  config.I2C_AcknowledgedAddress  = I2C_AcknowledgedAddress_7bit;
  config.I2C_ClockSpeed           = CONFIG_BOARD_I2C_SPEED;

  I2C_Cmd(I2C3, ENABLE);

  /* Apply configuration after enabling it */
  I2C_Init(I2C3, &config);


}

void BoardI2CDeinit(void)
{
  I2C_Cmd(I2C3, DISABLE);
  I2C_DeInit(I2C3);

  /*!< sEE_I2C Periph clock disable */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C3, DISABLE);

  GpioConfigArgs(I2C3_SCL, GPIO_MODE_IN_FLOAT,      0,            0);
  GpioConfigArgs(I2C3_SDA, GPIO_MODE_IN_FLOAT,      0,            0);
}

bool BoardI2CLock(uint32_t timeout_ms)
{
  if (!spinlock_lock(&i2c_lock, timeout_ms)) {
    return false;
  }
  BoardI2CDeinit();
  delay_ms(1);
  BoardI2CInit();
  return true;
}

bool BoardI2CLockTimeout(timeout_t* timeout)
{
  if (!spinlock_lock_timeout(&i2c_lock, timeout)) {
    return false;
  }
  BoardI2CDeinit();
  delay_ms(1);
  BoardI2CInit();
  return true;
}

void BoardI2CUnlock(void) {
  BoardI2CDeinit();
  spinlock_unlock(&i2c_lock);
}

#define BOARD_I2C_START_OR_RESTART_START    false
#define BOARD_I2C_START_OR_RESTART_RESTART  true
int BoardI2CStartOrRestart(uint8_t slave_addr, i2c_dir_t dir, timeout_t* timeout, bool restart)
{
  if (!restart) {
    // На всякий слуыай ждем, пока шина осовободится
    while(I2C_GetFlagStatus(I2C3, I2C_FLAG_BUSY)) {
      if (timeout_is_elapsed(timeout)) {
        return -EBUSY;
      }
    }
  }

  // Принудительная пауза перед стартом.
  delay_ms(2);

  // Генерируем старт - тут все понятно )
  I2C_GenerateSTART(I2C3, ENABLE);

  // Ждем пока взлетит нужный флаг
  while (!I2C_CheckEvent(I2C3, I2C_EVENT_MASTER_MODE_SELECT)) {
    if (timeout_is_elapsed(timeout)) {
      // Не дождались ответа.
      // Скорее всего придётся сбрасывать шину, поэтому EBUSY, а не ETIMEDOUT.
      return -EBUSY;
    }
  }

  // Посылаем адрес подчиненному
  uint8_t   direction = (uint8_t)dir;
  uint32_t  event     = dir == I2C_TRANSMIT
                        ? I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED
                        : I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED;

  I2C_Send7bitAddress(I2C3, slave_addr << 1, direction);

  for (;;) {
    uint32_t e = I2C_GetLastEvent(I2C3);
    if ((e & event) == event) {
      // Слейв подтвердил своё присутствие на шине.
      break;
    }

    if ((e & I2C_EVENT_BIT_NAK) == I2C_EVENT_BIT_NAK) {
      // Нет такого слейва на шине
      return -ENODEV;
    }

    if (timeout_is_elapsed(timeout)) {
      // Не дождались ответа.
      // Скорее всего придётся сбрасывать шину, поэтому EBUSY, а не ETIMEDOUT.
      return -EBUSY;
    }
  }


  return 0;
}

int BoardI2CStart(uint8_t slave_addr, i2c_dir_t dir, timeout_t* timeout)
{
  return BoardI2CStartOrRestart(slave_addr, dir, timeout, BOARD_I2C_START_OR_RESTART_START);
}

int BoardI2CRestart(uint8_t slave_addr, i2c_dir_t dir, timeout_t* timeout)
{
  return BoardI2CStartOrRestart(slave_addr, dir, timeout, BOARD_I2C_START_OR_RESTART_RESTART);
}

int BoardI2CStop(timeout_t* timeout)
{
  I2C_GenerateSTOP(I2C3, ENABLE);
  while (!timeout_is_elapsed(timeout)) {
    if (!(I2C_ReadRegister(I2C3, I2C_Register_CR1) & I2C_CR1_STOP)) {
      delay_ms(1);
      return 0;
    }
  }
  log_trace("%s: Timed out", __FUNCTION__);
  return -ETIMEDOUT;
}

bool BoardI2CSoftReset(void)
{
  unsigned int  clock_count;
  unsigned int  stretch_count;

  // if (!I2C_GetFlagStatus(I2C3, I2C_FLAG_BUSY)) {
  //   return true;
  // }
  log_trace("%s", __FUNCTION__);
  I2C_SoftwareResetCmd(I2C3, ENABLE);
  delay_ms(2);
  BoardI2CDeinit();

  GpioConfigArgs(I2C3_SCL, GPIO_MODE_OUT_OPENDRAIN,      0,            0);
  GpioConfigArgs(I2C3_SDA, GPIO_MODE_OUT_OPENDRAIN,      0,            1);

  clock_count = 0;
  while (!GpioRead(I2C3_SDA)) {
    if (clock_count++ > 10) {
      // Если за адекватное количество тактов не поличилось сбросить шину,
      // то выходим
      log_trace("%s: SDA stuck", __FUNCTION__);
      return false;
    }

    // Проверка, что завершилось "растягивание" тактовых импульсов
    // ведомым устройством
    stretch_count = 0;
    while (!GpioRead(I2C3_SCL)) {
      if (stretch_count++ > 10) {
        // За адекватное время слейв не отпустил линию SCL
        log_trace("%s: SCL stuck", __FUNCTION__);
        return false;
      }

      delay_ms(2);  // порядка 10-30 мкс
    } // while (!GpioRead(I2C3_SCL)) ...

    // Выводим такт SCL
    GpioWrite(I2C3_SCL, 0);   delay_ms(2);
    GpioWrite(I2C3_SCL, 1);   delay_ms(2);
  } // while (!GpioRead(I2C3_SDA))...

  // Слейв отпустил SDA и SCL. Отправим в шину START и STOP
  GpioWrite(I2C3_SDA, 0);     delay_ms(2);
  GpioWrite(I2C3_SCL, 0);     delay_ms(2);
  GpioWrite(I2C3_SCL, 1);     delay_ms(2);
  GpioWrite(I2C3_SDA, 1);     delay_ms(2);

  // Повторная инициализация I2C
  log_trace("%s: done", __FUNCTION__);
  BoardI2CInit();
  I2C_SoftwareResetCmd(I2C3, DISABLE);
  return true;
}

int BoardI2CWrite(const void* buf, size_t size, timeout_t* timeout)
{
  const uint8_t*  data  = (const uint8_t*)buf;
  int         nsent = 0;
  while (nsent != (int)size) {
    I2C_SendData(I2C3, *data);
    for(;;) {
      uint32_t e = I2C_GetLastEvent(I2C3);
      if (e == I2C_EVENT_MASTER_BYTE_TRANSMITTED) {
        break;
      }


      if ((e & I2C_EVENT_BIT_NAK) == I2C_EVENT_BIT_NAK) {
        log_trace(
          "%s: NAK received. size=%d, n=%d",
          __FUNCTION__,
          size,
          nsent
        );
        // Если делать в стиле posix, то тут следует возвращать ошибку
        // только если не передано ни одного байта
        return -EIO;
      }

      if (timeout_is_elapsed(timeout)) {
        log_trace(
          "%s: timeout. size=%d, n=%d",
          __FUNCTION__,
          size,
          nsent
        );
        // Если делать в стиле posix, то тут следует возвращать ошибку
        // только если не передано ни одного байта
        return -ETIMEDOUT;
      }
    } // for(;;)
    ++data;
    ++nsent;
  } // while (nsent != ...)
  return nsent;
}

int BoardI2CRead(void* buf, size_t size, timeout_t* timeout)
{
  uint8_t*  data  = (uint8_t*)buf;
  int       nread = 0;
  while (nread != (int)size) {
    if (nread == (int)size-1) {
      I2C_AcknowledgeConfig(I2C3, DISABLE);
    } else {
      I2C_AcknowledgeConfig(I2C3, ENABLE);
    }

    while( !I2C_CheckEvent(I2C3, I2C_EVENT_MASTER_BYTE_RECEIVED) ) {
      if (timeout_is_elapsed(timeout)) {
        // Если делать в стиле posix, то тут следует возвращать ошибку
        // только если не получено ни одного байта
        log_trace(
          "%s: timeout. size=%d, n=%d",
          __FUNCTION__,
          size,
          nread
        );

        return -ETIMEDOUT;
      }
    }

    *data = I2C_ReceiveData(I2C3);
    ++data;
    ++nread;
  }
  return nread;
}

int I2C_Tx(uint8_t addr, const void* regid, size_t regid_size, const void* data, size_t data_size, uint32_t timeout_ms)
{
  int       ret;
  bool      started = false;
  timeout_t timeout;

  if (!regid) {
    regid_size = 0;
  }

  if (!data) {
    data_size = 0;
  }

  if (!regid_size && !data_size) {
    return -EINVAL;
  }

  timeout_start(&timeout, timeout_ms);

  if (!BoardI2CLockTimeout(&timeout)) {
    return -EACCES;
  }

  if (regid_size) {
    ret = BoardI2CStart(addr, I2C_TRANSMIT, &timeout);
    if (ret < 0) {
      goto cleanup;
    }
    started = true;

    ret = BoardI2CWrite(regid, regid_size, &timeout);
    if (ret < 0) {
      goto cleanup;
    }

  }

  if (data_size) {
    if (!started) {
      ret = BoardI2CStart(addr, I2C_TRANSMIT, &timeout);
      if (ret < 0) {
        goto cleanup;
      }
      started = true;
    }

    ret = BoardI2CWrite(data, data_size, &timeout);
    if (ret < 0) {
      goto cleanup;
    }
  }

  if (started) {
    ret = BoardI2CStop(&timeout);
    if (ret < 0) {
      goto cleanup;
    }
    started = false;
  }

  ret = data_size;

cleanup:
  if (ret < 0) {
    log_warn("Can't tx to i2c @0x%02X, ret=%d", addr, ret);
    BoardI2CSoftReset();
  }
  BoardI2CUnlock();
  return ret;
}

int I2C_Rx(uint8_t addr, const void* regid, size_t regid_size, void* data, size_t data_size, uint32_t timeout_ms)
{
  int       ret;
  bool      started = false;
  timeout_t timeout;

  if (!regid) {
    regid_size = 0;
  }

  if (!data) {
    data_size = 0;
  }

  if (!regid_size && !data_size) {
    return -EINVAL;
  }

  timeout_start(&timeout, timeout_ms);

  if (!BoardI2CLockTimeout(&timeout)) {
    return -EACCES;
  }


  if (regid_size) {
    ret = BoardI2CStart(addr, I2C_TRANSMIT, &timeout);
    if (ret < 0) {
      goto cleanup;
    }
    started = true;

    ret = BoardI2CWrite(regid, regid_size, &timeout);
    if (ret < 0) {
      goto cleanup;
    }

  }

  if (data_size) {
    if (!started) {
      ret = BoardI2CStart(addr, I2C_RECEIVE, &timeout);
    } else {
      ret = BoardI2CRestart(addr, I2C_RECEIVE, &timeout);
    }

    if (ret < 0) {
      goto cleanup;
    }
    started = true;

    ret = BoardI2CRead(data, data_size, &timeout);
    if (ret < 0) {
      goto cleanup;
    }
  }

  if (started) {
    ret = BoardI2CStop(&timeout);
    if (ret < 0) {
      goto cleanup;
    }
    started = false;
  }

  ret = data_size;

cleanup:
  if (ret < 0) {
    log_warn("Can't rx from i2c @0x%02X, ret=%d", addr, ret);
    BoardI2CSoftReset();
  }
  BoardI2CUnlock();
  return ret;
}



////////////////////////////////////////////////////////////////////////////
//  Зарядное устройство
// -------------------------------------------------------------------------
// Его необходимо проинициализировать, т.к. при стандартной работе оно
// ограничивает входной ток.

#define I2CADDR_MAIN_CHARGER  0x6B    ///< Адрес зарядного устройства

static int bq2429x_putreg8(uint8_t reg, uint8_t value)
{
  return I2C_Tx(I2CADDR_MAIN_CHARGER, &reg, 1, &value, 1, 100);
}

int ChargerInit(void)
{
  // Из лога инициализации микросхемы заряда в основной прошивке:
  //
  // [1522034790.169000]bq2429x_putreg8: addr: 01 regval: 000000bb
  // [1522034790.172000]bq2429x_putreg8: addr: 05 regval: 0000008c
  // [1522034790.173000]bq2429x_putreg8: addr: 00 regval: 0000005c
  // [1522034790.175000]bq2429x_en_stat: int stat: REG07 4B INT_MASK1=1 INT_MASK0=1
  // [1522034790.176000]bq2429x_putreg8: addr: 07 regval: 00000048
  // [1522034790.178000]bq2429x_putreg8: addr: 04 regval: 0000007e

  int ret;
  int lasterror = 0;

#define CHK_BQ(op)     do if ((ret = (op)) < 0) { lasterror = ret; } while(0)

  CHK_BQ(bq2429x_putreg8(0x01, 0xbb));
  CHK_BQ(bq2429x_putreg8(0x05, 0x8c));
  CHK_BQ(bq2429x_putreg8(0x00, 0x5c));
  CHK_BQ(bq2429x_putreg8(0x07, 0x48));
  CHK_BQ(bq2429x_putreg8(0x04, 0x7e));

#undef CHK_BQ

  return lasterror;
}




////////////////////////////////////////////////////////////////////////////
//  Отладочный вывод
// -------------------------------------------------------------------------

#define AUX3_ADDR     0x23    ///< I2C адрес DD24

static volatile uint8_t debug_port_enable = false;

/// \brief Заглушка для включения вывода отладочного порта через AUX3
/// в режиме TTL порта
int DebugPortSetAuxTtl()
{
  uint8_t   auxmode = 0x07;

  return I2C_Tx(AUX3_ADDR, NULL, 0, &auxmode, 1, 100);
}


void DebugPortInit()
{
  if (debug_port_enable)
  {
    GpioConfigArgs(AUX3_TX,   GPIO_MODE_ALT_PUSHPULL, AUX3_GPIO_AF, 1);
    GpioConfigArgs(AUX3_RX,   GPIO_MODE_ALT,          AUX3_GPIO_AF, 1);
    GpioConfigArgs(AUX3_RTS,  GPIO_MODE_OUT_PUSHPULL, 0,            1);

    UartInit(AUX3_PORT, 921600, USART_CR1_TE, 0, 0, DEBUG_PORT_PRIORITY);
    DebugPortSetAuxTtl();

    dbg_set_port(AUX3_PORT);

    log_trace("Started logging.");
    return;
  }

  // отключаем вывод отладочной информации в порт
  DebugPortDeinit();
}

void DebugPortDeinit()
{
  dbg_set_port(NULL);
  UartDeinit(AUX3_PORT);
}





////////////////////////////////////////////////////////////////////////////
//  GSM Модуль (Sim800/Sim900)
// -------------------------------------------------------------------------

// Пустой обработчик для случая, когда прользовательская программа не предоставляет
// своего собственного обработчика.
__attribute__((weak)) void OnModemPortInterrupt(void)
{

}

void SIM_PORT_IRQ_HANDLER()
{
  OnModemPortInterrupt();
}

  // На плате 3.0 нет управления симкартами
void SimCardSwitchInit()              {}
void SimCardSwitchDeinit()            {}
void SimCardSwitchDeselect()          {}
void SimCardSwitchSelect(int card_id) { (void)card_id; }

bool SimCardPresent(int card_id)
{
  if (card_id == SIM_CARD_INTERNAL1
  ||  card_id == SIM_CARD_EXTERNAL1
  ) {
    return true;
  }

  return false;
}

bool SimCardInserted(int card_id)
{
  if (!SimCardPresent(card_id)) {
    return false;
  }

  // if (card_id == BRD22_SIM_CARD_EXTERNAL1) {
  //   return GpioRead(SIM_CARD_DETECT) == SIM_CARD_DETECT_INSERTED;
  // }
  return true;
}

void SimPortStartArgs(uint32_t baudrate, uint32_t cr1, uint32_t cr2, uint32_t cr3)
{
  GpioConfigArgs(SIM_TX,        GPIO_MODE_ALT,          SIM_GPIO_AF,  0);
  GpioConfigArgs(SIM_RX,        GPIO_MODE_ALT,          SIM_GPIO_AF,  0);
  uart_init(SIM_PORT, baudrate, cr1, cr2, cr3);
  NVIC_SetPriority(SIM_PORT_IRQN, SIM_PORT_PRIORITY);
  NVIC_EnableIRQ(SIM_PORT_IRQN);
}

void SimPortStart()
{
  SimPortStartArgs(115200, USART_CR1_RE | USART_CR1_TE | USART_CR1_RXNEIE, 0, 0);
}

void SimPortStop()
{
  NVIC_DisableIRQ(SIM_PORT_IRQN);
  uart_deinit(SIM_PORT);
  GpioConfigArgs(SIM_TX,        GPIO_MODE_IN_PULLDOWN,  0,            0);
  GpioConfigArgs(SIM_RX,        GPIO_MODE_IN_PULLDOWN,  0,            0);
}

void SimPortInit()
{
  // GpioConfigArgs(SIM_TX,        GPIO_MODE_ALT,          SIM_GPIO_AF,  0);
  // GpioConfigArgs(SIM_RX,        GPIO_MODE_ALT,          SIM_GPIO_AF,  0);
  GpioConfigArgs(SIM_TX,        GPIO_MODE_IN_PULLDOWN,  0,            0);
  GpioConfigArgs(SIM_RX,        GPIO_MODE_IN_PULLDOWN,  0,            0);
  GpioConfigArgs(SIM_POWER_EN,  GPIO_MODE_OUT_PUSHPULL, 0,            0);
  GpioConfigArgs(SIM_RI,        GPIO_MODE_IN_PULLDOWN,  0,            0);
  GpioConfigArgs(SIM_PWRKEY,    GPIO_MODE_OUT_PUSHPULL, 0,            0);
  GpioConfigArgs(SIM_STATUS,    GPIO_MODE_IN_FLOAT,     0,            0);
}

void SimPortDeinit(bool full)
{
  SimPortStop();
  SimCardSwitchDeselect();
  GpioConfigArgs(SIM_RI,        GPIO_MODE_IN_PULLDOWN,  0,            0);
  if (full)
  {
    GpioConfigArgs(SIM_POWER_EN,  GPIO_MODE_IN_PULLDOWN,  0,            0);
    GpioConfigArgs(SIM_PWRKEY,    GPIO_MODE_IN_PULLDOWN,  0,            0);
    GpioConfigArgs(SIM_STATUS,    GPIO_MODE_IN_PULLDOWN,  0,            0);
  }
}





////////////////////////////////////////////////////////////////////////////
//  Работа с EEPROM AT24C64
// -------------------------------------------------------------------------

#define CONFIG_BOARD_AT24_TIMEOUT_MS          500
#define AT24C64_ADDR                          0x53
#define AT24C64_PAGESIZE                      32

int AT24C64Read(uint32_t address, void* buf, size_t bufsize)
{
  int     ret;
  timeout_t   timeout;
  uint8_t     address_bytes[2] = {
    (address & 0xFF00) >> 8,
    (address & 0xFF)
  };

  timeout_start(&timeout, CONFIG_BOARD_AT24_TIMEOUT_MS);

  if (!BoardI2CLockTimeout(&timeout)) {
    log_trace("AT24R: Can't lock");
    return -EACCES;
  }

  ret = BoardI2CStart(AT24C64_ADDR, I2C_TRANSMIT, &timeout);
  if (ret < 0) {
    log_trace("AT24R: Can't start");
    goto cleanup;
  }

  ret = BoardI2CWrite(address_bytes, 2, &timeout);
  if (ret < 0) {
    log_trace("AT24R: Can't write");
    goto cleanup;
  }

  ret = BoardI2CRestart(AT24C64_ADDR, I2C_RECEIVE, &timeout);
  if (ret < 0) {
    log_trace("AT24R: Can't restart");
    goto cleanup;
  }

  ret = BoardI2CRead(buf, bufsize, &timeout);
  if (ret < 0) {
    log_trace("AT24R: Can't read");
    goto cleanup;
  }

  // Успешно прочитано
  ret = BoardI2CStop(&timeout);
  if (ret < 0) {
    log_trace("AT24R: Can't stop");
    goto cleanup;
  }

  ret = (int)bufsize;

cleanup:
  if (ret < 0) {
    BoardI2CSoftReset();
  }
  BoardI2CUnlock();
  return ret;
}

int AT24C64Wait(timeout_t* timeout)
{
  int ret;

  while (!timeout_is_elapsed(timeout)) {

    if (!BoardI2CLockTimeout(timeout)) {
      return -EACCES;
    }
    {
      ret = BoardI2CStart(AT24C64_ADDR, I2C_TRANSMIT, timeout);
      if (ret < 0 && ret != -ENODEV) {
        BoardI2CSoftReset();
      } else {
        BoardI2CStop(timeout);
      }
    }
    delay_ms(1);
    BoardI2CUnlock();

    if (ret == 0) {
      // Устройство ответило
      return 0;
    }

    delay_ms(1);
    continue;
  }

  return -ETIMEDOUT;
}

int AT24C64WritePage(uint32_t address, const void* buf, size_t size)
{
  int     ret;
  timeout_t   timeout;
  bool        locked = false;
  uint8_t     address_bytes[2] = {
    (address & 0xFF00) >> 8,
    (address & 0xFF)
  };

  timeout_start(&timeout, CONFIG_BOARD_AT24_TIMEOUT_MS);

  if (!BoardI2CLockTimeout(&timeout)) {
    log_trace("AT24:Can't lock I2C");
    return -EACCES;
  }
  locked = true;

  ret = BoardI2CStart(AT24C64_ADDR, I2C_TRANSMIT, &timeout);
  if (ret < 0) {
    log_trace("AT24:Can't start I2C, e=%d", ret);
    goto cleanup;
  }

  ret = BoardI2CWrite(address_bytes, 2, &timeout);
  if (ret < 0) {
    log_trace("AT24:Can't write mem addr, e=%d", ret);
    goto cleanup;
  }

  ret = BoardI2CWrite(buf, size, &timeout);
  if (ret < 0) {
    log_trace("AT24:Can't write page data, e=%d", ret);
    goto cleanup;
  }

  // Успешно прочитано
  ret = BoardI2CStop(&timeout);
  if (ret < 0) {
    log_trace("AT24:Can't stop I2C, e=%d", ret);
    goto cleanup;
  }

  BoardI2CUnlock();
  locked = false;

  ret = AT24C64Wait(&timeout);
  if (ret < 0) {
    log_trace("AT24: Can't wait wr complete, e=%d", ret);
    goto cleanup;
  }

  ret = (int)size;

cleanup:
  if (ret < 0) {
    BoardI2CSoftReset();
    log_trace("AT24: SoftReset done");
  }
  if (locked) {
    BoardI2CUnlock();
  }
  return ret;

}

int AT24C64Write(uint32_t address, const void* buf, size_t size)
{
  int         ret;
  size_t          ntotal  = size;
  const uint8_t*  data    = (const uint8_t*)buf;

  while (ntotal) {
    uint32_t page_byte  = address % AT24C64_PAGESIZE;
    uint32_t nbytes     = AT24C64_PAGESIZE - page_byte;
    if (nbytes > ntotal) {
      nbytes = ntotal;
    }

    ret = AT24C64WritePage(address, data, nbytes);
    if (ret < 0) {
      return ret;
    }

    data      += nbytes;
    address   += nbytes;
    ntotal    -= nbytes;
  }
  return size;
}



////////////////////////////////////////////////////////////////////////////
//  Загрузка настроек платы
// -------------------------------------------------------------------------

/// \brief Параметры основной платы
static cpumodule_spec_t   cpumodule_spec;
static mainbrd_spec_t     mainbrd_spec;
static radiobrd_spec_t    radiobrd_spec;


static const cpumodule_spec_t FALLBACK_CPUMODULE_SPEC = {
  .type = CPUMODULE_SOM_F207,
  .version_major  = 3,
  .version_minor  = 0,
  .name           = "SOM-F207ZG 1.0",
  .has_extra_data = 1,
  .som_f207 = {
    .cpu              = SOM_F207_CPU_STM32F207ZG,
    .cpuclock         = SOM_F207_CPUCLOCK_CRYSTAL,
    .aux2             = SOM_F207_AUX2_EXTSPI,
    .ethphy           = SOM_F207_ETHPHY_LAN8742A,
    .extflash         = SOM_F207_EXTFLASH_MX25L3233,
    .extsram          = SOM_F207_EXTRAM_SRAM_16BIT,
    .tsc              = SOM_F207_TSC_STMPE811,
    .reserved         = { 0 },
    .cpuclock_freq    = 8000000,
    .aux2_clock       = 14745600,
    .aux2_address     = 0x03,
    .aux2_rsvd        = { 0 },
    .extflash_size    = 4194304,
    .extflash_rsvd    = { 0 },
    .extsram_size     = 524288,
    .extsram_rsvd     = { 0 },
    .tsc_address      = 0x41,
  }
};

/// \brief Параметры полноценной платы 3.0
static const mainbrd_spec_t FALLBACK_MAINBRD_SPEC_FULL = {

  .mdb = {      // mdb_spec_t    mdb[2];   ///< Характеристики MDB/EXE портов
    [0] = { // MDB/EXE1
      .flags      = 0       // Флаги входа MDB/EXE1 (см. \ref mdb_spec_flags)
                  | MDBSPEC_F_PRESENT
                  | MDBSPEC_F_HAS_SLAVE
                  | MDBSPEC_F_HAS_MASTER
                  | MDBSPEC_F_PCF8574_LAYOUT_1
                  ,
      .reserved   = 0,      // Зарезервировано для расширения флагов.
      .pcf_addr   = 0x20,   // I2C адрес GPIO расширителя PCF8574 (0x20=DD33)
      .reserved2  = {0},    // Зарезервировано.
      .adc        = {       // Параметры АЦП
        .type       = ADCSPEC_T_ADC081C021, // Тип микросхемы АЦП (см. \ref adc_spec_types)
        .address    = 0x55,                 // I2C адрес микросхемы АЦП
        .channel    = 0,                    // Номер канала микросхемы АЦП (начиная с нуля)
        .unit       = ADCSPEC_U_MILLIVOLTS, // Тип измеряемого значения (см. \ref adc_spec_units)
        .ratio      = 1000,                 // Коэффициент преобразования
        .offset     = 0,                    // Смещение преобразованного результата
      },
    },

    [1] = { // MDB/EXE2
      .flags      = 0       // Флаги входа MDB/EXE2 (см. \ref mdb_spec_flags)
                  | MDBSPEC_F_PRESENT
                  | MDBSPEC_F_HAS_SLAVE
                  | MDBSPEC_F_HAS_MASTER
                  | MDBSPEC_F_PCF8574_LAYOUT_2
                  ,
      .reserved   = 0,      // Зарезервировано для расширения флагов.
      .pcf_addr   = 0x20,   // I2C адрес GPIO расширителя PCF8574 (0x20=DD33)
      .reserved2  = {0},    // Зарезервировано.
      .adc        = {       // Параметры АЦП
        .type       = ADCSPEC_T_ADC081C021, // Тип микросхемы АЦП (см. \ref adc_spec_types)
        .address    = 0x56,                 // I2C адрес микросхемы АЦП
        .channel    = 0,                    // Номер канала микросхемы АЦП (начиная с нуля)
        .unit       = ADCSPEC_U_MILLIVOLTS, // Тип измеряемого значения (см. \ref adc_spec_units)
        .ratio      = 1000,                 // int16_t - Коэффициент преобразования
        .offset     = 0,                    // int16_t - Смещение преобразованного результата
      },
    },
  },

  .aux = {      // aux_spec_t - Характеристики AUX портов
    [0] = { // AUX1
      .flags        = 0     // Флаги настроек канала AUX (см. \ref aux_spec_flags)
                    | AUXSPEC_F_PRESENT
                    | AUXSPEC_F_HAS_TTL
                    | AUXSPEC_F_HAS_RS232
                    | AUXSPEC_F_HAS_RS485V1
                    | AUXSPEC_F_HAS_RS485V2
                    | AUXSPEC_F_HAS_LOOPBACK
                    | AUXSPEC_F_HAS_RXTX_EXCHANGE
                    ,
      .reserved     = 0,    // Зарезервировано для расширения флагов.
      .pcf_address  = 0x21, // I2C адрес GPIO расширителя PCF8574
      .reserved2    = {0},  // Зарезервировано.
      .adc          = {     // Параметры АЦП.
        .type         = ADCSPEC_T_ADC081C021, // Тип микросхемы АЦП (см. \ref adc_spec_types)
        .address      = 0x50,                 // I2C адрес микросхемы АЦП
        .channel      = 0,                    // Номер канала микросхемы АЦП (начиная с нуля)
        .unit         = ADCSPEC_U_MILLIVOLTS, // Тип измеряемого значения (см. \ref adc_spec_units)
        .ratio        = 1000,                 // Коэффициент преобразования. Уточнить на плате
        .offset       = 0,                    // Смещение преобразованного результата
      },
    },
    [1] = { // AUX2
      .flags        = 0     // Флаги настроек канала AUX (см. \ref aux_spec_flags)
                    | AUXSPEC_F_PRESENT
                    | AUXSPEC_F_HAS_TTL
                    | AUXSPEC_F_HAS_RS232
                    | AUXSPEC_F_HAS_RS485V1
                    | AUXSPEC_F_HAS_RS485V2
                    | AUXSPEC_F_HAS_LOOPBACK
                    | AUXSPEC_F_HAS_RXTX_EXCHANGE
                    ,
      .reserved     = 0,    // Зарезервировано для расширения флагов.
      .pcf_address  = 0x22, // I2C адрес GPIO расширителя PCF8574
      .reserved2    = {0},  // Зарезервировано.
      .adc          = {     // Параметры АЦП.
        .type         = ADCSPEC_T_ADC081C021, // Тип микросхемы АЦП (см. \ref adc_spec_types)
        .address      = 0x51,                 // I2C адрес микросхемы АЦП
        .channel      = 0,                    // Номер канала микросхемы АЦП (начиная с нуля)
        .unit         = ADCSPEC_U_MILLIVOLTS, // Тип измеряемого значения (см. \ref adc_spec_units)
        .ratio        = 1000,                 // Коэффициент преобразования. Уточнить на плате
        .offset       = 0,                    // Смещение преобразованного результата
      },
    },
    [2] = { // AUX3
      .flags        = 0     // Флаги настроек канала AUX (см. \ref aux_spec_flags)
                    | AUXSPEC_F_PRESENT
                    | AUXSPEC_F_HAS_TTL
                    | AUXSPEC_F_HAS_RS232
                    | AUXSPEC_F_HAS_RS485V1
                    | AUXSPEC_F_HAS_RS485V2
                    | AUXSPEC_F_HAS_LOOPBACK
                    | AUXSPEC_F_HAS_RXTX_EXCHANGE
                    | AUXSPEC_F_HAS_CONSOLE
                    ,
      .reserved     = 0,    // Зарезервировано для расширения флагов.
      .pcf_address  = 0x23, // I2C адрес GPIO расширителя PCF8574
      .reserved2    = {0},  // Зарезервировано.
      .adc          = {     // Параметры АЦП.
        .type         = ADCSPEC_T_ADC081C021, // Тип микросхемы АЦП (см. \ref adc_spec_types)
        .address      = 0x52,                 // I2C адрес микросхемы АЦП
        .channel      = 0,                    // Номер канала микросхемы АЦП (начиная с нуля)
        .unit         = ADCSPEC_U_MILLIVOLTS, // Тип измеряемого значения (см. \ref adc_spec_units)
        .ratio        = 1000,                 // Коэффициент преобразования. Уточнить на плате
        .offset       = 0,                    // Смещение преобразованного результата
      },
    },
  },

  .chrg = {     // chrg_spec_t - Характеристики зарядного устройства
    .type     = CHRGSPEC_T_BQ24295,   // Тип микросхемы заряда (см. \ref chrg_spec_types)
    .addr     = 0x6B,                 // I2C адрес микросхемы заряда
    .v_chrg   = 40,                   // Напряжение заряда аккумулятора в 0.1 Вольтах
    .i_in     = 15,                   // Ограничение входного тока в 0.1 Амперах
    .reserved = {0},                  // Зарезервировано
  },

  .rtc = {      // rtc_spec_t    Характеристики часов реального времени
    .type     = RTCSPEC_T_MCP79401,   // Тип микросхемы RTC (см. \ref rtc_spec_types)
    .address  = 0x6F,                 // I2C адрес микросхемы RTC
    .reserved = {0},                  // Зарезервировано
  },

  .accel = {    // accel_spec_t  Характеристики акселерометра
    .type     = ACCELSPEC_T_NONE,     // Тип микросхемы акселерометра (см. \ref accel_spec_types)
    .reserved = {0},                  // Зарезервировано
  },

  .v_in = {     // adc_spec_t    Характеристики АЦП входного напряжения
    .type     = ADCSPEC_T_ADC081C021, // Тип микросхемы АЦП (см. \ref adc_spec_types)
    .address  = 0x52,                 // I2C адрес микросхемы АЦП
    .channel  = 0,                    // Номер канала микросхемы АЦП (начиная с нуля)
    .unit     = ADCSPEC_U_MILLIVOLTS, // Тип измеряемого значения (см. \ref adc_spec_units)
    .ratio    = 1000,                 // Коэффициент преобразования. Уточнить на плате
    .offset   = 0,                    // Смещение преобразованного результата
  },

  .doors = {    // doors_spec_t  Характеристики входа концевых датчиков
    .flags    = DOORSSPEC_F_PRESENT,  // Флаги настроек для входов концевых датчиков (см \ref doors_spec_flags).
    .reserved = 0,                    // Зарезервировано для дальнейшего использования
    .address  = 0x20,                 // I2C адрес GPIO расширителя PCF8574
    .reserved2= {0},                  // Зарезервировано.
  },

  .ethernet = { // eth_spec_t    Характеристики Ethernet разъема
    .flags    = 0                     // Флаги настроек Ethernet
              | ETHSPEC_F_PRESENT
              | ETHSPEC_F_HAS_10M
              | ETHSPEC_F_HAS_100M
              | ETHSPEC_F_HAS_1000M
              | ETHSPEC_F_HAS_LEDS
              ,
    .reserved = 0,                    // Зарезервировано
    .mac      = {0},                  // Используемый MAC адрес, если задан ETHSPEC_F_OVERRIDE_MAC и не ETHSPEC_F_UNIQUEID_AS_MAC
  },

  .usb = {      // usb_spec_t    Характеристики USB.
    .flags          = 0               // Флаги настроек USB (см. \ref usb_spec_flags)
                    | USBSPEC_F_PRESENT
                    | USBSPEC_F_HAS_USBSWITCH
                    | USBSPEC_F_HAS_DEVICE_MODE
                    | USBSPEC_F_HAS_HOST_MODE
                    ,
    .reserved       = 0,              // Зарезервировано.
    .host_max_power = 500/2,          // Максимальный ток, выдаваемый в режиме хоста в мА/2.
    .reserved2      = {0},            // Зарезервировано.
  },

};

static const radiobrd_spec_t FALLBACK_RADIOBRD_SPECS = {
  // Тип радио-модуля (см. \ref radio_spec_types)
  // uint8_t         type;
  .type       = RADIOSPEC_T_SIM800C_DS,

  // Битмаска симкарт, имеющихся на плате, и их параметры (см. \ref radio_spec_simcards)
  // uint8_t         simcards;
  .simcards   = 0
              | RADIOSPEC_SC_HAS_SIM1_CHAN
              | RADIOSPEC_SC_HAS_SIM2_CHAN
              | RADIOSPEC_SC_SIM2_IS_CHIP
              ,

  // Зарезервировано.
  // uint8_t         reserved[2];
  .reserved   = {0},

  // Настройки GPRS для каждого из каналов симкарт.
  //
  // Данные настройки используются, если в выбранном канале
  // распаян симчип (т.е. настройки GPRS известны в момент производства).
  // simchip_apn_t   apn[2];
  .apn        = {
    [0] = {
      .apn        = "",
      .user       = "",
      .password   = ""
    },

    [1] = {
      .apn        = "",
      .user       = "",
      .password   = ""
    }
  },
};




STATIC_ASSERT(sizeof(spec_hdr_t) == SPEC_HEADER_SIZE, bad_spec_hdr_t_size);
STATIC_ASSERT(sizeof(mainbrd_spec_t) <= SPEC_SIZE,    bad_mainbrd_spec_t_size);

bool LoadSpecs(
  const char* path,
  void*       dst,
  size_t      size,
  uint8_t     rec_type,
  uint16_t    lay_vers
)
{
  return spec_load_and_validate(path, dst, size, rec_type, lay_vers) >= 0;
}

bool SaveSpecs(
  const char* path,
  const void* src,
  size_t      size,
  uint8_t     rec_type,
  uint16_t    lay_vers
)
{
  return spec_writef(path, rec_type, lay_vers, src, size) >= 0;
}

static void LoadBoardConfiguration()
{
  if (!LoadSpecs("/cfg/cpumodule", &cpumodule_spec, sizeof(cpumodule_spec),
                  EE_RECTYPE_CPUMODULE_SPEC, CPUMODULE_SPEC_LAYOUT_VERSION)
  ) {
    memcpy(&cpumodule_spec, &FALLBACK_CPUMODULE_SPEC, sizeof(cpumodule_spec));
  }


  if (!LoadSpecs("/cfg/mainbrd", &mainbrd_spec,
                          sizeof(mainbrd_spec), EE_RECTYPE_MAINBRD_SPEC,
                          MAINBRD_LAYOUT_VERSION)
  ) {
    memcpy(&mainbrd_spec, &FALLBACK_MAINBRD_SPEC_FULL, sizeof(mainbrd_spec));
  }

  if (!LoadSpecs("/cfg/radio", &radiobrd_spec,
                          sizeof(radiobrd_spec), EE_RECTYPE_RADIOBRD_SPEC,
                          RADIOBRD_LAYOUT_VERSION)
  ) {
    memcpy(&radiobrd_spec, &FALLBACK_RADIOBRD_SPECS, sizeof(radiobrd_spec));
  }
}

const mainbrd_spec_t* BoardGetMainbrdSpecs(void)
{
  return &mainbrd_spec;
}

// bool BoardGetBootloaderConfiguration(bootldr_rodata_t* dst)
// {
//   return LoadSpecs("/cfg/boot_ro", dst, sizeof(*dst), EE_RECTYPE_BOOTLDR_RODATA, BOOTLDR_RODATA_LAYOUT_VERSION);
// }

// bool BoardGetBootloaderState(bootldr_data_t* dst)
// {
//   return LoadSpecs("/cfg/boot", dst, sizeof(*dst), EE_RECTYPE_BOOTLDR_PARAMS, BOOTLDR_PARAMS_LAYOUT_VERSION);
// }

// bool bootloader_set_state(&state) < 0(const bootldr_data_t* src)
// {
//   return SaveSpecs("/cfg/boot", src, sizeof(*src), EE_RECTYPE_BOOTLDR_PARAMS, BOOTLDR_PARAMS_LAYOUT_VERSION);
// }
////////////////////////////////////////////////////////////////////////////
//  Драйвер доступа к I2C EEPROM через файлы виртуальной файловой системы
// -------------------------------------------------------------------------

typedef struct {
  uint32_t  offset;
  uint32_t  size;
  uint32_t  sector_size;
  bool      readonly;
} ee_partfile_t;

static int   ee_part_open (file_t* file);
static int   ee_part_read (file_t* file, char* ptr, int len);
static int   ee_part_write(file_t* file, const char* ptr, int len);
static int   ee_part_fstat(file_t* file, struct stat *st);
//static off_t ee_part_lseek(file_t* file, off_t offset, int whence);

static const file_ops_t   EE_PARTITION_FILE_OPS = {
  .open   = ee_part_open,
  .close  = NULL,
  .read   = ee_part_read,
  .write  = ee_part_write,
  .fstat  = ee_part_fstat,
  .lseek  = NULL, // пока не используем
};

static int   ee_part_open (file_t* file)
{
  if (!file || !file->priv) {
    return -EINVAL;
  }
  ee_partfile_t* ee_partfile = (ee_partfile_t*)file->priv;
  file->size      = ee_partfile->size;
  file->capacity  = ee_partfile->size;
  return 0;
}

static int   ee_part_read (file_t* file, char* ptr, int len)
{
  if (!file || !file->priv || !ptr || len < 0) {
    return -EINVAL;
  }
  if (!len) {
    return 0;
  }

  ee_partfile_t* ee_partfile = (ee_partfile_t*)file->priv;
  if (file->pos >= file->capacity) {
    return 0;
  }
  if (file->pos + len > file->capacity) {
    len = file->capacity - file->pos;
  }

  int ret = AT24C64Read(ee_partfile->offset + file->pos, ptr, len);
  if (ret < 0) {
    return ret;
  }

  file->pos += ret;
  return ret;
}

static int   ee_part_write(file_t* file, const char* ptr, int len)
{
  if (!file || !file->priv || !ptr) {
    return -EINVAL;
  }

  ee_partfile_t* ee_partfile = (ee_partfile_t*)file->priv;
  if (file->pos >= file->capacity) {
    return -ENOSPC;
  }
  if (file->pos + len > file->capacity) {
    len = file->capacity - file->pos;
  }

  int ret = AT24C64Write(ee_partfile->offset + file->pos, ptr, len);
  if (ret < 0) {
    return ret;
  }

  file->pos += ret;
  return ret;

}

static int   ee_part_fstat(file_t* file, struct stat *st)
{
  if (!file || !file->priv || !st) {
    return -EINVAL;
  }
  ee_partfile_t* ee_partfile = (ee_partfile_t*)file->priv;

  st->st_size     = ee_partfile->size;
  st->st_blksize  = ee_partfile->sector_size;
  st->st_blocks   = (ee_partfile->size + ee_partfile->sector_size -1)
                    / ee_partfile->sector_size;
  return 0;
}

#define EE_PART_WRITABLE  true
#define EE_PART_READONLY  false
static int ee_part_register(
  const char*     path,
  ee_partfile_t*  ee_partfile,
  uint32_t        offset,
  uint32_t        size,
  bool            writable
)
{
  if (!path || !ee_partfile || !size) {
    return -EINVAL;
  }

  ee_partfile->offset       = offset;
  ee_partfile->size         = size;
  ee_partfile->sector_size  = AT24C64_PAGESIZE;
  ee_partfile->readonly     = !writable;

  int mode = VFS_MODE_READ | VFS_MODE_CHAR | VFS_MODE_SEEKABLE;
  if (writable) {
    mode |= VFS_MODE_WRITE;
  }
  return vfs_register(path, &EE_PARTITION_FILE_OPS, ee_partfile, mode);
}

////////////////////////////////////////////////////////////////////////////
//  Драйвер доступа к области памяти через файлы виртуальной файловой системы
// -------------------------------------------------------------------------

typedef struct {
  uint8_t*  data;
  uint32_t  size;
  uint32_t  capacity;
  bool      readonly;
} ramfile_t;

static int   ramfile_open (file_t* file);
static int   ramfile_read (file_t* file, char* ptr, int len);
static int   ramfile_write(file_t* file, const char* ptr, int len);
static int   ramfile_fstat(file_t* file, struct stat *st);
//static off_t ee_part_lseek(file_t* file, off_t offset, int whence);

static const file_ops_t   RAMFILE_OPS = {
  .open   = ramfile_open,
  .close  = NULL,
  .read   = ramfile_read,
  .write  = ramfile_write,
  .fstat  = ramfile_fstat,
  .lseek  = NULL, // пока не используем
};

static int   ramfile_open (file_t* file)
{
  if (!file || !file->priv) {
    return -EINVAL;
  }
  ramfile_t* ramfile = (ramfile_t*)file->priv;
  file->size      = ramfile->size;
  file->capacity  = ramfile->capacity;
  return 0;
}

static int   ramfile_read (file_t* file, char* ptr, int len)
{
  if (!file || !file->priv || !ptr || len < 0) {
    return -EINVAL;
  }
  if (!len) {
    return 0;
  }

  ramfile_t* ramfile = (ramfile_t*)file->priv;
  if (file->pos >= file->capacity) {
    return 0;
  }
  if (file->pos + len > file->capacity) {
    len = file->capacity - file->pos;
  }

  memcpy(ptr, &ramfile->data[file->pos], len);
  file->pos += len;
  return len;
}

static int   ramfile_write(file_t* file, const char* ptr, int len)
{
  if (!file || !file->priv || !ptr) {
    return -EINVAL;
  }

  ramfile_t* ramfile = (ramfile_t*)file->priv;
  if (file->pos >= file->capacity) {
    return -ENOSPC;
  }
  if (file->pos + len > file->capacity) {
    len = file->capacity - file->pos;
  }

  memcpy(&ramfile->data[file->pos], ptr, len);
  file->pos += len;
  return len;

}

static int   ramfile_fstat(file_t* file, struct stat *st)
{
  if (!file || !file->priv || !st) {
    return -EINVAL;
  }
  ramfile_t* ramfile = (ramfile_t*)file->priv;

  st->st_size     = ramfile->size;
  st->st_blksize  = 1;
  st->st_blocks   = ramfile->size;
  return 0;
}

#define RAMFILE_WRITABLE  true
#define RAMFILE_READONLY  false
static int ramfile_register(
  const char*     path,
  ramfile_t*      ramfile,
  uint8_t*        data,
  uint32_t        size,
  uint32_t        capacity,
  bool            writable
)
{
  if (!path || !ramfile || !size) {
    return -EINVAL;
  }

  ramfile->data         = data;
  ramfile->size         = size;
  ramfile->capacity     = capacity;
  ramfile->readonly     = !writable;

  int mode = VFS_MODE_READ | VFS_MODE_CHAR | VFS_MODE_SEEKABLE;
  if (writable) {
    mode |= VFS_MODE_WRITE;
  }
  return vfs_register(path, &RAMFILE_OPS, ramfile, mode);
}


////////////////////////////////////////////////////////////////////////////
//  Регистрация в виртуальной файловой системе всех необходимых разделов
//  I2C EEPROM памяти.
// -------------------------------------------------------------------------
static ramfile_t        g_rom_bootldr_rodata;
static ramfile_t        g_rom_cpumodule_params;

static ee_partfile_t    g_eepart_mainbrd_spec;
static ee_partfile_t    g_eepart_radiobrd_spec;
static ee_partfile_t    g_eepart_bootldr_data;
static ee_partfile_t    g_eepart_bootldr_params;
static ee_partfile_t    g_eepart_apn_params;
static ee_partfile_t    g_eepart_fw_params;

static int BoardRegisterEepromPartitions(void)
{
  int lasterror = 0;
# define CHK_EE(op) \
    do { int __ret = (op); if (__ret < 0) lasterror=__ret; } while(0)

  // Разделы настроек загрузчика и параметров платы - всегда только для чтения
  CHK_EE(
    ramfile_register(
      "/cfg/boot_ro",
      &g_rom_bootldr_rodata,
      (uint8_t*)CFG_BOOT_RODATA_ADDRESS,
      CFG_BOOT_RODATA_SIZE,
      CFG_BOOT_RODATA_SIZE,
      RAMFILE_READONLY
    )
  );

  CHK_EE(
    ramfile_register(
      "/cfg/cpumodule",
      &g_rom_cpumodule_params,
      (uint8_t*)CFG_BOOT_CPUMODULE_ADDRESS,
      CFG_BOOT_CPUMODULE_SIZE,
      CFG_BOOT_CPUMODULE_SIZE,
      RAMFILE_READONLY
    )
  );

  // Из загрузчика есть доступ на запись только к разделам
  // самого загрузчика
  CHK_EE(
    ee_part_register(
      "/cfg/bootdata",
      &g_eepart_bootldr_data,
      BOOTLDR_DATA_OFFSET,
      BOOTLDR_DATA_PART_SIZE,
      EE_PART_WRITABLE
    )
  );

  CHK_EE(
    ee_part_register(
      "/cfg/boot",
      &g_eepart_bootldr_params,
      BOOTLDR_PARAMS_OFFSET,
      BOOTLDR_PARAMS_PART_SIZE,
      EE_PART_WRITABLE
    )
  );

  // А в разделы настроек (по крайней мере сейчас)
  // доступ только для чтения.
  CHK_EE(
    ee_part_register(
      "/cfg/mainbrd",
      &g_eepart_mainbrd_spec,
      MAINBRD_SPEC_OFFSET,
      SPEC_PART_SIZE,
      RAMFILE_READONLY
    )
  );

  CHK_EE(
    ee_part_register(
      "/cfg/radio",
      &g_eepart_radiobrd_spec,
      RADIOBRD_SPEC_OFFSET,
      SPEC_PART_SIZE,
      RAMFILE_READONLY
    )
  );

  CHK_EE(
    ee_part_register(
      "/cfg/apn",
      &g_eepart_apn_params,
      APN_PARAMS_OFFSET,
      APN_PARAMS_PART_SIZE,
      EE_PART_READONLY
    )
  );

  CHK_EE(
    ee_part_register(
      "/cfg/fw",
      &g_eepart_fw_params,
      FW_PARAMS_OFFSET,
      FW_PARAMS_PART_SIZE,
      EE_PART_READONLY
    )
  );

#undef CHK_EE
  return lasterror;
}


////////////////////////////////////////////////////////////////////////////
//  Общая инициализация платы
// -------------------------------------------------------------------------

void BoardInit()
{
  GpioInit();
  TimersInit();
  __enable_irq();
  BoardI2CInit();
  BufferedUartDriverInit();
#if defined(CFG_BOOT_FORCE_USE_DEBUG_PORT) && (CFG_BOOT_FORCE_USE_DEBUG_PORT == 1)
  debug_port_enable = 1;
  DebugPortInit();
#endif
  BoardRegisterEepromPartitions();
  LoadBoardConfiguration();
#if !defined(CFG_BOOT_FORCE_USE_DEBUG_PORT) || (CFG_BOOT_FORCE_USE_DEBUG_PORT != 1)
  DebugPortInit();
#endif

  LedsInit();
  BuzzerInit();
  // ExtIoInit();
  ButtonsInit();
  AdcInit();

  // DexSwitchInit();
  // DexPortInit();
  // DexPortsDeinit();
  // MdbPortsInit();
  ChargerInit();
  SimPortInit();
  SimCardSwitchInit();
  SimCardSwitchDeselect();
  // SpiInit();
}

void BoardDeinit(bool full)
{
  // SpiDeinit();
  SimCardSwitchDeinit();
  SimPortDeinit(full);
  // MdbPortsDeinit();
  // DexPortsDeinit();
  DebugPortDeinit();

  TimersDeinit();
  AdcDeinit();
  ButtonsDeinit();
  // ExtIoDeinit();
  BuzzerDeinit();
  LedsDeinit();
  GpioDeinit();
}





#if 0

uint32_t     ADCClock=0;
int          dex_channel_selected=DEX_CHANNEL_NONE;

static const Board2v2Config   fallback_board_configuration = {
  .sim_card_presence = {
    [BRD22_SIM_CARD_NONE]         = BRD22_SIM_CARD_ABSENT,
    [BRD22_SIM_CARD_EXTERNAL1]    = BRD22_SIM_CARD_PRESENT,
    [BRD22_SIM_CARD_INTERNAL_U24] = BRD22_SIM_CARD_PRESENT,
    [BRD22_SIM_CARD_INTERNAL_U25] = BRD22_SIM_CARD_PRESENT,
    [BRD22_SIM_CARD_INTERNAL_U26] = BRD22_SIM_CARD_PRESENT,
  }
};

static const Board2v2Config*  board_config = &fallback_board_configuration;

static void LoadBoardConfiguration()
{
  if (!bootloader_load_board_configuration()) {
    // Настройка для платы, у которой нет информации о загрузчике.
    // Считаем, что все сим-карты и сим-чипы распаяны.
    board_config = &fallback_board_configuration;
    return;
  }

  const BootloaderInfoLayout* boot_info = bootloader_get_board_configuration();
  if (!boot_info || !boot_info->board_info.has_extra_data) {
    board_config = &fallback_board_configuration;
    return;
  }

  board_config = (const Board2v2Config*)boot_info->board_info.extra_data;
}





/// \brief Бит-маска каналов интерфейса с DEX, через которые может вестись
/// обмен данными в текущих настройках.
///
/// Это нужно из-за того, что на плате 2.2 нет выделенного порта для вывода отладочных сообщений
/// и для этих целей был использован TTL порт, который оказался нужен для снятия отчётов с Bianchi.
///
/// В зависимости от значения этой переменной либо разрешается либо запрещается вывод отладочной информации.
///
/// \note При старте платы 2.2 она инициализируется так, что для DEX оказываются разрешены
/// все доступные каналы. Таким образом, при старте платы 2.2 отладочная информация оказывается недоступна.
static uint32_t dex_channels_enabled = DEX_CHANNELS_PRESENT;

/// Переменная указывающая на включение вывода отладочной информации
static uint8_t debug_port_enable = DEBUG_PORT_EN;

/// \brief Читает обычный (не injected) канал АЦП \p port с номером \p channel_id.
static uint16_t adc_read_regular_chan(ADC_TypeDef* port, uint8_t channel_id)
{
  port->SQR3 = channel_id;
  port->CR2 |= ADC_CR2_SWSTART;
  while ((port->SR & ADC_SR_EOC) != ADC_SR_EOC);
  return port->DR;
}

/// Читает текущее значение температуры в градусах цельсия
int32_t ReadCoreTemperature(void)
{
  int32_t temp;
  int32_t temperature;
  // T_AVG_SLOPE - коэфициент пердачи функции термодатчика (4.3 mV/C паспортные данные)
  // T_V25 - значение напряжения на термодатчике при температуре 25С (1.41 V паспортные данные)
  #define T_V25             1500 // в mV
  #define T_AVG_SLOPE       4600 // в uV/C

  temp = adc_read_regular_chan(ADC1, TCORE_ADC_CHANNEL);
  temperature = ((((((T_V25<<12) - temp * V_REF_MV)*1000) / T_AVG_SLOPE)+(25<<12)))/4096;

  return temperature;
}

/// \brief Читает текущее напряжение питания в милливольтах.
uint32_t ReadSupplyMillivolts(void)
{
  uint32_t temp;
  uint32_t mV;


  // Выбор 10 канала (V24CTR) для преобразования.
  //               +------------------> V24CTR
  //               |
  //        R9=39k |   R10=2k7
  // 24V >--[__]---+---[__]---+-- GND
  //               |          |
  //               +----||----+
  //                   C16=0.1uF
  //
  // Vmax = (24/41.7)*2.7 = 1.554V
  // Диапазон измерения 0..Vref = 0 ... 4095 (т.к. 12 бит).
  // Vref = 3.3V
  // цена младшего бита 0.80586 mV, значит 1.554 = 1928
  //
  // Если смотреть с точки зрения напряжения до делителя, то младщий бит равен
  // 0.80586mV * 41.7 / 2.7 = 12.44606 mV
  //
  // Что бы привести к 0.01 за деление нужно умножить на 330/4096 или
  // на 165/2048.
  //
  // Формула вычисления напряжения:
  // V = (R9+R10)*Vref*value / (R10*4096) = ((R9+R10)*Vref/R10)*value/4096

#define R9_OHM      39000
#define R10_OHM     2700

#define MULTIPLIER  ((R9_OHM + R10_OHM) * V_REF_MV / R10_OHM)
#define DIVIDER     4096


  temp = adc_read_regular_chan(ADC1, V24CTR_ADC_CHANNEL);
  mV = temp * MULTIPLIER / DIVIDER;

  return mV;
}

/// \brief Данная функция должна вызываться в процессе инициализации
/// для переназначения альтернативных функций для GPIO выводов.
void BoardRemapPins(void)
{
  // Два светодиода попали на выводы JTDO и nJTRST/SWO.

  // Отключаем выводы для JTAG
  AFIO->MAPR = (AFIO->MAPR & ~AFIO_MAPR_SWJ_CFG) | AFIO_MAPR_SWJ_CFG_JTAGDISABLE;

  // PB3 может использоваться для TRACE OUT. Запрещаем это.
  DBGMCU->CR &= ~DBGMCU_CR_TRACE_IOEN;
}

void GpioInit()
{
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
  BoardRemapPins();
  RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA
                          | RCC_APB2Periph_GPIOB
                          | RCC_APB2Periph_GPIOC
                          | RCC_APB2Periph_GPIOD
                          | RCC_APB2Periph_GPIOE,
                        ENABLE);
}

void GpioDeinit()
{
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, DISABLE);
  BoardRemapPins();
  RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA
                          | RCC_APB2Periph_GPIOB
                          | RCC_APB2Periph_GPIOC
                          | RCC_APB2Periph_GPIOD
                          | RCC_APB2Periph_GPIOE,
                        DISABLE);
}

void LedsInit()
{
  GpioConfigArgs(LED1_GREEN,  GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
  GpioConfigArgs(LED1_RED,    GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
  GpioConfigArgs(LED2_GREEN,  GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
  GpioConfigArgs(LED2_RED,    GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
  GpioConfigArgs(LED3_GREEN,  GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
  GpioConfigArgs(LED3_RED,    GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
  GpioConfigArgs(LED4_GREEN,  GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
  GpioConfigArgs(LED4_RED,    GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
  GpioConfigArgs(LED5_GREEN,  GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
  GpioConfigArgs(LED5_RED,    GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
}

void LedsDeinit()
{
  GpioConfigArgs(LED1_GREEN,  GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(LED1_RED,    GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(LED2_GREEN,  GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(LED2_RED,    GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(LED3_GREEN,  GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(LED3_RED,    GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(LED4_GREEN,  GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(LED4_RED,    GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(LED5_GREEN,  GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(LED5_RED,    GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
}

void ExtIoInit()
{
  GpioConfigArgs(IO1, GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 1);
  GpioConfigArgs(IO2, GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 1);
  GpioConfigArgs(IO3, GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 1);
  GpioConfigArgs(IO4, GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 1);
  GpioConfigArgs(IO5, GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 1);
  GpioConfigArgs(IO6, GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 1);
  GpioConfigArgs(IO7, GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 1);
//  GpioConfigArgs(IO1, GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
//  GpioConfigArgs(IO2, GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
//  GpioConfigArgs(IO3, GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
//  GpioConfigArgs(IO4, GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
//  GpioConfigArgs(IO5, GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
//  GpioConfigArgs(IO6, GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
//  GpioConfigArgs(IO7, GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
}

static void ExtIoDeinit()
{
  GpioConfigArgs(IO1, GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(IO2, GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(IO3, GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(IO4, GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(IO5, GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(IO6, GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(IO7, GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
}

void BuzzerInit()
{
  GpioConfigArgs(BUZZER, GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
}

void BuzzerDeinit()
{
  GpioConfigArgs(BUZZER, GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
}

void ButtonsInit()
{
  GpioConfigArgs(BTN1, GPIO_DIR_INPUT, GPIO_MODE_IN_FLOAT, 1);
  GpioConfigArgs(BTN2, GPIO_DIR_INPUT, GPIO_MODE_IN_FLOAT, 1);
  GpioConfigArgs(BTN3, GPIO_DIR_INPUT, GPIO_MODE_IN_FLOAT, 1);
}

void ButtonsDeinit()
{
  // Кнопки в отключенном состоянии ведут себя так же, как и во включенном.
  // Ещё раз вызываем ButtonsInit() на случай, если в процессе работы были
  // отключены подтяжки
  ButtonsInit();
}

void AdcInit()
{
  ADC_InitTypeDef ADC_InitStructure;

  RCC_ADCCLKConfig(RCC_PCLK2_Div8);
  // Сообщим ор частоте дискретизации АЦП
  ADCClock=APB2Clock/8;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
  GpioConfigArgs(V24CTR, GPIO_DIR_INPUT, GPIO_MODE_IN_ANALOG, 0);


  ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
  ADC_InitStructure.ADC_ScanConvMode = DISABLE;
  ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;
  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
  ADC_InitStructure.ADC_NbrOfChannel = 1;
  ADC_Init(ADC1, &ADC_InitStructure);

  /* ADC1 regular channels configuration */
  ADC_RegularChannelConfig(ADC1, TCORE_ADC_CHANNEL, 1, ADC_SampleTime_55Cycles5);
  ADC_RegularChannelConfig(ADC1, V24CTR_ADC_CHANNEL, 1, ADC_SampleTime_28Cycles5);
  ADC_ExternalTrigConvCmd(ADC1, ENABLE);
  ADC_TempSensorVrefintCmd(ENABLE);

  /* Enable ADC1 */
  ADC_Cmd(ADC1, ENABLE);

  /* Enable ADC1 reset calibration register */
  ADC_ResetCalibration(ADC1);
  /* Check the end of ADC1 reset calibration register */
  while(ADC_GetResetCalibrationStatus(ADC1));

  /* Start ADC1 calibration */
  ADC_StartCalibration(ADC1);
  /* Check the end of ADC1 calibration */
  while(ADC_GetCalibrationStatus(ADC1));
}

void AdcDeinit()
{
  ADC_Cmd(ADC1, DISABLE);
  ADC_DeInit(ADC1);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, DISABLE);
}


// ============ Debug Port  ======================================================



// ============ DEX Port and Debug Port  =========================================

#define DEX_RS232_CHANNELS_MASK   (DEX_CHANNEL1_RS232A_BIT | DEX_CHANNEL2_RS232B_BIT)
#define DEX_TTL_CHANNELS_MASK     (DEX_CHANNEL3_TTLA_BIT)

void DebugPortInit()
{
  if (debug_port_enable)
  {
    if (0 == (dex_channels_enabled & DEX_TTL_CHANNELS_MASK)) {
        GpioConfigArgs(DEX_TX_TTLA,   GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_ALT_PUSHPULL, 0);
        GpioConfigArgs(DEX_RX_TTLA,   GPIO_DIR_INPUT, GPIO_MODE_IN_FLOAT, 0);
        UartInit(DEX_PORT_TTLA, 921600, USART_CR1_TE, 0, 0, DEBUG_PORT_PRIORITY);
        dbg_set_port(DEX_PORT_TTLA);
    } else if (0 == (dex_channels_enabled & DEX_RS232_CHANNELS_MASK)) {
        GpioConfigArgs(DEX_TX_RS232AB,GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_ALT_PUSHPULL, 0);
        GpioConfigArgs(DEX_RX_RS232AB,GPIO_DIR_INPUT, GPIO_MODE_IN_FLOAT, 0);
        // Поскольку работа идёт через MAX3232, то есть ограничение на максимальную скорость передачи.
        UartInit(DEX_PORT_RS232AB, 115200, USART_CR1_TE, 0, 0, DEBUG_PORT_PRIORITY);

        // Выбираем RS232A для вывода отладочной информации.
        GpioClear(DEX_SWITCH_RX);
        GpioClear(DEX_SWITCH_TX);
        dbg_set_port(DEX_PORT_RS232AB);
    } else {
        //  Если нет доступных интерфейсов, то отключаем отладочный порт.
        DebugPortDeinit();
    }
  }
  else
    // отключаем вывод отладочной информации в порт
        DebugPortDeinit();
}

void DebugPortDeinit()
{
  dbg_set_port(NULL);
  if (0 == (dex_channels_enabled & DEX_TTL_CHANNELS_MASK)) {
    UartDeinit(DEX_PORT_TTLA);
  } else if (0 == (dex_channels_enabled & DEX_RS232_CHANNELS_MASK)) {
    // Поскольку работа идёт через MAX3232, то есть ограничение на максимальную скорость передачи.
    UartDeinit(DEX_PORT_RS232AB);
  }
}

void DexSwitchInit(void)
{
  GpioConfigArgs(DEX_SWITCH_TX, GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
  GpioConfigArgs(DEX_SWITCH_RX, GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
}

void DexPortInit(int channel_id)
{
  dbg_assert(channel_id >= 0 && channel_id <= DEX_CHANNEL3_TTLA, "Invalid dex channel");
  //DebugPortDeinit();

  if ((channel_id==DEX_CHANNEL1_RS232A) || (channel_id==DEX_CHANNEL2_RS232B))
  if (0 != (dex_channels_enabled & DEX_RS232_CHANNELS_MASK)) {
    GpioConfigArgs(DEX_TX_RS232AB,GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_ALT_PUSHPULL, 0);
    GpioConfigArgs(DEX_RX_RS232AB,GPIO_DIR_INPUT, GPIO_MODE_IN_FLOAT, 0);
    UartInit(DEX_PORT_RS232AB, 115200, (USART_CR1_RE | USART_CR1_TE), 0, 0, DEX_PORT_PRIORITY);
  }

  if (channel_id==DEX_CHANNEL3_TTLA)
  if (0 != (dex_channels_enabled & DEX_TTL_CHANNELS_MASK)) {
    GpioConfigArgs(DEX_TX_TTLA,   GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_ALT_PUSHPULL, 0);
    GpioConfigArgs(DEX_RX_TTLA,   GPIO_DIR_INPUT, GPIO_MODE_IN_FLOAT, 0);
    UartInit(DEX_PORT_TTLA, 115200, (USART_CR1_RE | USART_CR1_TE), 0, 0, DEX_PORT_PRIORITY);
  }
  //DebugPortInit();
}

void DexPinTxSet(int channel_id, uint8_t tx_port_state)
{
  dbg_assert(channel_id > 0 && channel_id <= DEX_CHANNEL3_TTLA, "Invalid dex channel");

  if ((channel_id==DEX_CHANNEL1_RS232A) || (channel_id==DEX_CHANNEL2_RS232B))
  if (0 != (dex_channels_enabled & DEX_RS232_CHANNELS_MASK)) {
    if (tx_port_state==PORT_ZERO)
        GpioConfigArgs(DEX_TX_RS232AB,GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
    else
    {
        if (tx_port_state==PORT_ONE)
            GpioConfigArgs(DEX_TX_RS232AB,GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 1);
        else
            GpioConfigArgs(DEX_TX_RS232AB,GPIO_DIR_INPUT, GPIO_MODE_IN_FLOAT, 0);
    }
  }

  if (channel_id==DEX_CHANNEL3_TTLA)
  if (0 != (dex_channels_enabled & DEX_TTL_CHANNELS_MASK)) {
    if (tx_port_state==PORT_ZERO)
        GpioConfigArgs(DEX_TX_TTLA,   GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
    else
    {
        if (tx_port_state==PORT_ONE)
            GpioConfigArgs(DEX_TX_TTLA,   GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 1);
        else
            GpioConfigArgs(DEX_TX_TTLA,   GPIO_DIR_INPUT, GPIO_MODE_IN_FLOAT, 0);
    }
  }
}

void DexPortDeinit(int channel_id, uint8_t tx_port_state)
{
  dbg_assert(channel_id > 0 && channel_id <= DEX_CHANNEL3_TTLA, "Invalid dex channel");

  if ((channel_id==DEX_CHANNEL1_RS232A) || (channel_id==DEX_CHANNEL2_RS232B))
  if (0 != (dex_channels_enabled & DEX_RS232_CHANNELS_MASK)) {
    UartDeinit(DEX_PORT_RS232AB);
    if (tx_port_state==PORT_ZERO)
        GpioConfigArgs(DEX_TX_RS232AB,GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
    else
    {
        if (tx_port_state==PORT_ONE)
            GpioConfigArgs(DEX_TX_RS232AB,GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 1);
        else
            GpioConfigArgs(DEX_TX_RS232AB,GPIO_DIR_INPUT, GPIO_MODE_IN_FLOAT, 0);
    }
    GpioConfigArgs(DEX_RX_RS232AB,GPIO_DIR_INPUT, GPIO_MODE_IN_FLOAT, 0);
  }

  if (channel_id==DEX_CHANNEL3_TTLA)
  if (0 != (dex_channels_enabled & DEX_TTL_CHANNELS_MASK)) {
    UartDeinit(DEX_PORT_TTLA);
    if (tx_port_state==PORT_ZERO)
        GpioConfigArgs(DEX_TX_TTLA,   GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
    else
    {
        if (tx_port_state==PORT_ONE)
            GpioConfigArgs(DEX_TX_TTLA,   GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 1);
        else
            GpioConfigArgs(DEX_TX_TTLA,   GPIO_DIR_INPUT, GPIO_MODE_IN_FLOAT, 0);
    }
    GpioConfigArgs(DEX_RX_TTLA,   GPIO_DIR_INPUT, GPIO_MODE_IN_FLOAT, 0);
  }
}

uint8_t def_dex_port_state[DEX_MAX_CHANNELS]={PORT_ONE,       // Канал RS-232 A
                                              PORT_ONE,       // Канал RS-232 B
                                              PORT_ONE};      // Канал TTL

void DexPortStateSet(int channel_id, uint8_t tx_port_state)
{
  if (channel_id > 0 && channel_id <= DEX_MAX_CHANNELS)
  {
    if ((tx_port_state==PORT_FLOAT) ||
        (tx_port_state==PORT_ZERO) ||
        (tx_port_state==PORT_ONE))
        def_dex_port_state[channel_id-1]=tx_port_state;
  }
}

void DexPortsDeinit(void)
{
    uint8_t channel_id=DEX_MAX_CHANNELS;
    while (channel_id)
    {
        if (channel_id==DEX_CHANNEL1_RS232A)
        {
            GpioClear(DEX_SWITCH_RX);
            GpioClear(DEX_SWITCH_TX);
        }
        if (channel_id==DEX_CHANNEL2_RS232B)
        {
            GpioSet(DEX_SWITCH_RX);
            GpioSet(DEX_SWITCH_TX);
        }
        DexPortDeinit(channel_id, def_dex_port_state[channel_id-1]);
        channel_id--;
    }
}

void DexEnableChannels(uint32_t channels_mask) {
  DexPortsDeinit();
  DebugPortDeinit();
  dex_channels_enabled = channels_mask & DEX_CHANNELS_PRESENT;
  //DexPortInit();
  DebugPortInit();
}

static void DexSelectRS232A() {
  if (dex_channels_enabled & DEX_CHANNEL1_RS232A_BIT) {
    GpioClear(DEX_SWITCH_RX);
    GpioClear(DEX_SWITCH_TX);
  }
}

static void DexSelectRS232B() {
  if (dex_channels_enabled & DEX_CHANNEL2_RS232B_BIT) {
    GpioSet(DEX_SWITCH_RX);
    GpioSet(DEX_SWITCH_TX);
  }
}

static void DexDeselectRS232() {
  // На плате 2.2 вместо отключения RS232 выбираем RS232A, через который будет вестись вывод отладочной информации.
  GpioClear(DEX_SWITCH_RX);
  GpioClear(DEX_SWITCH_TX);
}

static void DexSelectTTLA() {
//  if (dex_channels_enabled & DEX_CHANNEL3_TTLA_BIT) {
//    DexDeselectRS232();
//  }
}

static void DexDeselectTTL() {
  // Порт TTL нельзя отключить.
}


void DexSelectChannel(int channel_id) {
  dbg_assert(channel_id >= 0 && channel_id <= DEX_CHANNEL3_TTLA, "Invalid dex channel");
  dex_channel_selected=channel_id;

  if (channel_id == DEX_CHANNEL_NONE) {
    // Деинитим все порты
    DexPortsDeinit();
    DexDeselectRS232();
    DexDeselectTTL();
  } else if (channel_id == DEX_CHANNEL1_RS232A) {
    DexDeselectTTL();
    DexSelectRS232A();
    DexPortInit(channel_id);
  } else if (channel_id == DEX_CHANNEL2_RS232B) {
    DexDeselectTTL();
    DexSelectRS232B();
    DexPortInit(channel_id);
  } else {
    DexDeselectRS232();
    DexSelectTTLA();
    DexPortInit(channel_id);
  }
}

void DexDeselectChannel(int channel_id) {
// Ждем опустошения буфера передачи
  UartWaitTxComplete(DexGetChannel(channel_id), 2000);
  DexSelectChannel(DEX_CHANNEL_NONE);
}

int DexGetSelectedChannel(void) {
    return(dex_channel_selected);
}


struct UartDriverTag* DexGetChannel(int channel_id) {
  if (channel_id == DEX_CHANNEL1_RS232A
      && (0 != (dex_channels_enabled & DEX_CHANNEL1_RS232A_BIT))) {
    return DEX_PORT_RS232AB;
  }

  if (channel_id == DEX_CHANNEL2_RS232B
      && (0 != (dex_channels_enabled & DEX_CHANNEL2_RS232B_BIT))) {
    return DEX_PORT_RS232AB;
  }

  if (channel_id == DEX_CHANNEL3_TTLA
      && (0 != (dex_channels_enabled & DEX_CHANNEL3_TTLA_BIT))) {
    return DEX_PORT_TTLA;
  }

  return NULL;
}

void DebugPortSet(uint8_t port_set)
{
    if ((port_set==DEBUG_PORT_DIS) || (port_set==DEBUG_PORT_EN))
        debug_port_enable=port_set;
}

uint8_t DebugPortGet(void)
{
    return debug_port_enable;
}

// ============ MDB/EXE Ports ====================================================

// Пустой обработчик для случая, когда прользовательская программа не предоставляет
// своего собственного обработчика.
__attribute__((weak)) void OnMdbRxPortInterrupt(void)
{

}

__attribute__((weak)) void OnMdbTxPortInterrupt(void)
{

}

void MDB_RX_PORT_IRQ_HANDLER()
{
  OnMdbRxPortInterrupt();
}

void MDB_TX_PORT_IRQ_HANDLER()
{
  OnMdbTxPortInterrupt();
}

void MdbPortsInit()
{
  // имеется внешний pull-up
  GpioConfigArgs(MDB_RX_PIN, GPIO_DIR_INPUT, GPIO_MODE_IN_FLOAT, 0);
  GpioConfigArgs(MDB_TX_PIN, GPIO_DIR_INPUT, GPIO_MODE_IN_FLOAT, 0);
  uart_init(MDB_RX_PORT, 9600, USART_CR1_RE | USART_CR1_RXNEIE, 0, 0);
  uart_init(MDB_TX_PORT, 9600, USART_CR1_RE | USART_CR1_RXNEIE, 0, 0);
  GpioClear(MDB_BUS_BLOCK);
  GpioConfigArgs(MDB_BUS_BLOCK,  GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
  NVIC_SetPriority(MDB_RX_PORT_IRQN, MDB_EXE_PORT_PRIORITY);
  NVIC_SetPriority(MDB_TX_PORT_IRQN, MDB_EXE_PORT_PRIORITY);
  NVIC_EnableIRQ(MDB_RX_PORT_IRQN);
  NVIC_EnableIRQ(MDB_TX_PORT_IRQN);
}

void MdbPortsDeinit()
{
  NVIC_DisableIRQ(MDB_RX_PORT_IRQN);
  NVIC_DisableIRQ(MDB_TX_PORT_IRQN);
  uart_deinit(MDB_RX_PORT);
  uart_deinit(MDB_TX_PORT);
  GpioConfigArgs(MDB_RX_PIN, GPIO_DIR_INPUT, GPIO_MODE_IN_FLOAT, 0);
  GpioConfigArgs(MDB_TX_PIN, GPIO_DIR_INPUT, GPIO_MODE_IN_FLOAT, 0);
  GpioConfigArgs(MDB_BUS_BLOCK,  GPIO_DIR_INPUT,       GPIO_MODE_IN_PU_PD, 0);
}


// ============ Modem Port (Sim900) ==============================================

// Пустой обработчик для случая, когда прользовательская программа не предоставляет
// своего собственного обработчика.
__attribute__((weak)) void OnModemPortInterrupt(void)
{

}

void SIM_PORT_IRQ_HANDLER()
{
  OnModemPortInterrupt();
}

void SimPortInit()
{
  GpioConfigArgs(SIM_TX,        GPIO_DIR_INPUT,       GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(SIM_RX,        GPIO_DIR_INPUT,       GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(SIM_POWER_EN,  GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
  GpioConfigArgs(SIM_RI,        GPIO_DIR_INPUT,       GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(SIM_PWRKEY,    GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
  GpioConfigArgs(SIM_STATUS,    GPIO_DIR_INPUT,       GPIO_MODE_IN_FLOAT, 0);
}

void SimCardSwitchInit()
{
  GpioConfigArgs(SIM_CARD_DETECT,     GPIO_DIR_INPUT,       GPIO_MODE_IN_PU_PD, 1); // pullup
  GpioConfigArgs(SIM_CARD_SW_E1,      GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
  GpioConfigArgs(SIM_CARD_SW_E2,      GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
  GpioConfigArgs(SIM_CARD_VOLTAGE,    GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
  GpioConfigArgs(SIM_CARD_SW_CHANNEL, GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_PUSHPULL, 0);
}

void SimCardSwitchDeinit()
{
  GpioConfigArgs(SIM_CARD_DETECT,     GPIO_DIR_INPUT,       GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(SIM_CARD_SW_E1,      GPIO_DIR_INPUT,       GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(SIM_CARD_SW_E2,      GPIO_DIR_INPUT,       GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(SIM_CARD_VOLTAGE,    GPIO_DIR_INPUT,       GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(SIM_CARD_SW_CHANNEL, GPIO_DIR_INPUT,       GPIO_MODE_IN_PU_PD, 0);
}

bool SimCardPresent(int card_id)
{
  if (!board_config) {
    // Это ошибка. Останавливаем выполненние программы.
    // Использовать лог нельзя, т.к. может вызываться до инициализации UART портов.
    while(1) {}
  }

  if (card_id < 0
      || card_id >= ARRAY_SIZE(board_config->sim_card_presence)
      || card_id == BRD22_SIM_CARD_NONE) {
    return false;
  }

  return board_config->sim_card_presence[card_id] == BRD22_SIM_CARD_PRESENT;
}

bool SimCardInserted(int card_id)
{
  if (!SimCardPresent(card_id)) {
    return false;
  }

  if (card_id == BRD22_SIM_CARD_EXTERNAL1) {
    return GpioRead(SIM_CARD_DETECT) == SIM_CARD_DETECT_INSERTED;
  }
  return true;
}

void SimCardSwitchDeselect()
{
  GpioWrite(SIM_CARD_SW_E1, 0);
  GpioWrite(SIM_CARD_SW_E2, 0);
}

void SimCardSwitchSelect(int card_id)
{
  SimCardSwitchDeselect();
  GpioWrite(SIM_CARD_VOLTAGE, SIM_CARD_VOLTAGE_3V0);

  switch(card_id) {
  case BRD22_SIM_CARD_EXTERNAL1:
    // Внешняя SIM карта в разъеме
    // расположена на канале A микросхемы U28 (выбор сигналом E1)
    GpioWrite(SIM_CARD_SW_CHANNEL, SIM_CARD_SW_CHANNEL_A);
    GpioWrite(SIM_CARD_SW_E1, 1);
    break;
  case BRD22_SIM_CARD_INTERNAL_U24:
    // U24 расположена на канале B микросхемы U27 (выбор сигналом E2)
    GpioWrite(SIM_CARD_SW_CHANNEL, SIM_CARD_SW_CHANNEL_B);
    GpioWrite(SIM_CARD_SW_E2, 1);
    break;
  case BRD22_SIM_CARD_INTERNAL_U25:
    // U25 расположена на канале A микросхемы U27 (выбор сигналом E2)
    GpioWrite(SIM_CARD_SW_CHANNEL, SIM_CARD_SW_CHANNEL_A);
    GpioWrite(SIM_CARD_SW_E2, 1);
    break;
  case BRD22_SIM_CARD_INTERNAL_U26:
    // U26 расположена на канале B микросхемы U28 (выбор сигналом E1)
    GpioWrite(SIM_CARD_SW_CHANNEL, SIM_CARD_SW_CHANNEL_B);
    GpioWrite(SIM_CARD_SW_E1, 1);
    break;
  default:
    // Во всех остальных случаях оставляем с отключенной sim картой.
    break;
  }
}

void SimPortStartArgs(uint32_t baudrate, uint32_t cr1, uint32_t cr2, uint32_t cr3)
{
  GpioConfigArgs(SIM_TX,        GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_OUT_ALT_PUSHPULL, 1);
  GpioConfigArgs(SIM_RX,        GPIO_DIR_OUTPUT_2MHZ, GPIO_MODE_IN_FLOAT, 1);
  uart_init(SIM_PORT, baudrate, cr1, cr2, cr3);
  NVIC_SetPriority(SIM_PORT_IRQN, SIM_PORT_PRIORITY);
  NVIC_EnableIRQ(SIM_PORT_IRQN);
}

void SimPortStart()
{
  SimPortStartArgs(115200, USART_CR1_RE | USART_CR1_TE | USART_CR1_RXNEIE, 0, 0);
}

void SimPortStop()
{
  NVIC_DisableIRQ(SIM_PORT_IRQN);
  uart_deinit(SIM_PORT);
  GpioConfigArgs(SIM_TX,        GPIO_DIR_INPUT,       GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(SIM_RX,        GPIO_DIR_INPUT,       GPIO_MODE_IN_PU_PD, 0);
}


void SimPortDeinit(bool full)
{
  SimPortStop();
  SimCardSwitchDeselect();
  GpioConfigArgs(SIM_RI,        GPIO_DIR_INPUT,       GPIO_MODE_IN_PU_PD, 0);
  if (full)
  {
    GpioConfigArgs(SIM_POWER_EN,  GPIO_DIR_INPUT,       GPIO_MODE_IN_PU_PD, 0);
    GpioConfigArgs(SIM_PWRKEY,    GPIO_DIR_INPUT,       GPIO_MODE_IN_PU_PD, 0);
    GpioConfigArgs(SIM_STATUS,    GPIO_DIR_INPUT,       GPIO_MODE_IN_PU_PD, 0);
  }
}

void SpiInit()
{
  GpioConfigArgs(SPI_CLK, GPIO_DIR_OUTPUT_50MHZ, GPIO_MODE_OUT_ALT_PUSHPULL, 0);
  GpioConfigArgs(SPI_MISO, GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0); // pull-down
  GpioConfigArgs(SPI_MOSI, GPIO_DIR_OUTPUT_50MHZ, GPIO_MODE_OUT_ALT_PUSHPULL, 0);
  GpioConfigArgs(SPI_CS_ACCEL, GPIO_DIR_OUTPUT_50MHZ, GPIO_MODE_OUT_PUSHPULL, 1);
  GpioConfigArgs(SPI_CS_FLASH, GPIO_DIR_OUTPUT_50MHZ, GPIO_MODE_OUT_PUSHPULL, 1);

  RCC->APB2ENR |= RCC_APB2ENR_SPI1EN;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);
  SPI_PORT->CR1     = 0x0000;
  SPI_PORT->CR2     = 0x0000;
  SPI_PORT->CR1    |= SPI_CR1_MSTR;

  // Частота системной шины 22 МГц.
  // Акселерометр поддерживает максимальную частоту шины 10МГц,
  // Память поддерживает до 50МГц.
  // Установим частоту SPI равной 5.5МГц т.е. Fpclk/4.
  //
  // Это максимально возможная частота при этих условиях, т.к. следующий
  // доступный делитель Fpclk/2 даёт 12МГц, что слишком много для акселерометра.
  //
  // Из даташита: Fpclk/4 - BR[2:0] = 001
  // Необходимо определить какой номер SPI

  //#if (SPI_PORT==SPI1)
  uint32_t APBClock=APB1Clock;
  //#else
  //#define APBClock      (APB2Clock)
  //#endif
  uint32_t DIV=(APBClock/6000000);
  if (DIV>8)
  {
    // Сделали делитель для SPI на 16. (Т.е. при частоте APB 72 МUц частота SPI не более 4.5 Мгц. Можно попробовать делитель на 8)
    DIV=(SPI_CR1_BR_1|SPI_CR1_BR_0);
  }
  else
  {
      if (DIV>4)
      {
        // Сделали делитель для SPI на 8. (Т.е. при частоте APB 36 МUц частота SPI не более 4.5 Мгц. Можно попробовать делитель на 8)
        DIV=(SPI_CR1_BR_1);
      }
      else
      {
        // Стандартный делитель на 4, для частоты APB 24 МГц
        DIV=(SPI_CR1_BR_0);
      }
  }
  SPI_PORT->CR1    |= DIV;
  SPI_PORT->CR1    |= SPI_CR1_SSM; // SSM=0 - Программное управление Chip-Select
  SPI_PORT->CR1    |= SPI_CR1_SSI; // SSI=0 - Без разницы при SSM=0
  SPI_PORT->CR1    |= SPI_CR1_SPE;    // SPI Enable
}

void SpiDeinit()
{
  SPI_PORT->CR1 = 0;
  SPI_PORT->CR2 = 0;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, DISABLE);

  GpioConfigArgs(SPI_CLK,       GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(SPI_MISO,      GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(SPI_MOSI,      GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 0);
  GpioConfigArgs(SPI_CS_ACCEL,  GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 1);
  GpioConfigArgs(SPI_CS_FLASH,  GPIO_DIR_INPUT, GPIO_MODE_IN_PU_PD, 1);
}

// Проверяет и устанавливает частоту работы таймера
bool Time_set_freq(TIM_TypeDef * TIM, uint32_t apbclock, float freq)
{
  dbg_assert((freq>=(apbclock/4294967295.0)), "ERROR: TIM freq is very low. Change APB freq");
  if (freq<(apbclock/4294967295.0))
  {
  //Частота очень низкая и недопустиимая, требуется перестройка apbclock
    log_error("Freq very low. TIM [0x%X]", TIM);
    return(0);
  }
  if ((apbclock/freq)<(0xFFFFl))
  {// Частота высокая
    TIM->PSC = 0;
    TIM->ARR = (apbclock/freq) - 1;
  }
  else
  {// Частота низкая
    if (((apbclock/1000l)/freq)>0xFFFFul)
    {
        if (((apbclock/10000l)/freq)>0xFFFFul)
        {
            TIM->PSC = ((apbclock/65536.0)/freq) - 1;
            TIM->ARR = 0x10000l-1;
        }
        else
        {
            TIM->PSC = ((apbclock/10000.0)/freq) - 1;
            TIM->ARR = 10000-1;
        }
    }
    else
    {
        TIM->PSC = ((apbclock/1000.0)/freq) - 1;
        TIM->ARR = 1000-1;
    }
  }
  //int32_t freq_u=(int32_t)(freq*100000.0);
  //log_info("TIM[0x%X]-> ARR[0x%X], PSC[0x%X], apbclock %d, freq %d", TIM, TIM->ARR, TIM->PSC, apbclock, freq_u);
  return(1);
}

void TimersInit()
{
#if 0
  // Вариант для кварца 11059200 Гц.
  // 1 раз в 60 секунд
  // 22118400 / 32768 = 675 / 40500 = 1/60 Гц.

  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);
  TIM5->PSC = 32768 - 1;
  TIM5->ARR = 40500 - 1;
  TIM5->DIER |= TIM_DIER_UIE;
  TIM5->CR1 = TIM_CR1_CEN | TIM_CR1_ARPE;
  NVIC_SetPriority(TIM5_IRQn, MINUTE_TIMER_PRIORITY);

  // 10 Гц
  // 22118400/8192 = 2700 / 270 = 10
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);
  TIM6->PSC = 8192 - 1;
  TIM6->ARR = 270;
  TIM6->DIER |= TIM_DIER_UIE;
  TIM6->CR1 = TIM_CR1_CEN | TIM_CR1_ARPE;
  NVIC_SetPriority(TIM6_IRQn, SERVICE_TIMER_PRIORITY);
  NVIC_EnableIRQ(TIM6_IRQn);

  // 1кГц
  // На плате 2.2 использован очень неудобный для вычисления миллисекунд кварц.
  // 22118400/221 = 100083.257918552 / 100  = 1000.83257918552 Гц.
  // 22118400/17  = 1301082.35294118 / 1301 = 1000.0632997242 Гц.
  // 22118400/101 = 218994.059405941 / 219  = 999.972873999731 Гц. разница = 0.027126000269 Гц.

  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, ENABLE);
  TIM7->PSC = 101 - 1;
  TIM7->ARR = 219 - 1;
  TIM7->DIER |= TIM_DIER_UIE;
  TIM7->CR1 = TIM_CR1_CEN | TIM_CR1_ARPE;
  NVIC_SetPriority(TIM7_IRQn, SYSTEM_TIMER_PRIORITY);
  NVIC_EnableIRQ(TIM7_IRQn);
#else
  //  Вариант для обычного кварца на 8МГц.
  uint32_t TIMclock=APB1Clock;
  if (APB1Clock<=(SystemCoreClock/2)) TIMclock=APB1Clock*2;
  // 1 раз в 60 секунд
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);
  Time_set_freq(TIM5, TIMclock, TIM5_freq);
  //TIM5->PSC = 32000 - 1;
  //TIM5->ARR = 45000 - 1;
  TIM5->DIER |= TIM_DIER_UIE;
  TIM5->CR1 = TIM_CR1_CEN | TIM_CR1_ARPE;
  NVIC_SetPriority(TIM5_IRQn, MINUTE_TIMER_PRIORITY);

  // 10 Гц
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);
  Time_set_freq(TIM6, TIMclock, TIM6_freq);
  //TIM6->PSC = 999;
  //TIM6->ARR = 2399;
  TIM6->DIER |= TIM_DIER_UIE;
  TIM6->CR1 = TIM_CR1_CEN | TIM_CR1_ARPE;
#ifdef STM32F10X_HD_VL
  NVIC_SetPriority(TIM6_DAC_IRQn, SERVICE_TIMER_PRIORITY);
  NVIC_EnableIRQ(TIM6_DAC_IRQn);
#else
  NVIC_SetPriority(TIM6_IRQn, SERVICE_TIMER_PRIORITY);
  NVIC_EnableIRQ(TIM6_IRQn);
#endif // STM32F10X_HD_VL

  // 1кГц
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, ENABLE);
  Time_set_freq(TIM7, TIMclock, TIM7_freq);
  //TIM7->PSC = 100 - 1;
  //TIM7->ARR = 240 - 1;
  TIM7->DIER |= TIM_DIER_UIE;
  TIM7->CR1 = TIM_CR1_CEN | TIM_CR1_ARPE;
  NVIC_SetPriority(TIM7_IRQn, SYSTEM_TIMER_PRIORITY);
  NVIC_EnableIRQ(TIM7_IRQn);
#endif
}

void TimersDeinit()
{
  NVIC_DisableIRQ(TIM7_IRQn);
  TIM7->CR1 = 0;
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, DISABLE);


#ifdef STM32F10X_HD_VL
  NVIC_DisableIRQ(TIM6_DAC_IRQn);
#else
  NVIC_DisableIRQ(TIM6_IRQn);
#endif
  TIM6->CR1 = 0;
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, DISABLE);

  NVIC_DisableIRQ(TIM5_IRQn);
  TIM5->CR1 = 0;
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, DISABLE);
}

void BoardInit()
{
  LoadBoardConfiguration();
  GpioInit();
  LedsInit();
  BuzzerInit();
  ExtIoInit();
  ButtonsInit();
  AdcInit();
  TimersInit();

  BufferedUartDriverInit();
  DexSwitchInit();
  //DexPortInit();
  DexPortsDeinit();
  DebugPortInit();
  MdbPortsInit();
  SimPortInit();
  SimCardSwitchInit();
  SimCardSwitchDeselect();
  SpiInit();
}

void BoardDeinit(bool full)
{
  SpiDeinit();
  SimCardSwitchDeinit();
  SimPortDeinit(full);
  MdbPortsDeinit();
  DexPortsDeinit();
  DebugPortDeinit();

  TimersDeinit();
  AdcDeinit();
  ButtonsDeinit();
  ExtIoDeinit();
  BuzzerDeinit();
  LedsDeinit();
  GpioDeinit();
}
#endif // 0
