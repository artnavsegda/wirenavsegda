/// \file uart.h
/// \author DL <dmitriy.linikov@gmail.com>
/// \brief Функции для работы с UART портом stm32f10x

#ifndef UART_H_INCLUDED
#define UART_H_INCLUDED

#include <stdlib.h>
#include <stdbool.h>
#include <stm32f2xx.h>
#include "systime.h"
#include "timeout.h"

#define UART_ERR_TIMEOUT      -1
#define UART_ERR_FRAME         0x1000

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

/// \brief Включает UART порт \p port и настраивает его.
/// \param baudrate   Требуемый битрейт.
/// \param cr1
void uart_init(USART_TypeDef* port, uint32_t baudrate, uint32_t cr1, uint32_t cr2, uint32_t cr3);

/// \brief Останавливает UART порт и отключает соответствующую периферию.
void uart_deinit(USART_TypeDef* port);

/// \brief Устанавливает скорость передачи \p baudrate для последовательного
/// порта \p port.
void uart_set_baudrate(USART_TypeDef* port, uint32_t baudrate);

/// \brief Выводит одиночный символ \p value в последовательный порт \p port.
void uart_putc(USART_TypeDef* port, int value);

/// \brief Выводит текстовую строку \p data (оканчивающуюся нулём) в
/// последовательный порт \p port.
void uart_puts(USART_TypeDef* port, const char* data);

/// \brief Выводит текстовую строку \p data (оканчивающуюся нулём) и символ
/// возврата каретки (<CR> = 0x0D) после неё в последовательный порт \p port.
void uart_puts_cr(USART_TypeDef* port, const char* data);

/// \brief Выводит текстовую строку \p data (оканчивающуюся нулём) и символы
/// возврата каретки (<CR> = 0x0D) и перевода строки (<LF> = 0x0A) после неё
/// в последовательный порт \p port.
void uart_puts_crlf(USART_TypeDef* port, const char* data);

/// \brief Выводит произвольный блок данных \p data длинною \p size в
/// последовательный порт \p port.
void uart_write(USART_TypeDef* port, const void* data, size_t size);

/// \brief Проверяет наличие данных в буффере приёма.
bool uart_rx_ready(USART_TypeDef* port);

/// \brief Проверяет наличие места в буффере передачи.
bool uart_tx_ready(USART_TypeDef* port);

/// \brief Читает из последовательного порта \p port один байт данных.
/// \return Если байт данных успешно прочитан, то возвращает его как uint8_t,
/// если в буффере нет данных, то возвращает UART_ERR_TIMEOUT (-1).
int uart_getc_immediate(USART_TypeDef* port);

/// \brief Ожидает приёма очередного байта данных последовательным
/// портом \p port и читает его.
/// \return Возвращает прочитанный байт как uint8_t.
int uart_getc(USART_TypeDef* port);

/// \brief Ожидает до \p timeout мс приёма очередного байта данных
/// последовательным портом \p port и читает его.
/// \return Возвращает прочитанный байт как uint8_t.
int uart_getc_timeout(USART_TypeDef* port, systime_t timeout);

/// \brief Ожидает приёма очередного байта данных
/// последовательным портом \p port пока не закончится таймаут \p timeout.
/// \return Возвращает прочитанный байт как uint8_t.
int uart_getc_timeout_ex(USART_TypeDef* port, timeout_t* timeout);

/// \brief Читает из последовательного порта \p port один байт данных.
/// \return Если байт данных успешно прочитан, то возвращает его как uint16_t,
/// если в буффере нет данных, то возвращает UART_ERR_TIMEOUT (-1).
/// \note В отличие от \see uart_getc_immediate данная функция возвращает
/// символ длиной до 9 бит. Обычно, старший бит - это бит чётности.
int uart_getc_parity_immediate(USART_TypeDef* port);

/// \brief Ожидает приёма очередного байта данных последовательным
/// портом \p port и читает его.
/// \return Возвращает прочитанный байт как uint16_t.
/// \note В отличие от \see uart_getc данная функция возвращает
/// символ длиной до 9 бит. Обычно, старший бит - это бит чётности.
int uart_getc_parity(USART_TypeDef* port);

/// \brief Читает из последовательного порта \p port в буффера \p dst ровно
/// \p size байт данных за время, не превышающее \p timeout миллисекунд.
/// \return Возвращает количество фактически прочитанных байт.
size_t uart_read_timeout(USART_TypeDef* port, void* dst, size_t size,
                         systime_t timeout);

/// \brief Читает из последовательного порта \p port в буффера \p dst ровно
/// \p size байт данных за время, не превышающее \p timeout миллисекунд.
/// \return Возвращает количество фактически прочитанных байт.
size_t uart_read_timeout_ex(USART_TypeDef* port, void* dst, size_t size,
                            timeout_t* timeout);

/// \brief Читает из последовательного порта \p port в буффера \p dst ровно
/// \p size байт данных.
/// \return Возвращает количество фактически прочитанных байт. Поскольку
/// данная функция ждёт бесконечно долго, то количество прочитанных байт
/// всегда равно \p size.
size_t uart_read(USART_TypeDef* port, void* dst, size_t size);

// Объявление inline функций для записи в порт USART1 и USART2. В конечном итоге
// функции uart1_xxxx и uart2_xxxx останутся без использования, т.к. все
// операции пойдут через uart_xxx(USART1, ....) и uart_xxx(USART2, ...),
// но на текущий момент это нужно.


#define DECLARE_PORT_FUNCTIONS(port, prefix)                        \
  static inline void prefix##putc(int value) {                      \
    uart_putc(port, value);                                         \
  }                                                                 \
  static inline void prefix##puts(const char* str) {                \
    uart_puts(port, str);                                           \
  }                                                                 \
  static inline void prefix##puts_cr(const char* str) {             \
    uart_puts_cr(port, str);                                        \
  }                                                                 \
  static inline void prefix##putc_crlf(const char* str) {           \
    uart_puts_crlf(port, str);                                      \
  }                                                                 \
  static inline void prefix##write(const void* data, size_t size) { \
    uart_write(port, data, size);                                   \
  }

DECLARE_PORT_FUNCTIONS(USART1, uart1_)
DECLARE_PORT_FUNCTIONS(USART3, uart3_)


#ifdef __cplusplus
}
#endif // __cplusplus

#endif // UART_H_INCLUDED
