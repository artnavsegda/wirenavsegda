/// \file
/// \brief  Реализация виртуальной файловой системы через переопределение
///         функции newlib
/// \author DL <dmitriy@linikov.ru>
///
/// Для облегчения back-портирования NuttX кода обратно в систему без ОС
/// добавим возможность использовать posix вызовы для некоторых "файлов"

#ifndef VFS_OVER_NEWLIB_H_INCLUDED
#define VFS_OVER_NEWLIB_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора

#ifndef MAX_SYS_FILES
#define MAX_SYS_FILES     8
#endif


#define VFS_MODE_READ           0x0001                  ///< Можно читать
#define VFS_MODE_WRITE          0x0002                  ///< Можно писать
#define VFS_MODE_RDWR           (VFS_READ | VFS_WRITE)  ///< Можно читать и писать
#define VFS_MODE_ACCESS_MASK    0x000F

#define VFS_MODE_CHAR           0x0010                  ///< Символьное устройство или файл
#define VFS_MODE_BLOCK          0x0020                  ///< Блочное устройство
#define VFS_MODE_DEVTYPE_MASK   0x00F0                  ///< Маска типа устройства

#define VFS_MODE_TTY            0x0100                  ///< Последовательный порт, терминал
#define VFS_MODE_SEEKABLE       0x0200                  ///< Поддерживает перемещение


#define VFS_MODE_STDIN          0x1000                  ///< Данный файл получит fd=0
#define VFS_MODE_STDOUT         0x2000                  ///< Данный файл получит fd=1
#define VFS_MODE_STDERR         0x3000                  ///< Данный файл получит fd=2
#define VFS_MODE_STDxxx_MASK    0x3000                  ///< Маска для файлов с фиксированным fd


////////////////////////////////////////////////////////////////////////////
//  Типы данных

typedef struct file_ops_s   file_ops_t;

/// Файловый дескриптор
typedef struct file_s {
  int32_t             flags;    ///< Флаги, использованные при открытии и служебные
  int32_t             size;     ///< Размер файла ( >= 0 - если известен, < 0 - если поточный)
  int32_t             capacity; ///< Максимальный размер файла (<0 - поточный, без ограничения)
  int32_t             pos;      ///< Текущее смещение в файле
  void*               priv;     ///< Указатель на внутренние данные файла/драйвера
} file_t;

/// Таблица функций для "файлового" драйвера.
struct file_ops_s {
  int   (*open) (file_t* file);
  int   (*close)(file_t* file);
  int   (*read) (file_t* file, char* ptr, int len);
  int   (*write)(file_t* file, const char* ptr, int len);
  int   (*fstat)(file_t* file, struct stat *st);
  off_t (*lseek)(file_t* file, off_t offset, int whence);
};

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

void  vfs_init(void);
int   vfs_register(const char* path, const file_ops_t* vmt, void* priv, int mode);
int   vfs_open(const char* path, int flags, int mode);
int   vfs_close(int fd);
off_t vfs_lseek(int fd, off_t offset, int whence);
int   vfs_write(int fd, const char* ptr, int len);
int   vfs_read(int fd, char* ptr, int len);
int   vfs_stat(const char* path, struct stat* st);
int   vfs_fstat(int fd, struct stat* st);
int   vfs_isatty(int fd);
int   vfs_link(const char* oldpath, const char* newpath);
int   vfs_unlink(const char* pathname);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // VFS_OVER_NEWLIB_H_INCLUDED
