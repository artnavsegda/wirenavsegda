/// @file all_gpio_pins.h
/// @author DL <dmitriy.linikov@gmail.com>
/// @brief данный файл служит для выбора нужного файла описания портов ввода-вывода для платы 2.7.

#include "stm32f2xx_qfp144_gpio_pins.h"
