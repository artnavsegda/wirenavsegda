/// @file board_3_0.h
/// @author DL <dmitriy.linikov@gmail.com>
/// @brief Определение констант, специфичных для платы 3.0

#ifndef BOARD_3_0_H_INCLUDED
#define BOARD_3_0_H_INCLUDED

#include "stm32f2xx.h"
#include "stm32f2xx_conf.h"
#include "system_stm32f2xx.h"

#include "gpio.h"
#include "all_gpio_pins.h"
#include "telemetron/board_config.h"


#include <pushbutton.h>
#include <indication/red_green_led.h>
#include <telemetron/bootloader_support.h>

#ifndef MODEM_VERSION_30
#define MODEM_VERSION_30
#endif // MODEM_VERSION_30

#define BOARD_NAME    "Telemetron 3.0 board"
#define BOARD_ID      0x00020007

/// Частоты таймеров
// период работы таймера отсчета одной минуты (число секунд в минуту)
#define ONE_MIN_TIMER      60.0f
// период работы системного таймера (в секундах)
#define SYSTEM_TIMER       0.001f
// период работы таймера периферии (в секундах)
#define PERIPHERY_TIMER    0.1f

#define TIM5_freq          (1.0f/ONE_MIN_TIMER)
#define TIM6_freq          (1.0f/PERIPHERY_TIMER)
#define TIM7_freq          (1.0f/SYSTEM_TIMER)

///----------------------

#define UART1_TX      &PA9
#define UART1_RX      &PA10

#define UART3_TX      &PC10
#define UART3_RX      &PB11



/// Расстановка приоритетов прерываний
// прерывание GSM модуля
#define SIM_PORT_PRIORITY               1
// прерывание  шины MDB/EXE
#define MDB_EXE_PORT_PRIORITY           2
// прерывание системного таймера и обработчика систм ввода/вывода
#define SYSTEM_TIMER_PRIORITY           3
// прерывание порта DEX
#define DEX_PORT_PRIORITY               5
// прервание отладочного порта
#define DEBUG_PORT_PRIORITY             10
// прерывание таймера 10 Гц (обрабтчик контроля напряжения и датчика удара)
#define SERVICE_TIMER_PRIORITY          12
// прервание минутного таймеhа
#define MINUTE_TIMER_PRIORITY           13
///====================================


// Определение понятных имён для выводов GPIO

#define SIM_POWER_EN            &PE5
#define SIM_PWRKEY              &PE6
#define SIM_STATUS              &PG15
#define SIM_RI                  &PG9
#define SIM_PORT                USART3
#define SIM_PORT_IRQN           USART3_IRQn
#define SIM_PORT_IRQ_HANDLER    USART3_IRQHandler
#define SIM_TX                  UART3_TX
#define SIM_RX                  UART3_RX
#define SIM_GPIO_AF             GPIO_AF_USART3


#define BUFFERED_UART_ENABLE_UART1    1

#define PORT_FLOAT              0
#define PORT_ZERO               1
#define PORT_ONE                2


#define AUX3_PORT               &SD1
#define AUX3_GPIO_AF            GPIO_AF_USART1
#define AUX3_TX                 UART1_TX
#define AUX3_RX                 UART1_RX
#define AUX3_RTS                &PA12

#define DEBUG_PORT_EN           0x01
#define DEBUG_PORT_DIS          0x00



// Определение активных уровней для каждой из кнопок
#define BTN1_PRESSED  0
#define BTN2_PRESSED  0
#define BTN3_PRESSED  0



#define I2C3_SCL      &PA8
#define I2C3_SDA      &PC9
#define I2C3_GPIO_AF  GPIO_AF_I2C3

#define DAC_OUT       &PA4
#define BUZZER        DAC_OUT

#define BTN0          &PC0


// SIM_CARD_DETECT - вход с замыканием на землю при наличии карты
#define SIM_CARD_DETECT_INSERTED  0




#define SIM_CARD_NONE             0
/// Идентификатор для SIM-карты, в разъеме SIM-карт
#define SIM_CARD_EXTERNAL1        1
/// Идентификатор для SIM-чипа
#define SIM_CARD_INTERNAL1        2

#define SIM_CARDS_COUNT           2


////////////////////////////////////////////////////////////////////////////
//  Определения Backup регистров (для совместимости с STM32F10x)
#define BKP_DR0     RTC_BKP_DR0
#define BKP_DR1     RTC_BKP_DR1
#define BKP_DR2     RTC_BKP_DR2
#define BKP_DR3     RTC_BKP_DR3
#define BKP_DR4     RTC_BKP_DR4
#define BKP_DR5     RTC_BKP_DR5
#define BKP_DR6     RTC_BKP_DR6
#define BKP_DR7     RTC_BKP_DR7
#define BKP_DR8     RTC_BKP_DR8
#define BKP_DR9     RTC_BKP_DR9
#define BKP_DR10    RTC_BKP_DR10
#define BKP_DR11    RTC_BKP_DR11
#define BKP_DR12    RTC_BKP_DR12
#define BKP_DR13    RTC_BKP_DR13
#define BKP_DR14    RTC_BKP_DR14
#define BKP_DR15    RTC_BKP_DR15
#define BKP_DR16    RTC_BKP_DR16
#define BKP_DR17    RTC_BKP_DR17
#define BKP_DR18    RTC_BKP_DR18
#define BKP_DR19    RTC_BKP_DR19



extern Pushbutton   BtnReset; // На плате 3.0 - кнопка сброса
extern Pushbutton   Btn1;
extern Pushbutton   Btn2;
extern Pushbutton   Btn3;

extern const Led    LedPower;
extern const Led    LedGsm;
extern const Led    LedServer;
extern const Led    LedDex;
extern const Led    LedMdbExe;


uint32_t ReadSupplyMillivolts(void);
int32_t ReadCoreTemperature(void);

/// \brief Переводит процессор в остановленный режим до возникновения очередного прерывания.
void WaitForEvent(void);

/// \brief Возвращает true, если sim карта с номером \p card_id подключена.
bool SimCardInserted(int card_id);
void SimCardSwitchSelectExternal(void);
void SimCardSwitchDeselect(void);
void SimCardSwitchSelect(int card_id);
void SimPortStartArgs(uint32_t baudrate, uint32_t cr1, uint32_t cr2, uint32_t cr3);
void SimPortStart(void);
void SimPortStop(void);


/// Включает порт Debug
void DebugPortSet(uint8_t port_set);
/// Сообщает о редиме рабоыт Debug порта
uint8_t DebugPortGet(void);


void BoardInit(void);
void BoardDeinit(bool full);
void BoardShutdown(bool reset) __attribute__((noreturn));
void BoardStandby(void) __attribute__((noreturn));

// Следующие функции нужны для загрузчика и прочих прошивок, где есть необходимость
// инициализировать плату поэтапно, а не всю периферию за раз.

void GpioInit(void);
void GpioDeinit(void);

void BuzzerInit(void);
void BuzzerDeinit(void);
void BoardBuzzerOn(void);
void BoardBuzzerOff(void);

void LedsInit(void);
void LedsDeinit(void);

void ButtonsInit(void);
void ButtonsDeinit(void);

void SimPortInit(void);
void SimPortDeinit(bool full);

void DebugPortInit(void);
void DebugPortDeinit(void);


void     InitBackupSram(void);
uint32_t ReadBackupRegister(unsigned reg);
void     WriteBackupRegister(unsigned reg, uint32_t value);

const mainbrd_spec_t* BoardGetMainbrdSpecs(void);
// bool BoardGetBootloaderConfiguration(bootldr_rodata_t* dst);
// bool BoardGetBootloaderState(bootldr_data_t* dst);
// bool BoardSetBootloaderState(const bootldr_data_t* src);

#endif // BOARD_3_0_H_INCLUDED
