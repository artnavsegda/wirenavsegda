/// \file int_flash.c
/// \author DL <dmitriy.linikov@gmail.com>
/// \see int_flash.h

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stm32f2xx.h>
#include "int_flash.h"



#define INTFLASH_BASE       0x08000000

typedef struct {
  uint32_t id;
  uint32_t start;
  uint32_t end;
} intflash_sector_t ;

static const intflash_sector_t INTFLASH_SECTORS[12] = {
  { FLASH_Sector_0,   0x08000000, 0x08003FFF },   // Сектор 0 - 16кБайт
  { FLASH_Sector_1,   0x08004000, 0x08007FFF },   // Сектор 1 - 16кБайт
  { FLASH_Sector_2,   0x08008000, 0x0800BFFF },   // Сектор 2 - 16кБайт
  { FLASH_Sector_3,   0x0800C000, 0x0800FFFF },   // Сектор 3 - 16кБайт
  { FLASH_Sector_4,   0x08010000, 0x0801FFFF },   // Сектор 4 - 64кБайт
  { FLASH_Sector_5,   0x08020000, 0x0803FFFF },   // Сектор 5 - 128кБайт
  { FLASH_Sector_6,   0x08040000, 0x0805FFFF },   // Сектор 6 - 128кБайт
  { FLASH_Sector_7,   0x08060000, 0x0807FFFF },   // Сектор 7 - 128кБайт
  { FLASH_Sector_8,   0x08080000, 0x0809FFFF },   // Сектор 8 - 128кБайт
  { FLASH_Sector_9,   0x080A0000, 0x080BFFFF },   // Сектор 9 - 128кБайт
  { FLASH_Sector_10,  0x080C0000, 0x080DFFFF },   // Сектор 10 - 128кБайт
  { FLASH_Sector_11,  0x080E0000, 0x080FFFFF },   // Сектор 11 - 128кБайт
};


void IntFlashWriteWord(uint32_t address, uint16_t data)
{
  FLASH_ProgramHalfWord(address, data);
}

void IntFlashWriteDWord(uint32_t address,uint32_t data)
{
  FLASH_ProgramWord(address, data);
}

void IntFlashWriteBuffer(uint32_t address, const void* data, uint32_t size)
{
  const uint8_t* src = (const uint8_t*) data;
  union {
    uint8_t bytes[2];
    uint16_t value;
  } tmp;

  if (!data || !src ) {
    return;
  }

  if (address % 2 != 0) {
    tmp.bytes[0] = 0xFF;
    tmp.bytes[1] = *src;

    IntFlashWriteWord(address-1, tmp.value);

    ++src;
    ++address;
    --size;
  }

  while (size >= 2) {
    IntFlashWriteWord(address, *(uint16_t*)src);

    src += 2;
    address += 2;
    size -= 2;
  }

  if (size) {
    tmp.bytes[0] = *src;
    tmp.bytes[1] = 0xFF;

    IntFlashWriteWord(address, *(uint16_t*)src);
  }
}

void IntFlashUnlock(uint32_t address)
{
  (void)address;  // Не используется для STM32F2xx
  FLASH_Unlock();
}

void IntFlashErasePage(uint32_t address)
{
  const intflash_sector_t* sector = NULL;
  for (size_t i=0; i < sizeof(INTFLASH_SECTORS)/sizeof(*INTFLASH_SECTORS); ++i) {
    if (address >= INTFLASH_SECTORS[i].start && address <= INTFLASH_SECTORS[i].end) {
      sector = &INTFLASH_SECTORS[i];
      break;
    }
  }

  if (!sector) {
    return;
  }

  bool dirty = false;
  for (address = sector->start; address < sector->end; address += 4) {
    if (*(uint32_t*)(address) != 0xFFFFFFFF) {
      dirty = true;
      break;
    }
  }

  if (!dirty) {
    return;
  }

  FLASH_EraseSector(sector->id, VoltageRange_3);
}

uint32_t IntFlashRead(uint32_t address)
{
  return (*(__IO uint32_t*) address);
}

void IntFlashSecureChip(uint32_t address)
{
  (void)address; // Не используется для STM32F2xx
  FLASH_OB_Unlock();
    FLASH_OB_RDPConfig(OB_RDP_Level_1);
  FLASH_OB_Lock();
}
