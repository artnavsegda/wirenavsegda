/// @file stm32f1xx_qfp100_gpio_pins.h
/// @author DL <dmitriy.linikov@gmail.com>
/// @brief Объявление всех GPIO выводов, которые доступны в контроллере
/// STM32F100М (в QFP100 корпусе)

#include "gpio.h"

#if defined(STM32F2XX_GPIO_IMPLEMENT_PINS)

// Если данный файл включается из исходного файла, в котором следует разместить
// опреледение всех GPIO выводов, то макрос DECL_PIN определяется так:

#   define DECL_PIN(port, pin_id, name, phy_pin)    \
        const GpioChannel  name = GPIO_CHANNEL((port), (pin_id))

// Создаём реализацию выводов, даже если уже были предварительно объявлены.
#   undef STM32F2XX_GPIO_MAP_INCLUDED
#else

// Если данный файл включается из заголовочного файла, то макрос DECL_PIN
// определяется как extern ссылка:
#   define DECL_PIN(port, pin_id, name, phy_pin)    extern const GpioChannel  name

#endif


#if !defined(STM32F2XX_GPIO_MAP_INCLUDED)

// GPIO каналы идут в том же порядке, что в datasheet
DECL_PIN(GPIOE,  2,  PE2,  1);
DECL_PIN(GPIOE,  3,  PE3,  2);
DECL_PIN(GPIOE,  4,  PE4,  3);
DECL_PIN(GPIOE,  5,  PE5,  4);
DECL_PIN(GPIOE,  6,  PE6,  5);
DECL_PIN(GPIOC,  13, PC13, 7);
DECL_PIN(GPIOC,  14, PC14, 8);
DECL_PIN(GPIOC,  15, PC15, 9);
DECL_PIN(GPIOF,  0,  PF0,  10);
DECL_PIN(GPIOF,  1,  PF1,  11);
DECL_PIN(GPIOF,  2,  PF2,  12);
DECL_PIN(GPIOF,  3,  PF3,  13);
DECL_PIN(GPIOF,  4,  PF4,  14);
DECL_PIN(GPIOF,  5,  PF5,  15);
DECL_PIN(GPIOF,  6,  PF6,  18);
DECL_PIN(GPIOF,  7,  PF7,  19);
DECL_PIN(GPIOF,  8,  PF8,  20);
DECL_PIN(GPIOF,  9,  PF9,  21);
DECL_PIN(GPIOF,  10, PF10, 22);
DECL_PIN(GPIOH,  0,  PH0,  23);
DECL_PIN(GPIOH,  1,  PH1,  24);
DECL_PIN(GPIOC,  0,  PC0,  26);
DECL_PIN(GPIOC,  1,  PC1,  27);
DECL_PIN(GPIOC,  2,  PC2,  28);
DECL_PIN(GPIOC,  3,  PC3,  29);
DECL_PIN(GPIOA,  0,  PA0,  34);
DECL_PIN(GPIOA,  1,  PA1,  35);
DECL_PIN(GPIOA,  2,  PA2,  36);
DECL_PIN(GPIOA,  3,  PA3,  37);
DECL_PIN(GPIOA,  4,  PA4,  40);
DECL_PIN(GPIOA,  5,  PA5,  41);
DECL_PIN(GPIOA,  6,  PA6,  42);
DECL_PIN(GPIOA,  7,  PA7,  43);
DECL_PIN(GPIOC,  4,  PC4,  44);
DECL_PIN(GPIOC,  5,  PC5,  45);
DECL_PIN(GPIOB,  0,  PB0,  46);
DECL_PIN(GPIOB,  1,  PB1,  47);
DECL_PIN(GPIOB,  2,  PB2,  48);
DECL_PIN(GPIOF,  11, PF11, 49);
DECL_PIN(GPIOF,  12, PF12, 50);
DECL_PIN(GPIOF,  13, PF13, 53);
DECL_PIN(GPIOF,  14, PF14, 54);
DECL_PIN(GPIOF,  15, PF15, 55);
DECL_PIN(GPIOG,  0,  PG0,  56);
DECL_PIN(GPIOG,  1,  PG1,  57);
DECL_PIN(GPIOE,  7,  PE7,  58);
DECL_PIN(GPIOE,  8,  PE8,  59);
DECL_PIN(GPIOE,  9,  PE9,  60);
DECL_PIN(GPIOE,  10, PE10, 63);
DECL_PIN(GPIOE,  11, PE11, 64);
DECL_PIN(GPIOE,  12, PE12, 65);
DECL_PIN(GPIOE,  13, PE13, 66);
DECL_PIN(GPIOE,  14, PE14, 67);
DECL_PIN(GPIOE,  15, PE15, 68);
DECL_PIN(GPIOB,  10, PB10, 69);
DECL_PIN(GPIOB,  11, PB11, 70);
DECL_PIN(GPIOB,  12, PB12, 73);
DECL_PIN(GPIOB,  13, PB13, 74);
DECL_PIN(GPIOB,  14, PB14, 75);
DECL_PIN(GPIOB,  15, PB15, 76);
DECL_PIN(GPIOD,  8,  PD8,  77);
DECL_PIN(GPIOD,  9,  PD9,  78);
DECL_PIN(GPIOD,  10, PD10, 79);
DECL_PIN(GPIOD,  11, PD11, 80);
DECL_PIN(GPIOD,  12, PD12, 81);
DECL_PIN(GPIOD,  13, PD13, 82);
DECL_PIN(GPIOD,  14, PD14, 85);
DECL_PIN(GPIOD,  15, PD15, 86);
DECL_PIN(GPIOG,  2,  PG2,  87);
DECL_PIN(GPIOG,  3,  PG3,  88);
DECL_PIN(GPIOG,  4,  PG4,  89);
DECL_PIN(GPIOG,  5,  PG5,  90);
DECL_PIN(GPIOG,  6,  PG6,  91);
DECL_PIN(GPIOG,  7,  PG7,  92);
DECL_PIN(GPIOG,  8,  PG8,  93);
DECL_PIN(GPIOC,  6,  PC6,  96);
DECL_PIN(GPIOC,  7,  PC7,  97);
DECL_PIN(GPIOC,  8,  PC8,  98);
DECL_PIN(GPIOC,  9,  PC9,  99);
DECL_PIN(GPIOA,  8,  PA8,  100);
DECL_PIN(GPIOA,  9,  PA9,  101);
DECL_PIN(GPIOA,  10, PA10, 102);
DECL_PIN(GPIOA,  11, PA11, 103);
DECL_PIN(GPIOA,  12, PA12, 104);
DECL_PIN(GPIOA,  13, PA13, 105);
DECL_PIN(GPIOA,  14, PA14, 109);
DECL_PIN(GPIOA,  15, PA15, 110);
DECL_PIN(GPIOC,  10, PC10, 111);
DECL_PIN(GPIOC,  11, PC11, 112);
DECL_PIN(GPIOC,  12, PC12, 113);
DECL_PIN(GPIOD,  0,  PD0,  114);
DECL_PIN(GPIOD,  1,  PD1,  115);
DECL_PIN(GPIOD,  2,  PD2,  116);
DECL_PIN(GPIOD,  3,  PD3,  117);
DECL_PIN(GPIOD,  4,  PD4,  118);
DECL_PIN(GPIOD,  5,  PD5,  119);
DECL_PIN(GPIOD,  6,  PD6,  122);
DECL_PIN(GPIOD,  7,  PD7,  123);
DECL_PIN(GPIOG,  9,  PG9,  124);
DECL_PIN(GPIOG,  10, PG10, 125);
DECL_PIN(GPIOG,  11, PG11, 126);
DECL_PIN(GPIOG,  12, PG12, 127);
DECL_PIN(GPIOG,  13, PG13, 128);
DECL_PIN(GPIOG,  14, PG14, 129);
DECL_PIN(GPIOG,  15, PG15, 132);
DECL_PIN(GPIOB,  3,  PB3,  133);
DECL_PIN(GPIOB,  4,  PB4,  134);
DECL_PIN(GPIOB,  5,  PB5,  135);
DECL_PIN(GPIOB,  6,  PB6,  136);
DECL_PIN(GPIOB,  7,  PB7,  137);
DECL_PIN(GPIOB,  8,  PB8,  139);
DECL_PIN(GPIOB,  9,  PB9,  140);
DECL_PIN(GPIOE,  0,  PE0,  141);
DECL_PIN(GPIOE,  1,  PE1,  142);


#define STM32F2XX_GPIO_MAP_INCLUDED
#undef DECL_PIN

#endif // !defined(STM32F2XX_GPIO_MAP_INCLUDED)
