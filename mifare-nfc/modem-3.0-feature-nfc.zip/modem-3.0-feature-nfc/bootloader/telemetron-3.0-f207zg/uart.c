/// \file uart.c
/// \author DL <dmitriy.linikov@gmail.com>
/// \see uart.h

#include "uart.h"
#include "timeout.h"
#include <system_stm32f2xx.h>
#include <stm32f2xx.h>

void uart_init(USART_TypeDef* port, uint32_t baudrate, uint32_t cr1, uint32_t cr2, uint32_t cr3) {
  if (port == USART1) {
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
  } else if (port == USART2) {
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
  } else if (port == USART3) {
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
  } else if (port == UART4) {
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);
  } else if (port == UART5) {
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5, ENABLE);
  } else if (port == USART6) {
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART6, ENABLE);
  } else {
    return;
  }

  port->CR1 &= ~USART_CR1_UE;
  uart_set_baudrate(port, baudrate);

  port->CR1 = cr1;
  port->CR2 = cr2;
  port->CR3 = cr3;

  port->CR1 |= USART_CR1_UE;
}

void uart_deinit(USART_TypeDef* port)
{
  port->CR1 = 0;
  if (port == USART1) {
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, DISABLE);
  } else if (port == USART2) {
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, DISABLE);
  } else if (port == USART3) {
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, DISABLE);
  } else if (port == UART4) {
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, DISABLE);
  } else if (port == UART5) {
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5, DISABLE);
  } else if (port == USART6) {
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART6, DISABLE);
  } else {
    return;
  }

}


void uart_set_baudrate(USART_TypeDef* port, uint32_t baudrate) {
  // В данном случае считаем, что частота шин APB1/APB2 совпадает с
  // частотой системных часов. Это верно только в текущих настройках проекта.
  uint32_t clock=0;
  if (port == USART1) {
      clock = GET_APB2_CLOCK();
  } else if (port == USART2) {
      clock = GET_APB1_CLOCK();
  } else if (port == USART3) {
      clock = GET_APB1_CLOCK();
  } else if (port == UART4) {
      clock = GET_APB1_CLOCK();
  } else if (port == UART5) {
      clock = GET_APB1_CLOCK();
  } else if (port == USART6) {
      clock = GET_APB2_CLOCK();
  } else {
      clock = SystemCoreClock;
  }
  uint32_t  divider = clock / baudrate;

  uint32_t  save_CR1 = port->CR1;
  port->CR1 = 0;//&=~ USART_CR1_UE;
  port->BRR = divider;
  port->CR1 = save_CR1;//|= USART_CR1_UE;
}


void uart_putc(USART_TypeDef* port, int value) {
  while (!(port->SR & USART_SR_TXE));
  port->DR = (uint8_t)value;
}

void uart_puts(USART_TypeDef* port, const char* data) {
  while(*data) {
    uart_putc(port, *data++);
  }
}

void uart_puts_cr(USART_TypeDef* port, const char* data) {
  uart_puts(port, data);
  uart_putc(port, '\r');
}

void uart_puts_crlf(USART_TypeDef* port, const char* data) {
  uart_puts_cr(port, data);
  uart_putc(port, '\n');
}

void uart_write(USART_TypeDef* port, const void* data, size_t size) {
  const uint8_t* ptr = data;
  while(size--) {
    uart_putc(port, *ptr++);
  }
}

bool uart_rx_ready(USART_TypeDef* port) {
  return (port->SR & USART_SR_RXNE) != 0;
}

bool uart_tx_ready(USART_TypeDef* port) {
  return (port->SR & USART_SR_TXE) != 0;
}


int uart_getc_immediate(USART_TypeDef* port) {
  if (!uart_rx_ready(port)) {
    return UART_ERR_TIMEOUT;
  }
  return (uint8_t)port->DR;
}

int uart_getc(USART_TypeDef* port) {
  while(!uart_rx_ready(port)) {
    // do nothing.
  }
  return (uint8_t)port->DR;
}

int uart_getc_parity(USART_TypeDef* port) {
  while(!uart_rx_ready(port)) {
    // do nothing
  }
  return (uint16_t)port->DR;
}

int uart_getc_parity_immediate(USART_TypeDef* port) {
  if (!uart_rx_ready(port)) {
    return UART_ERR_TIMEOUT;
  }
  uint16_t frame_err=(port->SR&USART_SR_FE)?UART_ERR_FRAME:0x0000;
  return (uint16_t)(port->DR|frame_err);
}

int uart_getc_timeout_ex(USART_TypeDef* port, timeout_t* timeout)
{
  do {
    if (uart_rx_ready(port)) {
      return (uint16_t)port->DR;
    }
  } while (!timeout_is_elapsed(timeout) );
  return UART_ERR_TIMEOUT;
}

int uart_getc_timeout(USART_TypeDef* port, systime_t timeout)
{
  timeout_t state;
  timeout_start(&state, timeout);
  return uart_getc_timeout_ex(port, &state);
}


size_t uart_read_timeout_ex(USART_TypeDef* port, void* dst, size_t size,
                            timeout_t* timeout)
{
  uint8_t*    ptr = dst;
  size_t      rx_size = 0;

  while (rx_size != size && !timeout_is_elapsed(timeout)) {
    if (uart_rx_ready(port)) {
      *ptr++ = uart_getc(port);
      --size;
    }
  }
  return rx_size;

}

size_t uart_read_timeout(USART_TypeDef* port, void* dst, size_t size,
                         systime_t timeout)
{
  timeout_t   t;
  timeout_start(&t, timeout);
  return uart_read_timeout_ex(port, dst, size, &t);
}

size_t uart_read(USART_TypeDef* port, void* dst, size_t size)
{
  return uart_read_timeout(port, dst, size, TIMEOUT_FOREVER);
}
