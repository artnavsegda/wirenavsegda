/// @file gpio.c
/// @author DL <dmitriy.linikov@gmail.com>

#include "gpio.h"


#define GPIO_IDR_MASK(pad)            (0x0001 << (pad)->pin_id)
// #define GPIO_CRL_MASK(pad)            (0x0000000F << (4 * (pad)->pin_id))
// #define GPIO_CRH_MASK(pad)            (0x0000000F << (4 * ((pad)->pin_id - 8)))
// #define GPIO_CR_VALUE(id,cnf,mode)    (uint32_t)((mode) | (cnf)) << ((id) * 4)
// #define GPIO_CRL_VALUE(pad,cnf,mode)  GPIO_CR_VALUE((pad)->pin_id, (cnf), (mode))
// #define GPIO_CRH_VALUE(pad,cnf,mode)  GPIO_CR_VALUE((pad)->pin_id-8, (cnf), (mode))


/// \brief Устанавливает GPIO вывод \p pad в высокое состояние (Vdd).
void GpioSet(const GpioChannel* pad)
{
  if (!pad || !pad->port) {
    return;
  }
  pad->port->BSRRL = (1u << pad->pin_id);
}

/// \brief Устанавливает GPIO вывод \p pad в низкое состояние (GND).
void GpioClear(const GpioChannel* pad)
{
  if (!pad || !pad->port) {
    return;
  }

  pad->port->BSRRH = (1u << pad->pin_id);
}

/// \brief Устанавливает новое значение GPIO вывода \p pad в 1 или 0
/// в соответствии со значением параметра \p new_value.
void GpioWrite(const GpioChannel* pad, bool new_value)
{
  if (!pad || !pad->port) {
    return;
  }

  if (new_value) {
    pad->port->BSRRL = (1u << pad->pin_id);
  } else {
    pad->port->BSRRH = (1u << pad->pin_id);
  }
}

/// \brief Возвращает значение (1 или 0) GPIO входа \p pad.
bool GpioRead(const GpioChannel* pad)
{
  if (!pad || !pad->port) {
    return false;
  }

  return !!(pad->port->IDR & GPIO_IDR_MASK(pad));
}

/// \brief Устанавливает новые настройки GPIO каналу \p pad.
void GpioConfigure(const GpioChannel* pad, const GpioConfig* config)
{
  if (!pad || !pad->port || !config || pad->pin_id > 15) {
    return ;
  }

  GPIO_TypeDef* port  = pad->port;
  int           pin   = pad->pin_id;
  int           pin2  = pin*2;
  uint8_t       mode  = config->mode;
  uint8_t       af    = config->af;


  port->MODER     = (port->MODER    & ~(0x3 << pin2)) | (GPIO_GET_MODER(mode) << pin2);
  port->OSPEEDR   = (port->OSPEEDR  & ~(0x3 << pin2)) | (GPIO_GET_OSPEEDR(mode) << pin2);
  port->OTYPER    = (port->OTYPER   & ~(0x1 << pin))  | (GPIO_GET_OTYPER(mode) << pin);
  port->PUPDR     = (port->PUPDR    & ~(0x2 << pin2)) | (GPIO_GET_PUPDR(mode) << pin2);


  port->AFR[pin >> 3] &= ~(0xF << ((pin & 0x7)*4));
  port->AFR[pin >> 3] |= (af & 0xF) << ((pin & 0x7)*4);
}

/// \brief Устанавливает новые настройки GPIO каналу, используя отдельные
/// параметры.
/// \param pad            Дескриптор GPIO канала
/// \param mode           Режим работы GPIO канала
/// \param af             Номер альтернативной функции - для режимов GPIO_MODE_ALT_xxx
/// \param initial_value  Значение, которое следует установить после настройки.
///                       (в случае Pull-Up/Pull-Down канала выбирает подтяжку:
///                        0 - к земле, 1 - к напряжению питания).
void GpioConfigArgs(const GpioChannel* pad,
                    GpioMode           mode,
                    uint8_t            af,
                    bool               initial_value)
{
  GpioConfig  config = {mode, af};
  GpioConfigure(pad, &config);
  GpioWrite(pad, initial_value);
}
