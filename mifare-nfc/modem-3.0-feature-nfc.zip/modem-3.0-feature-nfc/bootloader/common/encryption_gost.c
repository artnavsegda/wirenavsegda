/// \file encryption_gost.c
/// \author DL <dmitriy.linikov@gmail.com>
/// \see encryption_gost.h

#include <encryption_gost.h>

#include <string.h>
#include <utils/string_utils.h>


// <DL> Здесь кусок спираченного исходника без комментариев
// http://beginners.re/exercise-solutions/3/2/gost.c
// Подтянул недостающие куски.
/*
 * The standard does not specify the contents of the 8 4 bit->4 bit
 * substitution boxes, saying they're a parameter of the network
 * being set up.  For illustration purposes here, I have used
 * the first rows of the 8 S-boxes from the DES.  (Note that the
 * DES S-boxes are numbered starting from 1 at the msb.  In keeping
 * with the rest of the GOST, I have used little-endian numbering.
 * Thus, k8 is S-box 1.
 *
 * Obviously, a careful look at the cryptographic properties of the cipher
 * must be undertaken before "production" substitution boxes are defined.
 *
 * The standard also does not specify a standard bit-string representation
 * for the contents of these blocks.
 */
static unsigned char const k8[16] = {
  14,  4, 13,  1,  2, 15, 11,  8,  3, 10,  6, 12,  5,  9,  0,  7 };
static unsigned char const k7[16] = {
  15,  1,  8, 14,  6, 11,  3,  4,  9,  7,  2, 13, 12,  0,  5, 10 };
static unsigned char const k6[16] = {
  10,  0,  9, 14,  6,  3, 15,  5,  1, 13, 12,  7, 11,  4,  2,  8 };
static unsigned char const k5[16] = {
   7, 13, 14,  3,  0,  6,  9, 10,  1,  2,  8,  5, 11, 12,  4, 15 };
static unsigned char const k4[16] = {
   2, 12,  4,  1,  7, 10, 11,  6,  8,  5,  3, 15, 13,  0, 14,  9 };
static unsigned char const k3[16] = {
  12,  1, 10, 15,  9,  2,  6,  8,  0, 13,  3,  4, 14,  7,  5, 11 };
static unsigned char const k2[16] = {
  4, 11,  2, 14, 15,  0,  8, 13,  3, 12,  9,  7,  5, 10,  6,  1 };
static unsigned char const k1[16] = {
  13,  2,  8,  4,  6, 15, 11,  1, 10,  9,  3, 14,  5,  0, 12,  7 };

/* Byte-at-a-time substitution boxes */
static unsigned char k87[256];
static unsigned char k65[256];
static unsigned char k43[256];
static unsigned char k21[256];

/// \todo Заменить k87 ... k21 на константы и освободить 2 кБ оперативной памяти

/*
 * Build byte-at-a-time subtitution tables.
 * This must be called once for global setup.
 */
void
kboxinit(void)
{
  int i;
  for (i = 0; i < 256; i++) {
    k87[i] = k8[i >> 4] << 4 | k7[i & 15];
    k65[i] = k6[i >> 4] << 4 | k5[i & 15];
    k43[i] = k4[i >> 4] << 4 | k3[i & 15];
    k21[i] = k2[i >> 4] << 4 | k1[i & 15];
  }
}

/*
 * Do the substitution and rotation that are the core of the operation,
 * like the expansion, substitution and permutation of the DES.
 * It would be possible to perform DES-like optimisations and store
 * the table entries as 32-bit words, already rotated, but the
 * efficiency gain is questionable.
 *
 * This should be inlined for maximum speed
 */
#if __GNUC__
__inline__
#endif
static uint32_t
f(uint32_t x)
{
  /* Do substitutions */
#if 0
  /* This is annoyingly slow */
  x = k8[x>>28 & 15] << 28 | k7[x>>24 & 15] << 24 |
      k6[x>>20 & 15] << 20 | k5[x>>16 & 15] << 16 |
      k4[x>>12 & 15] << 12 | k3[x>> 8 & 15] <<  8 |
      k2[x>> 4 & 15] <<  4 | k1[x     & 15];
#else
  /* This is faster */
  x = k87[x>>24 & 255] << 24 | k65[x>>16 & 255] << 16 |
      k43[x>> 8 & 255] <<  8 | k21[x & 255];
#endif

  /* Rotate left 11 bits */
  return x<<11 | x>>(32-11);
}

/*
 * The GOST standard defines the input in terms of bits 1..64, with
 * bit 1 being the lsb of in[0] and bit 64 being the msb of in[1].
 *
 * The keys are defined similarly, with bit 256 being the msb of key[7].
 */
void gostcrypt(uint32_t out[2], uint32_t const in[2], uint32_t const key[8])
{
  register uint32_t n1, n2; /* As named in the GOST */

  n1 = in[0];
  n2 = in[1];

  n2 ^= f(n1+key[0]);
  n1 ^= f(n2+key[1]);
  n2 ^= f(n1+key[2]);
  n1 ^= f(n2+key[3]);
  n2 ^= f(n1+key[4]);
  n1 ^= f(n2+key[5]);
  n2 ^= f(n1+key[6]);
  n1 ^= f(n2+key[7]);

  n2 ^= f(n1+key[0]);
  n1 ^= f(n2+key[1]);
  n2 ^= f(n1+key[2]);
  n1 ^= f(n2+key[3]);
  n2 ^= f(n1+key[4]);
  n1 ^= f(n2+key[5]);
  n2 ^= f(n1+key[6]);
  n1 ^= f(n2+key[7]);

  n2 ^= f(n1+key[0]);
  n1 ^= f(n2+key[1]);
  n2 ^= f(n1+key[2]);
  n1 ^= f(n2+key[3]);
  n2 ^= f(n1+key[4]);
  n1 ^= f(n2+key[5]);
  n2 ^= f(n1+key[6]);
  n1 ^= f(n2+key[7]);

  n2 ^= f(n1+key[7]);
  n1 ^= f(n2+key[6]);
  n2 ^= f(n1+key[5]);
  n1 ^= f(n2+key[4]);
  n2 ^= f(n1+key[3]);
  n1 ^= f(n2+key[2]);
  n2 ^= f(n1+key[1]);
  n1 ^= f(n2+key[0]);

  out[0] = n2;
  out[1] = n1;
}

/*
 * The key schedule is somewhat different for decryption.
 * (The key table is used once forward and three times backward.)
 * You could define an expanded key, or just write the code twice,
 * as done here.
 */
void gostdecrypt(uint32_t const in[2], uint32_t out[2], uint32_t const key[8])
{
  register uint32_t n1, n2; /* As named in the GOST */

  n1 = in[0];
  n2 = in[1];

  n2 ^= f(n1+key[0]);
  n1 ^= f(n2+key[1]);
  n2 ^= f(n1+key[2]);
  n1 ^= f(n2+key[3]);
  n2 ^= f(n1+key[4]);
  n1 ^= f(n2+key[5]);
  n2 ^= f(n1+key[6]);
  n1 ^= f(n2+key[7]);

  n2 ^= f(n1+key[7]);
  n1 ^= f(n2+key[6]);
  n2 ^= f(n1+key[5]);
  n1 ^= f(n2+key[4]);
  n2 ^= f(n1+key[3]);
  n1 ^= f(n2+key[2]);
  n2 ^= f(n1+key[1]);
  n1 ^= f(n2+key[0]);

  n2 ^= f(n1+key[7]);
  n1 ^= f(n2+key[6]);
  n2 ^= f(n1+key[5]);
  n1 ^= f(n2+key[4]);
  n2 ^= f(n1+key[3]);
  n1 ^= f(n2+key[2]);
  n2 ^= f(n1+key[1]);
  n1 ^= f(n2+key[0]);

  n2 ^= f(n1+key[7]);
  n1 ^= f(n2+key[6]);
  n2 ^= f(n1+key[5]);
  n1 ^= f(n2+key[4]);
  n2 ^= f(n1+key[3]);
  n1 ^= f(n2+key[2]);
  n2 ^= f(n1+key[1]);
  n1 ^= f(n2+key[0]);

  out[0] = n2;
  out[1] = n1;
}


void gost_encrypt_bytes(uint8_t out[8], uint8_t const in[8],
                        uint32_t const key[8])
{
  // по факту достаточно было просто скастовать к (uint32_t*), но, тогда
  // будет обратный порядок байт, поэтому придется делать полную перетасовку.
  uint32_t input[2] = {(in[0] << 24) | (in[1] << 16) | (in[2] << 8) | in[3],
                       (in[4] << 24) | (in[5] << 16) | (in[6] << 8) | in[7]};
  uint32_t output[2];

  gostcrypt(output, input, key);
  out[0] = (output[0] >> 24) & 0xFF;
  out[1] = (output[0] >> 16) & 0xFF;
  out[2] = (output[0] >> 8)  & 0xFF;
  out[3] = output[0] & 0xFF;
  out[4] = (output[1] >> 24) & 0xFF;
  out[5] = (output[1] >> 16) & 0xFF;
  out[6] = (output[1] >> 8)  & 0xFF;
  out[7] = output[1] & 0xFF;
}

/// \brief Осуществляет шифрование буффера \p src с длиною \p length используя
/// алгоритм ГОСТ с ключом \p key, после чего преобразует полученное значение
/// в HEX строку и помещает результат в буффер \p dst.
void gost_encrypt_bytes_to_hex(void* dst, const void* src, size_t length,
                               uint32_t const key[8])
{
  char*             destination = dst;
  const uint8_t*    source = src;
  uint8_t           encrypted[8];
  uint8_t           tmp[8];

  while(length > 8) {
    // Кодирование основной части данных
    gost_encrypt_bytes(encrypted, source, key);
    CopyHexBytesToString(destination, encrypted, 8);

    source += 8;
    length -= 8;
    destination += 16; // т.к. в HEX нужно по 2 символа на один байт.
  }

  if (length) {
    // кодирование оставшихся данных, когда осталось меньше 8 байт
    memcpy(tmp, source, length);        // заполнение оставшихся данных
    memset(tmp + length, 0, 8-length);  // и забой нулём неиспользованного места
    gost_encrypt_bytes(encrypted, tmp, key);
    CopyHexBytesToString(destination, encrypted, 8);
  }
}
