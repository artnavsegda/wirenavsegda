/// @file system_utils.h
/// @author DL <dmitriy.linikov@gmail.com>
/// @brief Системные утилиты, такие, как остановка работы, рестарт, заглушки для
/// системных вызовов компиллятора, и т.д.

#ifndef SYSTEM_UTILS_H_INCLUDED
#define SYSTEM_UTILS_H_INCLUDED

#include "dbg.h"

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

#ifdef __GNUC__
// Даём понять gcc компиллятору, что помеченная данным макросом функция
// ни когда не завершается, что бы он мог отпимизировать её вызов.
#define ATTRIBUTE_NORETURN  __attribute__((noreturn))
#else
// Не мешаем работать другим компилляторам, которые не знают,
// что такое аттрибуты.
#define ATTRIBUTE_NORETURN
#define __attribute__(a)
#endif

/// \brief Глобальная переменная, указывающая на причину остановки прошивки.
extern const char* g_halt_reason;

/// \brief Останавливает работу прошивки с указанием причины остановки.
/// В зависимости от реализации может описание либо выводить в какой-либо
/// порт, либо просто сохранять для возможности проверки отладчиком.
void HaltWithReason(const char* reason, SW_State state, bool reset) ATTRIBUTE_NORETURN;

/// \brief Необходимая для компилляции заглушка для стандартной библиотеки -
/// Вызывается при выходе из main().
void _exit(int code) ATTRIBUTE_NORETURN;

/// Оставляет включенным питание RTC часов
void SystemRTCEnabled(bool power_down);

/// перевод числа Big-Little endian 16 бит
uint16_t Change_BL_Endian_UINT16(uint16_t input);
/// перевод числа Big-Little endian 32 бита
uint32_t Change_BL_Endian_UINT32(uint32_t input);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // SYSTEM_UTILS_H_INCLUDED
