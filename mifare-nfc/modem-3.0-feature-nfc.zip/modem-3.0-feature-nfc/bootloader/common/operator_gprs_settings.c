/// \file operator_gprs_settings.c
/// \author DL <dmitriy.linikov@gmail.com>
/// \see operator_gprs_settings.h

#include <stdlib.h>
#include <ccan/array_size/array_size.h>
#include <utils/string_utils.h>
#include "operator_gprs_settings.h"

static const GsmOperatorGprsSettings  operators[] = {
  { .ccid_prefix    = "8970101",
    .operator_name  = "MTS",
    .apn            = "internet",
    .apn2           = "internet",
    .user           = " ",
    .pwd            = " "
  },

  { .ccid_prefix    = "8970102",
    .operator_name  = "Megafon",
    .apn            = "internet",
    .apn2           = "internet",
    .user           = " ",
    .pwd            = " "
  },

  { .ccid_prefix    = "8970199",
    .operator_name  = "Beeline",
    .apn            = "m2m.beeline.ru",
    .apn2           = "internet.beeline.ru",
    .user           = " ",
    .pwd            = " "
  },

  { .ccid_prefix    = "8970120",
    .operator_name  = "Tele2",
    .apn            = "internet.tele2.ru",
    .apn2           = "internet.tele2.ru",
    .user           = " ",
    .pwd            = " "
  },

  { .ccid_prefix    = "8999777",
    .operator_name  = "Tele2 KZ",
    .apn            = "internet.tele2.kz",
    .apn2           = "internet.tele2.kz",
    .user           = " ",
    .pwd            = " "
  },
  // Молдова Orange Telecom
  { .ccid_prefix    = "8937301",
    .operator_name  = "Orange Telecom MD",
    .apn            = "internet",
    .apn2           = "internet",
    .user           = " ",
    .pwd            = " "
  },
  // Туркменистан tmcell
  { .ccid_prefix    = "8999302",
    .operator_name  = "TMCELL TM",
    .apn            = "gprs.tmcell",
    .apn2           = "gprs.tmcell",
    .user           = " ",
    .pwd            = " "
  },
  // Туркменистан MTS
  { .ccid_prefix    = "8999301",
    .operator_name  = "MTS TM",
    .apn            = "net.mts.tm",
    .apn2           = "net.mts.tm",
    .user           = " ",
    .pwd            = " "
  }
};

const GsmOperatorGprsSettings* GetOperatorInfoByCcid(const char* ccid)
{
  for (size_t i=0; i < ARRAY_SIZE(operators); ++i) {
    if (StartsWith(ccid, operators[i].ccid_prefix)) {
      return &operators[i];
    }
  }
  return NULL;
}
