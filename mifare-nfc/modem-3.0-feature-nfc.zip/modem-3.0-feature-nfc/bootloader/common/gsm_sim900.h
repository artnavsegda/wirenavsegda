/// \file gsm_sim900.h
/// \author DL <dmitriy.linikov@gmail.com>
/// \brief Функции для работы с GSM модулем SIM900.

#ifndef GSM_SIM900_H_INCLUDED
#define GSM_SIM900_H_INCLUDED

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdarg.h>

#include <board.h>

#include "time_utils.h"

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus


#define CLEAR_RXBUFFER          true
#define DONT_CLEAR_RXBUFFER     false

// Длительность импульса SMS сообщения (5мС запас)
#define SIM900_SMS_IMPULSE        200//125

#define RI_NOT_ACTIVE           true
#define RI_ACTIVE               false

extern bool signal_ri;


/// \brief Структура, описывающая настройки драйвера sim900.
typedef struct Sim900ConfigTag {
  /// \brief Указатель на используемый порт
  USART_TypeDef*    port;

  /// \brief Указатель на буффер, выделенный для работы драйвера sim900.
  uint8_t*          rx_buffer;

  /// \brief Размер буффера, выделенного для работы драйвера sim900.
  size_t            rx_buffer_size;
#ifdef CFG_FW_TCPIP
  /// указатель на функцию обновления (внешняя)
  bool              (*data_react)(void);
#endif // CFG_FW_TCPIP
} Sim900Config;


/// \brief Структура, описывающая входящее SMS сообщение.
typedef struct Sim900SmsInfoTag {
  /// \brief Номер отправителя.
  const char* originating_address;

  /// \brief Текст сообщения.
  const char* message_text;
} Sim900SmsInfo, sms_info_t;

typedef enum {
  IP_STATE_UNKNOWN,
  IP_STATE_INITIAL,
  IP_STATE_START,
  IP_STATE_CONFIG,
  IP_STATE_GPRSACT,
  IP_STATE_STATUS,
  IP_STATE_CONNECTING,
  IP_STATE_LISTENING,
  IP_STATE_CONNECTED,
  IP_STATE_CLOSING,
  IP_STATE_CLOSED,
  IP_STATE_PDP_DEACT
} Sim900IpState;

typedef enum {
  SIM_FUNC_MINIMAL=0,
  SIM_FUNC_NORMAL=1,
  SIM_FUNC_DISABLE_RADIO_RX_TX=4
} Sim900Functionality;

typedef enum {
  SIM_MODULE_UNKNOW=0,
  SIM_MODULE_SIM900,
  SIM_MODULE_SIM800,
  SIM_MODULE_ERROR,
} Sim900ModuleInfo;

/// \brief Функция, вызываемая при приёме очередного символа от GSM модуля.
/// Должна вызываться из обработчика прерывания нужного UART порта.
/// Сделана как быстрый костыль для отделения кода работы с GSM модулем
/// от основной прошивки.
void __sim900_on_rx_char(uint8_t value);

/// \brief Устанавливает флаг, что модем включен.
/// Этот флаг нужен для того, что бы внешний код не пытался общаться с модемом
/// до непосредственного включения модема.
void sim900_turn_on();
void sim900_turn_off();
bool sim900_is_on();
/// \brief Сбрасывает буффер приёма.
void sim900_clear_buffer();

/// \brief Устанавливает настройки драйвера sim900.
void sim900_init(Sim900Config* config);

/// \brief Выполняет команду AT
bool sim900_ping(void);

/// \brief Ожидание готовности GSM модуля к приёму команд.
bool sim900_wait_ready(size_t retries);

/// \brief отключает эхо-ответ GSM модуля.
bool sim900_disable_echo(void);

/// \brief Устанавливает режим функционирования GSM модуля.
bool sim900_set_functionality(Sim900Functionality mode, bool reset);

/// \brief Проверяет готовность SIM карты.
bool sim900_is_sim_ready(void);

/// \brief Делает до \p retries проверок готовности SIM карты с интервалом
/// в 500 мс.
/// \return Возвращает true, если SIM карта готова.
bool sim900_wait_sim_ready(size_t retries);

/// \brief Запрашивает текущее время у GSM модуля. В случае успеха сохраняет
/// указатель на строку с текущим временем в переменную по адресу \p dst.
bool sim900_get_time(UnpackedTime* dst);

/// \brief Записывает в часы реального времени GSM модуля указанное время.
bool sim900_set_time(UnpackedTime* t);

/// \brief Возвращает true, если GSM модуль зарегистрирован в домашней сети.
bool sim900_is_network_ready(bool * roaming);

/// \brief Делает до \p retries проверок регистрации в GSM сети с интервалом
/// в 1000 мс.
/// \return Возвращает true, если GSM модуль зарегистрирован в домашней сети.
bool sim900_wait_network_ready(size_t retries);

/// \brief Возвращает true, если в настоящий момент возможно начать GPRS
/// сеанс связи.
bool sim900_is_gprs_available(void);

/// \brief Вызывает +CGATT=1 для случаев, когда gsm модуль не пытается
/// автоматически подключиться к GPRS.
bool sim900_force_enable_gprs();

/// \brief Делает до \p retries проверок возможности начать GPRS сеанс
/// с интервалом в 500 мс.
/// \return Возвращает true, если в настоящий момент возможно начать GPRS
/// сеанс связи.
bool sim900_wait_gprs_available(size_t retries);

/// \brief Запрашивает у GSM модуля номер IMEI и сохраняет его в буффер
/// \p imei_buffer, заканчивая строку нуль-символом.
bool sim900_get_imei(char* imei_buffer, size_t buffer_size);

/// \brief Запрашивает у GSM модуля его идентификатор и сохраняет его в буффер
/// \p sim_buffer, заканчивая строку нуль-символом.
Sim900ModuleInfo sim900_get_siminfo(char* sim_buffer, size_t buffer_size);

/// \brief Запрашивает у GSM модуля версию прошивки и сохраняет его в буффер
/// \p sim_buffer, заканчивая строку нуль-символом.
bool sim900_get_swversion(char* sim_buffer, size_t buffer_size);

/// \brief Устанавливает настройки GPRS соединения.
bool sim900_set_gprs_settings(const char* apn,
                              const char* user, const char* password);

/// \brief Запрашивает у GSM модуля текущее состояние IP контекста.
Sim900IpState sim900_get_ip_state();

/// \brief Из даташита: Start Task and Set APN, USER, PASSWORD.
bool sim900_init_ip_session(const char* apn, const char* user, const char* pwd);

/// Осуществляет перевод GPRS в начальное состояние (для повтора инициализации)
bool sim900_deactivate_gprs(void);

/// \brief Осуществляет подключение GPRS сессии.
bool sim900_start_ip_session(void);

/// \brief Проверяет, что GSM модулю был выделен ip адрес.
bool sim900_has_local_ip_address(void);

/// \brief Запрашивает мощность принимаемого от сети сигнала и
/// сохраняет указатель на сами данные в переменной по адресу \p dst.
bool sim900_get_signal_quality(char** dst);

/// \brief Выбирает текстовый формат SMS сообщений (а не PDU).
bool sim900_select_smsformat_text(void);

/// \brief Возвращает номер ccid SIM карты.
bool sim900_get_ccid(char** ccid);

/// Возвращает номер IMSI SIM карты
bool sim900_get_imsi(char** imsi);

/// \brief Открывает соединение с сервером.
/// \return Если операция выполнена успешна, то возвращает true.
bool SocketOpen(const char* server_name, const char* port_str);

/// \brief Закрывает TCP/UDP соединение.
/// \return Если операция выполнена успешна, то возвращает true.
bool SocketClose(bool clear_rx_buffer);

/// \brief Подготавливает GSM модуль к приёму произвольной порции данных
/// для отправки серверу. Данные будут переданы при получении символа
/// Ctrl-Z (0x1A)
/// \return Если операция выполнена успешна, то возвращает true.
bool StartSendingData();

/// \brief Подготавливает GSM модуль к приёму порции данных длиной \p length
/// для отправки серверу. Данные будут переданы как только GSM модуль получит
/// \p length байт данных.
/// \return Если операция выполнена успешна, то возвращает true.
bool StartSendingDataWithLength(size_t length);

/// \brief Заканчивает передачу данных произвольной длины (символом 0x1A) и
/// ждёт передачи этих данных GSM модулем.
/// \return Если операция выполнена успешна, то возвращает true.
bool EndSendingData();

/// \brief Отправляет строку, оканчивающуюся нулём, на сервер.
/// \note Данная функция не проверяет длину строки, поэтому за один вызов
/// данной функции следует передавать не более 1460 байт (размер буффера
/// у GSM модуля).
/// \return Если операция выполнена успешна, то возвращает true.
bool SocketSendStr(const char* data);

/// \brief Форматирует текстовую строку и отправляет её на сервер.
/// \note Данная функция не проверяет длину строки, поэтому за один вызов
/// данной функции следует передавать не более 1460 байт (размер буффера
/// у GSM модуля).
/// \return Если операция выполнена успешна, то возвращает true.
bool SocketSendStrFormat(const char* format, ...);

/// \brief Отправляет на сервер \p size байт данных, находящихся
/// в буффере \p data.
/// \return Если операция выполнена успешна, то возвращает true.
bool SocketSendBuffer(const void* data, size_t size);

/// \brief Читает из GSM модуля SMS сообщение с индексом \p sms_index и
/// помещает информацию о нём в буффер \p dst.
/// \return Возвращает true, если запрос выполнен без ошибок.
bool sim900_read_sms(size_t sms_index, sms_info_t* dst);

/// \brief Форматирует строку \p format_str с произвольными
/// параметрами (\see sprintf) и отправляет полученную строку sms сообщением
/// на номер \p dst_phone.
/// \return Возвращает true, если запрос к GSM модулю был успешно обработан.
bool sim900_send_sms_va(const char* dst_phone, const char* format_str, va_list var_args);

/// \brief Форматирует строку \p format_str с произвольными
/// параметрами (\see sprintf) и отправляет полученную строку sms сообщением
/// на номер \p dst_phone.
/// \return Возвращает true, если запрос к GSM модулю был успешно обработан.
bool sim900_send_sms(const char* dst_phone, const char* format_str, ...);

/// \brief Удаляет все sms сообщения из памяти GSM модуля.
bool sim900_delete_all_sms(void);

/// \brief Удаляет все прочитанные sms сообщения из памяти GSM модуля.
bool sim900_delete_all_read_sms(void);

/// \brief Запрашивает информацию о ближайших сотах
///
/// После успешного выполнения переменная типа char*, на которую указывает
/// \p cell_id_buffer, получает указатель на строку, содержащую только
/// данные о сотах в формате
/// \code
/// +CENG:0,...... \r\n
/// +CENG:1,...... \r\n
/// ....
/// +CENG:N,......
/// \endcode
/// В конце ответа нет ни перевода строк, ни слова "OK"
///
/// Если запрос завершился ошибкой, то переменная по адресу \p cell_id_buffer
/// остаётся без изменений.
///
/// \return Возвращает true, если запрос к GSM модулю был успешно обработан.
bool sim900_get_cell_id(char** cell_id_buffer);

/// \brief Запрашивает информацию о заряде батареи.
///
/// После успешного выполнения, переменная, на которую указывает \p dst
/// получает указатель на строку, содержащую информацию в следующем формате:
/// `<status>,<charge percent>,<voltage_mv>`. Где
/// - <status> - число, состояние заряда:
///     0 - не заряжается
///     1 - заряжается
///     2 - полностью заряжена
/// - <charge percent> - степень заряженности в процентах 0..100
/// - <voltage_mv> - напряжение на входе GSM модуля в милливольтах.
///
/// Если запрос завершился ошибкой, то переменная по адресу \p dst
/// остаётся без изменений.
///
/// \return Возвращает true, если запрос к GSM модулю был успешно обработан.
bool sim900_get_battery_charge_info(char** dst);

/// \brief Запрашивает информацию о заряде батареи в процентах.
///
/// После успешного выполнения, переменная, на которую указывает \p dst
/// получает указатель на строку, содержащую текущий заряд батареи в процентах.
///
/// Если запрос завершился ошибкой, то переменная по адресу \p dst
/// остаётся без изменений.
///
/// \return Возвращает true, если запрос к GSM модулю был успешно обработан.
bool sim900_get_battery_charge_percent(char** dst);

/// \brief устанавливает Bearer Profile ID для использования модулем FTP (AT+FTPCID=<id>).
bool sim900_ftp_set_cid(int id);

/// \brief устанавливает позицию в файле, с которой следует продолжить скачивание.
bool sim900_ftp_set_resume_point(size_t byte_continue_from);

bool sim900_ftp_set_server(const char* server);

bool sim900_ftp_set_user(const char* user);

bool sim900_ftp_set_password(const char* password);

bool sim900_ftp_set_path(const char* path);

bool sim900_ftp_set_filename(const char* name);

bool sim900_ftp_start_download();

bool sim900_ftp_wait_data_ready(uint32_t timeout_ms);

int32_t sim900_ftp_get_file_length();

/// \return -1 в случае ошибки, иначе - количество прочитанных байт.
int32_t sim900_ftp_read_data(void* dst, uint32_t data_size);


/// \brief Отправляет команду \p command GSM модулю и ожидает в ответ
/// строку \p response_to_seek.
/// \return true, если искомая строка обнаружена в ответе GSM модуля,
/// иначе false.
/// \note Данная команда не добавляет ни каких дополнительных символов к
/// команде. Поэтому, команда должна содержать в себе в т.ч. символ возврата
/// каретки (<CR> = 0x0D = '\r').
bool sim900_cmd(const char* command, const char* response_to_seek, bool clear_rx);

/// Поддержка процедур для работы с PPP
#ifdef CFG_FW_TCPIP
/// Команды установления PDP режима
bool sim900_set_pdp(const char* apn);
bool sim900_dial(const char* number);
bool sim900_cmd_mode(void);
bool sim900_data_mode(void);
bool sim900_disconnect(void);
/// Возращает текущее сосотояние GSM модуля
bool sim900_get_data_mode(void);
#endif // CFG_FW_TCPIP

/// Поддержка процедур для работы с PPP
#ifdef CFG_FW_TCPIP
void* GSM_port_ptr(void);
uint8_t* GSM_read(uint8_t* dst, size_t max_rx_size_msg, uint32_t* error, bool only_check);
#endif // CFG_FW_TCPIP

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // GSM_SIM900_H_INCLUDED
