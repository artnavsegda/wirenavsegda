/// \file
/// \brief  Настройки платы 3.0 для использования в загрузчике
/// \author DL <dmitriy@linikov.ru>

#ifndef BOOTLOADER_COMMON_SETTINGS_H_INCLUDED
#define BOOTLOADER_COMMON_SETTINGS_H_INCLUDED

////////////////////////////////////////////////////////////////////////////
//  Подключение заголовочных файлов

#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "device_state.h"

////////////////////////////////////////////////////////////////////////////
//  Константы препроцессора


////////////////////////////////////////////////////////////////////////////
//  Типы данных

// Режим работы со структурами настройки
typedef enum {
    ALL_SETTINGS=0,
    MAIN_SETTINGS=1,
    SECOND_SETTINGS=1,
}Settings_Storage;

////////////////////////////////////////////////////////////////////////////
//  Предварительные определения констант

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif


////////////////////////////////////////////////////////////////////////////
//  Предварительные определения функций

#ifdef __cplusplus
extern "C" {
#endif

bool        SettingsIsBeepEnabled(void);
const char* SettingsGetImei(void);
const char* SettingsGetIccid(void);
const char* SettingsGetGprsApn(void);
const char* SettingsGetGprsUser(void);
const char* SettingsGetGprsPassword(void);

bool SettingsSetImei(const char* imei);
bool SettingsSetIccid(const char* iccid);
bool SettingsSetGprsApn(const char* apn);
bool SettingsSetGprsUser(const char* user);
bool SettingsSetGprsPassword(const char* pwd);


bool SettingsStrIsValid(const char* digstr, int32_t len);

/// \brief Сохраняет параметры во флеш.
void SettingsSave(Settings_Storage mode);

/// \brief Загружает параметры из флеш, либо стандартные значения, если
/// во флеш сохраненные параметры не найдены.
void SettingsLoad(void);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // BOOTLOADER_COMMON_SETTINGS_H_INCLUDED
