/// \file server_gateway.h
/// \author DL <dmitriy.linikov@gmail.com>
/// \brief Объект, выполняющий запросы к серверу.

#ifndef SERVER_GATEWAY_H_INCLUDED
#define SERVER_GATEWAY_H_INCLUDED

#include <stdbool.h>
#include "uart.h"
// #include "reports_storage.h"
#include "status_bitfield.h"

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

// ===================== Публичные функции =====================================

#define CFG_GSM_VDD_RAMPUP_TIME_MS            1000
#define CFG_GSM_VDD_RAMPDOWN_TIME_MS          2000
#define CFG_GSM_HARD_ERROR_RECOVER_TIME_MS    15000
#define CFG_GSM_PWRKEY_IMPULSE_DURATION_MS    1500
#define CFG_GSM_WARMUP_TIME_MS                2000
#define CFG_GSM_WAIT_AT_READY_MS              10000
#define CFG_GSM_WAIT_INIT_COMPLETE_MS         10000
#define CFG_GSM_WAIT_SIM_READY_MS             30000
#define CFG_GSM_WAIT_NETWORK_REGISTRATION_MS  60000
#define CFG_GSM_WAIT_GPRS_AVAILABLE_MS        60000
#define CFG_GSM_WAIT_IP_CONTEXT_ACTIVATION    60000
#define CFG_GSM_READY_CHECK_PERIOD_MS         120000

#define CFG_GSM_NO_RESPONSE_TO_POWERCYCLE_MS  300000

/// Режим работы GSM модуля (внутренний TCP/IP стек или PPP)
typedef enum {
  SIMCOM_TCPIP,
/// Поддержка процедур для работы с PPP
#ifdef CFG_FW_TCPIP
  SIMCOM_PPP,
#endif // CFG_FW_TCPIP
} ConnectType;

typedef enum {
  SIM_STATE_UNDEFINED = 0,
  SIM_STATE_OFF,
  SIM_STATE_INITIALIZATION,
  SIM_STATE_NETWORK_REGISTRATION,
  SIM_STATE_OK,
  SIM_STATE_ERROR,
  SIM_STATE_SIMCARD_ERROR,
  SIM_STATE_GSM_ERROR,
  SIM_STATE_GPRS_ERROR
} Sim900State;

#ifndef FW_TESTS
#else
extern bool simkey_debounce_over;
extern bool simkey_changed;
extern bool simkey_curent_state;
#endif // FW_TESTS


// Возвращает ранее считанное значение поля X-Checksum
uint32_t GetHttpXCecksum(void);

/// Сообщает о типе регистрации карты в сети (в проуминге или в домашней сети)
bool GetRoamingStatus(void);

/// \brief Тип функции, который вызывается при изменении состояния GSM модуля.
typedef void (*OnSim900StateChanged)(Sim900State new_state);

/// \brief Тип функции, который вызывается из CallServer
typedef void (*ServerResponseHandlerFxn)(char* server_response, priority_t * level);

/// \brief Настраивает драйвер gsm модуля, модуль отправки данных на сервер
/// и открывает GPRS сессию.
void ServerGatewayInit(USART_TypeDef* port, OnSim900StateChanged on_state_changed,
                       void (*turn_on_port)(void), void (*turn_off_port)(void),
                       void (*select_sim_card)(int card_id), ConnectType type);


#if 0
/// \brief Передаёт отчёт из буффера \p data на сервер,
/// при необходимости, шифруя данные.
bool SendToServer(char* data, size_t* response_length, char * ptr_3th_flow, priority_t * level);

/// \brief Передаёт на сервер запрос \p request, при получении ответа вызывает
/// обработчик response_handler.
bool CallServer(char* request, ServerResponseHandlerFxn response_handler, char * ptr_3th_flow, priority_t * level);

/// \brief Отправляет данные \p data на сервер. Если не удаётся, то сохраняет
/// их во флеш память.
bool SendToServerOrSaveToFlash(char* data, bool save_only, Report_data_type data_type);

/// \brief Отправляет все сохраненные во флеш памяти отчёты на сервер.
bool SendReportsFromFLASH(char* buffer, size_t buffer_size, char* ptr_3th_flow, char* ptr_3th_flow_end, Report_data_type type, bool last);
#endif

bool ServerGateway_React();
void ServerConnectionStatusUpdate(void);
bool ServerGateway_IsReady(void);
bool ServerGateway_WaitReady(systime_t timeout_ms);

/// Для прерывания. Обработчки сосотояние включения питания GSM для обеспечения работы RTC
void __ServerGSMPowerUp(void);

/// Процедура для прерывания. Периодический опрос состояния
void __SimKeyMonitor(void);
/// пердает значение флага смены сим карты
bool IsSimCardChaged(bool clear);
// Сообщает о том, что сим карта сменилась и готова к работе
bool SimIsChange_and_ready(void);

#ifdef CFG_FW_TCPIP
void GSM_close(void);
#endif // CFG_FW_TCPIP

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // SERVER_GATEWAY_H_INCLUDED
