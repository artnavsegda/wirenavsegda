/// \file systime.c
/// \author DL <dmitriy.linikov@gmail.com>
/// \see systime.h

#include <time.h>
#include <sys/time.h>
#include "board.h"
#include "systime.h"
#include "timeout.h"

static volatile systime_t   systick_timer = 0;
static volatile time_t      time_of_day = 1411639190; //09/25/2014 @ 9:59am
static volatile uint32_t    ms_counter = 0;

void __systime_tick(void)
{
  ++systick_timer;
  if (ms_counter >= 1000) {
    ++time_of_day;
    ms_counter = 0;
  }
}

systime_t systime_get(void)
{
  return systick_timer;
}

systime_t systime_ticks_from_timestamp(systime_t past_timestamp)
{
  return systime_get() - past_timestamp;
}

bool  systime_is_within(systime_t start, systime_t end)
{
  systime_t time = systime_get();
  return end > start ? (time >= start) && (time < end) :
                       (time >= start) || (time < end);
}

void delay_ms(uint32_t delay)
{
  timeout_t   t;
  timeout_start(&t, delay);
  while(!timeout_is_elapsed(&t)) {
    WaitForEvent();
  };
}

int _gettimeofday(struct timeval *__p, struct timezone *__z) {
  (void)__z; // не используется
  __p->tv_sec = time_of_day;
  __p->tv_usec = 1000*(1000-ms_counter);
  return 0;
}

void spin_wait(uint32_t iterations)
{
  volatile int i;
  while(iterations--) {
    i = 0;
  }
  (void)i;
}
