#ifndef BOOTLOADER_KEYS_H_INCLUDED
#define BOOTLOADER_KEYS_H_INCLUDED

#include <stdint.h>

extern const uint32_t bootkey_legacy_v1[8];
extern const uint32_t bootkey_legacy_v2[8];
extern const uint32_t bootkey_brd1_2_fw[8];
extern const uint32_t bootkey_brd2_2_fw[8];
extern const uint32_t bootkey_brd2_7_fw[8];
extern const uint32_t bootkey_brd3_0_som207zg[8];

#endif // BOOTLOADER_KEYS_H_INCLUDED
