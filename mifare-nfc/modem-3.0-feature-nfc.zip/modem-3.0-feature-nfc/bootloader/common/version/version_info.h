/// \file version_info.h
/// \author DL <dmitriy.linikov@gmail.com>
/// \brief

#ifndef VERSION_INFO_H_INCLUDED
#define VERSION_INFO_H_INCLUDED

#include <stdint.h>
#if defined(__cplusplus)
extern "C" {
#endif

const char* version_get_version_string(void);
const char* version_get_short_version_string(void);
const char* version_get_version_timestamp(void);
const char* version_get_build_timestamp(void);
const char* version_get_build_target(void);
const char* version_get_hardware_description(void);
uint32_t    version_get_hardware_id(void);

#if defined(__cplusplus)
}
#endif

#endif // VERSION_INFO_H_INCLUDED
