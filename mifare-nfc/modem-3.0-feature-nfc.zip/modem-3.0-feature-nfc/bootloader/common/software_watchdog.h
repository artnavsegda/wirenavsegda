/// \file software_watchdog.h
/// \author DL <dmitriy.linikov@gmail.com>
/// \brief Оболочка над watchdog, которая проверяет состояние отдельных
/// компонентов прошивки, и в случае сбоя - зависает, а в случае успеха - сбрасывает
/// аппаратный сторожевой таймер.



#ifndef SOFTWARE_WATCHDOG_H_INCLUDED
#define SOFTWARE_WATCHDOG_H_INCLUDED

void Softdog_Init();
void Softdog_OnServerResponse();
void Softdog_OnServerResponse_Wait(uint32_t time_ms);
void Softdog_OnReturnedToMainLoop();

/// \brief Должен вызываться из медленного таймера. В коде считаю, что частота
/// вызовов равна 10 Гц, т.е. 100мс между вызовами.
void __Softdog_React();

#endif // SOFTWARE_WATCHDOG_H_INCLUDED
