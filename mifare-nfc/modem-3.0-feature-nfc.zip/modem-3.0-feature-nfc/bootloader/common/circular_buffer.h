/// \file circular_buffer.h
/// \author DL <dmitriy.linikov@gmail.com>
/// \brief ��������� ������ ���� � ��������� ������������.

#ifndef CIRCULAR_BUFFER_H_INCLUDED
#define CIRCULAR_BUFFER_H_INCLUDED

#include <stdint.h>
#include <stddef.h>

typedef struct CircBufferTag {
  uint8_t*                data;
  uint8_t*                datatop;
  uint8_t*                wr_ptr;
  uint8_t*                rd_ptr;
  size_t                  size;
  size_t                  count;
} CircBuffer;

typedef enum {
  CIRCBUFFER_OK = 0,
  CIRCBUFFER_FULL = -1,
  CIRCBUFFER_EMPTY = -2
} CircBufferResult;

static inline void CircBufferObjectInit(CircBuffer* buffer, void* storage, uint16_t size)
{
  buffer->data = storage;
  buffer->datatop = buffer->data + size;
  buffer->wr_ptr = storage;
  buffer->rd_ptr = storage;
  buffer->size = size;
  buffer->count = 0;
}

static inline int CircBufferPush(CircBuffer* buffer, int value)
{
  if (buffer->count >= buffer->size) {
    return CIRCBUFFER_FULL;
  }

  buffer->count++;
  *buffer->wr_ptr++ = (uint8_t)value;
  if (buffer->wr_ptr >= buffer->datatop) {
    buffer->wr_ptr = buffer->data;
  }
  return CIRCBUFFER_OK;
}

static inline int CircBufferPop(CircBuffer* buffer)
{
  uint8_t value;
  if (!buffer->count) {
    return CIRCBUFFER_EMPTY;
  }

  value = *buffer->rd_ptr++;
  if (buffer->rd_ptr >= buffer->datatop) {
    buffer->rd_ptr = buffer->data;
  }
  buffer->count--;
  return value;
}


#endif // CIRCULAR_BUFFER_H_INCLUDED
