/// \file pushbutton.c
/// \author DL <dmitriy.linikov@gmail.com>

// #include "gpio.h"
#include "pushbutton.h"
//#include "..\src\settings.h"
// #include "..\src\ext_sensors.h"

#define CFG_PUSHBUTTON_MAX_VALUE          100
#define CFG_PUSHBUTTON_PRESS_THRESHOLD    80
#define CFG_PUSHBUTTON_RELEASE_THRESHOLD  20

#define PBTN_MIN_HOLD_TIME                100
#define PBTN_MAX_HOLD_TIME                1000
//#if (CFG_PUSHBUTTON_MAX_VALUE>PBTN_MIN_HOLD_TIME)
//#error "Invalid PBTN_MIN_HOLD_TIME"
//#endif


static void PushbuttonExecuteCallback(Pushbutton* pb, PushbuttonEvent event)
{
  if (pb && pb->callback) {
    if (pb->ext_cfg)
    {
        if (systime_ticks_from_timestamp(pb->time)>PBTN_MIN_HOLD_TIME)
            pb->callback(pb, event);
        pb->time=systime_get();
    }
    else
    {
        if (event==PUSHBUTTON_EVENT_PRESSED)
        {
            pb->time=systime_get();
        }
        else
        {
            if (systime_is_within(pb->time+PBTN_MIN_HOLD_TIME,pb->time+PBTN_MAX_HOLD_TIME))
                pb->callback(pb->callback_arg, PUSHBUTTON_EVENT_PRESSED);
            pb->time=0;
        }
    }
  }
}

// bool PushbuttonReadDefault(struct PushbuttonTag* pb)
// {
//   return GpioRead(pb->channel);
// }

void PushbuttonInit(Pushbutton* pb)
{
  pb->callback = NULL;
  pb->callback_arg = NULL;
  pb->value = 0;
  pb->state = 0;
}

void PushbuttonSetCallback(Pushbutton* pb, PushbuttonCallback callback, void* user_arg, void* ext_cfg)
{
  pb->callback      = NULL;

  pb->callback_arg  = user_arg;
  pb->callback      = callback;
  pb->ext_cfg       = ext_cfg;
}

bool PushbuttonIsPressed(Pushbutton* pb)
{
  return pb->state == PUSHBUTTON_STATE_PRESSED;
}

systime_t PushbuttonGetPressTime(Pushbutton* pb)
{
    return pb->time;
}

/// \brief Данная функция должна вызываться из высокочастотного таймера (1 мс);
int8_t __PushbuttonReact(Pushbutton* pb)
{
  if (!pb || !pb->read_pin) {
    return (0);
  }
  // Изменяем накопленную сумму: кнопка отпущена=-1, кнопка нажата=+1.
  int delta = pb->read_pin(pb) ? -1 : 1;
  // if (pb->ext_cfg)
  // {
  //   if (((_ext_var *)(pb->ext_cfg))->ext_settings->on ==SENSOR_OFF)
  //       return (0);
  //   if ((((_ext_var *)(pb->ext_cfg))->ext_settings->type==SENSOR_INV) ||
  //       (((_ext_var *)(pb->ext_cfg))->ext_settings->type==SENSOR_OPT_INV))
  //       delta*=-1;
  // }
  pb->value += delta;

  // И ограничиваем её в диапазоне [0, CFG_PUSHBUTTON_MAX_VALUE].
  if (pb->value < 0) {
    // кнопка отпущена.
    pb->value = 0;
  } else if (pb->value > CFG_PUSHBUTTON_MAX_VALUE) {
    pb->value = CFG_PUSHBUTTON_MAX_VALUE;
  }

  // Проверяем изменение состояния кнопки.
  if (pb->state == PUSHBUTTON_STATE_PRESSED && pb->value < CFG_PUSHBUTTON_RELEASE_THRESHOLD) {
    pb->state = PUSHBUTTON_STATE_RELEASED;
    PushbuttonExecuteCallback(pb, PUSHBUTTON_EVENT_RELEASED);
    return (delta);
  }

  if (pb->state != PUSHBUTTON_STATE_PRESSED && pb->value > CFG_PUSHBUTTON_PRESS_THRESHOLD) {
    pb->state = PUSHBUTTON_EVENT_PRESSED;
    PushbuttonExecuteCallback(pb, PUSHBUTTON_EVENT_PRESSED);
  }
  return (delta);
}
