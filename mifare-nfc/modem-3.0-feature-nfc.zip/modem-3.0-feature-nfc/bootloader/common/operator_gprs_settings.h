/// \file operator_gprs_settings.h
/// \author DL <dmitriy.linikov@gmail.com>
/// \brief Функция определения настроек GPRS соединения по началу номера SIM.

#ifndef OPERATOR_GPRS_SETTINGS_H_INCLUDED
#define OPERATOR_GPRS_SETTINGS_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

typedef struct GsmOperatorGprsSettingsTag {
  const char* ccid_prefix;
  const char* operator_name;
  const char* apn;
  const char* apn2;
  const char* user;
  const char* pwd;
} GsmOperatorGprsSettings;


/// \brief Возвращает информацию об операторе GSM связи по номеру SIM карты,
/// или NULL, если в базе данных нет информации об операторе.
const GsmOperatorGprsSettings* GetOperatorInfoByCcid(const char* ccid);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // OPERATOR_GPRS_SETTINGS_H_INCLUDED
