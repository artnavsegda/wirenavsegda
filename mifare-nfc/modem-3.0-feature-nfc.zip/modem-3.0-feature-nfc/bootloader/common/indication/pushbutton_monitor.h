/// \file pushbutton_monitor.h
/// \author DL <dmitriy.linikov@gmail.com>
/// \brief Модуль, который отслеживает состояние всех кнопок в системе.



#ifndef PUSHBUTTON_MONITOR_H_INCLUDED
#define PUSHBUTTON_MONITOR_H_INCLUDED


void PushbuttonMonitorInit();
void __PushbuttonMonitorReact();

#endif // PUSHBUTTON_MONITOR_H_INCLUDED
