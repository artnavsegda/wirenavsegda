/// @file sim_state_monitor.c
/// @author DL <dmitriy.linikov@gmail.com>

#include <indication/indicators.h>
#include "sim_state_monitor.h"

#define BEEPER_ON   1
#define BEEPER_OFF  0

static volatile Sim900State   prev_state = SIM_STATE_UNDEFINED;

static const Sequence    blink_net_registration = {
  .steps = (const SequencerStep[]) {
        { .value = LED_COLOR_GREEN, .duration = 200  },
        { .value = LED_COLOR_BLACK, .duration = 3000 },
      },
  .steps_count = 2,
  .repeat = true
};

static const Sequence    blink_gsm_error = {
  .steps = (const SequencerStep[]) {
        { .value = LED_COLOR_YELLOW, .duration = 200  },
        { .value = LED_COLOR_BLACK, .duration = 200 },
      },
  .steps_count = 2,
  .repeat = true
};

static const Sequence    blink_sim_error = {
  .steps = (const SequencerStep[]) {
        { .value = LED_COLOR_RED, .duration = 200  },
        { .value = LED_COLOR_BLACK, .duration = 200 },
      },
  .steps_count = 2,
  .repeat = true
};

static const Sequence     beep_sim_error = {
  .steps = (const SequencerStep[]) {
        // звуковой сигнал 2 секунды с интервалом в 5 секунд
        { .value = BEEPER_ON,       .duration = 2000 },
        { .value = BEEPER_OFF,      .duration = 500 },
        { .value = BEEPER_ON,       .duration = 2000 },
        { .value = BEEPER_OFF,      .duration = 500 }
      },
  .steps_count = 2,
  .repeat = false
};



void SimStateMonitor_OnStateChanged(Sim900State new_state)
{
  Sim900State   prev;
  __disable_irq();
  prev = prev_state;
  prev_state = new_state;
  __enable_irq();

  if (prev == new_state) {
    return;
  }

  switch(new_state) {
  case SIM_STATE_UNDEFINED:
  case SIM_STATE_OFF:
  case SIM_STATE_INITIALIZATION:
    SequencerSetValue(&LedGsmController, LED_COLOR_BLACK);
    BeepCancell();
    break;

  case SIM_STATE_ERROR:
    SequencerPlay(&LedGsmController, &blink_sim_error);
    //SequencerSetValue(&LedGsmController, LED_COLOR_BLACK);

    BeepSequence(&beep_sim_error);
    break;

  case SIM_STATE_SIMCARD_ERROR:
    SequencerSetValue(&LedGsmController, LED_COLOR_RED);
    break;

  case SIM_STATE_NETWORK_REGISTRATION:
    SequencerPlay(&LedGsmController, &blink_net_registration);
    break;

  case SIM_STATE_GSM_ERROR:
    SequencerPlay(&LedGsmController, &blink_gsm_error);
    break;

  case SIM_STATE_GPRS_ERROR:
    SequencerSetValue(&LedGsmController, LED_COLOR_YELLOW);
    break;

  case SIM_STATE_OK:
    SequencerSetValue(&LedGsmController, LED_COLOR_GREEN);
    break;
  }
}
