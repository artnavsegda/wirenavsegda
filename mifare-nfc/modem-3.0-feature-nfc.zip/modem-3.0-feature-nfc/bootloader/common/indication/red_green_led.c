/// \file red_green_led.c
/// \author DL <dmitriy.linikov@gmail.com>
/// \see red_green_led.h

#include <gpio.h>
#include "red_green_led.h"


void LedSetColor(const Led* led, LedColor color)
{
  if (!led) {
    return;
  }

  if (led->red_channel && led->red_channel->write) {
    led->red_channel->write(led->red_channel, !!(color & LED_COLOR_RED));
  }
  if (led->green_channel && led->green_channel->write) {
    led->green_channel->write(led->green_channel, !!(color & LED_COLOR_GREEN));
  }
}
