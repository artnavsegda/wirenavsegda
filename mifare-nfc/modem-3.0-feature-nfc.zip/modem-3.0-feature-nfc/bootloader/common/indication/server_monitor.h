/// @file server_monitor.h
/// @author DL <dmitriy.linikov@gmail.com>
/// @brief Монитор, отслеживающий состояние связи с сервером и обновляющий
/// в соответствии с этим индикацию.

#ifndef SERVER_MONITOR_H_INCLUDED
#define SERVER_MONITOR_H_INCLUDED

typedef enum ServerState {
  SERVER_STATE_UNDEFINED = 0,
  SERVER_STATE_DISCONNECTED,
  SERVER_STATE_CONNECTING,
  SERVER_STATE_DATA_EXCHANGE,
  SERVER_STATE_ONLINE,
  SERVER_STATE_SERVER_NOT_AVAILABLE,
  SERVER_STATE_INVALID_SERVER_RESPONSE
} ServerState;


void ServerMonitor_OnStateChanghed(ServerState new_state);

#endif // SERVER_MONITOR_H_INCLUDED
