/// \file leds.h
/// \author DL <dmitriy.linikov@gmail.com>
/// \brief

#ifndef INDICATORS_H_INCLUDED
#define INDICATORS_H_INCLUDED

#include "sequencer.h"

extern Sequencer    LedPowerController;
extern Sequencer    LedGsmController;
extern Sequencer    LedServerController;
extern Sequencer    LedDexController;
extern Sequencer    LedMdbExeController;

void UpdateLeds(void);
void UpdateBeeper(void);

void BeepOnce(systime_t duration);
void BeepError();
void BeepSuccess();
void BeepSequence(const Sequence* sequence);
void BeepCancell();

sequencer_mutex_t BeepSequenceMutex(const Sequence* sequence, sequencer_mutex_t mutex);
sequencer_mutex_t BeepOnceMutex(systime_t duration, sequencer_mutex_t mutex);
sequencer_mutex_t BeepErrorMutex(sequencer_mutex_t mutex);
sequencer_mutex_t BeepClearMutex(void);

#endif // LEDS_H_INCLUDED
