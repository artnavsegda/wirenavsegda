/// \file leds.c
/// \author DL <dmitriy.linikov@gmail.com>
/// \see leds.h

#include <board.h>
#include <settings.h>
#include "indicators.h"

// В данном случае все приведения безопасны, но нужно быть осторожным, если
// изменятся параметры вызова LedSetColor или GpioWrite

DECLARE_SEQUENCER(LedPowerController,  (SequencerUpdateFxn)LedSetColor, (void*)&LedPower);
DECLARE_SEQUENCER(LedGsmController,    (SequencerUpdateFxn)LedSetColor, (void*)&LedGsm);
DECLARE_SEQUENCER(LedServerController, (SequencerUpdateFxn)LedSetColor, (void*)&LedServer);
DECLARE_SEQUENCER(LedDexController,    (SequencerUpdateFxn)LedSetColor, (void*)&LedDex);
DECLARE_SEQUENCER(LedMdbExeController, (SequencerUpdateFxn)LedSetColor, (void*)&LedMdbExe);


static void BeeperUpdateFxn(void* unused, sequencer_value_t new_value)
{
  (void)unused;
  /// \todo Драйвер ЦАП для бут-загрузчика не реализован.
  if (new_value != 0) {
    BoardBuzzerOn();
  } else {
    BoardBuzzerOff();
  }
}


// Для того, что бы не было возможности запустить писк в обход функций
// BeepOnce и BeepSequence, в которых учитывается, разрешён ли сейчас
// писк или нет, данный секвенсер объявлен статическим.
static DECLARE_SEQUENCER(BeeperController,    BeeperUpdateFxn,   NULL);

void UpdateLeds(void)
{
  SequencerProcess(&LedPowerController);
  SequencerProcess(&LedGsmController);
  SequencerProcess(&LedServerController);
  SequencerProcess(&LedDexController);
  SequencerProcess(&LedMdbExeController);
  SequencerProcess(&BeeperController);
}

void UpdateBeeper(void)
{
  SequencerProcess(&BeeperController);
}

void BeepSequence(const Sequence* sequence)
{
  if (SettingsIsBeepEnabled()) {
    SequencerPlay(&BeeperController, sequence);
  }
}


void BeepOnce(systime_t duration)
{
  static SequencerStep  single_beep_steps[] = {
    { .value = 1, .duration = 0 },
    { .value = 0, .duration = 0 }
  };

  static const Sequence       single_beep = {
    .steps = single_beep_steps,
    .steps_count = 2,
    .repeat = false
  };

  single_beep_steps[0].duration = duration;
  BeepSequence(&single_beep);
}

void BeepError()
{
  static const SequencerStep  error_beep_steps[] = {
    { .value = 1, .duration = 200 },
    { .value = 0, .duration = 200 },
    { .value = 1, .duration = 200 },
    { .value = 0, .duration = 200 },
    { .value = 1, .duration = 200 },
    { .value = 0, .duration = 200 },
    { .value = 1, .duration = 200 },
    { .value = 0, .duration = 200 },
    { .value = 1, .duration = 200 },
    { .value = 0, .duration = 200 }
  };

  static const Sequence    error_beep = {
    .steps = error_beep_steps,
    .steps_count = 10,
    .repeat = false
  };

  BeepSequence(&error_beep);
}

void BeepSuccess()
{
  BeepOnce(500);
}

void BeepCancell()
{
  SequencerSetValue(&BeeperController, 0);
}

sequencer_mutex_t BeepSequenceMutex(const Sequence* sequence, sequencer_mutex_t mutex)
{
  sequencer_mutex_t ret=0;
  if (SettingsIsBeepEnabled()) {
    ret=SequencerPlayMutex(&BeeperController, sequence, mutex);
  }
  return(ret);
}

sequencer_mutex_t BeepOnceMutex(systime_t duration, sequencer_mutex_t mutex)
{
  static SequencerStep  single_beep_steps[] = {
    { .value = 1, .duration = 0 },
    { .value = 0, .duration = 0 }
  };

  static const Sequence       single_beep = {
    .steps = single_beep_steps,
    .steps_count = 2,
    .repeat = false
  };

  single_beep_steps[0].duration = duration;
  return(BeepSequenceMutex(&single_beep, mutex));
}

sequencer_mutex_t BeepErrorMutex(sequencer_mutex_t mutex)
{
  static const SequencerStep  error_beep_steps[] = {
    { .value = 1, .duration = 200 },
    { .value = 0, .duration = 200 },
    { .value = 1, .duration = 200 },
    { .value = 0, .duration = 200 },
    { .value = 1, .duration = 200 },
    { .value = 0, .duration = 200 },
    { .value = 1, .duration = 200 },
    { .value = 0, .duration = 200 },
    { .value = 1, .duration = 200 },
    { .value = 0, .duration = 200 }
  };

  static const Sequence    error_beep = {
    .steps = error_beep_steps,
    .steps_count = 10,
    .repeat = false
  };

  return(BeepSequenceMutex(&error_beep, mutex));
}

sequencer_mutex_t BeepClearMutex(void)
{
    return(SequencerClearMutex(&BeeperController));
}
