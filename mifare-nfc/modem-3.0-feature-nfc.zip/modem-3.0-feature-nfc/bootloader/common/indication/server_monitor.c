/// @file server_monitor.c
/// @author DL <dmitriy.linikov@gmail.com>

#include "indicators.h"
#include "server_monitor.h"

static ServerState   current_state = SERVER_STATE_UNDEFINED;

static const Sequence    blink_connecting_to_server = {
  .steps = (const SequencerStep[]) {
        { .value = LED_COLOR_GREEN, .duration = 1000 },
        { .value = LED_COLOR_BLACK, .duration = 1000 },
      },
  .steps_count = 2,
  .repeat = true
};

static const Sequence    blink_server_data_exchange = {
  .steps = (const SequencerStep[]) {
        // начинаем с чёрного, что бы можно было обнаружить короткую
        // передачу в online режиме
        { .value = LED_COLOR_BLACK, .duration = 200 },
        { .value = LED_COLOR_GREEN, .duration = 200 },
      },
  .steps_count = 2,
  .repeat = true
};

static const Sequence    blink_server_invalid_response = {
  .steps = (const SequencerStep[]) {
        { .value = LED_COLOR_RED,   .duration = 1000 },
        { .value = LED_COLOR_BLACK, .duration = 1000 },
      },
  .steps_count = 2,
  .repeat = true
};



void ServerMonitor_OnStateChanghed(ServerState new_state)
{
  if (new_state == current_state) {
    return;
  }
  current_state = new_state;

  switch(new_state) {
  case SERVER_STATE_UNDEFINED:
  case SERVER_STATE_DISCONNECTED:
    SequencerSetValue(&LedServerController, LED_COLOR_BLACK);
    break;

  case SERVER_STATE_CONNECTING:
    SequencerPlay(&LedServerController, &blink_connecting_to_server);
    break;

  case SERVER_STATE_DATA_EXCHANGE:
    SequencerPlay(&LedServerController, &blink_server_data_exchange);
    break;

  case SERVER_STATE_ONLINE:
    SequencerSetValue(&LedServerController, LED_COLOR_GREEN);
    break;

  case SERVER_STATE_SERVER_NOT_AVAILABLE:
    SequencerSetValue(&LedServerController, LED_COLOR_RED);
    break;

  case SERVER_STATE_INVALID_SERVER_RESPONSE:
    SequencerPlay(&LedServerController, &blink_server_invalid_response);
    break;
  }


}
