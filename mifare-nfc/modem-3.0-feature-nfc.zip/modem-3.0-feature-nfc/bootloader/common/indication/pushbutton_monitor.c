/// \file pushbutton_monitor.c
/// \author DL <dmitriy.linikov@gmail.com>

#include <board.h>
// #include "device_state.h"
#include "indication/indicators.h"
#include "pushbutton_monitor.h"
#include "status_bitfield.h"

static volatile uint8_t button_flags = 0;
static volatile bool pushbutton_monitor_enabled = false;

static void OnBtnResetEvent(void* unused, PushbuttonEvent event)
{
  ((void)unused);
  if (event == PUSHBUTTON_EVENT_PRESSED) {
    StatusSetFlag(STATUS_BTNRESET_PRESSED);
    BeepOnce(300);
  }
}

static void OnBtn1Event(void* unused, PushbuttonEvent event)
{
  ((void)unused);
  if (event == PUSHBUTTON_EVENT_PRESSED) {
    StatusSetFlag(STATUS_BTN1_PRESSED);
    BeepOnce(300);
  }
}

static void OnBtn2Event(void* unused, PushbuttonEvent event)
{
  ((void)unused);
  if (event == PUSHBUTTON_EVENT_PRESSED) {
    StatusSetFlag(STATUS_BTN2_PRESSED);
    BeepOnce(300);
  }
}

static void OnBtn3Event(void* unused, PushbuttonEvent event)
{
  ((void)unused);
  if (event == PUSHBUTTON_EVENT_PRESSED) {
    StatusSetFlag(STATUS_BTN3_PRESSED);
    BeepOnce(300);
  }
}


void PushbuttonMonitorInit()
{
  pushbutton_monitor_enabled = false;
  PushbuttonInit(&BtnReset);
  PushbuttonInit(&Btn1);
  PushbuttonInit(&Btn2);
  PushbuttonInit(&Btn3);
  PushbuttonSetCallback(&BtnReset, OnBtnResetEvent, NULL, NULL);
  PushbuttonSetCallback(&Btn1, OnBtn1Event, NULL, NULL);
  PushbuttonSetCallback(&Btn2, OnBtn2Event, NULL, NULL);
  PushbuttonSetCallback(&Btn3, OnBtn3Event, NULL, NULL);
  pushbutton_monitor_enabled = true;
}

void __PushbuttonMonitorReact()
{
  if (!pushbutton_monitor_enabled) {
    return;
  }
  __PushbuttonReact(&BtnReset);
  __PushbuttonReact(&Btn1);
  __PushbuttonReact(&Btn2);
  __PushbuttonReact(&Btn3);
}
