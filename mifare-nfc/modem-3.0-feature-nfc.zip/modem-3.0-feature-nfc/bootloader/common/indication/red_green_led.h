/// \file red_green_led.h
/// \author DL <dmitriy.linikov@gmail.com>
/// \brief Оболочка над двумя GPIO каналами для управления двухцветным
/// (красный-зелёный) светодиодом.

#ifndef RED_GREEN_LED_H_INCLUDED
#define RED_GREEN_LED_H_INCLUDED


/// \brief Перечисление доступных цветов для светодиода.
typedef enum LedColorTag {
  LED_COLOR_BLACK   = 0,
  LED_COLOR_RED     = (1u << 0),
  LED_COLOR_GREEN   = (1u << 1),
  LED_COLOR_YELLOW  = (LED_COLOR_RED | LED_COLOR_GREEN),
} LedColor;


// предварительное объявление.
typedef struct LedChanTag{
  void (*write)(const struct LedChanTag* instance, int value);
} LedChan;

/// \brief Дескриптор, описывающий двухцветный светодиод.
typedef struct {
  const LedChan*  red_channel;
  const LedChan*  green_channel;
} RedGreenLed;

/// \brief Сокращённая запись для удобства использования.
typedef RedGreenLed   Led;

/// \brief Устанавливает новый цвет \p color светодиоду \p led.
void LedSetColor(const Led* led, LedColor color);

#endif // RED_GREEN_LED_H_INCLUDED