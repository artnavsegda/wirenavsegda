/// \file led_controller.h
/// \author DL <dmitriy.linikov@gmail.com>
/// \brief Контроллер, управляющий светодиодом.

#ifndef SEQUENCER_H_INCLUDED
#define SEQUENCER_H_INCLUDED

#include <stddef.h>
#include <stdint.h>
#include "red_green_led.h"
#include <timeout.h>

#define CLEAR_VALUE             0xFF

#define SEQUENCER_DATA(name, update_func, update_arg)     \
    {update_func, update_arg, NULL, 0 , CLEAR_VALUE, NULL, 0, {0}}


/// \brief Объявляет и статически настраивает экземпляр секвенсера
/// (контроллера, который может изменять состояние какого-либо объекта
/// по заданной "программе")
///
/// \param name   имя     создаваемой переменной.
/// \param update_func    функция, вызываемая при необходимости изменить
///                       состояние объекта, связанного с данным секвенсером.
/// \param update_arg     Значение (типа void*), передаваемое в \p update_func
///                       первым аргументом.
#define DECLARE_SEQUENCER(name, update_func, update_arg)  \
    Sequencer   name = SEQUENCER_DATA(name, update_func, update_arg)

/// \brief Тип переменной, предназначенная для хранения моментального значения
/// состояния секвенсера.
typedef uint8_t   sequencer_value_t;

typedef uint16_t  sequencer_mutex_t;


/// \brief Описание одиночного шага "программы" секвенсера.
typedef struct {
  /// \brief Значение, которое следует записать в связанный объект.
  sequencer_value_t     value;

  /// \brief Задержка перед переходом к следующему шагу "программы" секвенсера.
  systime_t             duration;
} SequencerStep;


/// \brief Описание "программы" секвенсера.
typedef struct {
  /// \brief Указатель на массив с шагами "программы" секвенсера
  const SequencerStep*  steps;

  /// \brief Количество шагов в "программе" секвенсера.
  uint8_t               steps_count;

  /// \brief Нужно ли повторять программу после выполнения последнего шага.
  bool                  repeat;
} Sequence;

/// \brief Тип функции, вызываемой для изменения состояния объекта,
/// связанного с данным секвенсером.
typedef void (*SequencerUpdateFxn)(void* user_arg, sequencer_value_t new_value);


/// \brief Внутреннее состояние секвенсера.
typedef struct {
  SequencerUpdateFxn    update;
  void*                 update_arg;

  const Sequence*       current_sequence;
  uint8_t               current_step;
  sequencer_value_t     save_value;
  const Sequence*       save_sequence;
  sequencer_mutex_t     mutex;
  timeout_t             current_timeout;
} Sequencer;


/// \brief Проверяет текущее время и при необходимости переходит к следующему
/// шагу программы секвенсера.
void SequencerProcess(Sequencer* me);

/// \brief Останавливает выполнение текущей "программы" и устанавливает
/// новое значение связанному объекту.
void SequencerSetValue(Sequencer* me, sequencer_value_t color);

/// \brief Останавливает выполнение текущей "программы" и начинает выполнение
/// новой.
void SequencerPlay(Sequencer* me, const Sequence* sequence);

sequencer_mutex_t SequencerPlayMutex(Sequencer* me, const Sequence* sequence, sequencer_mutex_t mutex);
sequencer_mutex_t SequencerSetMutexValue(Sequencer* me, LedColor value, sequencer_mutex_t mutex);
sequencer_mutex_t SequencerClearMutex(Sequencer* me);



#endif // SEQUENCER_H_INCLUDED
