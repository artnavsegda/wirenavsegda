/// \file dbg.c
/// \author DL <dmitriy.linikov@gmail.com>
/// \see dbg.h

#include <board.h>
#include <stdarg.h>
#include <xprintf.h>
#include <system_utils.h>
#include <buffered_uart.h>
#include "sysutils/crc.h"
#include "dbg.h"

#define DBG_SAFE                2034

volatile uint32_t back_software_position;
volatile uint32_t back_software_halt_position;
volatile uint32_t back_software_work_time;
volatile uint32_t back_timeline_id;
volatile uint32_t software_position __attribute__((section (".user_software_position")));
volatile uint32_t software_halt_position __attribute__((section (".user_software_position")));
volatile uint32_t software_work_time __attribute__((section (".user_software_position")));
volatile struct{uint32_t id; uint32_t time; uint32_t packet_number; uint16_t crc;} timeline_id __attribute__((section (".user_software_position")));
//volatile uint8_t array_software_position[2] __attribute__((section (".user_software_position")));

static uint8_t  soft_time=0;

SW_State Set_Software_Position(SW_State state)
{
  SW_State ret=software_position;
  software_position=state;
  return ret;
}

void Set_Halt_Position(SW_State state)
{
  software_halt_position=state;
}

SW_State Get_Halt_Position(void)
{
    return software_halt_position;
}

void SetSoftTime(void)
{
    soft_time++;
    if (soft_time>=10)
    {
        soft_time=0;
        software_work_time++;
        timeline_id.time++;
    }
}

uint32_t GetSetSoftTime(systime_t time)
{
    uint32_t ret=software_work_time;
    time/=1000;
    software_work_time=time;
    return(ret);
}

uint32_t GetSoftTime(void)
{
    return(software_work_time);
}

uint32_t GetTimelineIdTime(void)
{
    return(timeline_id.time);
}

uint32_t GetTimelineId(void)
{
    if (crc16_calc_block(DBG_SAFE,(const void *)(&timeline_id.id),sizeof(timeline_id.id))!=timeline_id.crc)
    {
        // Новый Timeline ID
        srand(ReadCoreTemperature()+ReadSupplyMillivolts());
        timeline_id.id=rand();
        timeline_id.packet_number=0;
        timeline_id.time=0;
        timeline_id.crc=crc16_calc_block(DBG_SAFE,(const void *)(&timeline_id.id),sizeof(timeline_id.id));
    }
    return(timeline_id.id);
}

// Выдает (с измененеим) номер нового пакета сквозной нумерации
uint32_t GetPacketNumber(void)
{
    return(timeline_id.packet_number++);
}

#if !defined(CFG_USE_LOG) || (CFG_USE_LOG != 1)
#else

#ifndef CFG_DEBUG_PORT
#define CFG_DEBUG_PORT    DEBUG_PORT
#endif // CFG_DEBUG_PORT

UartDriver* volatile   dbg_port = NULL;


static inline size_t min(size_t a, size_t b)
{
  return (a < b) ? a : b;
}

static void dbg_putc(unsigned char value) {
#ifdef DBG_ACTIVITY_GUARD
  DBG_ACTIVITY_GUARD = true;
#endif // DBG_ACTIVITY_GUARD

  UartDriver* port = dbg_port;
  if (port) {
    UartPut(port, value);
  }

#ifdef DBG_ACTIVITY_GUARD
  if (port)
  {
    if (UartWaitTxCompleteImmediately(port,TIMEOUT_FOREVER))
        DBG_ACTIVITY_GUARD = false;
  }
  else
        DBG_ACTIVITY_GUARD = false;
#endif // DBG_ACTIVITY_GUARD
}

static void dbg_puts(const char* str) {
#ifdef DBG_ACTIVITY_GUARD
  DBG_ACTIVITY_GUARD = true;
#endif // DBG_ACTIVITY_GUARD

  UartDriver* port = dbg_port;
  if (port) {
    while(*str) {
      UartPut(port, *str++);
    }
  }

#ifdef DBG_ACTIVITY_GUARD
  if (port)
  {
    if (UartWaitTxCompleteImmediately(port,TIMEOUT_FOREVER))
        DBG_ACTIVITY_GUARD = false;
  }
  else
        DBG_ACTIVITY_GUARD = false;
#endif // DBG_ACTIVITY_GUARD
}

void dbg_set_port(UartDriver* port) {
  dbg_port = port;
}

void dbg_print(const char* format, ...)
{
  va_list   args;
  va_start(args, format);
  xfvaprintf(dbg_putc, format, args);
  va_end(args);
}


void dbg_printhex(const void* buffer, size_t size)
{
#define bytes_per_line  16

  const uint8_t*  data = buffer;
  size_t          address = 0;
  size_t          bytes_left = size;

  while(bytes_left) {
    size_t bytes_in_line = min(bytes_left, bytes_per_line);

    // Вывод начального адреса текущей строки
    dbg_print("\r\n%08X: ", address);

    // Вывод данных текущей строки в 16-ричном виде
    for (size_t i=0; i < bytes_per_line; ++i) {
      char delimiter = ' ';
      if ((i % 8) == 7 && i != (bytes_per_line-1)) {
        // Разделяем 16-ричную строку на сегменты по 8 байт
        delimiter = '|';
      }

      if (i < bytes_in_line) {
        dbg_print("%02X%c", data[i], delimiter);
      } else {
        // данных нет, но нужно дойти до конца строки.
        dbg_print("  %c", delimiter);
      }
    }

    // Вывод разделителя
    dbg_puts("  | ");

    // Вывод в данных в сыром виде
    for (size_t i=0; i < bytes_per_line; ++i) {
      uint8_t byte;
      if (i >= bytes_in_line) {
        byte = ' ';
      } else if (data[i] < ' ') {
        byte = '.';
      } else {
        byte = data[i];
      }
      dbg_putc(byte);
    }

    // Завершение строки.
    dbg_puts(" |");
    data += bytes_in_line;
    address += bytes_in_line;
    bytes_left -= bytes_in_line;
  }

  // Завершение печати.
  dbg_puts("\r\n");
}

void __log_print_va(const char* level, const char* format, va_list args)
{
  dbg_puts(level);
  dbg_putc(':');
  dbg_putc(' ');

  xfvaprintf(dbg_putc, format, args);

  dbg_putc('\r');
  dbg_putc('\n');
}

void __log_print(const char* level, const char* format, ...)
{
  va_list   args;
  va_start(args, format);
  __log_print_va(level, format, args);
  va_end(args);
}

void __assert_failed(const char* file, int line, const char* function,
                     const char* expression, const char* comment)
{
#define UNKNOWN   "unknown"
  if (!file) {
    file = UNKNOWN;
  }
  if (!function) {
    function = UNKNOWN;
  }
  if (!expression) {
    expression = UNKNOWN;
  }
  if (!comment) {
    comment = "";
  }
  __log_print("FATAL",  "Assertion failed:\r\n\t"
                        "'%s' is false\r\n\t"
                        "in function %s\r\n\t"
                        "in file %s:%d\r\n\r\n\t"
                        "Description: '%s'",
              expression, function, file, line, comment);
  HaltWithReason("Assertion failed.", Halt_Assert_Failed, false);
}
#endif
