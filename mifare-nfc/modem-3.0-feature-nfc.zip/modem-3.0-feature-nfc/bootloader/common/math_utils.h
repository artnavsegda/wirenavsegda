/// \file math_utils.h
/// \author DL <dmitriy.linikov@gmail.com>
/// \brief вспомогательные вычислительные функции.

#ifndef MATH_UTILS_H_INCLUDED
#define MATH_UTILS_H_INCLUDED

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>


#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

static inline uint16_t abs_u16(int16_t value)
{
  return value > 0
         ? value
         : -value;
}

static inline size_t min_sizet(size_t a, size_t b) {
  return (a < b) ? a : b;
}

static inline uint32_t  min_u32(uint32_t a, uint32_t b) {
  return (a < b) ? a : b;
}

/// \brief Проверяет, что значение \p value находится в диапазоне значений
/// от \p min_inclusive до \p max_inclusive включительно.
static inline bool InRange(int value, int min_inclusive, int max_inclusive) {
  return value >= min_inclusive && value <= max_inclusive;
}

static inline bool FlagIsSet(uint32_t value, uint32_t flag) {
  return !!(value & flag);
}


#ifdef __cplusplus
}
#endif // __cplusplus

#endif // MATH_UTILS_H_INCLUDED
