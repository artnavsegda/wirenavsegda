/// \file encryption_gost.h
/// \author DL <dmitriy.linikov@gmail.com>
/// \brief Декларация функций для работы с шифрованием по ГОСТ.
/// \details Данный модуль адаптирован из public-domain исходного кода:
/// \see http://beginners.re/exercise-solutions/3/2/gost.c

#ifndef ENCRYPTION_GOST_H_INCLUDED
#define ENCRYPTION_GOST_H_INCLUDED

#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

/// \brief Build byte-at-a-time subtitution tables.
/// This must be called once for global setup.
extern void kboxinit(void);

/// \brief Does the GOST encryption on input buffer \p in and places the result
/// in output buffer \p out using the encription key \p key.
///
/// The GOST standard defines the input in terms of bits 1..64, with
/// bit 1 being the lsb of in[0] and bit 64 being the msb of in[1].
///
/// The keys are defined similarly, with bit 256 being the msb of key[7].
extern void gostcrypt(uint32_t out[2],
                      uint32_t const in[2],
                      uint32_t const key[8]);

/// \brief Decodes input buffer \p in, encoded with the encription key \p key,
/// and places the result to the output buffer \p out.
///
/// The GOST standard defines the input in terms of bits 1..64, with
/// bit 1 being the lsb of in[0] and bit 64 being the msb of in[1].
///
/// The keys are defined similarly, with bit 256 being the msb of key[7].
extern void gostdecrypt(uint32_t const in[2],
                        uint32_t out[2],
                        uint32_t const key[8]);


/// \brief Does the GOST encryption on input buffer \p in and places the result
/// in output buffer \p out using the encription key \p key.
///
/// The GOST standard defines the input in terms of bits 1..64, with
/// bit 1 being the lsb of in[0] and bit 64 being the msb of in[1].
///
/// The keys are defined similarly, with bit 256 being the msb of key[7].
extern void gost_encrypt_bytes(uint8_t        out[8],
                               uint8_t const  in[8],
                               uint32_t const key[8]);

/// \brief Осуществляет шифрование буффера \p src с длиною \p length используя
/// алгоритм ГОСТ с ключом \p key, после чего преобразует полученное значение
/// в HEX строку и помещает результат в буффер \p dst.
/// \warning Целевой буффер \p dst должен быть в 2 раза большего размера,
/// по сравнению с исходным размером данных \p length, плюс ещё 16 символов для
/// завершающего нуля и выравнивания.
extern void gost_encrypt_bytes_to_hex(void* dst, const void* src, size_t length,
                                      uint32_t const key[8]);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // ENCRYPTION_GOST_H_INCLUDED
