/// \file dbg.h
/// \author DL <dmitriy.linikov@gmail.com>
/// \brief

#ifndef DBG_H_INCLUDED
#define DBG_H_INCLUDED

// список точек входа
typedef enum SW_State_Position {
    SW_MAIN_START                           =   0x80000055,
    SW_MAIN_START_1                         =   0x80000056,
    SW_MAIN_START_2                         =   0x80000057,
    SW_MAIN_START_3                         =   0x80000058,
    SW_MAIN_START_4                         =   0x80000059,
    SW_MAIN_START_5                         =   0x8000005A,
    SW_MAIN_LOOP                            =   0x800000AA,
    SW_MAIN_LOOP_1                          =   0x800000AB,
    SW_MAIN_LOOP_2                          =   0x800000AC,
    SW_MAIN_LOOP_3                          =   0x800000AD,
    SW_MAIN_LOOP_4                          =   0x800000AE,
    SW_MAIN_SHORT_LOOP                      =   0x80000022,
    SW_MAIN_SHORT_LOOP_1                    =   0x80000023,
    SW_MAIN_SHORT_LOOP_2                    =   0x80000024,
    SW_MAIN_SHORT_LOOP_3                    =   0x80000025,
    SW_MAIN_SHORT_LOOP_4                    =   0x80000026,
    SW_MAIN_SHORT_LOOP_5                    =   0x80000027,
    SW_MAIN_SHORT_LOOP_6                    =   0x80000028,
    SW_MAIN_SHORT_LOOP_7                    =   0x80000029,
    SW_MAIN_SHORT_LOOP_8                    =   0x8000002A,
    SW_MAIN_SHORT_LOOP_9                    =   0x8000002B,
    SW_MAIN_SHORT_LOOP_10                   =   0x8000002C,
    SW_MAIN_SHORT_LOOP_11                   =   0x8000002D,
    SW_MAIN_SHORT_LOOP_12                   =   0x8000002E,
    SW_MAIN_SHORT_LOOP_13                   =   0x8000002F,
    SW_MAIN_SHORT_LOOP_14                   =   0x80000030,
    SW_MAIN_SHORT_LOOP_15                   =   0x80000031,
    SW_MAIN_SHORT_LOOP_16                   =   0x80000032,
    SW_MAIN_SHORT_LOOP_17                   =   0x80000033,
    SW_MAIN_SHORT_LOOP_18                   =   0x80000034,
    SW_MAIN_SHORT_LOOP_19                   =   0x80000035,
    Halt_UartDeinit                         =   0xF0000000,
    Halt_UartInit                           =   Halt_UartDeinit+1,
    Halt_Assert_Failed                      =   Halt_UartInit+1,
    Halt_SMS_Reset                          =   Halt_Assert_Failed+1,
    Halt_SaveReportToFLASH                  =   Halt_SMS_Reset+1,
    Halt_SendReportsFromFLASH               =   Halt_SaveReportToFLASH+1,
    Halt_Softdog_OnServerResponse           =   Halt_SendReportsFromFLASH+1,
    Halt_Softdog_OnReturnedToMainLoop       =   Halt_Softdog_OnServerResponse+1,
    Halt_Watchdog_Main                      =   Halt_Softdog_OnReturnedToMainLoop+1,
    Halt_Watchdog_Server                    =   Halt_Watchdog_Main+1,
    Halt__exit                              =   Halt_Watchdog_Server+1,
    Halt_Tests_Main                         =   Halt__exit+1,
    Halt_Tests_Main_GPRS                    =   Halt_Tests_Main+1,
    Halt_EnterLowPowerMode                  =   Halt_Tests_Main_GPRS+1,
    Halt_Jump_To_Boot                       =   Halt_EnterLowPowerMode+1,
    Not_Halt_Normal_Work                    =   Halt_Jump_To_Boot+1,
    Halt_Shutdown                           =   Not_Halt_Normal_Work+1,
    Halt_Softdog_OnServerResponse_Wait      =   Halt_Shutdown+1
} SW_State;


#include <stdarg.h>
#include "buffered_uart.h"
#include "system_utils.h"

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

extern volatile uint32_t back_software_position;
extern volatile uint32_t back_software_halt_position;
extern volatile uint32_t back_software_work_time;
extern volatile uint32_t back_timeline_id;

extern UartDriver* volatile   dbg_port;

SW_State Set_Software_Position(SW_State state);
SW_State Get_Halt_Position(void);
void Set_Halt_Position(SW_State state);
uint32_t GetSetSoftTime(systime_t time);
uint32_t GetSoftTime(void);
uint32_t GetTimelineIdTime(void);
void SetSoftTime(void);
// Выдает новый или старый идентификатор временного континиума модема
uint32_t GetTimelineId(void);
// Выдает (с измененеим) номер нового пакета сквозной нумерации
uint32_t GetPacketNumber(void);


#define LOG_LEVEL_TRACE   0
#define LOG_LEVEL_ALL     LOG_LEVEL_TRACE
#define LOG_LEVEL_DEBUG   1
#define LOG_LEVEL_INFO    2
#define LOG_LEVEL_WARN    3
#define LOG_LEVEL_ERROR   4
#define LOG_LEVEL_FATAL   5
#define LOG_LEVEL_OFF     128

#ifndef CFG_LOG_LEVEL
#define CFG_LOG_LEVEL     LOG_LEVEL_TRACE
#endif

#ifndef CFG_FILE_LOG_LEVEL
#define CFG_FILE_LOG_LEVEL  LOG_LEVEL_ALL
#endif // CFG_FILE_LOG_LEVEL

// Выбор уровня логов, использованного для текущего .c файла:
// Если глобальная настройка минимального уровня сообщений более строгая,
// чем установлено локально для текущего файла, то используется глобальная настройка
#if (CFG_LOG_LEVEL > CFG_FILE_LOG_LEVEL)
#define USED_LOG_LEVEL      CFG_LOG_LEVEL
#else
#define USED_LOG_LEVEL      CFG_FILE_LOG_LEVEL
#endif


#ifndef CFG_ASSERT_ENABLED
#define CFG_ASSERT_ENABLED  1
#endif

#if !defined(CFG_USE_LOG) || (CFG_USE_LOG != 1)
// Возможность полного отключения логов.

#define dbg_set_port(...)     ((void)0)
#define dbg_print(...)        ((void)0)
#define dbg_printhex(...)     ((void)0)
#define __log_print(...)      ((void)0)
#define __log_print_va(...)   ((void)0)
#define __assert_failed(...)  HaltWithReason("AssertionFailed.", Halt_Assert_Failed, false)

#else

void dbg_set_port(UartDriver* port);
void dbg_print(const char* format, ...);
void dbg_printhex(const void* buffer, size_t size);
void __log_print(const char* level, const char* format, ...);
void __log_print_va(const char* level, const char* format, va_list args);
void __assert_failed(const char* file, int line, const char* function,
                     const char* expression, const char* comment);
#endif // if !defined(CFG_USE_LOG) || (CFG_USE_LOG != 1)


#if (USED_LOG_LEVEL <= LOG_LEVEL_TRACE)
#define log_trace(...)                __log_print("TRACE", __VA_ARGS__)
#define log_trace_va(format, args)    __log_print_va("TRACE", (format), (args))
#define log_trace_printhex            dbg_printhex
#else
#define log_trace(...)                ((void)0)
#define log_trace_va(format, args)    ((void)0)
#define log_trace_printhex(...)       ((void)0)
#endif

#if (USED_LOG_LEVEL <= LOG_LEVEL_DEBUG)
#define log_debug(...)    __log_print("DEBUG", __VA_ARGS__)
#else
#define log_debug(...)    ((void)0)
#endif

#if (USED_LOG_LEVEL <= LOG_LEVEL_INFO)
#define log_info(...)    __log_print("INFO ", __VA_ARGS__)
#else
#define log_info(...)    ((void)0)
#endif

//#ifdef CFG_FW_TCPIP
#if (USED_LOG_LEVEL <= LOG_LEVEL_INFO)
#define log_lwip(...)    __log_print("lwip ", __VA_ARGS__)
#else
#define log_lwip(...)    ((void)0)
#endif
//#endif // CFG_FW_TCPIP

#if (USED_LOG_LEVEL <= LOG_LEVEL_WARN)
#define log_warn(...)    __log_print("WARN ", __VA_ARGS__)
#else
#define log_warn(...)    ((void)0)
#endif

#if (USED_LOG_LEVEL <= LOG_LEVEL_ERROR)
#define log_error(...)    __log_print("ERROR", __VA_ARGS__)
#else
#define log_error(...)    ((void)0)
#endif


#define log_func()          log_trace(__PRETTY_FUNCTION__)
#define log_func_result(ok) log_debug("%s: %s.", __PRETTY_FUNCTION__, \
                                      (ok) ? "Ok" : "Fail")

#if (CFG_ASSERT_ENABLED != 0)

#ifndef CFG_ASSERT_FAILED_CALL
/// Стандартная реализация вызова функции уведомления об ошибке.
/// При необходимости её можно переопределить.
#define CFG_ASSERT_FAILED_CALL(file, line, func, cond, msg)           \
  __assert_failed(file, line, func, cond, msg)

#endif // CFG_ASSERT_FAILED_CALL

#define dbg_assert(condition, message)                                \
    ((condition)                                                      \
      ? (void)0                                                       \
      : CFG_ASSERT_FAILED_CALL(__FILE__,                              \
                               __LINE__,                              \
                               __PRETTY_FUNCTION__,                   \
                               #condition,                            \
                               (message))                             \
    )

#else
#define dbg_assert(condition, message)    ((void)0)
#endif


#ifdef __cplusplus
}
#endif // __cplusplus

#endif // DBG_H_INCLUDED
