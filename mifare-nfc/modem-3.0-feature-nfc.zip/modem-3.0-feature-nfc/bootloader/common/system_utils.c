/// @file system_utils.c
/// @author DL <dmitriy.linikov@gmail.com>
/// @see system_utils.h

#include <stdlib.h>
#include "dbg.h"
#include "system_utils.h"

const char* g_halt_reason = NULL;


// перевод числа Big-Little endian 16 бит
uint16_t Change_BL_Endian_UINT16(uint16_t input)
{
    input=((input<<8)|(input>>8));
    return(input);
}

// перевод числа Big-Little endian 32 бита
uint32_t Change_BL_Endian_UINT32(uint32_t input)
{
    uint32_t f=Change_BL_Endian_UINT16((uint16_t)input);
    uint32_t s=Change_BL_Endian_UINT16((uint16_t)(input>>16));
    input=((f<<16)|s);
    return(input);
}



void HaltWithReason(const char* reason, SW_State state, bool reset)
{
  Set_Halt_Position(state);
  g_halt_reason = reason;

  log_info("Firmware execution stopped due to the following reason:");
  log_info(reason);
  log_info("Software position [0x%X], MSP [0x%X], PSP [0x%X],", state, __get_MSP(), __get_PSP());
  // Возобновляем питание RTC часов
  SystemRTCEnabled(true);
  delay_ms(500);
  BoardShutdown(reset);
}


/// \brief Необходимая для компилляции заглушка для стандартной библиотеки -
/// Вызывается при выходе из main().
void _exit(int code)
{
  (void)code;
  HaltWithReason("_exit() called.", Halt__exit, false);
}
