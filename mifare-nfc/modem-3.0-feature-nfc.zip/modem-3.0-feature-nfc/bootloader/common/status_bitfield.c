/// \file status_bitfield.c
/// \author DL <dmitriy.linikov@gmail.com>
/// \see status_bitfield.h

// #include "settings.h"
#include "status_bitfield.h"
// #include "dbg.h"
//#include "protocol_ofd.h"

volatile uint32_t status=0;

// // Процедура проверки флагов высоких приоритетов
// bool IsHighPriority(void)
// {
//     if (((status & (STATUS_BTN1_PRESSED | STATUS_BTN2_PRESSED | STATUS_BTN3_PRESSED)) && (StatusIsPowerOk())) ||
//         StatusIsScheduledTimeCome() ||
//         //OFDNeedToSend() ||
//         //(StatusIsPunchDetected() && (SettingsIsPunchDetectorEnabled())) ||
//         ((SettingsIsSendVendEnabled()) && (StatusHaveEventExeVend())) ||
//         ((SettingsIsSendVendEnabled()) && (StatusHasEventMdbVend()))
//         )
//             return (true);
//     return (false);
// }

// /// Процедура определения высокоприеритетного события по отношению к месту вызова (кcurrent_priority)
// bool NeedBreakeHighPriority(priority_t * level)
// {
//     bool ishigh=false;
//     if (level)
//     {
//         if (*level==HIGH_INTERRUPT)
//         {
//             log_error("NeedBreakeHighPriority: Error set level. Level is set HIGH_INTERRUPT.");
//             //*level=PRIORITY_LEVEL_MIN;
//             return (true);
//         }
//         // Печать чека
//         if (*level>PRIORITY_LEVEL_1)
//         {/// Приложение по приоритету ниже level 1
// #ifdef CFG_FW_PRINTER
//             ishigh|=
//             ((((SettingsIsSendVendEnabled()) && (StatusHaveEventExeVend())) ||
//             ((SettingsIsSendVendEnabled()) && (StatusHasEventMdbVend()))) == true);
// #endif // CFG_FW_PRINTER
//             /// ТЕСТ уБРАТЬ
//             //ishigh|=((status & (STATUS_BTN3_PRESSED)) == true);
//             if (ishigh) log_trace("Level 1 is higher");
//         }
//         // обработка SMS
//         if (*level>PRIORITY_LEVEL_2)
//         {/// Приложение по приоритету ниже level 2
//             ishigh|=
//             ((StatusHaveUnreadSms() && (SettingsIsSmsEnabled())) == true);
//             if (ishigh) log_trace("Level 2 is higher");
//         }
//         // Снятие отчета по кнопке
//         if (*level>PRIORITY_LEVEL_3)
//         {/// Приложение по приоритету ниже level 3
//             ishigh|=
//             (((status & (STATUS_BTN1_PRESSED | STATUS_BTN2_PRESSED | STATUS_BTN3_PRESSED)) && (StatusIsPowerOk())) == true);
//             if (ishigh) log_trace("Level 3 is higher");
//         }
//         // Снятие отчета по заданию
//         if (*level>PRIORITY_LEVEL_4)
//         {/// Приложение по приоритету ниже level 4
//             ishigh|=StatusIsScheduledTimeCome();
//             if (ishigh) log_trace("Level 4 is higher");
//         }
//         if (*level>PRIORITY_LEVEL_7)
//         {/// Приложение по приоритету ниже level 7
//             ishigh|=
//             ((((SettingsIsSendVendEnabled()) && (StatusHaveEventExeVend())) ||
//             ((SettingsIsSendVendEnabled()) && (StatusHasEventMdbVend()))) == true);
//             if (ishigh) log_trace("Level 7 is higher");
//         }
//     }
//     else log_error("NeedBreakeHighPriority: Not set level.");
//     if (ishigh)
//     {
//         log_info("NeedBreakeHighPriority: input priority level %d, set HIGH_INTERRUPT.", *level);
//         /// Соообщаем об обнаружении высокоприоритетного события
//         if (level) *level=HIGH_INTERRUPT;
//     }
//     return(ishigh);
// }
