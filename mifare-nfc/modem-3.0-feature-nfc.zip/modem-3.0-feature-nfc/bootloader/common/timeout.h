/// \file timeout.h
/// \author DL <dmitriy.linikov@gmail.com>
/// \brief Функции для более удобного отслеживания таймаутов.

#ifndef TIMEOUT_H_INCLUDED
#define TIMEOUT_H_INCLUDED

#include "systime.h"

#define TIMEOUT_FOREVER     (((systime_t)0) - 1)

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

typedef struct TimeoutStateTag {
  /// \brief Время старта данного таймаута
  systime_t   start;
  /// \brief Время завершения данного таймаута
  systime_t   end;
} timeout_t;

/// \brief Настраивает таймаута \p state на обратный отсчёт
/// с длительностью \p duration системных тиков.
static inline void timeout_start(timeout_t* state, systime_t duration) {
  systime_t now = systime_get();
  state->start = now;
  state->end = now + duration;
}

static inline bool timeout_is_elapsed(timeout_t* state) {
  return !systime_is_within(state->start, state->end);
}

static inline systime_t   timeout_ticks_left(timeout_t* state) {
  return timeout_is_elapsed(state)
          ? 0
          : state->end - systime_get();
}

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // TIMEOUT_H_INCLUDED
