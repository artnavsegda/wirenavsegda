/// \file gsm_sim900.c
/// \author DL <dmitriy.linikov@gmail.com>
/// \see gsm_sim900.h

#ifndef CFG_FILE_LOG_LEVEL
#define CFG_FILE_LOG_LEVEL  LOG_LEVEL_INFO
#endif // CFG_FILE_LOG_LEVEL

#include <string.h>

#include <xprintf.h>
#include <ccan/array_size/array_size.h>

#include "uart.h"
#include "timeout.h"
#include "gsm_sim900.h"
#include <utils/string_utils.h>
#include "system_utils.h"
#include "watchdog.h"
#include "math_utils.h"
#include "dbg.h"
#include "gsm_sim900.h"

#define CFG_GSM_DEFAULT_TIMEOUT   2000

#define CFG_GSM_SOCKET_TIMEOUT    60000

typedef struct {
  bool              initialized;
  bool              turned_on;
  USART_TypeDef*    port;
  uint8_t*          rx_buffer;
  size_t            rx_buffer_size;
  size_t            rx_buffer_index;
  size_t            readed_index;
  Sim900ModuleInfo  module;
#ifdef CFG_FW_TCPIP
  bool              data_mode;
  bool             (*data_react)(void);
#endif // CFG_FW_TCPIP
} Sim900Driver;

// Обязательно с символами перевода строки, что бы всегда дожидаться полного ответа.
static const char   RESPONSE_OK[] = "\r\nOK\r\n";

static Sim900Driver   drv_obj = {false, false, NULL, NULL,.module=SIM_MODULE_UNKNOW,
#ifdef CFG_FW_TCPIP
                                .data_mode=false,.data_react=NULL,
#endif // CFG_FW_TCPIP
                                };

// Данная переменная нужна для относительно лёгкого перехода к
// работе с sim900 через хэндл. Это должно быть единственное место использования
// переменной drv_obj
static Sim900Driver*  handle = &drv_obj;

/// Обертки команд
#ifdef CFG_FW_TCPIP
// Должна вызываться в начале каждой команды
#define SET_CMD_MODE()         volatile bool cmd_mode=false;\
                                if (handle->data_mode)\
                                {/* В режиме данных */\
                                    if (handle->data_react){ /*if (handle->data_react()) delay_ms(100);*/\
                                    timeout_t timeout;\
                                    timeout_start(&timeout, 150);\
                                    uint16_t wait=0;\
                                    while (!timeout_is_elapsed(&timeout))\
                                    {\
                                        if (!handle->data_react())\
                                        {\
                                            if (wait++<2) delay_ms(2);\
                                            else break;\
                                        }\
                                        else wait=0;\
                                    }}\
                                        /* Переключаемся в командный режим */\
                                        cmd_mode=sim900_cmd_mode();\
                                }\

// Должна вызываться в конце каждой команды
#define SET_DATA_MODE()         /* Возврат в установленный режим */\
                                    if (cmd_mode) sim900_data_mode();
#else
#define SET_CMD_MODE()          ((void)0)
#define SET_DATA_MODE()         ((void)0)
#endif

/// \brief Функция, вызываемая при приёме очередного символа от GSM модуля.
/// Должна вызываться из обработчика прерывания нужного UART порта.
/// Сделана как быстрый костыль для отделения кода работы с GSM модулем
/// от основной прошивки.
void __sim900_on_rx_char(uint8_t value)
{
  if (handle->rx_buffer_index < handle->rx_buffer_size) {
    handle->rx_buffer[handle->rx_buffer_index] = value;
    ++handle->rx_buffer_index;
  }
}

#ifdef CFG_FW_TCPIP
static void ClearRxBuffer_fake(void)
{
  __disable_irq();
  handle->readed_index=handle->rx_buffer_index;
  __enable_irq();
}
#endif

static void ClearRxBuffer()
{
  __disable_irq();
  memset(handle->rx_buffer, 0, handle->rx_buffer_size);
  handle->rx_buffer_index = 0;
  handle->readed_index=0;
  __enable_irq();
}

/// \brief Выводит один символ в последовательный порт модема.
/// \note Данная функция служит только одной цели: для осуществления
/// форматированного вывода текста через xfvaprintf в функции cmd_ex.
/// Во всех остальных случаях следует использовать uart_putc(handle->port,...)
static void print_to_modem(unsigned char value)
{
  uart_putc(handle->port, value);
}



/// \brief Осуществляет форматированный вывод текста в последовательный порт
/// GSM модуля, используя список аргументов.
static void SendToModemVA(const char* format_str, va_list var_args)
{
  xfvaprintf(print_to_modem, format_str, var_args);
}


void sim900_clear_buffer()
{
  ClearRxBuffer();
}

/// \brief Устанавливает флаг, что модем включен.
/// Этот флаг нужен для того, что бы внешний код не пытался общаться с модемом
/// до непосредственного включения модема.
void sim900_turn_on()
{
  handle->turned_on = true;
#ifndef FW_TESTS
  signal_ri=RI_NOT_ACTIVE;
#endif // FW_TESTS
}

void sim900_turn_off()
{
  handle->turned_on = false;
#ifdef CFG_FW_TCPIP
  handle->data_mode = false;
#endif // CFG_FW_TCPIP
}

bool sim900_is_on()
{
  return handle->turned_on;
}


void sim900_init(Sim900Config* config)
{
  log_func();

  handle->initialized = false;
  if (   !config
      || !config->port
      || !config->rx_buffer
      || !config->rx_buffer_size) {
    return;
  }
  handle->port = config->port;
  handle->rx_buffer = config->rx_buffer;
  handle->rx_buffer_size = config->rx_buffer_size;
#ifdef CFG_FW_TCPIP
  handle->data_react= config->data_react;
#endif // CFG_FW_TCPIP

  ClearRxBuffer();

  handle->initialized = true;
}





/// \brief Ждёт в течение \p seek_timeout_ms миллисекунд ответ модема \p response_to_seek.
/// \return Если искомый ответ был получен в установленное время,
/// то возвращает true, иначе, возвращает false.
bool SeekModemResponse(const char* response_to_seek, uint16_t offset,
                       uint32_t seek_timeout_ms)
{
  bool  response_found = 0;
  char* src = (char*)(handle->rx_buffer + offset);

  timeout_t   timeout;
  timeout_start(&timeout, seek_timeout_ms);

  while( !timeout_is_elapsed(&timeout) && !response_found) {
    __disable_irq();
    uint16_t current_offset = handle->rx_buffer_index;
    __enable_irq();
    if (current_offset>offset)
    {
        response_found = (memcmpstr_ext(src, response_to_seek, current_offset-offset) != NULL);
        if (memcmpstr_ext(src, "\r\nERROR\r\n", current_offset-offset) != NULL) {
            log_debug("     GSM returned ERROR.\r\n Buffer=[%s]", handle->rx_buffer);
            return false;
        }
        if (memcmpstr_ext(src, "\r\nCONNECT FAIL\r\n", current_offset-offset) != NULL) {
            log_debug("     GSM returned CONNECT FAIL.\r\n Buffer=[%s]", handle->rx_buffer);
            return false;
        }
    }
  }

  //printbuffer();

  if (timeout_is_elapsed(&timeout)) {
    log_debug("     GSM response time out.\r\n Buffer=[%s]", handle->rx_buffer);
  } else {
    log_trace("     GSM response in time.");
  }

  return response_found;
}

/// \brief Отправляет команду \p command GSM модулю и ожидает в ответ
/// строку \p response_to_seek.
/// \return true, если искомая строка обнаружена в ответе GSM модуля,
/// иначе false.
/// \note Данная команда не добавляет ни каких дополнительных символов к
/// команде. Поэтому, команда должна содержать в себе в т.ч. символ возврата
/// каретки (<CR> = 0x0D = '\r').
bool cmd_timeout(const char* command, const char* response_to_seek,
                 bool clear_rx, uint32_t timeout_ms)
{
  if (!handle->turned_on) {
    return false;
  }

  if (clear_rx) {
    ClearRxBuffer();
  }

  uart_puts(handle->port, command);
  __disable_irq();
  uint16_t current_offset = handle->rx_buffer_index;
  __enable_irq();
  bool ok = SeekModemResponse(response_to_seek, current_offset,
                              timeout_ms);

  log_trace("SIM900: cmd() complete. Status=%s\r\n\tCMD=[%s]\r\n\tRSP=[%s]\r\n",
            ok ? "Ok" : "Fail", command, handle->rx_buffer);
#if (USED_LOG_LEVEL <= LOG_LEVEL_DEBUG)
  uint16_t current_offset_s=current_offset;
  __disable_irq();
  current_offset = handle->rx_buffer_index;
  __enable_irq();
  dbg_printhex(handle->rx_buffer+current_offset_s, current_offset-current_offset_s);
#endif
  return ok;
}

/// \brief Отправляет команду \p command GSM модулю и ожидает в ответ
/// строку \p response_to_seek.
/// \return true, если искомая строка обнаружена в ответе GSM модуля,
/// иначе false.
/// \note Данная команда не добавляет ни каких дополнительных символов к
/// команде. Поэтому, команда должна содержать в себе в т.ч. символ возврата
/// каретки (<CR> = 0x0D = '\r').
bool cmd(const char* command, const char* response_to_seek, bool clear_rx)
{
  return cmd_timeout(command, response_to_seek, clear_rx,
                     CFG_GSM_DEFAULT_TIMEOUT);
}

/// \brief Отправляет команду \p command GSM модулю и ожидает в ответ
/// строку \p response_to_seek.
/// \return true, если искомая строка обнаружена в ответе GSM модуля,
/// иначе false.
/// \note Данная команда не добавляет ни каких дополнительных символов к
/// команде. Поэтому, команда должна содержать в себе в т.ч. символ возврата
/// каретки (<CR> = 0x0D = '\r').
bool sim900_cmd(const char* command, const char* response_to_seek, bool clear_rx)
{
  return cmd(command, response_to_seek, clear_rx);
}

static bool cmd_va(const char* command_format, const char* response_to_seek,
                   uint32_t timeout_ms, bool clear_rx, va_list format_args)
{
  if (!handle->turned_on) {
    return false;
  }

  if (clear_rx) {
    ClearRxBuffer();
  }

  __disable_irq();
  uint16_t current_offset = handle->rx_buffer_index;
  __enable_irq();

  xfvaprintf(print_to_modem, command_format, format_args);

  bool ok = SeekModemResponse(response_to_seek, current_offset, timeout_ms);
  log_trace("SIM900: cmd_va() complete. Status=%s\r\n\tCMD=[%s]\r\n\tRSP=[%s]\r\n",
            ok ? "Ok" : "Fail", command_format, handle->rx_buffer);
  log_trace_va(command_format, format_args);
#if (USED_LOG_LEVEL <= LOG_LEVEL_DEBUG)
  __disable_irq();
  current_offset = handle->rx_buffer_index;
  __enable_irq();
  dbg_printhex(handle->rx_buffer, current_offset);
#endif
  return ok;
}

/// \brief Форматирует (\see xprintf или \see printf) команду и выводит её
/// в последовательный порт модема, после чего ждёт ответа \p response_to_seed.
/// \param command_format     строка форматирования команды (без символа <CR>)
/// \param response_to_seek   строка, которую следует искать в ответе модема.
/// \param clear_rx           нужно ли перед выполнением команды очистить буффер
/// \param ...                дополнительные параметры, для форматирования команды
///
/// \note Данная команда не добавляет ни каких дополнительных символов к
/// команде. Поэтому, команда должна содержать в себе в т.ч. символ возврата
/// каретки (<CR> = 0x0D = '\r').
///
/// \return true, если искомая строка (\p response_to_seek) обнаружена
/// в ответе GSM модуля, иначе false.
bool cmd_ex(const char* command_format, const char* response_to_seek, bool clear_rx, ...)
     __attribute__ (( format( printf, 1, 4 ) ));

bool cmd_ex(const char* command_format, const char* response_to_seek, bool clear_rx, ...)
{
  bool result;

  va_list   var_args;
  va_start(var_args, clear_rx);

  result = cmd_va(command_format, response_to_seek,
                  CFG_GSM_DEFAULT_TIMEOUT, clear_rx, var_args);

  va_end(var_args);
  return result;
}

bool cmd_ex_timeout(const char* command_format, const char* response_to_seek,
                    uint32_t timeout, bool clear_rx, ...)
                    __attribute__ (( format( printf, 1, 5 ) ));

bool cmd_ex_timeout(const char* command_format, const char* response_to_seek,
                    uint32_t timeout_ms, bool clear_rx, ...)
{
  bool result;

  va_list   var_args;
  va_start(var_args, clear_rx);

  result = cmd_va(command_format, response_to_seek, timeout_ms,
                  clear_rx, var_args);

  va_end(var_args);
  return result;
}

/// \brief Выполняет команду AT
bool sim900_ping(void)
{
  log_func();
  SET_CMD_MODE();
  bool ok = cmd("AT\r", RESPONSE_OK, CLEAR_RXBUFFER);
  /// Временно. Включает расширенный режим вывода ошибок
  //cmd("AT+CMEE=2\r", RESPONSE_OK, CLEAR_RXBUFFER);
  /// Отключает автодетект карты
  //cmd("AT+CSDT=0\r", RESPONSE_OK, CLEAR_RXBUFFER);
  log_func_result(ok);
  SET_DATA_MODE();
  return ok;
}

/// \brief Ожидание готовности GSM модуля к приёму команд.
bool sim900_wait_ready(size_t retries)
{
  log_func();
  bool ret=false;
  SET_CMD_MODE();
  while(retries--) {
    if (sim900_ping()) {
      ret=true;
      break;
    }
    delay_ms(500);
  }
  SET_DATA_MODE();
  return(ret);
}

/// \brief отключает эхо-ответ GSM модуля.
bool sim900_disable_echo(void)
{
  log_func();
  SET_CMD_MODE();
  bool ok = cmd("ATE0\r", RESPONSE_OK, CLEAR_RXBUFFER);
  //cmd("AT+CPIN?\r", RESPONSE_OK, CLEAR_RXBUFFER);
  log_func_result(ok);
  SET_DATA_MODE();
  return ok;
}

/// \brief Устанавливает режим функционирования GSM модуля.
bool sim900_set_functionality(Sim900Functionality mode, bool reset)
{
  log_func();
  SET_CMD_MODE();
  uint32_t timeout = (mode == SIM_FUNC_NORMAL)
                   ? (CFG_GSM_DEFAULT_TIMEOUT * 2)
                   : CFG_GSM_SOCKET_TIMEOUT;
  bool ok = cmd_ex_timeout("AT+CFUN=%u%s\r", RESPONSE_OK, timeout, CLEAR_RXBUFFER,
                           mode,
                           reset ? ",1" : "");
  log_func_result(ok);
  SET_DATA_MODE();
  return ok;
}

/// \brief Проверяет готовность SIM карты.
bool sim900_is_sim_ready(void)
{
  log_func();
  SET_CMD_MODE();
  // Необходимо дождаться ответа OK
  bool ready = cmd("AT+CPIN?\r", RESPONSE_OK, CLEAR_RXBUFFER);
  if (!ready) {
    log_debug("Failed to read +CPIN form GSM module.");
  }
  else
  {
    char* status = strstr_ex((char*)handle->rx_buffer, "+CPIN: ");
    if (!status) {
        log_debug("No +CPIN: in GSM response.");
        ready=false;
    }
    else
    {
        char* status_end = strstr(status, RESPONSE_OK);
        if (!status_end) {
            log_debug("No OK in +CPIN response.");
            ready=false;
        }
        else
        {
            *status_end = '\0';
            log_trace("is_sim_ready: SIM status = '%s'", status);

            ready = StartsWith(status, "READY");
        }
    }
  }
  log_func_result(ready);
  SET_DATA_MODE();
  return ready;
}

/// \brief Делает до \p retries проверок готовности SIM карты с интервалом
/// в 500 мс.
/// \return Возвращает true, если SIM карта готова.
bool sim900_wait_sim_ready(size_t retries)
{
  log_func();
  bool ret=false;
  SET_CMD_MODE();
  while (retries--) {
    if (sim900_is_sim_ready()) {
      ret=true;
      break;
    }
    delay_ms(500);
  }
  SET_DATA_MODE();
  return(ret);
}

/// \brief Запрашивает текущее время у GSM модуля. В случае успеха сохраняет
/// указатель на строку с текущим временем в переменную по адресу \p dst.
bool sim900_get_time(UnpackedTime* dst)
{
#define MAX_SIM900_TIME_LEN         20
  log_func();
  bool ret=false;
  SET_CMD_MODE();
  if (!cmd("AT+CCLK?\r", RESPONSE_OK, CLEAR_RXBUFFER)) {
    ret=false;
  }
  else
  {
    char* time = strstr_ex((char*)handle->rx_buffer, "+CCLK: \"");
    if (!time) {
        ret=false;
    }
    else
    {
        char* end_time = strchr(time, '\"');
        if (!end_time) {
            ret=false;
        }
        else
        {
            // удаляем, всё, что не входит в кавычки.
            *end_time = '\0';
            // Проверяем длину строки с полученным временем
            if ((end_time-time)<MAX_SIM900_TIME_LEN)
                ret=false;
            else
            {
                log_debug("Sim900 RTC value=[%s].", time);
                if (dst) {
                    ret=TimeParseSim900Format(dst, time);
                }
                else ret=true;
            }
        }
    }
  }
  SET_DATA_MODE();
  return(ret);
}

/// \brief Записывает в часы реального времени GSM модуля указанное время.
bool sim900_set_time(UnpackedTime* t)
{
  log_debug("Setting time to GSM module: %02u/%02u/%02u,%02u:%02u:%02u+00",
                t->year % 100, t->month % 100, t->day % 100,
                t->hour % 100, t->minute % 100, t->second % 100);
  bool ret;
  SET_CMD_MODE();
  // Вывод строки в формате AT+CCLK="ГГ/ММ/ДД,чч:мм:сс+00".
  // Все параметры делим по модулю 100, что бы точно было не больше 2 цифр,
  // иначе может случиться переполнение буффера и порча стека.
  ret= cmd_ex("AT+CCLK=\"%02u/%02u/%02u,%02u:%02u:%02u+00\"\r", RESPONSE_OK,
                CLEAR_RXBUFFER,
                t->year % 100, t->month % 100, t->day % 100,
                t->hour % 100, t->minute % 100, t->second % 100);
  SET_DATA_MODE();
  return(ret);
}

/// \brief Возвращает true, если GSM модуль зарегистрирован в домашней сети.
bool sim900_is_network_ready(bool * roaming)
{
  log_func();
  SET_CMD_MODE();
  bool ready = cmd("AT+CREG?\r", "+CREG: 0,1", CLEAR_RXBUFFER);
  /// Роуминг
  if (!ready)
  {
      ready = cmd("AT+CREG?\r", "+CREG: 0,5", CLEAR_RXBUFFER);
      if ((ready) && (roaming)) *roaming=true;
  }
  log_func_result(ready);
  SET_DATA_MODE();
  return ready;
}

/// \brief Делает до \p retries проверок регистрации в GSM сети с интервалом
/// в 1000 мс.
/// \return Возвращает true, если GSM модуль зарегистрирован в домашней сети.
bool sim900_wait_network_ready(size_t retries)
{
  log_func();
  bool ret=false;
  SET_CMD_MODE();
  while (retries--) {
    if (sim900_is_network_ready(NULL)) {
      ret=true;
      break;
    }
    delay_ms(1000);
  }
  SET_DATA_MODE();
  return(ret);
}

/// \brief Возвращает true, если в настоящий момент возможно начать GPRS
/// сеанс связи.
bool sim900_is_gprs_available(void)
{
  log_func();
  SET_CMD_MODE();
  bool available = cmd("AT+CGATT?\r", "+CGATT: 1", CLEAR_RXBUFFER);
  log_func_result(available);
  SET_DATA_MODE();
  return available;
}

/// \brief Вызывает +CGATT=1 для случаев, когда gsm модуль не пытается
/// автоматически подключиться к GPRS.
bool sim900_force_enable_gprs()
{
  log_func();
  SET_CMD_MODE();
  bool result = cmd_timeout("AT+CGATT=1\r", RESPONSE_OK, CLEAR_RXBUFFER,
                            CFG_GSM_SOCKET_TIMEOUT);
  log_func_result(result);
  SET_DATA_MODE();
  return result;
}

/// \brief Делает до \p retries проверок возможности начать GPRS сеанс
/// с интервалом в 500 мс.
/// \return Возвращает true, если в настоящий момент возможно начать GPRS
/// сеанс связи.
bool sim900_wait_gprs_available(size_t retries)
{
  log_func();
  bool ret=false;
  SET_CMD_MODE();
  while (retries--) {
    if (sim900_is_gprs_available()) {
      ret=true;
      break;
    }
  }
  SET_DATA_MODE();
  return(ret);
}

/// \brief Запрашивает у GSM модуля номер IMEI и сохраняет его в буффер
/// \p imei_buffer, заканчивая строку нуль-символом.
bool sim900_get_imei(char* imei_buffer, size_t buffer_size)
{
  log_func();
  bool ret=false;
  SET_CMD_MODE();
  if (!cmd("AT+GSN\r", RESPONSE_OK, CLEAR_RXBUFFER)) {
    ret=false;
  }
  else
  {
    if (imei_buffer) {
        strncpy_ex(imei_buffer, (char*)handle->rx_buffer + 2, --buffer_size);
        log_debug("Requested imei=[%s]", imei_buffer);
    }
    ret=true;
  }
  SET_DATA_MODE();
  return(ret);
}

/// \brief Запрашивает у GSM модуля его идентификатор и сохраняет его в буффер
/// \p sim_buffer, заканчивая строку нуль-символом.
Sim900ModuleInfo sim900_get_siminfo(char* sim_buffer, size_t buffer_size)
{
  log_func();
  Sim900ModuleInfo ret=SIM_MODULE_UNKNOW;
  SET_CMD_MODE();
  if (!cmd("ATI\r", RESPONSE_OK, CLEAR_RXBUFFER)) {
    ret=SIM_MODULE_ERROR;
  }
  else
  {

    char * sim_id=strstr((char*)handle->rx_buffer,"SIM900");
    if (sim_id) ret=SIM_MODULE_SIM900;
    else
    {
        sim_id=strstr((char*)handle->rx_buffer,"SIM800");
        if (sim_id) ret=SIM_MODULE_SIM800;
    }

    if (sim_buffer) {
        sim_id=strstr((char*)handle->rx_buffer + 2,"\r\n");
        if (sim_id)
        {
            size_t len=sim_id-((char*)handle->rx_buffer + 2);
            buffer_size=min_u32(len+1,buffer_size);
        }
        strncpy_ex(sim_buffer, (char*)handle->rx_buffer + 2, --buffer_size);
        sim_buffer[buffer_size+1]='\0';
        log_debug("Requested SIM info=[%s]", sim_buffer);
    }
    if (ret==SIM_MODULE_SIM800)
    {
        /// Для модуля SIM800 выключем поддержку контроля напряжений
        /// Из-за ошибок на нашей плате (MODEM 1.x и MODEM 2.x), нет возможности сформировать напряжение в диапазоне для SIM800 (сделано только для SIM900)
        if (cmd("AT+CBATCHK?\r", RESPONSE_OK, CLEAR_RXBUFFER))
        {
            char * cbatchk=strstr_ex((char*)handle->rx_buffer,"+CBATCHK: 0");
            if (!cbatchk)
            {// Параметр не установлен. Задаем его
                /// Для модуля SIM800 выключаем информирование о напряжениях
                if (!cmd("AT+CBATCHK=0\r", RESPONSE_OK, CLEAR_RXBUFFER))
                    log_error("Can't set AT+CBATCHK=0 - disable information about power.");
                /// Для модуля SIM800 выключаем контроль напряженяи со стороны SIMcom
                if (!cmd("AT+CBATRANG=0\r", RESPONSE_OK, CLEAR_RXBUFFER))
                    log_error("Can't set AT+CBATRANG=0 - disable voltage control.");
                /// Сохраняем настройки
                if (!cmd("AT&W\r", RESPONSE_OK, CLEAR_RXBUFFER))
                    log_error("Can't save settings.");
            }
        }
    }
    handle->module=ret;
  }
  SET_DATA_MODE();
  return ret;
}

/// \brief Запрашивает у GSM модуля версию прошивки и сохраняет его в буффер
/// \p sim_buffer, заканчивая строку нуль-символом.
bool sim900_get_swversion(char* sim_buffer, size_t buffer_size)
{
  log_func();
  bool ret=false;
  SET_CMD_MODE();
  if (!cmd("AT+GMR\r", RESPONSE_OK, CLEAR_RXBUFFER)) { // или AT+CGMR
    ret=false;
  }
  else
  {

    char * sw_version=strstr_ex((char*)handle->rx_buffer,"Revision:");
    if (!sw_version) sw_version=(char*)handle->rx_buffer;
    if (sim_buffer) {
        char * sw_version_end=strstr(sw_version,"\r\n");
        if (sw_version_end)
        {
            size_t len=sw_version_end-sw_version;
            buffer_size=min_u32(len+1,buffer_size);
        }
        strncpy_ex(sim_buffer, sw_version, --buffer_size);
        sim_buffer[buffer_size+1]='\0';
        log_debug("Requested module SW version =[%s]", sim_buffer);
    }
    ret=true;
  }
  SET_DATA_MODE();
  return ret;
}


/// \brief Устанавливает настройки GPRS соединения.
bool sim900_set_gprs_settings(const char* apn,
                              const char* user, const char* password)
{
  log_func();
  bool ret=false;
  SET_CMD_MODE();
  if (cmd("AT+SAPBR=3,1,\"CONTYPE\",\"GPRS\"\r", RESPONSE_OK, CLEAR_RXBUFFER)) {
    if (cmd_ex("AT+SAPBR=3,1,\"APN\",\"%s\"\r", RESPONSE_OK, CLEAR_RXBUFFER, apn)) {
        if (cmd_ex("AT+SAPBR=3,1,\"USER\",\"%s\"\r", RESPONSE_OK, CLEAR_RXBUFFER, user)) {
            if (cmd_ex("AT+SAPBR=3,1,\"PWD\",\"%s\"\r", RESPONSE_OK, CLEAR_RXBUFFER, password)) {
                // Очень долго поднимается FTP стек в модуле SIMCOM
                if (cmd_timeout("AT+SAPBR=1,1\r", RESPONSE_OK, CLEAR_RXBUFFER, 20000)) {
                    ret=true;;
                }
            }
        }
    }
  }
  SET_DATA_MODE();
  return(ret);
}

/// \brief Из даташита: Start Task and Set APN, USER, PASSWORD.
bool sim900_init_ip_session(const char* apn, const char* user, const char* pwd)
{
  log_func();
  SET_CMD_MODE();
  bool ok = cmd_ex_timeout("AT+CSTT=\"%s\",\"%s\",\"%s\"\r", RESPONSE_OK,
                           CFG_GSM_SOCKET_TIMEOUT,
                           CLEAR_RXBUFFER,
                           apn, user, pwd);
  log_func_result(ok);
  SET_DATA_MODE();
  return ok;
}

/// Осуществляет перевод GPRS в начальное состояние (для повтора инициализации)
bool sim900_deactivate_gprs(void)
{
  log_func();
  SET_CMD_MODE();
  bool ok = cmd_timeout("AT+CIPSHUT\r", "\r\nSHUT OK", CLEAR_RXBUFFER,
                        CFG_GSM_SOCKET_TIMEOUT);
  log_func_result(ok);
  SET_DATA_MODE();
  return ok;
}

/// \brief Осуществляет подключение GPRS сессии.
bool sim900_start_ip_session(void)
{
  log_func();
  SET_CMD_MODE();
  bool ok = cmd_timeout("AT+CIICR\r", RESPONSE_OK, CLEAR_RXBUFFER,
                        CFG_GSM_SOCKET_TIMEOUT);
  log_func_result(ok);
  SET_DATA_MODE();
  return ok;
}

/// \brief Проверяет, что GSM модулю был выделен ip адрес.
bool sim900_has_local_ip_address(void)
{
  log_func();
  SET_CMD_MODE();
  bool ok = cmd("AT+CIFSR\r",".", CLEAR_RXBUFFER);
  log_func_result(ok);
  SET_DATA_MODE();
  return ok;
}

/// \brief Запрашивает мощность принимаемого от сети сигнала и
/// сохраняет указатель на сами данные в переменной по адресу \p dst.
///
/// Полученные данные имеют формат: `<rssi>,<ber>\0`, где
/// - <rssi> - мощность сигнала: 0=-115дБ и ниже, 1=-111дБ, 2..30=-110..-54дБ,
/// - <ber> - bit error rate в процентах
///
/// Если функция возвращает false, то состояние переменной, на которую указывает
/// \p dst, остаётся без изменений.
bool sim900_get_signal_quality(char** dst)
{
  log_func();
  bool ret=false;
  SET_CMD_MODE();
  if (!cmd("AT+CSQ\r", RESPONSE_OK, CLEAR_RXBUFFER)) {
    ret=false;
  }
  else
  {
    char* result_start = strstr_ex((char*)handle->rx_buffer, "+CSQ: ");
    if (!result_start) {
        ret=false;
    }
    else
    {
        char* result_end = strstr(result_start, "\r\n");
        if (!result_end) {
            ret=false;
        }
        else
        {
            // удаляем всё, что дальше конца превой строки ответа.
            *result_end = '\0';
            log_debug("GSM signal strength: %s", result_start);
            if (dst) {
                *dst = result_start;
            }
            ret=true;
        }
    }
  }
  SET_DATA_MODE();
  return(ret);
}

/// \brief Выбирает текстовый формат SMS сообщений (а не PDU).
bool sim900_select_smsformat_text(void)
{
  log_func();
  SET_CMD_MODE();
  bool ok = cmd("AT+CMGF=1\r", RESPONSE_OK, CLEAR_RXBUFFER);
  log_func_result(ok);
  SET_DATA_MODE();
  return ok;
}

/// \brief Возвращает номер ccid SIM карты.
bool sim900_get_ccid(char** ccid)
{
  log_func();
  bool ret=false;
  SET_CMD_MODE();
  if (cmd_timeout("AT+CCID\r", RESPONSE_OK, CLEAR_RXBUFFER, CFG_GSM_SOCKET_TIMEOUT)) {
    if (ccid) {
        *ccid = (char*)handle->rx_buffer + 2;
    }
    ret=true;
  }
  SET_DATA_MODE();
  return(ret);
}

/// Возвращает номер IMSI SIM карты
bool sim900_get_imsi(char** imsi)
{
  log_func();
  bool ret=false;
  SET_CMD_MODE();
  if (cmd_timeout("AT+CIMI\r", RESPONSE_OK, CLEAR_RXBUFFER, CFG_GSM_SOCKET_TIMEOUT)) {
    if (imsi) {
        *imsi = (char*)handle->rx_buffer + 2;
    }
    ret=true;
  }
  SET_DATA_MODE();
  return(ret);
}

/// \brief Открывает соединение с сервером.
/// \return Если операция выполнена успешна, то возвращает true.
bool SocketOpen(const char* server_name, const char* port_str)
{
  log_func();
  SET_CMD_MODE();
  // формат команды AT+CIPSTART="TCP","имя_сервера","номер_порта"
  bool ok = cmd_ex_timeout("AT+CIPSTART=\"TCP\",\"%s\",\"%s\"\r",
                          "CONNECT OK",
                          CFG_GSM_SOCKET_TIMEOUT,
                          CLEAR_RXBUFFER,
                          server_name,
                          port_str);
  log_func_result(ok);
  SET_DATA_MODE();
  return ok;
}

/// \brief Закрывает TCP/UDP соединение.
/// \return Если операция выполнена успешна, то возвращает true.
bool SocketClose(bool clear_rx_buffer)
{
  log_func();
  SET_CMD_MODE();
  bool ok = cmd("AT+CIPCLOSE\r", "CLOSE OK", clear_rx_buffer);
  log_func_result(ok);
  SET_DATA_MODE();
  return ok;
}

/// \brief Подготавливает GSM модуль к приёму произвольной порции данных
/// для отправки серверу. Данные будут переданы при получении символа
/// Ctrl-Z (0x1A)
/// \return Если операция выполнена успешна, то возвращает true.
bool StartSendingData()
{
  log_func();
  SET_CMD_MODE();
  bool ok = cmd("AT+CIPSEND\r", ">", CLEAR_RXBUFFER);
  log_func_result(ok);
  SET_DATA_MODE();
  return ok;
}

/// \brief Подготавливает GSM модуль к приёму порции данных длиной \p length
/// для отправки серверу. Данные будут переданы как только GSM модуль получит
/// \p length байт данных.
/// \return Если операция выполнена успешна, то возвращает true.
bool StartSendingDataWithLength(size_t length)
{
  log_func();
  SET_CMD_MODE();
  bool ok = cmd_ex("AT+CIPSEND=%u\r", ">", CLEAR_RXBUFFER, length);
  log_func_result(ok);
  SET_DATA_MODE();
  return ok;
}

/// \brief Заканчивает передачу данных произвольной длины (символом 0x1A) и
/// ждёт передачи этих данных GSM модулем.
/// \return Если операция выполнена успешна, то возвращает true.
bool EndSendingData()
{
  log_func();
  SET_CMD_MODE();
  bool ok = cmd_timeout("\x1A", "SEND OK", CLEAR_RXBUFFER,
                        CFG_GSM_SOCKET_TIMEOUT);
  log_func_result(ok);
  SET_DATA_MODE();
  return ok;
}

/// \brief Отправляет строку, оканчивающуюся нулём, на сервер.
/// \note Данная функция не проверяет длину строки, поэтому за один вызов
/// данной функции следует передавать не более 1460 байт (размер буффера
/// у GSM модуля).
/// \return Если операция выполнена успешна, то возвращает true.
bool SocketSendStr(const char* data)
{
  log_trace("SocketSendStr: \r\n[%s]\r\n", data);
  bool ok=false;
  SET_CMD_MODE();
  if (StartSendingData()) {
    uart_puts(handle->port, data);
    ok = EndSendingData();
  }
  log_func_result(ok);
  SET_DATA_MODE();
  return ok;
}

/// \brief Форматирует текстовую строку и отправляет её на сервер.
/// \note Данная функция не проверяет длину строки, поэтому за один вызов
/// данной функции следует передавать не более 1460 байт (размер буффера
/// у GSM модуля).
/// \return Если операция выполнена успешна, то возвращает true.
bool SocketSendStrFormat(const char* format, ...)
{
  log_func();
  bool ok=false;
  SET_CMD_MODE();
  if (StartSendingData()) {
    va_list   var_args;
    va_start(var_args, format);
    SendToModemVA(format, var_args);
    va_end(var_args);

    ok = EndSendingData();
  }
  log_func_result(ok);
  SET_DATA_MODE();
  return ok;
}

/// \brief Отправляет на сервер \p size байт данных, находящихся
/// в буффере \p data.
/// \return Если операция выполнена успешна, то возвращает true.
bool SocketSendBuffer(const void* data, size_t size)
{
  log_func();
  bool ok=false;
  SET_CMD_MODE();
  if (StartSendingDataWithLength(size)) {
    ClearRxBuffer();
    uart_write(handle->port, data, size);
    ok = SeekModemResponse("SEND OK", 0, CFG_GSM_SOCKET_TIMEOUT);
  }
  log_func_result(ok);
  SET_DATA_MODE();
  return ok;
}

/// \brief Читает из GSM модуля SMS сообщение с индексом \p sms_index и
/// помещает информацию о нём в буффер \p dst.
/// \return Возвращает true, если запрос выполнен без ошибок.
bool sim900_read_sms(size_t sms_index, sms_info_t* dst)
{
  log_func();
  bool ret=false;
  SET_CMD_MODE();
  if (!cmd_ex("AT+CMGR=%u,0\r", RESPONSE_OK, CLEAR_RXBUFFER, sms_index)) {
    ret=false;
  }
  else
  {

    char* response = strstr((char*)handle->rx_buffer, "+CMGR:");
    if (!response) {
        // Если в ответе модема не найдено +CMGR, это ошибка
        log_trace("No +CMGR found in gsm response.");
        ret=false;
    }
    else
    {
        response += 6; // пропускаем заголовок ответа "+CMGR:"

        // Текст сообщения идёт с начала следующей строки.
        char* sms_text = strstr(response, "\r\n");
        if (!sms_text) {
            // нет перевода строки - ошибка.
            log_trace("No newlint in CMGR response.");
            ret=false;
        }
        else
        {

            // Текст сообщения заканчивается ответом модема \r\nOK\r\n
            // Его нужно забить нулями, что бы не светился в тексте sms.
            char* sms_text_end = strstr(sms_text, "\r\nOK\r\n");
            if (!sms_text_end) {
                log_trace("No OK found in CMGR response.");
                ret=false;
            }
            else
            {
                *sms_text_end = '\0';

                // разделяем строку служебных полей от текст сообщения и забиваем перевод
                // строки нулями.
                *sms_text++ = '\0';
                *sms_text++ = '\0';

                // Теперь response указывает на строку служебной информации, в которой
                // поля разделены запятыми, а sms_text указывает на первый символ текста sms.
                //
                // Максимальное количество полей - 11.
                char* sms_parameters[11];
                size_t parameters_count = SplitString(sms_parameters, ARRAY_SIZE(sms_parameters),
                                                        response, ",", SPLITSTRING_KEEP_EMPTY);

                if (parameters_count < 2) {
                    // Не удалось разбить заголовок на отдельные параметры. Выходим.
                    ret=false;
                }
                else
                {

                    char* origin = sms_parameters[1];

                    // адрес отправителя заключён в кавычки. Необходимо их убрать.
                    ++origin;
                    origin[strlen(origin)-1] = '\0';

                    log_debug("Got SMS from [%s]:\r\n\r\n[%s]\r\n", origin, sms_text);
                    if (dst) {
                        dst->originating_address = origin;
                        dst->message_text = sms_text;
                    }
                    ret=true;
                }
            }
        }
    }
  }

  SET_DATA_MODE();
  return(ret);
}

/// \brief Форматирует строку \p format_str с произвольными
/// параметрами (\see sprintf) и отправляет полученную строку sms сообщением
/// на номер \p dst_phone.
/// \return Возвращает true, если запрос к GSM модулю был успешно обработан.
bool sim900_send_sms_va(const char* dst_phone, const char* format_str, va_list var_args)
{
  log_func();
  bool result=false;
  SET_CMD_MODE();
  log_trace("Starting SMS phone number...");
  // Начинаем отправку сообщения на номер dst_phone. После получения символа '>'
  // GSM модуль готов к получению текста сообщения.
  if (cmd_ex_timeout("AT+CMGS=\"%s\"\r",
                      ">",
                      CFG_GSM_SOCKET_TIMEOUT,
                      CLEAR_RXBUFFER,
                      dst_phone)) {

    log_trace("Sending SMS body:");

    log_trace_va(format_str, var_args);
    SendToModemVA(format_str, var_args);

    result = cmd_timeout("\x1A", RESPONSE_OK, CLEAR_RXBUFFER,
                            CFG_GSM_SOCKET_TIMEOUT);
  }
  log_func_result(result);
  SET_DATA_MODE();
  return result;
}
/// \brief Форматирует строку \p format_str с произвольными
/// параметрами (\see sprintf) и отправляет полученную строку sms сообщением
/// на номер \p dst_phone.
/// \return Возвращает true, если запрос к GSM модулю был успешно обработан.
bool sim900_send_sms(const char* dst_phone, const char* format_str, ...)
{
  SET_CMD_MODE();
  log_info("Sending ACK SMS.");
  va_list   var_args;
  va_start(var_args, format_str);
  bool result = sim900_send_sms_va(dst_phone, format_str, var_args);
  va_end(var_args);

  SET_DATA_MODE();
  return result;
}

/// \brief Удаляет все sms сообщения из памяти GSM модуля.
bool sim900_delete_all_sms(void)
{
  log_func();
  SET_CMD_MODE();
  bool ok = cmd("AT+CMGDA=\"DEL ALL\"\r", RESPONSE_OK, CLEAR_RXBUFFER);
  log_func_result(ok);
  SET_DATA_MODE();
  return ok;
}

/// \brief Удаляет все прочитанные sms сообщения из памяти GSM модуля.
bool sim900_delete_all_read_sms(void)
{
  log_func();
  SET_CMD_MODE();
  bool ok = cmd("AT+CMGDA=\"DEL READ\"\r", RESPONSE_OK, CLEAR_RXBUFFER);
  log_func_result(ok);
  SET_DATA_MODE();
  return ok;
}

/// \brief Запрашивает информацию о ближайших сотах
bool sim900_get_cell_id(char** cell_id_buffer)
{
  log_func();
  bool ret=false;
  SET_CMD_MODE();
  if (cmd("AT+CENG=3\r",RESPONSE_OK, CLEAR_RXBUFFER)) {
    if (cmd("AT+CENG?\r", RESPONSE_OK, CLEAR_RXBUFFER)) {

  // Получен ответ в формате
  // +CENG: 3,0
  //
  // +CENG:0,250,02,1e7a,0f50,05,35
  // +CENG:1,250,02,1e7a,0f51,07,34
  // ...............
  // +CENG:6,000,00,0000,0000,77,22
  //
  // OK

        // Первая часть ответа не интересна. Пропускаем её
        char* response_start = strstr_ex((char*)handle->rx_buffer, "+CENG: ");
        if (response_start) {
            // и два перевода строки после неё.
            response_start = strstr_ex(response_start, "\r\n\r\n");
            if (response_start) {

                // удаляем из ответа "OK" и два перевода строки перед ним.
                char* response_end = strstr(response_start, "\r\n\r\nOK");
                if (response_end) {
                    *response_end = '\0';

                    log_debug("GSM Cell info: \r\n\r\n[%s]\r\n", response_start);
                    if (cell_id_buffer) {
                        *cell_id_buffer = response_start;
                    }
                    ret=true;
                }
            }
        }
    }
  }
  SET_DATA_MODE();
  return(ret);
}

/// \brief Запрашивает информацию о заряде батареи.
///
/// После успешного выполнения, переменная, на которую указывает \p dst
/// получает указатель на строку, содержащую информацию в следующем формате:
/// `<status>,<charge percent>,<voltage_mv>`. Где
/// - <status> - число, состояние заряда:
///     0 - не заряжается
///     1 - заряжается
///     2 - полностью заряжена
/// - <charge percent> - степень заряженности в процентах 0..100
/// - <voltage_mv> - напряжение на входе GSM модуля в милливольтах.
///
/// Если запрос завершился ошибкой, то переменная по адресу \p dst
/// остаётся без изменений.
///
/// \return Возвращает true, если запрос к GSM модулю был успешно обработан.
bool sim900_get_battery_charge_info(char** dst)
{
  log_func();
  bool ret=false;
  SET_CMD_MODE();
  if (cmd("AT+CBC\r", RESPONSE_OK, CLEAR_RXBUFFER)) {

    char* response_start = strstr_ex((char*)handle->rx_buffer, "+CBC: ");
    if (response_start) {

        char* response_end = strstr(response_start, "\r\n");
        if (response_end) {

            *response_end = '\0';

            log_debug("GSM Battery info: [%s]", response_start);
            if (dst) {
                *dst = response_start;
            }
            ret=true;
        }
    }
  }
  SET_DATA_MODE();
  return(ret);
}


/// \brief Запрашивает информацию о заряде батареи в процентах.
///
/// После успешного выполнения, переменная, на которую указывает \p dst
/// получает указатель на строку, содержащую текущий заряд батареи в процентах.
///
/// Если запрос завершился ошибкой, то переменная по адресу \p dst
/// остаётся без изменений.
///
/// \return Возвращает true, если запрос к GSM модулю был успешно обработан.
bool sim900_get_battery_charge_percent(char** dst)
{
  log_func();
  bool ret=false;
  SET_CMD_MODE();
  char* info = NULL;
  if (sim900_get_battery_charge_info(&info)) {

    char* percent_start = strchr(info, ',');
    if (percent_start) {

        char* percent_end = strchr(++percent_start, ',');
        if (percent_end) {
            *percent_end = '\0';

            if (dst) {
                *dst = percent_start;
            }
            ret=true;
        }
    }
  }
  SET_DATA_MODE();
  return(ret);
}

Sim900IpState sim900_get_ip_state()
{
  Sim900IpState ret=IP_STATE_UNKNOWN;
  SET_CMD_MODE();
  const char* search_string = "STATE: ";
  if (!cmd("AT+CIPSTATUS\r", search_string, CLEAR_RXBUFFER)) {
    ret=IP_STATE_UNKNOWN;
  }
  else
  {

    delay_ms(200); // на случай, если не успели принять целиком.

    char* state_str = strstr_ex((char*)handle->rx_buffer, search_string);
    if (StartsWith(state_str, "IP INITIAL")) {
        ret=IP_STATE_INITIAL;
    }
    else
    {

        if (StartsWith(state_str, "IP START")) {
            ret=IP_STATE_START;
        }
        else
        {

            if (StartsWith(state_str, "IP CONFIG")) {
                ret=IP_STATE_CONFIG;
            }
            else
            {

                if (StartsWith(state_str, "IP GPRSACT")) {
                    ret=IP_STATE_GPRSACT;
                }
                else
                {

                    if (StartsWith(state_str, "IP STATUS")) {
                        ret=IP_STATE_STATUS;
                    }
                    else
                    {

                        if (StartsWith(state_str, "TCP CONNECTING")
                            || StartsWith(state_str, "UDP CONNECTING")) {
                            ret=IP_STATE_CONNECTING;
                        }
                        else
                        {

                            if (StartsWith(state_str, "SERVER LISTENING")) {
                                ret=IP_STATE_LISTENING;
                            }
                            else
                            {

                                if (StartsWith(state_str, "CONNECT OK")) {
                                    ret=IP_STATE_CONNECTED;
                                }
                                else
                                {

                                    if (StartsWith(state_str, "TCP CLOSING")
                                        || StartsWith(state_str, "UDP CLOSING")) {
                                        ret=IP_STATE_CLOSING;
                                    }
                                    else
                                    {

                                        if (StartsWith(state_str, "TCP CLOSED")
                                            || StartsWith(state_str, "UDP CLOSED")) {
                                            ret=IP_STATE_CLOSED;
                                        }
                                        else
                                        {

                                            if (StartsWith(state_str, "PDP DEACT")) {
                                                ret=IP_STATE_PDP_DEACT;
                                            }
                                            else
                                                ret=IP_STATE_UNKNOWN;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
  }
  SET_DATA_MODE();
  return (ret);
}

/// \brief устанавливает Bearer Profile ID для использования модулем FTP (AT+FTPCID=<id>).
bool sim900_ftp_set_cid(int id)
{
  log_func();
  SET_CMD_MODE();
  bool ret= cmd_ex("AT+FTPCID=%d\r", RESPONSE_OK, CLEAR_RXBUFFER, id);
  SET_DATA_MODE();
  return(ret);
}

/// \brief устанавливает позицию в файле, с которой следует продолжить скачивание.
bool sim900_ftp_set_resume_point(size_t byte_continue_from)
{
  log_func();
  SET_CMD_MODE();
  bool ret= cmd_ex("AT+FTPREST=%u\r", RESPONSE_OK, CLEAR_RXBUFFER, byte_continue_from);
  SET_DATA_MODE();
  return(ret);
}

bool sim900_ftp_set_server(const char* server)
{
  log_func();
  SET_CMD_MODE();
  bool ret= cmd_ex("AT+FTPSERV=\"%s\"\r", RESPONSE_OK, CLEAR_RXBUFFER, server);
  SET_DATA_MODE();
  return(ret);
}

bool sim900_ftp_set_user(const char* user)
{
  log_func();
  SET_CMD_MODE();
  bool ret= cmd_ex("AT+FTPUN=\"%s\"\r", RESPONSE_OK, CLEAR_RXBUFFER, user);
  SET_DATA_MODE();
  return(ret);
}

bool sim900_ftp_set_password(const char* password)
{
  log_func();
  SET_CMD_MODE();
  bool ret= cmd_ex("AT+FTPPW=\"%s\"\r", RESPONSE_OK, CLEAR_RXBUFFER, password);
  SET_DATA_MODE();
  return(ret);
}

bool sim900_ftp_set_path(const char* path)
{
  log_func();
  SET_CMD_MODE();
  bool ret= cmd_ex("AT+FTPGETPATH=\"%s\"\r", RESPONSE_OK, CLEAR_RXBUFFER, path);
  SET_DATA_MODE();
  return(ret);
}

bool sim900_ftp_set_filename(const char* name)
{
  log_func();
  SET_CMD_MODE();
  bool ret= cmd_ex("AT+FTPGETNAME=\"%s\"\r", RESPONSE_OK, CLEAR_RXBUFFER, name);
  SET_DATA_MODE();
  return(ret);
}

bool sim900_ftp_start_download()
{
  log_func();
  SET_CMD_MODE();
  bool ret= cmd("AT+FTPGET=1\r", RESPONSE_OK, CLEAR_RXBUFFER);
  SET_DATA_MODE();
  return(ret);
}

bool sim900_ftp_wait_data_ready(uint32_t timeout_ms)
{
  log_func();
  const char * cmd=NULL;
  if (handle->module==SIM_MODULE_SIM900)
    cmd="+FTPGET:1,1";
  else
  {
      if (handle->module==SIM_MODULE_SIM800)
        cmd="+FTPGET: 1,1";
  }
  if (cmd==NULL) {
    log_error("Unknown device module");
    return(false);
  }
  SET_CMD_MODE();
  // необходимо менять, ее в зависимости от типа SIM модуля
  bool ret= SeekModemResponse(cmd, 0, timeout_ms);
  SET_DATA_MODE();
  return(ret);
}

int32_t sim900_ftp_get_file_length()
{
  log_func();
  long result = -1;
  SET_CMD_MODE();
  if (!cmd("AT+FTPSIZE\r", RESPONSE_OK, CLEAR_RXBUFFER)) {
    log_debug("Can't execute AT+FTPSIZE");
    result=-1;
  }
  else
  {
    // необходимо менять, ее в зависимости от типа SIM модуля
    static const char* RESPONSE_FTPSIZE_1=NULL;
    if (handle->module==SIM_MODULE_SIM900)
        RESPONSE_FTPSIZE_1 = "+FTPSIZE:1,";
    else
    {
        if (handle->module==SIM_MODULE_SIM800)
            RESPONSE_FTPSIZE_1 = "+FTPSIZE: 1,";
    }
    if (RESPONSE_FTPSIZE_1==NULL){
        log_error("Unknown device module");
        result= -1;
    }
    else
    {

        if (!SeekModemResponse(RESPONSE_FTPSIZE_1, 0, CFG_GSM_SOCKET_TIMEOUT)) {
            log_debug("Can't get file length from remote host.");
            result= -1;
        }
        else
        {

            char* status_start = strstr_ex((char*)handle->rx_buffer, RESPONSE_FTPSIZE_1);

            // Дожидаемся конца строки
            if (!SeekModemResponse("\r\n", (uint8_t*)status_start - handle->rx_buffer, CFG_GSM_DEFAULT_TIMEOUT)) {
                log_debug("No newline after +FTPSIZE:1");
                result= -1;
            }
            else
            {

                // разбираем строку
                if (status_start[0] != '0' || status_start[1] != ',') {
                    log_debug("FTPSIZE returned error.");
                    result= -1;
                }
                else
                {

                    result = atol(status_start + 2);
                    log_debug("File length is %d", result);
                }
            }
        }
    }
  }
  SET_DATA_MODE();
  return result;
}

/// \return -1 в случае ошибки, иначе - количество прочитанных байт.
int32_t sim900_ftp_read_data(void* dst, uint32_t data_size)
{
  log_func();
  // необходимо менять, ее в зависимости от типа SIM модуля
  static const char* RESPONSE_FTPGET_2=NULL;
  if (handle->module==SIM_MODULE_SIM900)
    RESPONSE_FTPGET_2 = "+FTPGET:2,";
  else
  {
      if (handle->module==SIM_MODULE_SIM800)
        RESPONSE_FTPGET_2 = "+FTPGET: 2,";
  }
  if (RESPONSE_FTPGET_2==NULL) {
    log_error("Unknown device module");
    return -1;
  }

  long confirm_length = -1;
  SET_CMD_MODE();
  if (!cmd_ex("AT+FTPGET=2,%lu\r", RESPONSE_FTPGET_2, CLEAR_RXBUFFER, data_size)) {
    log_debug("+ftpget failed.");
    confirm_length= -1;
  }
  else
  {

    char* pos = strstr((char*)handle->rx_buffer, RESPONSE_FTPGET_2);
    if (!pos) {
        log_debug("No +FTPGET:2 response");
        confirm_length= -1;
    }
    else
    {

        // перешли на начало подтверждённой длины
        pos += strlen(RESPONSE_FTPGET_2);

        // ждем появления перевода строки.
        SeekModemResponse("\r\n", (uint8_t*)pos - handle->rx_buffer, CFG_GSM_DEFAULT_TIMEOUT);
        char* response_start = strstr(pos, "\r\n");
        uint32_t response_offset = (uint8_t*)response_start - handle->rx_buffer;

        if (!response_start) {
            log_debug("No newline after +FTPGET:2");
            confirm_length= -1;
        }
        else
        {
            response_start += 2;
            response_offset += 2;

            // разбираем длину
            confirm_length = atol(pos);
            if (!confirm_length) {
                log_debug("No more data received yet");
                confirm_length= 0;
            }
            else
            {

                timeout_t t;
                timeout_start(&t, CFG_GSM_DEFAULT_TIMEOUT);

                __disable_irq();
                size_t cur_index=handle->rx_buffer_index;
                __enable_irq();
                while (cur_index < (response_offset + confirm_length)) {
                    if (timeout_is_elapsed(&t)) {
                        log_debug("No data after +FTPGET:2 response, but expected %d bytes", confirm_length);
                        confirm_length= -1;
                        break;
                    }
                    __disable_irq();
                    cur_index=handle->rx_buffer_index;
                    __enable_irq();
                }
                if (confirm_length>=0)
                {

                    if (!SeekModemResponse(RESPONSE_OK,
                                                response_offset + confirm_length,
                                                CFG_GSM_DEFAULT_TIMEOUT)) {
                            log_debug("No OK response after +FTPGET:2");
                            confirm_length= -1;
                    }
                    else
                    {
                        if (dst)
                            memcpy(dst, response_start, confirm_length);
                    }
                }
            }
        }
    }
  }
  SET_DATA_MODE();
  return confirm_length;
}

/// Поддержка процедур для работы с PPP
#ifdef CFG_FW_TCPIP
void* GSM_port_ptr(void)
{
    return((void*)SIM_PORT);
}

/// Возращает текущее сосотояние GSM модуля
bool sim900_get_data_mode(void)
{
    return(handle->data_mode);
}

bool sim900_set_pdp(const char* apn)
{
  log_func();
  SET_CMD_MODE();
  bool ret=cmd_ex("AT+CGDCONT=1,\"IP\",\"%s\"\r", RESPONSE_OK, CLEAR_RXBUFFER, apn);
  SET_DATA_MODE();
  return(ret);
}

bool sim900_dial(const char* number)
{
  log_func();
  SET_CMD_MODE();
  bool ret=cmd_ex("ATD*%s#\r", "\r\nCONNECT", CLEAR_RXBUFFER, number);
  if (ret) handle->data_mode=true;
  return(ret);
}

bool sim900_cmd_mode(void)
{
  log_func();
  // Ждем 1 секунду (ничего не передаем в GSM)
  delay_ms(1200);
  /// Отправляем команду на выход в командный режим и ждем отклика
  // Буфер в модеме очвень большой, дождаться подтверждения не всега получается, так как у нас буфер маленький.
  // Выполнив все требования к посылке +++, просто подождем еще 100 мС и считаем что команда отработала.
  cmd("+++", "\r\nOK\r\n", CLEAR_RXBUFFER);
  delay_ms(100);
/*  if (!cmd("+++", "\r\nOK\r\n", CLEAR_RXBUFFER)) {  /// ВНИМАНИЕ. Если последний перенос строки \r\n не всегда приходит, то нужно убарть их проверку отсюда и вычищать эти символы после вычитки (просто проверяя два последних символа)
    /// Отклика нет, видимо уже находимся в командном режиме
    //if (sim900_ping()) handle->data_mode=false;
    //log_error("SIM900_CMD_MODE -----");
    return(!handle->data_mode);
  }*/
  handle->data_mode=false;
  return true;
}

bool sim900_data_mode(void)
{
  log_func();
  /// Отправляем команду на возврат в режим передачи данных
  if (!cmd("ATO\r", "\r\nCONNECT\r\n", DONT_CLEAR_RXBUFFER)) {  /// ВНИМАНИЕ. Если последний перенос строки \r\n не всегда приходит, то нужно убарть их проверку отсюда и вычищать эти символы после вычитки (просто проверяя два последних символа)
    //handle->data_mode=false;
    return false;
  }
  handle->data_mode=true;
  /// Выравниваем указатели в буфере
  ClearRxBuffer_fake();
  return true;
}

bool sim900_disconnect(void)
{
  log_func();
  SET_CMD_MODE();
  /// Отправляем команду на возврат в режим передачи данных
  bool ret=cmd("ATH\r", "\r\nOK", CLEAR_RXBUFFER);
  return(ret);
}

uint8_t* GSM_read(uint8_t* dst, size_t max_rx_size_msg, uint32_t* error, bool only_check)
{
    //log_func();

    if (dst==NULL)
    {
        log_error("GSM_read(): No dst pointer.");
        if (error) *error = 0xFF552233;
        return NULL;
    }

    if (!handle->data_mode)
    {
        //log_error("GSM_read(): No data mode.");
        if (error) *error = 0x11550033;
        return NULL;
    }

    __disable_irq();
    uint16_t cur_index = handle->rx_buffer_index;
    __enable_irq();
    while (cur_index > (handle->readed_index)) {
        log_trace("!! GSM_read ENTER!: %d, %d, 0x%X", cur_index, handle->readed_index, dst);
        do{
            // Копируем
            *dst++=handle->rx_buffer[handle->readed_index++];
            max_rx_size_msg--;
        }while((cur_index!=handle->readed_index) && (max_rx_size_msg));
        __disable_irq();
        if (handle->rx_buffer_index==handle->readed_index)
        {
            handle->rx_buffer_index = 0;
            handle->readed_index=0;
        }
        cur_index=handle->rx_buffer_index;
        __enable_irq();
        if (cur_index==handle->readed_index)
        {
            log_trace("$ clear buffer");
            break;
        }
        if (!max_rx_size_msg) break;
    }
    return(dst);
}

#endif // CFG_FW_TCPIP
