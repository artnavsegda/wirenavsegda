/// \file device_state.h
/// \author DL <dmitriy.linikov@gmail.com>
/// \brief Функции для отслеживания текущего состояния устройства.

#ifndef DEVICE_STATE_H_INCLUDED
#define DEVICE_STATE_H_INCLUDED

#include "status_bitfield.h"
// #include "version.h"
#include "time_utils.h"

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

#define IMEI_LENGTH   15
#define ICCID_LENGTH  20
#define IMSI_LENGTH   15
#define MAX_LENGTH_SIM_NAME 20
#define MAX_LENGTH_GSM_SW_VERSION   30

//extern bool           imei_is_set;
//extern char           imei[IMEI_LENGTH+1];

extern bool           iccid_is_set;
extern char           iccid[ICCID_LENGTH+1];
extern char           imsi[IMSI_LENGTH+1];

extern uint32_t       key_imei[8];
extern UnpackedTime   g_time;
extern uint16_t       current_minute_of_day;
#define MAX_MINUTES_OF_DAY  1439

/// \brief Принудительно запрашивает у GSM модуля номер IMEI,
/// сохраняет его в глобальную переменную \see imei, а так же сохраняет его в
/// качестве ключа шифрования в глобальную переменную \see key_imei.
/// \note Если запрос IMEI завершается ошибкой, то устанавливает
/// номер "000000000000000".
void DevStateForceRequestImei(void);

/// \brief Возвращает номер IMEI устройства. Если этот номер ещё не запрошен,
/// то запрашивает. Номер всегда содержит \see IMEI_LENGTH символов
/// и заканчивается на нуль-символ.
//char* DevStateGetImei(void);

/// \brief Возвращает 8 байт ключа шифрования, полученных на основе IMEI.
uint32_t* DevStateGetPrivateKey(void);

/// \brief Записывает в часы реального времени GSM модуля время, хранящееся в
/// глобальной переменной g_time.
void DevStateSetTimeToModem();

/// \brief Запрашивает текущее время у GSM модуля и записывает его
/// в глобальную переменную \see g_time.
bool DevStateUpdateTime(void);


/// \brief Возвращает указатель на структуру \see UnpackedTime, хранящую
/// текущее время.
const UnpackedTime* DevStateGetTime(void);


/// \brief Разбирает строку времени и сохраняет полученные значения в
/// глобальную переменную \see g_time.
bool DevStateParseAndSetTime(const char* time_str);

/// \brief Запрашивает из GSM модуля номер установленной SIM карты.
/// \note Если запрос ICCID заканчивается ошибкой, то устанавливает
bool DevStateForceRequestIccid(void);

/// \brief Запрашивает из GSM модуля номер установленной SIM карты.
/// \note Если запрос IMSI заканчивается ошибкой, то устанавливает
/// номер 0000000000000000000.
bool DevStateForceRequestImsi(void);

/// \brief Возвращает номер текущей SIM карты. Данный номер всегда содержит
/// 19 или 20 символов.
const char* DevStateGetIccid(void);

/// \brief Возвращает номер текущей SIM карты. Данный номер всегда содержит
const char* DevStateGetImsi(void);

/// \brief Запрашивает из GSM модуля тип SIM модуля.
bool DevStateForceRequestSimInfo(void);

/// \brief Возвращает названеи текущего сим модуля.
const char* DevStateGetSimInfo(void);

/// \brief Запрашивает из GSM модуля версию программного обеспечения.
bool DevStateForceRequestModuleSwVersion(void);

/// \brief Возвращает версию программного обеспечения модуля.
const char* DevStateGetModuleSwVersion(void);

/// Проверка по IMSI типа
bool DevStateIsUsim(char* imsi);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // DEVICE_STATE_H_INCLUDED
