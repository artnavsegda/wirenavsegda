/// \file server_gateway.c
/// \author DL <dmitriy.linikov@gmail.com>
/// \see server_gateway.h

#ifndef CFG_FILE_LOG_LEVEL
//#define CFG_FILE_LOG_LEVEL  LOG_LEVEL_INFO
#endif // CFG_FILE_LOG_LEVEL
// std
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

// drivers
#include "board.h"
// #include "ext_flash_m25p.h"
#include "gsm_sim900.h"
#include "watchdog.h"
#include "systime.h"

// other modules
#include "settings.h"
#include "system_utils.h"
#include <utils/string_utils.h>
#include "math_utils.h"
#include "device_state.h"
#include "operator_gprs_settings.h"
#include "encryption_gost.h"
// #include "server_command_processor.h"
// #include "reports_storage.h"
#include "dbg.h"
#include "sysutils/crc.h"
// #include "controller.h"
#include "software_watchdog.h"
// #include "reporter.h"

// this file header
#include "server_gateway.h"
#include <indication/server_monitor.h>
#include <version/version_info.h>

#if 0
#ifdef CFG_FW_TCPIP
#include "protocol_tcp_ip.h"
#include "xprintf.h"
static uint16_t mtu=TCP_MSS;
#else
static uint16_t mtu=700;
#endif // CFG_FW_TCPIP
#endif

#define MY_PRIORITY         PRIORITY_LEVEL_7

// Время антидребезга ключа наличия симкарты
#define TIME_DEBOUNCE_SIM_KEY   3
static uint32_t sim_time_zz=0;
#ifndef FW_TESTS
static bool simkey_debounce_over=false;
static bool simkey_changed=false;
static bool simkey_curent_state=true;
#else
bool simkey_debounce_over=false;
bool simkey_changed=false;
bool simkey_curent_state=true;
#endif // FW_TESTS

#ifndef CFG_GSM_RXBUFFER_SIZE
    #ifdef CFG_FW_TCPIP
        #define CFG_GSM_RXBUFFER_SIZE   1000
    #else
        #define CFG_GSM_RXBUFFER_SIZE   768
    #endif // CFG_FW_TCPIP
#endif

#define rxsizeofbuffer CFG_GSM_RXBUFFER_SIZE
uint8_t rxbuffer[rxsizeofbuffer];
#ifdef CFG_FW_TCPIP
uint8_t mas_rx_data[rxsizeofbuffer];
char * rx_data=(char *)mas_rx_data;
#else
char * rx_data=(char *)rxbuffer;
#endif // CFG_FW_TCPIP
uint16_t index_rxbuffer=0;
int current_sim_card=0;

#if defined(CFG_USE_ENCRYPTION) && (CFG_USE_ENCRYPTION == 1)
uint8_t txbuffer_enc[5000];
#endif // if defined(CFG_USE_ENCRYPTION) && (CFG_USE_ENCRYPTION == 1)

#if !defined(CFG_GSM_USE_STORAGE)
#define CFG_GSM_USE_STORAGE   1
#endif

static OnSim900StateChanged   on_sim_state_changed = NULL;

static void (*turn_on_port_fxn)(void) = NULL;
static void (*turn_off_port_fxn)(void) = NULL;

#if 0
#define DEF_HDR_X_CHECKSUM          "X-Checksum"
#define MAX_LEN_X_CHECKSUM          (6)
static const char hdr_x_checksum[]=DEF_HDR_X_CHECKSUM;
static uint32_t http_input_x_checksum;
#endif

bool roaming=false;

// Функция, вызываемая для выбора сим карты.
// Если card_id равен нулю, то следует отключить все сим карты.
static void (*select_sim_card_fxn)(int card_id) = NULL;

static ConnectType  connect_type;
#ifdef CFG_FW_TCPIP
static void * gsm_port=NULL;
static void * gsm_socket=NULL;
#endif // CFG_FW_TCPIP

// ===================== Приватные функции =====================================

static void ServerGateway_ResetReadyCheckTimeout();
static void ServerGateway_RecheckState();
static void ServerGateway_OnConnectionSuccess();
//static void ServerGateway_OnConnectionFailure();
static void ResetNoResponseTimer();
static inline bool GsmStateIsReady(void);

static void SetSimState(Sim900State new_state)
{
  if (on_sim_state_changed) {
    on_sim_state_changed(new_state);
  }
}

#if 0
// Возвращает ранее считанное значение поля X-Checksum
uint32_t GetHttpXCecksum(void)
{
    return(http_input_x_checksum);
}
#endif

// Сообщает о типе регистрации карты в сети (в проуминге или в домашней сети)
bool GetRoamingStatus(void)
{
    return(roaming);
}

#if CFG_FW_TCPIP
static bool ServerGatewayCheckDataMode(void);

// Заглушка для выбора протокола
/// Открыть Сокет
bool ServerGatewaySocketOpen(const char* server_name, const char* port_str)
{
    if (connect_type==SIMCOM_PPP)
    {
        /// 1. Необходимо открыть соединенеи TCP  на указынный адрес и порт (внутри должна быть проверка на необходимость обращения к DNS)
        /// 2. Получить указатель на структуру соединения с которым потмо везде работать.
        /// 3. Внутри открыть соединение и выдать результат действий
        if ((GsmStateIsReady()) && (gsm_port) && (gsm_socket==NULL))
            gsm_socket=ProtocolTcpIpSocketOpen(gsm_port, &gsm_socket, server_name, port_str);
        if (gsm_socket!=NULL) log_info("SERVER GATEWAY socket OPEN!");
        //log_info("1 socket address [0x%X]", gsm_socket);
        return(gsm_socket!=NULL);
    }
    /// Режим работы через машину TCP/IP SIMCOM
    else return(SocketOpen(server_name, port_str));
    return(false);
}

/// Закрыть сокет
bool ServerGatewaySocketClose(bool clear_rx_buffer)
{
    if (connect_type==SIMCOM_PPP)
    {
        if (gsm_socket)
        {
            /// 1. Закрыть соединение
            /// 2. Освободить структуру (занулить ее)
            /// 3. Вернуть сюда значенеи указателя равное 0
            gsm_socket=ProtocolTcpIpSocketClose(gsm_socket);
            return(gsm_socket==NULL);
        }
    }
    /// Режим работы через машину TCP/IP SIMCOM
    else return(SocketClose(clear_rx_buffer));
    return(false);
}

/// Передать строку в формате
bool ServerGatewaySocketSendStrFormat(const char* format, ...)
{
    bool ret=false;
    va_list   var_args;
    va_start(var_args, format);
    if (connect_type==SIMCOM_PPP)
    {
        static char data[1500];
        /// 1. Преобразовать строку в буфер
        xsvaprintf(data, format, var_args);
        //dbg_printhex(data, strlen(data));
        /// 2. Передать данные буфер на передачу по указателю
        gsm_socket=ProtocolTcpIpSocketSend(gsm_socket, data, strlen(data));
        /// 3. Результат действий вернуть
        //log_info("2 socket address [0x%X]", gsm_socket);
        if (gsm_socket) ret=true;
    }
    /// Режим работы через машину TCP/IP SIMCOM
    else
        ret=SocketSendStrFormat(format, var_args);
    va_end(var_args);
    log_func_result(ret);
    return(ret);
}

bool ServerGatewaySocketSendBuffer(const void* data, size_t size)
{
    bool ret=false;
    if (connect_type==SIMCOM_PPP)
    {
        /// 1. Передать данные на передачу по указателю
        gsm_socket=ProtocolTcpIpSocketSend(gsm_socket, data, size);
        /// 2. Результат действий вернуть
        //log_info("3 socket address [0x%X]", gsm_socket);
        if (gsm_socket) ret=true;
    }
    /// Режим работы через машину TCP/IP SIMCOM
    else ret=SocketSendBuffer(data, size);
    log_func_result(ret);
    return(ret);
}
/// Передать данные
#else
// Для сбоорки прошивок без LwIP
#define ServerGatewaySocketOpen                     SocketOpen
#define ServerGatewaySocketClose                    SocketClose
#define ServerGatewaySocketSendStrFormat            SocketSendStrFormat
#define ServerGatewaySocketSendBuffer               SocketSendBuffer
#endif

#if 0
/// \brief Передает \p content_length байт данных из буффера \p buffer
/// на сервер по протоколу HTTP методом POST.
static bool SendBufferToServer(const void* buffer, size_t content_length,
                               size_t* received_length, const void* ptr_3th_flow, size_t length_3th_flow, priority_t * level)
{
  #define MAX_REPEATS_PACKS   (2)
  int32_t count=MAX_REPEATS_PACKS;
  bool ok=false;
  if (!ServerGateway_WaitReady(500)) {
    log_info("SendBufferToServer: gsm is not in valid state yet.");
    return false;
  }

  // Считаем CRC тела.
  uint16_t content_crc=0;
  if (buffer)
    content_crc=crc16_calc_block(content_crc, buffer, content_length);
  else
    content_length=0;
  if (ptr_3th_flow)
    content_crc=crc16_calc_block(content_crc, ptr_3th_flow, length_3th_flow);
 else
    length_3th_flow=0;
  /// \todo Возможно, стоит использовать данный флаг на уровень выше,
  /// что бы он отражал непосредственно передачу, а не оставался
  /// установленным при ошибках передачи.

 // priority_t level=MY_PRIORITY;
  while (count>=0)
  {
    // Вставил выход при возникновении высокоприооритетных событий. Фигня, но пока так.
    if (count!=MAX_REPEATS_PACKS)
    {
        if (NeedBreakeHighPriority(level))
            break;
    }
      Softdog_OnReturnedToMainLoop();
      count--;
  log_trace("SendBufferToServer(): attempt=0x%X", MAX_REPEATS_PACKS-count);
  log_trace("SendBufferToServer(): content-length=%u", content_length+length_3th_flow);
  ServerMonitor_OnStateChanghed(SERVER_STATE_CONNECTING);

  ServerGatewaySocketClose(CLEAR_RXBUFFER);
  if (!ServerGatewaySocketOpen(g_settings.server, g_settings.port)) {
    ServerMonitor_OnStateChanghed(SERVER_STATE_SERVER_NOT_AVAILABLE);
    if (count)
        continue;
    ServerGateway_OnConnectionFailure();
    return false;
  }

  ServerMonitor_OnStateChanghed(SERVER_STATE_DATA_EXCHANGE);

  // Отправка HTTP заголовка.
  static const char* http_header_format =
      "POST %s HTTP/1.0\r\n"
      "Host: %s\r\n"
      "User-Agent: %s\r\n"
      "X-Imei: %s\r\n"
      "X-Iccid: %s\r\n"
      "Content-Type: application/x-www-form-urlencoded\r\n"
      "Content-Length: %u\r\n"
      DEF_HDR_X_CHECKSUM
      ": %x\r\n"
      "\r\n";
  if (!ServerGatewaySocketSendStrFormat(http_header_format,
                           g_settings.directory,
                           g_settings.server,
                           version_get_version_string(),
                           SettingsGetImei(),
                           DevStateGetIccid(),
                           content_length+length_3th_flow,
                           content_crc)) {
    ServerMonitor_OnStateChanghed(SERVER_STATE_DISCONNECTED);
    if (count)
        continue;
    ServerGateway_OnConnectionFailure();
    return false;
  }

  // Отправка данных, отрезками по mtu байт за раз.
  bool ret=false;
  /// Передача основного потока данных
  size_t content_length_tmp=content_length;
  const uint8_t* data_ptr = buffer;
  while (content_length_tmp) {
    size_t bytes_to_send = min_sizet(content_length_tmp, mtu);

    if (!ServerGatewaySocketSendBuffer(data_ptr, bytes_to_send)) {
      ServerMonitor_OnStateChanghed(SERVER_STATE_DISCONNECTED);
      if (count)
      {
          ret=true;
          break;
      }
      ServerGateway_OnConnectionFailure();
      return false;
    }
    data_ptr += bytes_to_send;
    content_length_tmp -= bytes_to_send;
  }
  if (ret)
    continue;

  /// Передача третьего потока данных
  content_length_tmp=length_3th_flow;
  data_ptr = ptr_3th_flow;
  while (content_length_tmp) {
    size_t bytes_to_send = min_sizet(content_length_tmp, mtu);

    if (!ServerGatewaySocketSendBuffer(data_ptr, bytes_to_send)) {
      ServerMonitor_OnStateChanghed(SERVER_STATE_DISCONNECTED);
      if (count)
      {
          ret=true;
          break;
      }
      ServerGateway_OnConnectionFailure();
      return false;
    }
    data_ptr += bytes_to_send;
    content_length_tmp -= bytes_to_send;
  }
  if (ret)
    continue;

  sim900_clear_buffer();

  // Ожидание ответа от сервера.
  timeout_t   timeout;
  char* end_of_response = NULL;

  timeout_start(&timeout, 60000);
#ifdef CFG_FW_TCPIP
  int32_t len=0;
  uint32_t offset=0;
  if (connect_type==SIMCOM_PPP)
    rx_data=(char *)mas_rx_data;
  else
#endif // CFG_FW_TCPIP
    rx_data=(char *)rxbuffer;
#ifdef CFG_FW_TCPIP
  log_info(">>>> buffer [0x%X], size [%d]", rx_data, sizeof(mas_rx_data)-1);
#endif // CFG_FW_TCPIP

  while (!timeout_is_elapsed(&timeout)) {
#ifdef CFG_FW_TCPIP
    if (connect_type==SIMCOM_PPP)
    {
        /// Переносим данные в буфер
        len=ProtocolTcpIpGetSocketData(&gsm_socket, rx_data+offset, sizeof(mas_rx_data)-offset-1);
        if (!len) continue;
        else
        {
            if (len>0)
            {
                offset+=len;
                rx_data[offset]='\0';
                //log_info("!!!!! buffer [0x%X], size [%d], len [%d]", rx_data+offset, sizeof(mas_rx_data)-offset-1, len);
                //dbg_printhex(rx_data, strlen(rx_data));
            }
            else
            {
                rx_data[offset]='\0';
                end_of_response=rx_data;//NULL
                break;
            }
        }
    }
    else
#endif // CFG_FW_TCPIP
    {
        // Детектируем конец ответа по закрытию соединения сервером.
        end_of_response = strstr((char*)rx_data, "\r\nCLOSED\r\n");
        if (end_of_response != NULL) {
            *end_of_response = '\0';
            break;
        }
    }

    // Договорились, что в конце ответа сервера всегда будет стоять status=ok.
    // Это позволит детектировать окончание ответа сервера быстрее, чем по разрыву соединения.
    static const char STATUS_OK[] = "status=ok";
    end_of_response = strstr((char*)rx_data, STATUS_OK);
    if (end_of_response != NULL) {
      end_of_response += strlen(STATUS_OK);
      // !! Так пистаь нельзя. Буфер можеть быть полным и мы запишем в чужую область. Прерывание может перезаписать этот байт.
      // Пока вставил паузу, что бы гарантировать приход всех данных из модема. Запись символ а/0 тут нужно только для вывода в лог полученной строки. Или отказываемся от записи символа или записываем его с раздвиганием данных.
      delay_ms(20);
      if (end_of_response<((char *)(&rx_data[rxsizeofbuffer])))
        *end_of_response = '\0';
      else
        rx_data[rxsizeofbuffer-1]='\0';
      break;
    }
    delay_ms(200);
  }


  ServerGatewaySocketClose(DONT_CLEAR_RXBUFFER);
  if (!end_of_response) {
    log_warn("Server response timed out or error.");
    ServerMonitor_OnStateChanghed(SERVER_STATE_INVALID_SERVER_RESPONSE);
//    if (count)
//        continue;
    ServerGateway_OnConnectionFailure();
    return false;
  }

  // Возвращаем true только если получен статус успешного HTTP запроса.
  log_trace("SendBufferToServer: Response:\r\n\r\n[%s]\r\n", rx_data);
  if (strstr((char*)rx_data, "200 OK") == NULL) {
    log_warn("Got invalid server response.");
    ServerMonitor_OnStateChanghed(SERVER_STATE_INVALID_SERVER_RESPONSE);
    if (count)
        continue;
    return false;
  }
  // Производим поиск заголовка X-Checksum
  http_input_x_checksum=0;
  char* x_checksum=strstr((char*)rx_data, hdr_x_checksum);
  if (x_checksum != NULL) {
    // переводим указатель на начало данных контрольной суммы
    x_checksum+=sizeof(hdr_x_checksum)-1+sizeof(": ")-1;
    // Определяем конец данных
    char* end_x_checksum=strstr(x_checksum, "\r\n");
    if (end_x_checksum!=NULL)
    {
        char* pref=strstr(x_checksum, "0x");
        if (pref!=NULL)
        {
            if (pref<end_x_checksum)
                x_checksum+=2;
        }
        uint32_t len_x_xhecksum=end_x_checksum-x_checksum;
        if (len_x_xhecksum<MAX_LEN_X_CHECKSUM)
        {
            http_input_x_checksum=DecodeHexToInt(x_checksum,len_x_xhecksum);
            // Преобразуем полученное значение из HEX строки в число
            log_trace("Got X-Checksum: %x len of X-Checksum %d",http_input_x_checksum, len_x_xhecksum);
            // Поиск начала HTTP ответа по двойному переводу строки
            char* response = strstr((char*)rx_data, "\r\n\r\n");
            if (!response) {
                log_warn("Received invalid HTTP response: [%s]", (char*)rx_data);
                ServerMonitor_OnStateChanghed(SERVER_STATE_INVALID_SERVER_RESPONSE);
                if (count)
                    continue;
                return false;
            }
            // передвигаем указатель на начало тела ответа.
            response += 4;
            // Определим размер тела сообщения
            if (end_of_response>response)
            {
                // Подсчитываем CRC тела сообщения
                uint16_t crc=crc16_calc_block(0,response,end_of_response-response);
                if (http_input_x_checksum!=crc)
                {
                    log_error("Received invalid body CRC : [X-Checksum=%x, calculate=%x]", http_input_x_checksum, crc);
                    ServerMonitor_OnStateChanghed(SERVER_STATE_INVALID_SERVER_RESPONSE);
                    if (count)
                        continue;
                    return false;
                }
            }
            else
            {
                // Ошибка определения тела сообщения
                ServerMonitor_OnStateChanghed(SERVER_STATE_INVALID_SERVER_RESPONSE);
                if (count)
                    continue;
                return false;
            }
        }
        else
            log_error("Got X-Checksum with length: %d",len_x_xhecksum);
    }
  }

  ServerMonitor_OnStateChanghed(SERVER_STATE_ONLINE);
  ServerGateway_OnConnectionSuccess();
  Softdog_OnServerResponse();

  if (received_length) {
    *received_length = (uint8_t*)end_of_response - (uint8_t*)rx_data;
  }
    ok=true;
    break;
  }
  if (!ok) return false;
  return true;
}
#endif

// Номер основной сим карты.
#define CFG_GSM_DEFAULT_SIMCARD_ID            1
static bool flag_ServerGsmPowerUp=true;

typedef enum GsmStatesTag {
  GSM_STATE_UNINITED,
  GSM_STATE_START_RECOVER_FROM_HARD_ERROR,
  GSM_STATE_START_RECOVER_FROM_SIMCARD_ERROR,
  GSM_STATE_START_RECOVER_FROM_GSM_ERROR,
  GSM_STATE_START_RECOVER_FROM_GPRS_ERROR,
  GSM_STATE_RECOVERING_FROM_HARD_ERROR,
  GSM_STATE_RECOVERING_FROM_SIMCARD_ERROR,
  GSM_STATE_RECOVERING_FROM_GSM_ERROR,
  GSM_STATE_RECOVERING_FROM_GPRS_ERROR,
  GSM_STATE_VDD_RAMPDOWN,
  GSM_STATE_IRQ_POWER_UP,
  GSM_STATE_VDD_RAMPUP,
  GSM_STATE_TURNON_PWRKEY_ACTIVE,
  GSM_STATE_WARM_UP_TIMEOUT,
  GSM_STATE_WAITING_FOR_AT_READY,
  GSM_STATE_SETTING_UP,
  GSM_STATE_DESELECT_SIM_CARD,
  GSM_STATE_START_WAITING_BEFORE_RESELECT_SIM_CARD,
  GSM_STATE_WAIT_BEFORE_RESELECT_SIM_CARD,
  GSM_STATE_START_WAITING_FOR_SECOND_AT_READY,
  GSM_STATE_WAITING_FOR_SECOND_AT_READY,
  GSM_STATE_START_WAITING_SIM_READY,
  GSM_STATE_WAITING_SIM_READY,
  GSM_STATE_START_WAITING_NET_REGISTRATION,
  GSM_STATE_WAITING_NET_REGISTRATION,
  GSM_STATE_START_WAITING_GPRS_AVAILABILITY,
  GSM_STATE_WAITING_GPRS_AVAILABILITY,
  GSM_STATE_ENTER_STARTING_IP_CONTEXT,
  GSM_STATE_STARTING_IP_CONTEXT,
  GSM_STATE_ENTER_READY,
  GSM_STATE_READY,

} GsmStates;

static GsmStates    gsm_state;
static timeout_t    state_timeout;
static timeout_t    ready_check_timeout;
static timeout_t    no_response_timer;

static inline bool GsmStateIsReady(void)
{
    return(gsm_state==GSM_STATE_READY);
}

static void ResetNoResponseTimer()
{
  timeout_start(&no_response_timer, CFG_GSM_NO_RESPONSE_TO_POWERCYCLE_MS);
}

static bool NoResponseTimerElapsed()
{
  return timeout_is_elapsed(&no_response_timer);
}


static void ServerGateway_ResetReadyCheckTimeout()
{
  // раз в 5 минут принудительно проверяем состояние связи.
#ifdef CFG_FW_TCPIP
  timeout_start(&ready_check_timeout, (g_settings.time_repeat*60l*1000l)*2);
#else
  timeout_start(&ready_check_timeout, CFG_GSM_READY_CHECK_PERIOD_MS);
#endif
}

#ifdef CFG_FW_TCPIP
static void ServerGateway_RedialState() {
    sim900_disconnect();
    gsm_state = GSM_STATE_START_WAITING_GPRS_AVAILABILITY;
}
#endif // CFG_FW_TCPIP

static void ServerGateway_RecheckState() {
  log_func();
#ifdef CFG_FW_TCPIP
  /// Закрываем соединение
  gsm_socket=ProtocolTcpIpSocketClose(gsm_socket);
  /// Закрываем порт.
  gsm_port=ProtocolTcpIpClosePort(gsm_port);
  sim900_disconnect();
#endif // CFG_FW_TCPIP
  gsm_state = GSM_STATE_START_WAITING_SIM_READY;
}

static void ServerGateway_OnConnectionSuccess()
{
  ServerGateway_ResetReadyCheckTimeout();
  ResetNoResponseTimer();
}

#if 0
static void ServerGateway_OnConnectionFailure()
{
  ServerGateway_RecheckState();
}
#endif

static void ServerGateway_DisableIOPorts()
{
  if (turn_off_port_fxn) {
    turn_off_port_fxn();
  }
}

static void ServerGateway_EnableIOPorts()
{
  if (turn_on_port_fxn) {
    turn_on_port_fxn();
  }
}

static void ServerGateway_SelectSimCard(int simcard_id)
{
  current_sim_card = simcard_id;
  if (select_sim_card_fxn) {
    select_sim_card_fxn(simcard_id);
  }
}

static int ServerGateway_ChooseSimCard()
{
  if (SimCardInserted(SIM_CARD_EXTERNAL1)) {
    return SIM_CARD_EXTERNAL1;
  }

#ifdef SIM_CARD_INTERNAL1
  if (SimCardInserted(SIM_CARD_INTERNAL1)) {
    return SIM_CARD_INTERNAL1;
  }
#endif // SIM_CARD_INTERNAL1

#ifdef SIM_CARD_INTERNAL2
  if (SimCardInserted(SIM_CARD_INTERNAL2)) {
    return SIM_CARD_INTERNAL2;
  }
#endif // SIM_CARD_INTERNAL2

#ifdef SIM_CARD_INTERNAL3
  if (SimCardInserted(SIM_CARD_INTERNAL3)) {
    return SIM_CARD_INTERNAL3;
  }
#endif

  return SIM_CARD_NONE;
}

static void ServerGateway_TurnOffGsm(GsmStates next_state, systime_t rampdown_ms, Sim900State indicator_state)
{
#ifdef CFG_FW_TCPIP
  /// Закрываем соединение
  gsm_socket=ProtocolTcpIpSocketClose(gsm_socket);
  /// Закрываем порт.
  gsm_port=ProtocolTcpIpClosePort(gsm_port);
#endif // CFG_FW_TCPIP
  ServerGateway_SelectSimCard(0);
  ServerGateway_DisableIOPorts();
  SetSimState(indicator_state);
  GpioClear(SIM_POWER_EN);
  sim900_turn_off();

  roaming=false;
  gsm_state = next_state;
  timeout_start(&state_timeout, rampdown_ms);
  flag_ServerGsmPowerUp=false;
}

static bool ServerGateway_LoadImei()
{
  char  buffer[IMEI_LENGTH + 1];

  if (sim900_get_imei(buffer, sizeof(buffer)))
  {
    int32_t len=strlen(buffer);
    if (len==IMEI_LENGTH)
      return SettingsSetImei(buffer);
  }

  return false;
}

static bool flag_NoResponseTimerElapsed=true;

// Для прерывания. Обработчки сосотояние включения питания GSM для обеспечения работы RTC
void __ServerGSMPowerUp(void)
{
    if (!flag_ServerGsmPowerUp)
    {
        if (timeout_is_elapsed(&state_timeout))
        {
            GpioSet(SIM_POWER_EN);
            flag_ServerGsmPowerUp=true;
        }
    }
}

/// \return Возвращает true только в том случае, когда текущее состояние
bool ServerGatewayStateMachine_React()
{
  if (simkey_debounce_over)
  {
      simkey_debounce_over=false;
      // Состояние кнопки изменилось. Меняем статус работы модема
      log_debug("Sim card %s now.",simkey_curent_state?"insert":"remove");
      gsm_state = GSM_STATE_START_RECOVER_FROM_SIMCARD_ERROR;
      simkey_changed=true;
  }
  if (NoResponseTimerElapsed()) {
    flag_NoResponseTimerElapsed=true;
    gsm_state = GSM_STATE_UNINITED;
  }

  switch (gsm_state) {
    case GSM_STATE_UNINITED:
      // В неизвестном состоянии необходимо отключить модуль.
      ResetNoResponseTimer();
      log_debug("Disabled power for gsm.");
      ServerGateway_TurnOffGsm(GSM_STATE_VDD_RAMPDOWN, CFG_GSM_VDD_RAMPDOWN_TIME_MS, SIM_STATE_OFF);
      break;

    case GSM_STATE_START_RECOVER_FROM_HARD_ERROR:
      log_debug("Recovering from hard error. Turned off the modem.");
      ServerGateway_TurnOffGsm(GSM_STATE_RECOVERING_FROM_HARD_ERROR,
                               CFG_GSM_HARD_ERROR_RECOVER_TIME_MS,
                               SIM_STATE_ERROR);
      break;

    case GSM_STATE_START_RECOVER_FROM_SIMCARD_ERROR:
      log_debug("Recovering from simcard error. Turned off the modem.");
      ServerGateway_TurnOffGsm(GSM_STATE_RECOVERING_FROM_SIMCARD_ERROR,
                               CFG_GSM_HARD_ERROR_RECOVER_TIME_MS,
                               SIM_STATE_SIMCARD_ERROR);
      break;

    case GSM_STATE_START_RECOVER_FROM_GSM_ERROR:
      log_debug("Recovering from long gsm registration. Turned off the modem.");
      ServerGateway_TurnOffGsm(GSM_STATE_RECOVERING_FROM_GSM_ERROR,
                               CFG_GSM_HARD_ERROR_RECOVER_TIME_MS,
                               SIM_STATE_GSM_ERROR);
      break;

    case GSM_STATE_START_RECOVER_FROM_GPRS_ERROR:
      log_debug("Recovering from long gprs inactivity. Turned off the modem.");
      ServerGateway_TurnOffGsm(GSM_STATE_RECOVERING_FROM_GPRS_ERROR,
                               CFG_GSM_HARD_ERROR_RECOVER_TIME_MS,
                               SIM_STATE_GPRS_ERROR);
      break;


    case GSM_STATE_RECOVERING_FROM_SIMCARD_ERROR:
      // Fall-through
    case GSM_STATE_RECOVERING_FROM_HARD_ERROR:
      // Fall-through
    case GSM_STATE_RECOVERING_FROM_GSM_ERROR:
      // Fall-through
    case GSM_STATE_RECOVERING_FROM_GPRS_ERROR:
      // Fall-through
    case GSM_STATE_VDD_RAMPDOWN:
      // Обработку состояния восставноленяи питания на модуле GSM делаем в прерывании. Что бы не сбросились часы RTC
      gsm_state = GSM_STATE_IRQ_POWER_UP;
      break;
      // Это состояние обрабатываеся в прерывании, для того что бы не сбросились RTC часы
    case GSM_STATE_IRQ_POWER_UP:
      if (flag_ServerGsmPowerUp)
      {
        log_trace("Gsm Vdd rampdown done. Turning voltage on...");
        //GpioSet(SIM_POWER_EN);

        gsm_state = GSM_STATE_VDD_RAMPUP;
        timeout_start(&state_timeout, CFG_GSM_VDD_RAMPUP_TIME_MS);
      }
      break;

    case GSM_STATE_VDD_RAMPUP:
      if (timeout_is_elapsed(&state_timeout)) {
        log_trace("Gsm Vdd rampup done. Pushing PWRKEY...");
        //ServerGateway_SelectSimCard(CFG_GSM_DEFAULT_SIMCARD_ID);
        GpioSet(SIM_PWRKEY);

        gsm_state = GSM_STATE_TURNON_PWRKEY_ACTIVE;
        timeout_start(&state_timeout, CFG_GSM_PWRKEY_IMPULSE_DURATION_MS);
      }
      break;

    case GSM_STATE_TURNON_PWRKEY_ACTIVE:
      if (timeout_is_elapsed(&state_timeout)) {
        log_trace("Released PWRKEY. Waiting gsm module to warmup.");
        GpioClear(SIM_PWRKEY);
        ResetNoResponseTimer();

        gsm_state = GSM_STATE_WARM_UP_TIMEOUT;
        timeout_start(&state_timeout, CFG_GSM_WARMUP_TIME_MS);
      }
      break;

    case GSM_STATE_WARM_UP_TIMEOUT:
      if (timeout_is_elapsed(&state_timeout)) {
        log_trace("Warmup ended. Trying to ping modem.");
        ServerGateway_EnableIOPorts();
        sim900_turn_on();
        gsm_state = GSM_STATE_WAITING_FOR_AT_READY;
        timeout_start(&state_timeout, CFG_GSM_WAIT_AT_READY_MS);
      }
      break;

    case GSM_STATE_WAITING_FOR_AT_READY:
      if (sim900_ping()) {
        log_trace("Gsm responded to AT. Setting up.");
        gsm_state = GSM_STATE_SETTING_UP;
        timeout_start(&state_timeout, CFG_GSM_WAIT_INIT_COMPLETE_MS);
        break;
      }

      /// \todo Убрать бесконечный AT после отладки
      //timeout_start(&state_timeout, CFG_GSM_WAIT_AT_READY_MS);

      if (timeout_is_elapsed(&state_timeout)) {
        // Закончились попытки подключиться к модулю.
        log_error("Gsm did not responded to AT.");
        gsm_state = GSM_STATE_UNINITED;//GSM_STATE_START_RECOVER_FROM_HARD_ERROR;
      } else {
        delay_ms(1000);
      }
      break;

    case GSM_STATE_SETTING_UP:
      if (timeout_is_elapsed(&state_timeout)) {
        log_error("Failed to write initial settings to GSM.");
        gsm_state = GSM_STATE_START_RECOVER_FROM_HARD_ERROR;
        break;
      }

      // команда отключения эхо-ответов может завершиться ошибкой из-за наличия эхо-ответов.
      sim900_disable_echo();
      // Инитим тип модуля

      if ((!DevStateForceRequestSimInfo()) || (!DevStateForceRequestModuleSwVersion()))
      {
        log_error("Unknown GSM module and SW version. ");
        delay_ms(500);
        break;
      }

      if ((DevStateGetSimInfo()) && (DevStateGetModuleSwVersion()))
        log_info("\r\n\tDevice module is [%s]\r\n\tSW version [%s]\r\n\t", DevStateGetSimInfo(), DevStateGetModuleSwVersion());

      /// Убрано, так как в SIM800 эта команда стала зивисеть от наличия sim карты, а она до этого не подключена!
      //if (!sim900_select_smsformat_text()) {
      //  log_error("Failed to set SMS settings to GSM.");
      //  delay_ms(500);
      //  break;
      //}

      if (!ServerGateway_LoadImei()){
        log_error("Failed to load IMEI from GSM module.");
        delay_ms(500);
        break;
      }
      log_info("Device IMEI is [%s]", SettingsGetImei());

      // и переход в следующее состояние
      //gsm_state = GSM_STATE_START_WAITING_SIM_READY;
      gsm_state = GSM_STATE_DESELECT_SIM_CARD;
      break;

    case GSM_STATE_DESELECT_SIM_CARD:
//      gsm_state = GSM_STATE_START_WAITING_BEFORE_RESELECT_SIM_CARD;
//      break;

      if (sim900_set_functionality(SIM_FUNC_DISABLE_RADIO_RX_TX, false)) {
        log_trace("Set minimal functionality for GSM module. Pause before selecting SIM card.");
        // Отключение sim карты реализовано при отключении питания модуля.
        // Здесь же добавил для случаев смены sim карты без отключения питания модуля,
        // когда такая функциональность появится.
        ServerGateway_SelectSimCard(0);
        gsm_state = GSM_STATE_START_WAITING_BEFORE_RESELECT_SIM_CARD;
        break;
      }

      // Не получилось перевести GSM модуль в режим минимального функционала.
      log_error("Can't set min function for GSM module.");
      gsm_state = GSM_STATE_START_RECOVER_FROM_HARD_ERROR;
      break;

    case GSM_STATE_START_WAITING_BEFORE_RESELECT_SIM_CARD:
      timeout_start(&state_timeout, 3000);
      gsm_state = GSM_STATE_WAIT_BEFORE_RESELECT_SIM_CARD;
      break;

    case GSM_STATE_WAIT_BEFORE_RESELECT_SIM_CARD:
      if (!timeout_is_elapsed(&state_timeout)) {
        // время ожидания ещё не закончилось.
        break;
      }

      ServerGateway_SelectSimCard(ServerGateway_ChooseSimCard());
      // Первый вызов без перезагрузки, т.к. SIM900 не позволяет
      // перезагрузиться из любого состояния кроме полнофункционального.
      if (!sim900_set_functionality(SIM_FUNC_NORMAL, false)) {
        log_trace("Failed to set full functionality mode for GSM module.");
        gsm_state = GSM_STATE_START_RECOVER_FROM_HARD_ERROR;
        break;
      }

      log_trace("Set Full func mode for GSM. Resetting it to apply SIM card change...");

      delay_ms(500);
      // Данный вызов будет возвращать false, если модем в режиме автоматического
      // выбора скорости UART порта, т.к. при этих условиях после перезагрузки
      // команда не сможет вернуть "OK".
      sim900_set_functionality(SIM_FUNC_NORMAL, true);
      log_trace("Reset complete.");
      gsm_state = GSM_STATE_START_WAITING_FOR_SECOND_AT_READY;
      break;

    case GSM_STATE_START_WAITING_FOR_SECOND_AT_READY:
      log_trace("Waiting for modem restart to complete.");
      gsm_state = GSM_STATE_WAITING_FOR_SECOND_AT_READY;
      timeout_start(&state_timeout, CFG_GSM_WAIT_AT_READY_MS);
      break;

    case GSM_STATE_WAITING_FOR_SECOND_AT_READY:
      if (timeout_is_elapsed(&state_timeout)) {
        // Закончились попытки подключиться к модулю.
        log_error("Gsm did not responded to AT.");
        gsm_state = GSM_STATE_START_RECOVER_FROM_HARD_ERROR;
      }

      if (!sim900_ping()) {
        delay_ms(1000);
        break;
      }

      log_trace("Gsm restart completed. Setting up.");
      sim900_disable_echo();

      gsm_state = GSM_STATE_START_WAITING_SIM_READY;
      break;

    case GSM_STATE_START_WAITING_SIM_READY:
      log_trace("Waiting for sim card to get ready.");
      timeout_start(&state_timeout, CFG_GSM_WAIT_SIM_READY_MS);
      gsm_state = GSM_STATE_WAITING_SIM_READY;
      break;

    case GSM_STATE_WAITING_SIM_READY:
      if (sim900_is_sim_ready()) {
        log_debug("Sim is ready.");

        if (sim900_select_smsformat_text()) {
            log_info("SIM is ready. GSM text SMS settings is set.");

            if (!DevStateForceRequestImsi()) {
                log_warn("Can't read IMSI.");
                break;
            }
            if (!DevStateForceRequestIccid()) {
                log_warn("Can't read ICCID.");
                break;
            }
            bool need_update=false;
            const char* ccid = DevStateGetIccid();
            const char* save_ccid = SettingsGetIccid();
            if ((ccid!=NULL) && (save_ccid!=NULL))
            {
                if (strcmp(ccid,save_ccid))
                    need_update=true;
            }
            else
            {
                if (save_ccid==NULL)
                    need_update=true;
            }

            const char* apn_name = SettingsGetGprsApn();
            const char* apn_user = SettingsGetGprsUser();
            const char* apn_pwd  = SettingsGetGprsPassword();

            (void)apn_user; // Может не использоваться, если выключены логи
            (void)apn_pwd;  // Может не использоваться, если выключены логи

            log_info("Current APN settings: APN=[%s], USER=[%s], PWD=[%s] %s",
                apn_name, apn_user, apn_pwd,
                need_update?"\r\n need_update":"");

            if (apn_name[0] == '\0' || apn_name[0] == ' ' || need_update) {
                if (!ccid) {
                    log_warn("Can't get previously read ICCID, but it should already exist.");
                    break;
                }

                const GsmOperatorGprsSettings* gprs_settings = GetOperatorInfoByCcid(ccid);
                if (!gprs_settings) {
                    log_warn("No GPRS exist for sim card with ICCID=%s", ccid);
                } else {
                    log_info("No APN/user/password set yet. Selecting [%s/%s/%s]",
                            gprs_settings->apn, gprs_settings->user, gprs_settings->pwd);
                    if (DevStateIsUsim(imsi))
                        SettingsSetGprsApn(gprs_settings->apn2);
                    else
                        SettingsSetGprsApn(gprs_settings->apn);
                    SettingsSetGprsUser(gprs_settings->user);
                    SettingsSetGprsPassword(gprs_settings->pwd);
                    SettingsSetIccid(ccid);
                    SettingsSave(SECOND_SETTINGS);
                }
            }

            // Переходим в следующее состояние только если получилось
            // считать CCID сим карты.
            gsm_state = GSM_STATE_START_WAITING_NET_REGISTRATION;
            break;
        }
      }

      if (timeout_is_elapsed(&state_timeout)) {
        log_error("Sim card failed to get ready in time. Or Failed to set SMS settings to GSM.");
        gsm_state = GSM_STATE_START_RECOVER_FROM_SIMCARD_ERROR;
      } else {
        delay_ms(1000);
      }
      break;

    case GSM_STATE_START_WAITING_NET_REGISTRATION:
      // Это состояние нужно что бы не писать несколько раз одно и то же.
      log_debug("Started waiting for network registration.");
      SetSimState(SIM_STATE_NETWORK_REGISTRATION);
      timeout_start(&state_timeout, CFG_GSM_WAIT_NETWORK_REGISTRATION_MS);
      gsm_state = GSM_STATE_WAITING_NET_REGISTRATION;
      break;

    case GSM_STATE_WAITING_NET_REGISTRATION:
      if (sim900_is_network_ready(&roaming)) {
        /// Принудительно перечитываем SMS
        StatusSetFlag(STATUS_HAVE_UNREAD_SMS);
        log_debug("Registered. Waiting GPRS availability.");
        gsm_state = GSM_STATE_START_WAITING_GPRS_AVAILABILITY;
        break;
      }

      if (timeout_is_elapsed(&state_timeout)) {
        log_error("Can't register to GSM network.");
        gsm_state = GSM_STATE_START_RECOVER_FROM_GSM_ERROR;
      } else {
        delay_ms(1000);
      }
      break;

    case GSM_STATE_START_WAITING_GPRS_AVAILABILITY:
      log_debug("Waiting for GPRS availability.");
      timeout_start(&state_timeout, CFG_GSM_WAIT_GPRS_AVAILABLE_MS);
      gsm_state = GSM_STATE_WAITING_GPRS_AVAILABILITY;
      break;

    case GSM_STATE_WAITING_GPRS_AVAILABILITY:
      if (sim900_is_gprs_available()) {
        log_debug("GPRS is available.");
        gsm_state = GSM_STATE_ENTER_STARTING_IP_CONTEXT;
        break;
      }
      if (!sim900_force_enable_gprs()) {
        log_debug("Can't enable GPRS.");
      }

      if (timeout_is_elapsed(&state_timeout)) {
        log_error("GPRS is still not available.");
        gsm_state = GSM_STATE_START_RECOVER_FROM_GPRS_ERROR;
      } else {
        delay_ms(1000);
      }
      break;

    case GSM_STATE_ENTER_STARTING_IP_CONTEXT:
      log_debug("Checking IP context state...");
      timeout_start(&state_timeout, CFG_GSM_WAIT_IP_CONTEXT_ACTIVATION);
      gsm_state = GSM_STATE_STARTING_IP_CONTEXT;
      break;

    case GSM_STATE_STARTING_IP_CONTEXT:
      {
        if (timeout_is_elapsed(&state_timeout)) {
            log_error("IP session can not be started.");
            gsm_state = GSM_STATE_START_RECOVER_FROM_GPRS_ERROR;
            break;
        }

/// Поддержка процедур для работы с PPP
#ifdef CFG_FW_TCPIP
        if (connect_type==SIMCOM_PPP)
        {/// настройка выхода в GPRS для PPP
            /// Вызвать команду AT+CGDCONT=1,”IP”,”internet”
            if (!sim900_set_pdp(SettingsGetGprsApn()))
            {
                log_warn("Set pdp type fail.");
                delay_ms(200);
                break;
            }
            /// Вызвать ATD*99# и получить отклик CONNECT
            if (!sim900_dial("99"))
            {
                log_warn("Set pdp type fail.");
                delay_ms(200);
                break;
            }
            /// После этого можно работать.
            sim900_clear_buffer();
            // всё успешно.
            gsm_state = GSM_STATE_ENTER_READY;
        }
        else
#endif // CFG_FW_TCPIP
        {/// настройка выхода с использованием внутреннего стека TCP/IP
        Sim900IpState ipstate = sim900_get_ip_state();
        if (ipstate == IP_STATE_UNKNOWN) {
          log_warn("Get ip state failed.");
          break;
        }


        if (ipstate == IP_STATE_CONNECTED
            || ipstate == IP_STATE_CONNECTING
            || ipstate == IP_STATE_LISTENING)
        {
          log_warn("There is a connection is opened. Closing it.");
          SocketClose(CLEAR_RXBUFFER);
          break;
        }

        if (ipstate == IP_STATE_PDP_DEACT)
        {
          if (!sim900_deactivate_gprs()) {
            log_error("Failed to close GPRS context.");
          }
          break;
        }

        if (ipstate == IP_STATE_INITIAL){//} || ipstate == IP_STATE_PDP_DEACT) {
#if defined(CFG_GSM_USE_SIM900_SOCKETS) && (CFG_GSM_USE_SIM900_SOCKETS == 1)
          // Из состояний INITIAL выход по команде AT+CSTT
          if (!sim900_init_ip_session(  SettingsGetGprsApn(),
                                        SettingsGetGprsUser(),
                                        SettingsGetGprsPassword())) {
            log_error("Failed to init ip session.");
          }
#elif defined(CFG_GSM_USE_SIM900_FTP) && (CFG_GSM_USE_SIM900_FTP == 1)
          if (!sim900_set_gprs_settings(SettingsGetGprsApn(),
                                        SettingsGetGprsUser(),
                                        SettingsGetGprsPassword())) {
            log_error("Failed to init ip session.");
          }

          // когда используем FTP, активация PDP - через bearer prifile идентификатор.
          // Поэтому дальнейшая настройка не требуется.
          gsm_state = GSM_STATE_ENTER_READY;
#else
#error Please define either CFG_GSM_USE_SIM900_SOCKETS or CFG_GSM_USE_SIM900_FTP to be equal 1.
#endif
          // Команды инициализации выполняем по одной за раз.
          break;
        }

        if (ipstate == IP_STATE_START) {
          if (!sim900_start_ip_session()) {
            log_error("Failed to start ip session.");
          }
          // Команды инициализации выполняем по одной за раз.
          break;
        }
        // Состояние IP CONFIG пропускаем и ждём состояния GPRSACT

        if (ipstate == IP_STATE_GPRSACT
            || ipstate == IP_STATE_CLOSED
            || ipstate == IP_STATE_STATUS) {

          if (!sim900_has_local_ip_address()) {
            log_error("Failed to get ip adress.");
            break;
          }
          // всё успешно.
          gsm_state = GSM_STATE_ENTER_READY;
        }
        }
      }
      break;

    case GSM_STATE_ENTER_READY:
#ifdef CFG_FW_TCPIP
      if (connect_type==SIMCOM_PPP)
      {
          /// Закрыть предыдущее состояние (вдруг забыли)
          gsm_port=ProtocolTcpIpClosePort(gsm_port);
          /// Поднять PPP и открыть канал передачи данных
          gsm_port=ProtocolTcpIpOpenPort(GSM_PORT_TYPE, CFG_GSM_WAIT_IP_CONTEXT_ACTIVATION);
          if (gsm_port==NULL)
          {// Открыть не удалось.
              sim900_disconnect();
              // Откатываемс яна стадию проверки GPRS среды
              timeout_start(&state_timeout, CFG_GSM_WAIT_GPRS_AVAILABLE_MS);
              gsm_state=GSM_STATE_WAITING_GPRS_AVAILABILITY;
              break;
          }
      }
#endif // CFG_FW_TCPIP
      log_info("Gsm is now ready for TCP IP communication.");
      ServerGateway_ResetReadyCheckTimeout();
      SetSimState(SIM_STATE_OK);
      gsm_state = GSM_STATE_READY;
      break;

    case GSM_STATE_READY:
      if (timeout_is_elapsed(&ready_check_timeout)) {
        // Повторная проверка состояния GSM модуля.
        ServerGateway_RecheckState();
      }
#ifdef CFG_FW_TCPIP
      /// Обновляем машину LwIP
      if (connect_type==SIMCOM_PPP)
      {
          /// Обновляем машину состояний LwIP
          ProtocolTcpIp_react();
          /// Проверяем сосотянеи PDP (доделать процедуруу)
          if (ServerGatewayCheckDataMode()) ResetNoResponseTimer();
          /// Проверяем статус соединения
          if (ProtocolTcpIpStatusPort(gsm_port)!=PORT_CONNECTED)
          {
              log_error("******* Lose GSM connection. Restart PDP! ************");
              /// Взбадриваем GSM и всю машину модуля
              ServerGateway_RecheckState();
          }
      }
#endif // CFG_FW_TCPIP
      break;
  }

  return gsm_state == GSM_STATE_READY;
}

bool ServerGateway_IsReady(void)
{
    bool ret=false;
    switch (gsm_state)
    {
        case GSM_STATE_UNINITED :
            flag_NoResponseTimerElapsed=true;
            ret=false;
            break;
        case GSM_STATE_READY :
            flag_NoResponseTimerElapsed=false;
            ret=true;
            break;
        default:
            if (flag_NoResponseTimerElapsed)
                ret=false;
            else
                ret=true;
            break;
    }
    return ret;
}

#ifdef CFG_FW_TCPIP
bool ServerGatewayCmdMode(void)
{
    log_func();
    uint32_t count=4;
    if (connect_type==SIMCOM_PPP)
    {
        while (count--)
        {
            if ((gsm_state==GSM_STATE_READY) && (sim900_cmd_mode()))
            {
                return(true);
            }
            else
            {
                if ((gsm_state>=GSM_STATE_WAITING_FOR_AT_READY) && (gsm_state!=GSM_STATE_READY))
                    return(true);
                else
                    break;
            }
        }
        return(false);
    }
    return(true);
}

static bool ServerGatewayCheckDataMode(void)
{
    //log_func();
    bool ret=true;
    if (connect_type==SIMCOM_PPP)
    {
        if ((gsm_state==GSM_STATE_READY) && (!sim900_get_data_mode()))
        {// Ошибка возврата в режим передачи данных
            log_error("GSM module in state READY, but not data mode");
            // Для тестирования. Провалимся сюда или нет.
            //#include "indication/indicators.h"
            //BeepOnce(1000);
            //delay_ms(15000);
            // Закрыть все TCP, LCP и т.д. соединения
            gsm_socket=ProtocolTcpIpSocketClose(gsm_socket);
            gsm_port=ProtocolTcpIpClosePort(gsm_port);
            ServerGateway_RedialState();
            ret=false;
        }
    }
    return(ret);
}
#endif // CFG_FW_TCPIP

bool ServerGateway_WaitReady(systime_t timeout_ms)
{
  timeout_t     t;
  timeout_start(&t, timeout_ms);

  while(!timeout_is_elapsed(&t)) {
    if (ServerGatewayStateMachine_React()) {
      return true;
    }
  }
  return false;
}

void set_sim900_state_listener(OnSim900StateChanged listener)
{
  log_func();
  on_sim_state_changed = listener;
}


#if 0
/// \brief Передаёт отчёт из буффера \p data на сервер,
/// ptr_3th_flow дополнительный поток данных, формируется непосредственно перед отправкой пакета
/// при необходимости, шифруя данные.
bool SendToServer(char* data, size_t* response_length, char * ptr_3th_flow, priority_t * level)
{
  log_func();
  if (data)
  log_debug("Sending to server: \r\n[%s] ", data);
  if (ptr_3th_flow)
  log_debug("Sending to server 3th_flow: \r\n[%s] ", ptr_3th_flow);

  // Для того, что бы передача не оказалась прерванной, из буффера необходимо
  // убрать все вхождения символов 0x1A и 0x1B, которые GSM модем воспринимает
  // как служебные символы и при их появлении либо начинает, либо отменяет
  // передачу данных.
  static const char   chars_to_replace[]    = {0x1A, 0x1B, 0};
  static const char   substitution_values[] = {' ',  ' ',  0};
  if (data)
  ReplaceMultipleChars((char*)data, chars_to_replace, substitution_values);
  if (ptr_3th_flow)
  ReplaceMultipleChars((char*)ptr_3th_flow, chars_to_replace, substitution_values);

  size_t content_length = 0;
  if (data)
    content_length = strlen(data);
  size_t length_3th_flow = 0;
  if (ptr_3th_flow)
    length_3th_flow = strlen(ptr_3th_flow);

#if defined(CFG_USE_ENCRYPTION) && (CFG_USE_ENCRYPTION == 1)
  if (SettingsIsEncryptEnabled()) {
    char* dst = strcpy_ex((char*)txbuffer_enc, "data=");
    gost_encrypt_bytes_to_hex(dst,
                              data,
                              content_length,
                              DevStateGetPrivateKey());

    data = (char*)txbuffer_enc;
    content_length = strlen(data);
  }
#endif // if defined(CFG_USE_ENCRYPTION) && (CFG_USE_ENCRYPTION == 1)

  bool ok = SendBufferToServer(data, content_length, response_length, ptr_3th_flow, length_3th_flow, level);
  log_func_result(ok);
  return ok;
}

void SaveReportToFLASH(char* buffer, Report_data_type data_type)
{
#if !defined(CFG_GSM_USE_STORAGE) || (!CFG_GSM_USE_STORAGE)
  HaltWithReason("Invalid Operation", Halt_SaveReportToFLASH, false); // not available when storage is disabled.
#else
  size_t  report_size = strlen(buffer);
  StorageSaveReport(buffer, report_size, data_type);
#endif // !defined(CFG_GSM_USE_STORAGE) || (!CFG_GSM_USE_STORAGE)
}


/// \brief Отправляет все сохраненные во флеш памяти отчёты на сервер.
bool SendReportsFromFLASH(char* buffer, size_t buffer_size, char* ptr_3th_flow, char* ptr_3th_flow_end, Report_data_type type, bool last)
{
  log_func();
  log_info("Report type = %d, %s", type, last?"only one last packet":"");
  #define MAX_REPORT_SEND       10
#if !defined(CFG_GSM_USE_STORAGE) || (!CFG_GSM_USE_STORAGE)
  HaltWithReason("Invalid Operation", Halt_SendReportsFromFLASH, false); // not available when storage is disabled.
#else
  ReportIterator   it;
  bool             set_prev=false;
  size_t           prev_it_address=0;
  ReadReportResult  read_result;

  read_result = StorageReadFirstReport(&it, buffer, buffer_size-1);
  uint16_t count=0;
  if (last) count=MAX_REPORT_SEND;
  priority_t level=MY_PRIORITY;
  while ((read_result != READ_REPORT_FAILED) && (count<=MAX_REPORT_SEND)){
// Перенес проверку в конец цикла. Что бы успели передать хотя бы один отчет. Иначе отчет на обновленеи прошивки по SMS не отправлялся (флаг SMS скидывается только при полном отсутствии SMS в буфере)
//    // Вставил выход при возникновении высокоприооритетных событий. Фигня, но пока так.
    if (NeedBreakeHighPriority(&level))
    //if (IsHighPriority())
    {
        count=MAX_REPORT_SEND+1;
        //log_info("= High! Break SendReportsFromFLASH.");
        //return(false);
    }
    // поскольку отправка в текстовом режиме, то добавляем нуль-символ
    // для того, что бы буффер наверняка был корректно закончен.
    buffer[min_sizet(buffer_size-1, it.record.header.data_size)] = '\0';

    if (read_result == READ_REPORT_SUCCESS
        && it.record.report_complete == REPORT_IS_COMPLETE
        && it.record.report_erased == REPORT_IS_ACTIVE) {
        log_info("Read packet type =%d",it.record.header.data_type.type);
        if ((it.record.header.data_type.type==type) || (type==UNKNOW_PACKET))
        {
            // Запоминаем данные о валидной записи
            prev_it_address=it.address;
            set_prev=true;
            if (!last)
            {
                // прочитан ещё не отправленный отчёт.

                count++;
                // Формируем данные третьего потока
                CreatePacket_3th_flow(ptr_3th_flow, ptr_3th_flow_end, PACKET_SOURCE_FLASH);
#ifndef FW_TESTS
                if (!CallServer(buffer, OnServerResponse_ControlModem, ptr_3th_flow, &level)) {//OnServerResponse_UpdateTime)) {
#else
                if (!CallServer(buffer, NULL, NULL, NULL)) {//OnServerResponse_UpdateTime)) {
#endif // FW_TESTS
                    // Неудалось отправить отчёт на сервер. Выходим из данной функции.
                    // Подождём до лучших времён.
                    log_debug("Failed to send report to server.");
                    return (false);//continue; // Не стоит пока делать continue. При ошибке сервера. Будет 10 раз по 3 раза (в SendToServer) пытаться передать пакет.
                }
                //if (NeedBreakeHighPriority(&level)) return(false);
            }
        }
    }

    // Если добрались до сюда, то отчёт либо был успешно отправлен,
    // либо был неполным, либо был уже удалённым. Необходимо своевременно
    // удалять неполные и отправленные отчёты.
    if ((it.record.header.data_type.type==type) || (type==UNKNOW_PACKET)){
        if ((it.record.report_erased == REPORT_IS_ACTIVE) && (!last)) {
            StorageEraseReport(&it);
        }
    }

    // Переход к следующему отчёту.
    read_result = StorageReadNextReport(&it);
    // Достигнут конец
    if ((last) && (read_result==READ_REPORT_FAILED))
    {
        if (set_prev)
        {
            // Производим восстановление it
            it.address=prev_it_address;
            read_result = StorageReReadReport(&it);
        }
        // Сброс признака последнего
        last=false;
    }
    // Вставил выход при возникновении высокоприооритетных событий. Фигня, но пока так.
    //if (IsHighPriority())
    //{
    //    log_info("= IsHighPriority present! Exit from SendReportsFromFLASH.");
    //    return(false);
    //}

  }
  if (read_result != READ_REPORT_FAILED)
    return(true);
#endif // !defined(CFG_GSM_USE_STORAGE) || (!CFG_GSM_USE_STORAGE)
  return (false);
}


/// \brief Отправляет данные \p data на сервер. Если не удаётся, то сохраняет
/// их во флеш память.
bool SendToServerOrSaveToFlash(char* data, bool save_only, Report_data_type data_type)
{
#if !defined(CFG_GSM_USE_STORAGE) || (!CFG_GSM_USE_STORAGE)
  size_t  report_size = strlen(data);
  return SendBufferToServer(data, report_size, NULL, NULL, 0, NULL);
#else
  SaveReportToFLASH(data, data_type);
  if (!save_only)
    SendStoredReports(true);
  else
    SetNeedToSend();
  return true;
#endif // !defined(CFG_GSM_USE_STORAGE) || (!CFG_GSM_USE_STORAGE)
}
#endif //0

/// \brief Настраивает драйвер gsm модуля, модуль отправки данных на сервер
/// и открывает GPRS сессию.
void ServerGatewayInit(USART_TypeDef* port, OnSim900StateChanged  on_state_changed,
                      void (*turn_on_port)(void),
                      void (*turn_off_port)(void),
                      void (*select_sim_card)(int card_id),
                      ConnectType type)
{
#if !defined(CFG_GSM_USE_STORAGE) || (!CFG_GSM_USE_STORAGE)
  // do nothing
#else
  StorageInit();
#endif // !defined(CFG_GSM_USE_STORAGE) || (!CFG_GSM_USE_STORAGE)

  simkey_curent_state=SimCardInserted(SIM_CARD_EXTERNAL1);
  turn_on_port_fxn = turn_on_port;
  turn_off_port_fxn = turn_off_port;
  select_sim_card_fxn = select_sim_card;
  switch (type)
  {
    case SIMCOM_TCPIP:
/// Поддержка процедур для работы с PPP
#ifdef CFG_FW_TCPIP
    case SIMCOM_PPP:
#endif // CFG_FW_TCPIP
        connect_type=type;
        break;
    default:
        connect_type=SIMCOM_TCPIP;
        break;
  }

  set_sim900_state_listener(on_state_changed);
  ServerMonitor_OnStateChanghed(SERVER_STATE_DISCONNECTED);

  Sim900Config  sim900_config = {
    .port = port,
    .rx_buffer = rxbuffer,
    .rx_buffer_size = sizeof(rxbuffer),
#ifdef CFG_FW_TCPIP
    .data_react = ProtocolTcpIp_react,
#endif // CFG_FW_TCPIP
  };
  sim900_init(&sim900_config);

  gsm_state = GSM_STATE_UNINITED;

  if (!ServerGateway_WaitReady(30000)) {
    log_info("Failed to start server gateway.");
  }
  log_info("ServerGateway initialization complete.");
}

#if 0
/// \brief Передаёт на сервер запрос \p request, при получении ответа вызывает
/// обработчик response_handler.
bool CallServer(char* request, ServerResponseHandlerFxn response_handler, char* ptr_3th_flow, priority_t * level)
{
  log_func();
  log_debug("Sending request to server:\r\n\r\n[%s]\r\n\r\n", request);
  if (SendToServer(request, NULL, ptr_3th_flow, level))
  {
    if (response_handler != NULL) {
#ifdef CFG_FW_TCPIP
        if (connect_type==SIMCOM_PPP)
            rx_data=(char *)mas_rx_data;
        else
#endif // CFG_FW_TCPIP
            rx_data=(char *)rxbuffer;
        response_handler((char*)rx_data, level);
        return true;
    }
    return true;
  }
  return false;
}
#endif

// Процедура для прерывания. Периодический опрос состояния
void __SimKeyMonitor(void)
{
  if (simkey_curent_state==SimCardInserted(SIM_CARD_EXTERNAL1))
  {
      sim_time_zz=TIME_DEBOUNCE_SIM_KEY;
  }
  else
  {
    if (sim_time_zz)
    {
        sim_time_zz--;
        if (sim_time_zz<=0)
        {
            sim_time_zz=0;
            simkey_debounce_over=true;
            simkey_curent_state=SimCardInserted(SIM_CARD_EXTERNAL1);
        }
    }
  }
}


// пердает значение флага смены сим карты для команды Конфиг
bool IsSimCardChaged(bool clear)
{
    bool ret=simkey_changed;
    if (clear)
    {
        simkey_changed=false;
    }
    return(ret);
}

// Сообщает о том, что сим карта сменилась и готова к работе
bool SimIsChange_and_ready(void)
{
    return (gsm_state==GSM_STATE_READY) && (IsSimCardChaged(false));
}

void ServerConnectionStatusUpdate(void)
{
    ServerGateway_OnConnectionSuccess();
}

bool ServerGateway_React()
{
  return ServerGatewayStateMachine_React();
}


bool ServerGateway_WaitReadyForSms(systime_t timeout_ms)
{
  timeout_t     t;
  timeout_start(&t, timeout_ms);

  while(!timeout_is_elapsed(&t)) {
    if (ServerGatewayStateMachine_React()) {
      return true;
    }
    if (gsm_state > GSM_STATE_WAITING_SIM_READY) {
      return true;
    }
  }
  return false;
}

bool ServerGateway_ReadSms(size_t sms_index, sms_info_t* dst)
{
  log_func();
  if (!ServerGateway_WaitReadyForSms(500)) {
    return false;
  }

  return sim900_read_sms(sms_index, dst);
}

bool ServerGateway_SendSms(const char* dst_phone, const char* format_str, ...)
{
  log_func();
  if (!ServerGateway_WaitReadyForSms(500)) {
    return false;
  }

  va_list   var_args;
  va_start(var_args, format_str);
  bool result = sim900_send_sms_va(dst_phone, format_str, var_args);
  va_end(var_args);

  return result;
}

bool ServerGateway_DeleteAllSms()
{
  log_func();
  if (!ServerGateway_WaitReadyForSms(500)) {
    return false;
  }
  return sim900_delete_all_sms();
}

#ifdef CFG_FW_TCPIP
void GSM_close(void)
{
    log_func();
    gsm_state=GSM_STATE_UNINITED;
}
#endif // CFG_FW_TCPIP
