/// \file pushbutton.h
/// \author DL <dmitriy.linikov@gmail.com>
/// \brief Драйвер кнопки с гистерезисным подавлением дребезга контактов.



#ifndef PUSHBUTTON_H_INCLUDED
#define PUSHBUTTON_H_INCLUDED

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include "systime.h"

#define PUSHBUTTON_STATE_PRESSED  true
#define PUSHBUTTON_STATE_RELEASED false

typedef enum {
  PUSHBUTTON_EVENT_NONE = 0,
  PUSHBUTTON_EVENT_PRESSED,
  PUSHBUTTON_EVENT_RELEASED
} PushbuttonEvent;

struct PushbuttonTag;

typedef void (*PushbuttonCallback)(void* user_arg, PushbuttonEvent event);

typedef struct PushbuttonTag {
  const void*                   channel;
  bool                          (*read_pin)(struct PushbuttonTag* pb);
  volatile PushbuttonCallback   callback;
  void*                         callback_arg;
  int16_t                       value;
  bool                          state;
  systime_t                     time;
  void*                         ext_cfg;
} Pushbutton;


#define DEFINE_PUSHBUTTON_EX(gpio_channel_ptr, read_fxn)                              \
                                            { .channel          = (gpio_channel_ptr), \
                                              .read_pin         = (read_fxn),         \
                                              .callback         = NULL,               \
                                              .callback_arg     = NULL,               \
                                              .value            = 0,                  \
                                              .state            = 0,                  \
                                              .time             = 0,                  \
                                              .ext_cfg          = NULL                \
                                            }



void PushbuttonInit(Pushbutton* pb);
void PushbuttonSetCallback(Pushbutton* pb, PushbuttonCallback callback, void* user_arg, void* ext_cfg);
bool PushbuttonIsPressed(Pushbutton* pb);
systime_t PushbuttonGetPressTime(Pushbutton* pb);

/// \brief Данная функция должна вызываться из высокочастотного таймера (1 мс);
int8_t __PushbuttonReact(Pushbutton* pb);

#endif // PUSHBUTTON_H_INCLUDED
