#include "settings.h"
#include "../../telemetron/apps/include/settings/settings.h"

#include <ctype.h>
#include <string.h>

static settings_t   g_settings;

static char         g_imei[IMEI_LENGTH + 1];
static char         g_iccid[ICCID_LENGTH + 1];


bool        SettingsIsBeepEnabled(void)
{
  const onoff_t* onoff = settings_get_beep(&g_settings);
  return onoff && *onoff == VALUE_ON;
}

const char* SettingsGetGprsApn(void)
{
  return settings_get_apn_name(&g_settings);
}

const char* SettingsGetGprsUser(void)
{
  return settings_get_apn_user(&g_settings);;
}

const char* SettingsGetGprsPassword(void)
{
  return settings_get_apn_pwd(&g_settings);;
}


bool SettingsSetGprsApn(const char* apn)
{
  return settings_set_apn_name(&g_settings, apn) >= 0;
}

bool SettingsSetGprsUser(const char* user)
{
  return settings_set_apn_user(&g_settings, user) >= 0;
}

bool SettingsSetGprsPassword(const char* pwd)
{
  return settings_set_apn_pwd(&g_settings, pwd) >= 0;
}

////////////////////////////////////////////////////////////////////////////
//  Заглушки, скопированные из Modem-2.7 для параметров, которых больше
//  не хранится в настройках
// -------------------------------------------------------------------------

bool SettingsStrIsValid(const char* digstr, int32_t len)
{
  bool has_value = false;
  if (digstr==NULL)
    return false;
  for (int32_t i=0; i < len; ++i) {
    if (!isdigit((uint8_t)digstr[i])) {
      return false;
    }
    if (digstr[i] != '0') {
      has_value = true;
    }
  }
  if (digstr[len] != '\0') {
    // Если длина digstr отличается от len, то это неправильный номер.
    return false;
  }
  if (!has_value) {
    // digstr, состоящий из одних нулей - невалиден.
    return false;
  }
  return true;
}

bool SettingsImeiIsValid(const char* imei)
{
  return(SettingsStrIsValid(imei, IMEI_LENGTH));
}

const char* SettingsGetImei(void)
{
  return SettingsImeiIsValid(g_imei)
         ? g_imei
         : NULL;
}

bool SettingsSetImei(const char* new_imei)
{
  if (!SettingsImeiIsValid(new_imei)) {
    return false;
  }

  if (strcmp(g_imei, new_imei) != 0) {
    // Если IMEI изменился, то необходимо сразу сохранить настройки.
    strcpy(g_imei, new_imei);
    SettingsSave(MAIN_SETTINGS);
  }
  return true;
}

const char* SettingsGetIccid(void)
{
  uint16_t len=strlen(g_iccid);
  if (len>ICCID_LENGTH)
    return NULL;
  return SettingsStrIsValid(g_iccid, len)
         ? g_iccid
         : NULL;
}

bool SettingsSetIccid(const char* new_iccid)
{
  uint16_t len=strlen(new_iccid);
  if (len>ICCID_LENGTH)
    return false;
  if (!SettingsStrIsValid(new_iccid, len)) {
    return false;
  }

  if (strcmp(g_iccid, new_iccid) != 0) {
    // Если ICCID изменился, то необходимо сразу сохранить настройки.
    strcpy(g_iccid, new_iccid);
    SettingsSave(MAIN_SETTINGS);
  }
  return true;
}


/// \brief Сохраняет параметры во флеш.
void SettingsSave(Settings_Storage mode)
{
  // Не используется в загрузчике
  (void)mode;
}

/// \brief Загружает параметры из флеш, либо стандартные значения, если
/// во флеш сохраненные параметры не найдены.
void SettingsLoad(void)
{
  settings_create(&g_settings);
  settings_load_all(&g_settings);
}
