/// \file software_watchdog.h
/// \author DL <dmitriy.linikov@gmail.com>

#include <stdint.h>
#include "system_utils.h"
#include "watchdog.h"
#include "software_watchdog.h"

#ifndef CFG_SOFTDOG_MS_PER_TICK
#define CFG_SOFTDOG_MS_PER_TICK                 100
#endif // CFG_SOFTDOG_MS_PER_TICK

#ifndef CFG_SOFTDOG_NO_SERVER_RESPONSE_MS
#define CFG_SOFTDOG_NO_SERVER_RESPONSE_MS       1800000
#endif // CFG_SOFTDOG_NO_SERVER_RESPONSE_MS

#ifndef CFG_SOFTDOG_OUT_OF_MAIN_LOOP_MS
#define CFG_SOFTDOG_OUT_OF_MAIN_LOOP_MS         200000
#endif // CFG_SOFTDOG_OUT_OF_MAIN_LOOP_MS

#ifndef CFG_SOFTDOG_HW_WATCHDOG_TIMEOUT_MS
#define CFG_SOFTDOG_HW_WATCHDOG_TIMEOUT_MS      20000
#endif // CFG_SOFTDOG_HW_WATCHDOG_TIMEOUT_MS

#define SOFTDOG_TICKS(ms)                       (1 + ((ms) / CFG_SOFTDOG_MS_PER_TICK))
#define SOFTDOG_NO_SERVER_RESPONSE_TICKS        SOFTDOG_TICKS(CFG_SOFTDOG_NO_SERVER_RESPONSE_MS)
#define SOFTDOG_OUT_OF_MAIN_LOOP_TICKS          SOFTDOG_TICKS(CFG_SOFTDOG_OUT_OF_MAIN_LOOP_MS)

static volatile uint32_t   server_ticks_left     = SOFTDOG_NO_SERVER_RESPONSE_TICKS;
static volatile uint32_t   main_loop_ticks_left  = SOFTDOG_OUT_OF_MAIN_LOOP_TICKS;

void Softdog_Init()
{
#if defined(CFG_USE_WATCHDOG) && (CFG_USE_WATCHDOG == 1)
  watchdog_configure(CFG_SOFTDOG_HW_WATCHDOG_TIMEOUT_MS);
  watchdog_start();
#endif
}

void Softdog_OnServerResponse()
{
  if (server_ticks_left > SOFTDOG_NO_SERVER_RESPONSE_TICKS) {
    HaltWithReason("Invalid state of software watchdog.", Halt_Softdog_OnServerResponse, false);
  }

  server_ticks_left = SOFTDOG_NO_SERVER_RESPONSE_TICKS;
  Softdog_OnReturnedToMainLoop();
}

void Softdog_OnServerResponse_Wait(uint32_t time_ms)
{
  if (server_ticks_left > SOFTDOG_NO_SERVER_RESPONSE_TICKS) {
    HaltWithReason("Invalid state of software watchdog. In Wait", Halt_Softdog_OnServerResponse_Wait, false);
  }

  if ((time_ms<CFG_SOFTDOG_NO_SERVER_RESPONSE_MS) && (time_ms))
  {
    if (server_ticks_left<SOFTDOG_TICKS(time_ms)) server_ticks_left = SOFTDOG_TICKS(time_ms);
  }
  Softdog_OnReturnedToMainLoop();
}


void Softdog_OnReturnedToMainLoop()
{
  if (main_loop_ticks_left > SOFTDOG_OUT_OF_MAIN_LOOP_TICKS) {
    HaltWithReason("Invalid state of software watchdog.", Halt_Softdog_OnReturnedToMainLoop, false);
  }
  main_loop_ticks_left = SOFTDOG_OUT_OF_MAIN_LOOP_TICKS;
}

void __Softdog_React()
{
  if (!(--main_loop_ticks_left)) {
    while (1) {
      HaltWithReason("Watchdog: Out of main loop for too long. Restarting.", Halt_Watchdog_Main, false);
    }
  }

  if (!(--server_ticks_left)) {
    while (1) {
      HaltWithReason("Watchdog: No response from server for too long. Restarting.", Halt_Watchdog_Server, false);
    }
  }

#if defined(CFG_USE_WATCHDOG) && (CFG_USE_WATCHDOG == 1)
  // Если добрались до сюда, значит все проверки пройдены и можно сбрасывать
  // аппаратный сторожевой таймер.
  watchdog_reset();
#endif
}

