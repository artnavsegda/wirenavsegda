#!/bin/bash
st-flash --format ihex write nuttx/nuttx/nuttx.hex