#!/bin/bash

# Выбор платы STM32F3Discovery с использованием USB консоли
pushd .
cd nuttx/nuttx/tools

./configure.sh stm32f3discovery/usbnsh

popd
