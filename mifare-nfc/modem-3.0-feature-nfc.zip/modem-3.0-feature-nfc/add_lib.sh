#!/bin/bash

# Создание нового приложения в /telemetron/apps из шаблона.
# Параметры:
# add_lib.sh --name <lib_name> --id <LIB_UPPERCASE_ID> --force
#
# Где 	<lib_name> 				- имя приложения (и имя директории по совместительству)
# 		<APP_UPPERCASE_ID>		- идентификатор приложения, используемый как часть создаваемых конфигурационных констант в Kconfig и т.д.
#
# Если есть параметр --force, то при нахождении в папке telemetron/apps/<lib_name>, 
# данная папка будет удалена, а на её место будет записано новое приложение из шаблона.

function PrintUsageAndDie {
	# Сделал подсказку двуязычной на случай, если консоль имеет отличную от UTF-8 кодировку
	echo "================================================================================"
	echo ""
	echo "Script to create from template a new library and save it to /telemetron/apps"
	echo "Usage:"
	echo ""
	echo "  ./add_lib.sh --name <lib_name> --id <LIB_UPPERCASE_ID> [--force]"
	echo "  Where:"
	echo "    <lib_name>         - lowercase name of the lib (no spaces, no lib_ prefix)"
	echo "    <LIB_UPPERCASE_ID> - ID of the lib, used as part of #ifdef/#define"
	echo ""
	echo "If --force is present then existing app with the same name will be deleted."
	echo ""
	echo "--------------------------------------------------------------------------------"
	echo ""
	echo "Скрипт для создания из шаблона новой библиотеки в папке /telemetron/apps"
	echo "Правила использования:"
	echo ""
	echo "  ./add_lib.sh --name <lib_name> --id <LIB_UPPERCASE_ID> [--force]"
	echo "  где:"
	echo "    <lib_name>         - имя создаваемой библиотеки, желательно в нижнем "
	echo "                         регистре. Оно должно быть таким, что бы в C можно было "
	echo "                         создать переменную с таким именем."
	echo "    <LIB_UPPERCASE_ID> - ID создаваемой библиотеки, в верхнем регистре,"
	echo "                         Этот ID будет использоваться в составе #ifdef/#define "
	echo ""
	echo "Если задан парамер --force, то уже существующая библиотека с таким именем"
	echo "будет удалено из папки /telemetron/apps перед созданием нового."
	echo ""
	echo "================================================================================"
	echo ""
	exit $1
}



if [[ $# -eq 0 ]]
then
	PrintUsageAndDie 1
fi


while [[ $# -gt 0 ]]
do
key="$1"


case $key in
    -n|--name)
      LIB_NAME="$2"
      shift # past argument
    ;;
    -i|--id)
      LIB_ID="$2"
      shift # past argument
    ;;
    -f|--force)
      FORCE=1
    ;;
    *)
      # unknown option
      echo "Unknown option \"$1\""
    ;;
esac
shift # past argument or value
done

ERROR=0

# Проверка правильности имени приложения
if [ -z ${LIB_NAME+x} ]
then
	echo "ERROR: Lib name is not specified"
	ERROR=1

elif [ ${#LIB_NAME} -eq 0 ]
then
	echo "ERROR: Lib name is empty"
	ERROR=1

elif [ ${LIB_NAME:0:1} = - ]
then
	echo "ERROR: Lib name \($LIB_NAME\) is invalid"
	ERROR=1

fi


# Проверка правильности идентификатора приложения
if [ -z ${LIB_ID+x} ]
then
	echo "ERROR: Lib ID is not specified"
	ERROR=1

elif [ ${#LIB_ID} -eq 0 ]
then
	echo "ERROR: Lib ID is empty"
	ERROR=1

elif [ ${LIB_ID:0:1} = - ]
then
	echo "ERROR: Lib ID \($LIB_ID\) is invalid"
	ERROR=1

fi

# Проверка наличия переменной FORCE и подстановка стандартного значения
if [ -z ${FORCE+x} ]
then
	FORCE=0
fi

if [ $ERROR -ne 0 ]
then
	echo "ERROR: Not all parameters are set. Can't continue"
	PrintUsageAndDie $ERROR
fi


TEMPLATE_FOLDER="telemetron/templates/lib_template"
TEMPLATE_SRC="template.c"
TEMPLATE_HDR="template.h"
TEMPLATE_KCONFIG="Kconfig"

FOLDER_NAME="telemetron/apps/lib_$LIB_NAME"
INC_FOLDER_NAME="telemetron/apps/include/$LIB_NAME"
MAIN_C="${LIB_NAME}.c"
MAIN_H="${LIB_NAME}.h"


# Проверка, что директория отсутствует

if [[ -e $FOLDER_NAME && $FORCE -eq 1 ]]
then
	echo "WARNING: The folder '$FOLDER_NAME' already exist. Removed it because --force is specified."
	rm -rf $FOLDER_NAME

elif [[ -e $FOLDER_NAME && $FORCE -eq 0 ]]
then
	echo "ERROR: Can't write to '$FOLDER_NAME' - already exist."
	exit 2
fi

# Проверка, что директория с заголовочными файлами отсутствует
if [[ -e $INC_FOLDER_NAME && $FORCE -eq 1 ]]
then
	echo "WARNING: The folder '$INC_FOLDER_NAME' already exist. Removed it because --force is specified."
	rm -rf $INC_FOLDER_NAME

elif [[ -e $INC_FOLDER_NAME && $FORCE -eq 0 ]]
then
	echo "ERROR: Can't write to '$INC_FOLDER_NAME' - already exist."
	exit 2
fi


# Копирование шаблона в целевую директорию
cp -R $TEMPLATE_FOLDER/. $FOLDER_NAME

# Создание папки под заголовочные файлы
mkdir ${INC_FOLDER_NAME}

# Замена всех вхождений:
#   {LIB_ID}        на ID
#   {LIB_NAME}      на название приложения.
#   {AUTHOR}        на имя автора, взятое из git
#   {AUTHOR_EMAIL}  на почту автора, взятую из git

AUTHOR=$(git config user.name)
AUTHOR_EMAIL=$(git config user.email)

REPLACE_LIST=""
REPLACE_LIST+="s/{LIB_NAME}/${LIB_NAME}/g; "
REPLACE_LIST+="s/{LIB_ID}/${LIB_ID}/g; "
REPLACE_LIST+="s/{AUTHOR}/${AUTHOR}/g; "
REPLACE_LIST+="s/{AUTHOR_EMAIL}/${AUTHOR_EMAIL}/g; "

pushd . > /dev/null
cd $FOLDER_NAME
sed -i -- "${REPLACE_LIST}" *
popd > /dev/null



# Переименование основного файла и его заголовка для соответствия с названием приложения
mv $FOLDER_NAME/$TEMPLATE_SRC $FOLDER_NAME/$MAIN_C
mv $FOLDER_NAME/$TEMPLATE_HDR $INC_FOLDER_NAME/$MAIN_H

echo
echo "Done. Library location:  $FOLDER_NAME, "
echo "      Headers location:  $INC_FOLDER_NAME."
echo "Don't forget to 'make distclean'"
echo

exit 0