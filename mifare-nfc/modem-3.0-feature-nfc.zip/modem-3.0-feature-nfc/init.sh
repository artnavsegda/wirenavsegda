#!/bin/bash

# Данный скрипт необходимо выполнить сразу после первоначального
# получения файлов из репозитория.
#
# Он обновляет все используемые субмодули и создаёт в файловой системе
# ссылку на папку приложений telemetron/apps

git submodule update --init --recursive

pushd .
cd ./nuttx/apps/
ln -sfrn ../../telemetron/apps external
popd
