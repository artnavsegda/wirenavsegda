#!/bin/bash
# Запускает openocd, открывает консоль nsh и swo syslog
DATE=$(date +%d-%m-%Y-%H%M%S);
#TERM_LINE="netcat localhost 4001 | tee >(ts \"%y-%m-%d-%H%M%S\" >$HOME/putty_logs/$DATE-SYSLOG-telemetron.log)"
#TERM_LINE_QUOTED="gnome-terminal -x $TERM_LINE"
gnome-terminal -e 'JLinkGDBServer -device STM32F101VG -if SWD -speed auto -port 3333 -swoport 4000 -telnetport 4001'
echo ${!} > /var/tmp/jlink.pid

putty -serial -log ~/putty_logs/$DATE-NSH-telemetron.log -sercfg 115200,8,1,n,N -title 'NSH' /dev/ttyACM0 &
echo ${!} > /var/tmp/nsh.pid

putty -raw -log ~/putty_logs/$DATE-SYSLOG-telemetron.log -P 4001 -title 'SYSLOG' localhost &
echo ${!} > /var/tmp/syslog.pid

arm-none-eabi-gdb --tui --eval-command="target extended :3333" --eval-command="load" --eval-command="mon reset" --eval-command="mon SWO EnableTarget 36000000 1000000 1 0" --eval-command="ni" nuttx/nuttx/nuttx

# Подчистка после выхода из gdb
if [ -f /var/tmp/syslog.pid ]; then
  kill -n 9 $(cat /var/tmp/syslog.pid && rm /var/tmp/syslog.pid)
fi

if [ -f /var/tmp/nsh.pid ]; then
  kill -n 9 $(cat /var/tmp/nsh.pid && rm /var/tmp/nsh.pid)
fi

if [ -f /var/tmp/jlink.pid ]; then
  kill -n 9 $(cat /var/tmp/jlink.pid && rm /var/tmp/jlink.pid)
fi
pkill --signal SIGABRT JLinkGDBServer

#echo $TERM_LINE

#TERM_LINE_EVAL="$(printf '%s' 'netcat localhost 4001 | tee $HOME/putty_logs/$DATE-SYSLOG-telemetron.log')"

#echo "$TERM_LINE_EVAL"

#gnome-terminal -x $TERM_LINE_EVAL
#gnome-terminal -e "netcat localhost 4001 | tee $HOME/putty_logs/$DATE-SYSLOG-telemetron.log)"


#gnome-terminal -e 'openocd -f ./telemetron-nucleo-f207zg.cfg'
#./parse_itm.py