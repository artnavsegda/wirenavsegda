#!/bin/bash
# Запускает openocd, открывает консоль nsh и swo syslog
DATE=$(date +%d-%m-%Y-%H%M%S);
#TERM_LINE="netcat localhost 4001 | tee >(ts \"%y-%m-%d-%H%M%S\" >$HOME/putty_logs/$DATE-SYSLOG-telemetron.log)"
#TERM_LINE_QUOTED="gnome-terminal -x $TERM_LINE"
#gnome-terminal --hide-menubar -e 'JLinkGDBServer -device STM32F101VG -if SWD -speed auto -port 3333 -swoport 4000 -telnetport 4001 -vd'
xterm -fa "Consolas" -fs 8 -geometry 315x25 -leftbar -T "JLink GDB" -e 'JLinkGDBServer -device STM32F101VG -if SWD -speed auto -port 3333 -swoport 4000 -telnetport 4001 -vd' &
echo ${!} > /var/tmp/jlink.pid

sleep 0.2

putty -serial -log ~/putty_logs/$DATE-NSH-telemetron.log -sercfg 115200,8,1,n,N -title 'NSH' /dev/ttyACM0 &
echo ${!} > /var/tmp/nsh.pid

putty -raw -log ~/putty_logs/$DATE-SYSLOG-telemetron.log -P 4001 -title 'SYSLOG' localhost &
echo ${!} > /var/tmp/syslog.pid

