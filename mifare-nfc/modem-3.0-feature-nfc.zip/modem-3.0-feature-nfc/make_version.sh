#!/bin/bash

source common.sh
GIT_DIRTY=`git status --porcelain --ignore-submodules=untracked | head -1`
GIT_BRANCH_RAW=`git symbolic-ref --short HEAD 2>/dev/null`
GIT_BRANCH=${GIT_BRANCH_RAW//[^A-Za-z0-9._-]/-}
GIT_NODE=`git log -1 --pretty=%H`
GIT_NODE_SHORT=`git log -1 --pretty=%h`
COMMIT_TIMESTAMP=`git log -1 --pretty=%ai`
COMMIT_TIMESTAMP_COMPACT=`git log -1 --date=format:'%Y%m%d-%H%M' --pretty=%cd`
BUILD_TIMESTAMP=`date +"%Y-%m-%d %H:%M %z"`
BUILD_TIMESTAMP_COMPACT=`date +"%Y%m%d-%H%M"`
CONFIGURATION=`sed -n -e 's/BUILD_CONFIG_NAME="\([^"]*\)"/\1/p' ${DIR_NUTTX}/Make.defs`

if [ -z ${CONFIGURATION} ]; then
  CONFIGURATION="Unknown"
fi

# Отладочный вывод. Раскомментировать, если нужен
# echo "GIT_DIRTY=${GIT_DIRTY}"
# echo "branch_raw=${GIT_BRANCH_RAW}"
# echo "branch=${GIT_BRANCH}"
# echo "node=${GIT_NODE}"
# echo "node_short=${GIT_NODE_SHORT}"
# echo "commit_timestamp=${COMMIT_TIMESTAMP}"
# echo "commit_timestamp_compact=${COMMIT_TIMESTAMP_COMPACT}"
# echo "build_timestamp=${BUILD_TIMESTAMP}"
# echo "build_config=${CONFIGURATION}"

echo "Generating version info."
if [ "X${GIT_BRANCH}" = "Xmaster" ]; then
  echo "On master branch. This is release."
  # TODO: В релизной сборке Major/minor числа брать из ближайшего тега.
  # TODO: Следует решить, какой формат тега нужен для этого.
  MAJORMINOR=1.0
  # TODO: В релизной сборке номер билда считать от ближайшего тега или слияния
  # Пока что оставил так же, как и в отладочных билдах - подсчёт коммитов от
  # начала репозитория до текущего.
  BUILD_NUMBER=`git rev-list HEAD --count`
else
  echo "On branch ${GIT_BRANCH}. Development build."
  MAJORMINOR=0.0
  BUILD_NUMBER=`git rev-list HEAD --count`
fi

if [ ! -z "${GIT_DIRTY}" ]; then
  echo "WARNING: working tree is dirty!"
  DIRTY_SUFFIX="+"
  # Поскольку при изменённых исходниках нельзя сказать, отличаются ли
  # прошивки собранные в разное время, то заменим время коммита
  # на время сборки. Так можно будет различить две сборки,
  # собранные в разное время.
  COMMIT_TIMESTAMP=${BUILD_TIMESTAMP}
  COMMIT_TIMESTAMP_COMPACT=${BUILD_TIMESTAMP_COMPACT}
else
  DIRTY_SUFFIX=""
fi


VERSINFO_VERSION_STRING="${MAJORMINOR}.${BUILD_NUMBER}(${GIT_NODE_SHORT})${DIRTY_SUFFIX}__${CONFIGURATION}__${GIT_BRANCH}"
VERSINFO_VERSION_SHORT="${MAJORMINOR}.${BUILD_NUMBER}(${GIT_NODE_SHORT})${DIRTY_SUFFIX}"
VERSINFO_VERSION_TIMESTAMP=${COMMIT_TIMESTAMP}
VERSINFO_BUILD_TIMESTAMP=${BUILD_TIMESTAMP}

# Создание файла
${DIR_NUTTX_TOOLS}/version.sh -v ${MAJORMINOR} -b ${GIT_NODE_SHORT} ${FILE_VERSION}

# Добавление в него своих параметров
echo "VERSINFO_VERSION_STRING=\"${VERSINFO_VERSION_STRING}\"" >>${FILE_VERSION}
echo "VERSINFO_VERSION_SHORT=\"${VERSINFO_VERSION_SHORT}\"" >>${FILE_VERSION}
echo "VERSINFO_VERSION_TIMESTAMP=\"${VERSINFO_VERSION_TIMESTAMP}\"" >>${FILE_VERSION}
echo "VERSINFO_BUILD_TIMESTAMP=\"${VERSINFO_BUILD_TIMESTAMP}\"" >>${FILE_VERSION}
echo "VERSINFO_BUILD_TARGET=\"${CONFIGURATION}\"" >>${FILE_VERSION}
echo "VERSINFO_VERSION_DIR=\"${COMMIT_TIMESTAMP_COMPACT}-${VERSINFO_VERSION_SHORT}\"" >>${FILE_VERSION}
echo "VERSINFO_VERSION_ARCHNAME=\"${COMMIT_TIMESTAMP_COMPACT}-${VERSINFO_VERSION_STRING}\"" >>${FILE_VERSION}

# Отладочный вывод полученного файла - раскомментировать, если нужно
# cat ${FILE_VERSION}

echo "Generated version: ${VERSINFO_VERSION_STRING} (from ${VERSINFO_VERSION_TIMESTAMP}). Build timestamp: ${VERSINFO_BUILD_TIMESTAMP}"
